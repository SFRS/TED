﻿using System;
using System.ComponentModel;

namespace SFR.TOR.Utility
{

    public enum ActivityPartType
    {
        HalfDay = 1,
        FullDay = 2        
    }

    public enum EventPartTypeEnum
    {
        Morning = 1,
        Afternoon = 2,
        FullDay = 3
    }

    public enum ActivityStatus
    {
        Incomplete = 1,
        Complete = 2,
        Obsolete = 3
    }

    public enum EventStatusEnum
    {
        NotReady = 1,
        Ready = 2,
        Scheduled = 3,
        Blocked = 4,
        Complete = 5,
        Cancelled = 6,        
    }

    public enum Trigger
    {        
        AllDatesAdded,
        DateRemoved,
        AllResourcesAdded,
        EventCancelled,
        EventPostponed,
        EventDatePast,
        PartResourced,
        NotResourced,
        TotalActivityDaysReduced,
        TotalActivityDaysIncreased,
        TotalActivityDaysDecreased,
        EventPartDateTypeChanged,
        EventPartAdded,
        EventPartRemoved,
        InstructorRequirementIncreased,
        VenueMinNumberIncreased,
        EquipmentMinNumberIncreased,
        InstructorRequirementDecreased,
        VenueMinNumberDecreased,
        EquipmentMinNumberDecreased,
        EventUploadedToITrent,
        EventFailedToUploadToITrent,
        ITrentExportDeleted,
        ITrentExportCreated,
        EventIdentificationChanged
    }

    public enum ResourceStatus
    {
        [Code("N")]
        NotResourced = 1,
        [Code("P")]
        PartResourced = 2,
        [Code("F")]
        FullyResourced = 3
    }

    public enum DateChoice
    {
        Any = 1,
        Specific = 2,
        Between = 3
    }

    [Flags]
    public enum TORRole
    {
        Invalid = 1,
        User = 1 << 1,
        Editor = 1 << 2,
        Admin = 1 << 3,
    }

    public enum ReportDaysCounted
    {
        [Description("Weekdays only")]
        Weekdays = 1,
        [Description("Weekends only")]
        Weekends = 2,
        [Description("Weekdays and weekends")]
        WeekdaysAndWeekends = 3
    }

    public enum InstructorUnavailableReasonGroups
    {
        NON_WORK_RELATED = 2,
        OTHER_TRAINING_RELATED = 3,
        NON_TRAINING_RELATED = 4,
        EVENING_TRAINING = 5,
    }

    public enum ReportInstructorAvailabilityGroups
    {
        [Description("Daytime Training"), Available(true)]
        DAYTIME_TRAINING = 0,
        [Description("Non-Work Related"), Available(false)]
        NON_WORK_RELATED = 2,
        [Description("Other Training Related"), Available(false)]
        OTHER_TRAINING_RELATED = 3,
        [Description("Non-Training Related"), Available(false)]
        NON_TRAINING_RELATED = 4,
        [Description("Evening Training"), Available(false)]
        EVENING_TRAINING = 5,
        [Description("Free Days"), Available(true)]
        FREE_DAYS = 998,
        [Description("Total Days"), Available(true)]
        TOTAL_DAYS = 999,
    }

    public enum TimePeriods
    {
        [Description("Month")]
        MONTH = 1,
        [Description("Year")]
        YEAR = 2,
    }

    public enum iTrentExportTypeEnum
    {
        [Description("Ready & Cancelled Events")]
        ReadyAndCancelledEvents = 1,
        [Description("Updates to Scheduled Events")]
        UpdatesToScheduledEvents = 2
    }

    public enum iTrentExportStatusEnum
    {
        Pending = 1,
        Uploaded = 2
    }
}
