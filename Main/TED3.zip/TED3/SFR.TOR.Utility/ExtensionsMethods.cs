﻿using System;
using System.Linq;
using System.ComponentModel;
using System.Reflection;
using System.Web.Mvc;
using Trirand.Web.Mvc;
using System.Collections.Generic;
using System.Text;

namespace SFR.TOR.Utility
{
    public static class ExtensionMethods
    {
        public static void SetupDropDownFilterColumn(this JQGrid grid, string columnName, SearchOperation searchOperation, SearchType searchType, SelectList data, bool addAll)
        {
            // setup the grid search criteria for the column
            JQGridColumn col = grid.Columns.Find(c => c.DataField == columnName); 

            // DataType must be set in order to use searching
            col.DataType = typeof(string);
            col.SearchToolBarOperation = searchOperation; 
            col.SearchType = searchType; 

            // Populate the search dropdown only on initial request, in order to optimize performance
            if (grid.AjaxCallBackMode == AjaxCallBackMode.RequestData)
            {
                col.SearchList = data.ToList();

                //if (addAll)
                //{
                    col.SearchList.Insert(0, new SelectListItem { Text = "All", Value = "" });
                //}
                
            }
        }

        public static string GetAttribute<TAttr>(this Enum value, Func<TAttr, string> expr) where TAttr : Attribute
        {
            Type type = value.GetType();
            string name = Enum.GetName(type, value);
            if (name != null)
            {
                FieldInfo field = type.GetField(name);
                if (field != null)
                {
                    TAttr attr =
                           Attribute.GetCustomAttribute(field,
                             typeof(TAttr)) as TAttr;
                    if (attr != null)
                    {
                        return expr(attr);
                    }
                    else
                    {
                        return name;
                    }
                }
            }
            return null;
        }

        public static TRet GetAttribute<TAttr, TRet>(this Enum value, Func<TAttr, TRet> expr, TRet defaultValue = default(TRet)) 
            where TAttr : Attribute 
            where TRet : struct
        {
            Type type = value.GetType();
            string name = Enum.GetName(type, value);
            if (name != null)
            {
                FieldInfo field = type.GetField(name);
                if (field != null)
                {
                    TAttr attr =
                           Attribute.GetCustomAttribute(field,
                             typeof(TAttr)) as TAttr;
                    if (attr != null)
                    {
                        return expr(attr);
                    }
                }
            }
            return defaultValue;
        }

        public static string GetDescription(this Enum value)
        {
            return value.GetAttribute<DescriptionAttribute>(da => da.Description);
        }

        public static string GetCode(this Enum value)
        {
            return value.GetAttribute<CodeAttribute>(ca => ca.Code);
        }

        public static bool GetAvailable(this Enum value)
        {
            return value.GetAttribute<AvailableAttribute, bool>(aa => aa.Available);
        }

        public static bool IsWeekendDate(this DateTime value)
        {
            return value.DayOfWeek == DayOfWeek.Sunday || value.DayOfWeek == DayOfWeek.Saturday;
        }

        public static bool IsWeekendDate(this DateTime? value)
        {
            if (!value.HasValue) return false;
            return value.Value.DayOfWeek == DayOfWeek.Sunday || value.Value.DayOfWeek == DayOfWeek.Saturday;
        }

        public static Dictionary<TKey, TValue> AddFluent<TKey, TValue>(this Dictionary<TKey, TValue> dict, TKey key, TValue value)
        {
            dict.Add(key, value);
            return dict;
        }

        public static string GetFullMessage(this Exception e)
        {
            var sb = new StringBuilder(e.Message);
            var inner = e.InnerException;

            while (inner != null)
            {
                sb.AppendLine(";").Append(inner.Message);
                inner = inner.InnerException;
            }

            return sb.ToString();
        }

        /// <summary>
        /// Converts e.g. 2013 into 2013/14
        /// </summary>
        /// <param name="startYear">The year when the financial year starts</param>
        /// <returns></returns>
        public static string FormatFinancialYear(int startYear)
        {
            return startYear.ToString() + "/" + (startYear + 1).ToString().Substring(2, 2);
        }
    }
}
