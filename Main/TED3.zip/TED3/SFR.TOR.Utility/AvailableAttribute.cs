﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SFR.TOR.Utility
{
    public class AvailableAttribute : Attribute
    {
        public AvailableAttribute(bool available) { this.Available = available; }

        public virtual bool Available { get; protected set; }
    }
}
