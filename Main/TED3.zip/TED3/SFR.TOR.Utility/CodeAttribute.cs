﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SFR.TOR.Utility
{
    public class CodeAttribute : Attribute
    {
        public CodeAttribute(string code) { this.Code = code; }

        public virtual string Code { get; protected set; }
    }
}
