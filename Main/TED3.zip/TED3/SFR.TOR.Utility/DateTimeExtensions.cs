﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Globalization;
using System.Linq;
using System.Text;

namespace SFR.TOR.Utility
{
    // http://dotnetslackers.com/articles/aspnet/5-Helpful-DateTime-Extension-Methods.aspx
    // http://stackoverflow.com/questions/1004698/how-to-truncate-milliseconds-off-of-a-net-datetime
    public static class DateTimeExtensions
    {
        public static DateTime SetTime(this DateTime date, int hour)
        {
            return date.SetTime(hour, 0, 0, 0);
        }
        public static DateTime SetTime(this DateTime date, int hour, int minute)
        {
            return date.SetTime(hour, minute, 0, 0);
        }
        public static DateTime SetTime(this DateTime date, int hour, int minute, int second)
        {
            return date.SetTime(hour, minute, second, 0);
        }
        public static DateTime SetTime(this DateTime date, int hour, int minute, int second, int millisecond)
        {
            return new DateTime(date.Year, date.Month, date.Day, hour, minute, second, millisecond);
        }

        public static DateTime FirstDayOfMonth(this DateTime date)
        {
            return new DateTime(date.Year, date.Month, 1);
        }
        public static DateTime LastDayOfMonth(this DateTime date)
        {
            return new DateTime(date.Year, date.Month, DateTime.DaysInMonth(date.Year, date.Month));
        }

        public static string ToString(this DateTime? date)
        {
            return date.ToString(null, DateTimeFormatInfo.CurrentInfo);
        }
        public static string ToString(this DateTime? date, string format)
        {
            return date.ToString(format, DateTimeFormatInfo.CurrentInfo);
        }
        public static string ToString(this DateTime? date, IFormatProvider provider)
        {
            return date.ToString(null, provider);
        }
        public static string ToString(this DateTime? date, string format, IFormatProvider provider)
        {
            if (date.HasValue)
                return date.Value.ToString(format, provider);
            else
                return string.Empty;
        }

        public static string ToRelativeDateString(this DateTime date)
        {
            return GetRelativeDateValue(date, DateTime.Now);
        }
        public static string ToRelativeDateStringUtc(this DateTime date)
        {
            return GetRelativeDateValue(date, DateTime.UtcNow);
        }
        private static string GetRelativeDateValue(DateTime date, DateTime comparedTo)
        {
            TimeSpan diff = comparedTo.Subtract(date);
            if (diff.TotalDays >= 365)
                return string.Concat("on ", date.ToString("MMMM d, yyyy"));
            if (diff.TotalDays >= 7)
                return string.Concat("on ", date.ToString("MMMM d"));
            else if (diff.TotalDays > 1)
                return string.Format("{0:N0} days ago", diff.TotalDays);
            else if (diff.TotalDays == 1)
                return "yesterday";
            else if (diff.TotalHours >= 2)
                return string.Format("{0:N0} hours ago", diff.TotalHours);
            else if (diff.TotalMinutes >= 60)
                return "more than an hour ago";
            else if (diff.TotalMinutes >= 5)
                return string.Format("{0:N0} minutes ago", diff.TotalMinutes);
            if (diff.TotalMinutes >= 1)
                return "a few minutes ago";
            else
                return "less than a minute ago";
        }

        public static DateTime TrimMilliseconds(this DateTime date)
        {
            return new DateTime(date.Ticks - (date.Ticks % TimeSpan.TicksPerSecond), date.Kind);
        }

        public static double UnixTicks(this DateTime dt)
        {
            DateTime d1 = new DateTime(1970, 1, 1);
            DateTime d2 = dt.ToUniversalTime();
            TimeSpan ts = new TimeSpan(d2.Ticks - d1.Ticks);
            return ts.TotalMilliseconds;
        }

        /// <summary>
        /// Converts the supplied DateTime into UTC. If the supplied DateTime is Unspecified, SpecifyKind is used to
        /// change it to UTC without affecting the time. Otherwise, ToUniversalTime is used to convert the time.
        /// </summary>
        /// <param name="dt">The DateTime to convert</param>
        /// <returns></returns>
        public static DateTime ToUniversalSpecifyKind(this DateTime dt)
        {
            DateTime ret;

            if (dt.Kind == DateTimeKind.Unspecified)
                ret = DateTime.SpecifyKind(dt, DateTimeKind.Utc);
            else
                ret = dt.ToUniversalTime();

            return ret;
        }

        /// <summary>
        /// Converts the supplied DateTime into UTC. If the supplied DateTime is Unspecified, SpecifyKind is used to
        /// change it to UTC without affecting the time. Otherwise, ToUniversalTime is used to convert the time.
        /// </summary>
        /// <param name="dt">The DateTime to convert</param>
        /// <returns></returns>
        public static DateTime? ToUniversalSpecifyKind(this DateTime? dt)
        {
            if (!dt.HasValue)
                return null;

            return dt.Value.ToUniversalSpecifyKind();
        }

        /// <summary>
        /// Converts the supplied DateTime into Local time. If the supplied DateTime is Unspecified, SpecifyKind is used to
        /// change it to Local without affecting the time. Otherwise, ToLocalTime is used to convert the time.
        /// </summary>
        /// <param name="dt">The DateTime to convert</param>
        /// <returns></returns>
        public static DateTime ToLocalSpecifyKind(this DateTime dt)
        {
            DateTime ret;

            if (dt.Kind == DateTimeKind.Unspecified)
                ret = DateTime.SpecifyKind(dt, DateTimeKind.Local);
            else
                ret = dt.ToLocalTime();

            return ret;
        }

        /// <summary>
        /// Converts the supplied DateTime into Local time. If the supplied DateTime is Unspecified, SpecifyKind is used to
        /// change it to Local without affecting the time. Otherwise, ToLocalTime is used to convert the time.
        /// </summary>
        /// <param name="dt">The DateTime to convert</param>
        /// <returns></returns>
        public static DateTime? ToLocalSpecifyKind(this DateTime? dt)
        {
            if (!dt.HasValue)
                return null;

            return dt.Value.ToLocalSpecifyKind();
        }

        // not an extension method but let's put it here anyway
        public static DateTime SqlMinValue()
        {
            return SqlDateTime.MinValue.Value;
        }
    }
}
