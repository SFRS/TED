﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.DirectoryServices.AccountManagement;
using System.Web;

namespace SFR.TOR.Utility.Security
{
    public class TORSession : ITORSession
    {
        private string _UserSession = "UserSession";
        public HttpContextBase HttpContext { get; set; }
        public TORUser User { 
            get
            {
                return GetUser();
            }
            set
            {
                HttpContext.Session[_UserSession] = value;
            }
        }

        public TORSession(HttpContextBase httpContext)
        {
            HttpContext = httpContext;
        }

        private TORUser GetUser()
        {
            return HttpContext.Session[_UserSession] as TORUser
                            ?? GetUserFromActiveDirectory();
        }

        /// <summary>
        /// Gets the users details from AD 
        /// </summary>
        /// <returns></returns>
        private TORUser GetUserFromActiveDirectory()
        {  
            string name = HttpContext.User.Identity.Name;

            int slashPos = name.IndexOf(@"\");
            string domain = name.Substring(0, slashPos);

            UserPrincipal up = UserPrincipal.FindByIdentity(
                new PrincipalContext(ContextType.Domain, domain),
                IdentityType.SamAccountName,
                name);

            if (up == null)
                throw new Exception("Unable to identify your user account.");

            var u = new TORUser()
            {
                FullName = string.Format("{0} {1}", up.GivenName, up.Surname),
                UserName = name
            };

            bool isAdmin = HttpContext.User.IsInRole(ConfigurationManager.AppSettings["AdminGroup"]);
            bool isEditor = HttpContext.User.IsInRole(ConfigurationManager.AppSettings["EditorGroup"]);
            bool isUser = HttpContext.User.IsInRole(ConfigurationManager.AppSettings["UserGroup"]);

            u.TORRole = isAdmin ? TORRole.Admin : isEditor ? TORRole.Editor : isUser ? TORRole.User : TORRole.Invalid;
            
            //store the user details in the session so we do not have to repeatedly query AD
            HttpContext.Session[_UserSession] = u;

            return u;
        }


    }
}