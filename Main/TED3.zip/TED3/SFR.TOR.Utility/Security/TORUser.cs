﻿using System.Collections.Generic;

namespace SFR.TOR.Utility.Security
{
    public class TORUser
    {
        public TORUser()
        {
            WindowsGroups = new List<string>();
        }

        public int ID { get; set; }

        public string FullName { get; set; }

        public List<string> WindowsGroups { get; set; }

        public string UserName { get; set; }

        public int DefaultTrainingCentreID { get; set; }


        public int CurrentTrainingCentreID
        {
            get
            {
                return DefaultTrainingCentreID;
            }
        }

        public int ResourceDisplayTrainingCentreID
        {
            get
            {
                return DefaultTrainingCentreID;
            }
        }

        public string DefaultTrainingCentreName { get; set; }

        public TORRole TORRole { get; set; }

    }
}