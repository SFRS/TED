﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace SFR.TOR.Utility.Security
{
    public interface ITORSession
    {
        HttpContextBase HttpContext { get; set; }
        TORUser User { get; set; }
    }
}
