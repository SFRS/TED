﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SFR.TOR.Utility
{
    public static class Constants
    {
        public const string REPORT_VIEWER_URL = "~/ReportViewer.aspx";
        public const string NOT_APPLICABLE_STRING = "n/a";
        public const int DAY_PARTS_PER_DAY = 2;
        public const string APP_SETTINGS_KEY_REPORT_TIMEOUT_SECS = "ReportTimeoutSecs";

        public const string QUERY_STRING_REPORT_NAME = "ReportName";
        public const string QUERY_STRING_REPORT_FROM_DATE = "FromDate";
        public const string QUERY_STRING_REPORT_TO_DATE = "ToDate";
        public const string QUERY_STRING_REPORT_SELECTED_EVENT_STATUSES = "EventStatus";
        public const string QUERY_STRING_REPORT_SELECTED_INSTRUCTORS = "Instructors";
        public const string QUERY_STRING_REPORT_SELECTED_SECTION = "Section";
        public const string QUERY_STRING_REPORT_SELECTED_DATE = "SelectedDate";
        public const string QUERY_STRING_REPORT_SELECTED_EVENT_RESOURCE_STATUSES = "EventResourceStatus";
        public const string QUERY_STRING_REPORT_TRAINING_CENTRE_ID = "TrainingCentreID";
        public const string QUERY_STRING_REPORT_SELECTED_AVAILABILITY_REASON = "SelectedAvailabilityReason";
        public const string QUERY_STRING_REPORT_EVENING_EVENTS_ONLY = "EveningOnlyEvents";
        public const string QUERY_STRING_REPORT_SELECTED_TIME_PERIOD = "SelectedTimePeriod";
        public const string QUERY_STRING_REPORT_SELECTED_SECTIONS = "SelectedSections";
        public const string QUERY_STRING_REPORT_DAYS_TO_COUNT = "ReportDays";

        public const string REPORT_PARAM_FROM_DATE = "FromDate";
        public const string REPORT_PARAM_TO_DATE = "ToDate";
        public const string REPORT_FILE_PATH = "~/Report";
        public const string REPORT_FILENAME_EXTENSION = "rdl";
        public const string REPORT_DATASET_NAME = "DataSet";
        public const string REPORT_PARAM_TOTAL_DAYS = "TotalDays";
        public const string REPORT_PARAM_TOTAL_WORKING_DAYS = "TotalWorkingDays";
        public const string REPORT_PARAM_SELECTED_AVAILABILITY_ID = "SelectedAvailabilityTypeID";
        public const string REPORT_PARAM_SELECTED_AVAILABILITY_TYPE = "SelectedAvailabilityTypeString";
        public const string REPORT_PARAM_SELECTED_TIME_PERIOD = "SelectedTimePeriod";
        public const string REPORT_PARAM_INSTRUCTOR_ID = "InstructorID";
        public const string REPORT_PARAM_TRAINING_CENTRE_ID = "TrainingCentreID";
        public const string REPORT_PARAM_TRAINING_CENTRE_NAME = "TrainingCentreName";
        public const string REPORT_PARAM_COUNT_WEEKDAYS = "CountWeekdays";
        public const string REPORT_PARAM_COUNT_WEEKENDS = "CountWeekends";
        public const string REPORT_PARAM_SECTION_IDS = "SectionIDs";
        public const string REPORT_PARAM_EVENT_STATUS_IDS = "EventStatusIDs";
        public const string REPORT_PARAM_RESOURCE_STATUS_IDS = "ResourceStatusIDs";
        public const string REPORT_PARAM_SECTION_NAME = "SectionName";
        public const string REPORT_PARAM_NAME_DATE_FORMAT = "DateFormat";
        public const string REPORT_PARAM_TOTAL_INSTRUCTORS = "TotalInstructors";
        public const string REPORT_PARAM_VALUE_DATE_FORMAT_MONTH = "dd MMM";
        public const string REPORT_PARAM_VALUE_DATE_FORMAT_YEAR = "MMM yyyy";
        public const string REPORT_PARAM_NAME_WEELY_OR_MONTHLY      = "WeeklyOrMonthly";
        public const string REPORT_PARAM_VALUE_WEEKLY_PERIOD        = "weekly";
        public const string REPORT_PARAM_VALUE_MONTHLY_PERIOD       = "monthly";

        public const string REPORT_NAME_EVENTS = "EventsByStatus";
        public const string REPORT_NAME_CATERING = "Catering";
        public const string REPORT_NAME_RESOURCE_UTILISATION = "ResourceUtilisation";
        public const string REPORT_NAME_INSTRUCTOR_ASSIGNMENTS = "InstructorAssignments";
        public const string REPORT_NAME_VENUE_CATEGORIES = "VenueCategories";
        public const string REPORT_NAME_EVENTS_BY_VENUE_GROUP = "EventsByVenueGroup";
        public const string REPORT_NAME_TOR_SECTION = "TORSection";
        public const string REPORT_NAME_TOR_SECTION_SIGN_OFF = "TORSectionSignOff";
        public const string REPORT_NAME_INSTRUCTOR_UTILISATION = "InstructorUtilisation";
        //public const string REPORT_NAME_FACILITIES_MANAGEMENT       = "FacilitiesManagement";
        //public const string REPORT_NAME_CARETAKING                  = "Caretaking";
        //public const string REPORT_NAME_FIREGROUND_TECHNICIAN       = "FiregroundTechnician";
        //public const string REPORT_NAME_TRAINING_CENTRE_FACILITIES  = "TrainingCentreFacilities";
        //public const string REPORT_NAME_RECEPTION_DESK              = "ReceptionDesk";

        public const string REGEX_UK_DATE_FORMAT = @"^(?:(?:(?:(?:31\/(?:0?[13578]|1[02]))|(?:(?:29|30)\/(?:0?[13-9]|1[0-2])))\/(?:1[6-9]|[2-9]\d)\d{2})|(?:29\/0?2\/(?:(?:(1[6-9]|[2-9]\d)(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))|(?:0?[1-9]|1\d|2[0-8])\/(?:(?:0?[1-9])|(?:1[0-2]))\/(?:(?:1[6-9]|[2-9]\d)\d{2}))$";
        // matches dd/MM/yyyy format
        // matches d/M/yyyy   format

        public const string AM_STRING = "AM";
        public const string PM_STRING = "PM";
        public const string EVE_STRING = "EVE";

        public const string UNCATEGORISED_STRING = "&#60;Uncategorised&#62";
        public const string REPORT_UNCATEGORISED_STRING = "<Uncategorised>";
        public const string EVENING_TRAINING_STRING = "Evening";
        public const string DAY_TRAINING_STRING = "Day";

        // Admin jqGrid Validation Messages
        public const string GRID_GROUP_ITEM_ALREADY_EXISTS_ERROR                            = "A group with this name already exists.";
        public const string GRID_GROUP_UNABLE_TO_DELETE_ERROR                               = "This group has equipment assigned to it. Remove the assigned equipment and try again.";

        public const string GRID_GROUP_UNABLE_TO_DELETE_UNEDITABLE_GROUP_ERROR              = "This group can not be edited as it must remain as is, for use with reporting.";

        public const string GRID_PINCHPOINT_REASON_ITEM_ALREADY_EXISTS_ERROR                = "A pinch point reason with this name already exists";
        public const string GRID_PINCHPOINT_REASON_UNABLE_TO_DELETE_ERROR                   = "This pinchpoint reason has pinchpoints assigned to it. Remove the pinchpoint assignments and try again.";

        public const string GRID_VENUE_CATEGORY_ITEM_ALREADY_EXISTS_ERROR                   = "A venue category with this name already exists";
        public const string GRID_VENUE_CATEGORY_UNABLE_TO_DELETE                            = "This venue category has venues assigned to it. Remove the venues from the venue category and try again.";

        public const string GRID_EQUIPMENT_CATEGORY_ITEM_ALREADY_EXISTS_ERROR               = "An equipment category with this name already exists";
        public const string GRID_EQUIPMENT_CATEGORY_UNABLE_TO_DELETE_ERROR                  = "This equipment category has equipment assigned to it. Remove the equipment from this category and try again";

        public const string GRID_INSTRUCTOR_AVAILABILITY_REASON_ITEM_ALREADY_EXISTS_ERROR   = "An instructor availability reason with this name already exists.";
        public const string GRID_INSTRUCTOR_AVAILABLE_REASON_UNABLE_TO_DELETE_ERROR         = "This availability reason has instructors asigned to it. Please remove the instructors and try again.";

        public const string GRID_VENUE_AVAILABILITY_ITEM_ALREADY_EXISTS_ERROR               = "A venue availability reason with this name already exists.";
        public const string GRID_VENUE_UNAVAILABLE_UNABLE_TO_DELETE_ERROR                   = "A venue has been assigned this availability reason. Remove the venue's assignment and try again.";

        public const string GRID_EQUIPMENT_AVAILABILITY_ITEM_ALREADY_EXISTS_ERROR           = "An availability reason with this name already exists.";
        public const string GRID_EQUIPMENT_AVAILABILITY_REASON_UNABLE_TO_DELETE_ERROR       = "Equipment has been assigned this availability reason. Remove the equipment assignment and try again.";

        public const string GRID_VENUE_GROUP_ITEM_ALREADY_EXISTS_ERROR                      = "A venue group with this name already exists.";
        public const string GRID_VENUE_GROUP_UNABLE_TO_DELETE_ERROR                         = "Venues were found to be assigned to this group. Please remove the venue assignment and try again.";

        public const string GRID_INSTRUCTOR_UNAVAILABLE_REASONS_ITEM_ALREADY_EXISTS_ERROR   = "An instructor unavailable reason with this name already exists.";
        public const string GRID_INSTRUCTOR_UNAVAILABLE_REASON_UNABLE_TO_DELETE_ERROR       = "An instructor unavailable reason has been assigned to this group. Please remove the instructor unavailable reason assignment and try again.";

        public const string EVENT_PART_INVALID_DATE_TIME                                    = "* This event part conflicts with another";
        public const string EVENT_PART_INVALID_START_TIME_END_TIME                          = "* Invalid Time: End Time cannot be before Start Time";

        public const string GRID_SECTION_UNABLE_TO_DELETE_ERROR                             = "This section has either instructors, events or activities assigned to it. Remove the assigned items and try again.";

        public const string GRID_INSTRUCTOR_GROUP_UNABLE_TO_DELETE_ERROR                    = "This group has instructors assigned to it. Remove the assigned instructors and try again.";

        public const string GRID_GROUP_TRAINING_CENTRE_ALREADY_EXISTS_ERROR                 = "A training centre with this name already exists.";
        public const string GRID_GROUP_TRAINING_CENTRE_UNABLE_TO_DELETE                     = "This training centre has either instructors, equipment, venues, pinchpoints or group calendar entries assigned to it. Remove the assigned items and try again.";

        public const string GRID_INSTRUCTOR_AVAILABILITY_EVENING_TRAINING_PERIOD_ERROR      = "'Period' must be 'Full Day' when 'Reason' relates to evening training";
        public const string GRID_INSTRUCTOR_AVAILABILITY_INVALID_DAY_TYPE_ERROR             = "'Period' must be set to 'Full Day' when 'Start Date' is not equal to 'End Date'.";

        public const string GRID_OBJECT_AVAILABILITY_START_DATE_EARLIER_THAN_END_DATE_ERROR = "Start date must be earlier than end date.";
        public const string GRID_INSTRUCTOR_AVAILABILITY_CONFLICTING_DATES_ERROR            = "The selected dates conflict with another availability period.";
        public const string GRID_EVENT_INSTRUCTOR_UNAVAILABILITY_PERIOD_EXISTS              = "The instructor is unavailable for booking on this date and time.";

        public const string GRID_EQUIPMENT_AVAILABILITY_INVALID_DAY_TYPE_ERROR              = "'Period' must be set to 'Full Day' when 'Start Date' is not equal to 'End Date'.";
        public const string GRID_VENUES_AVAILABILITY_INVALID_DAY_TYPE_ERROR                 = "'Period' must be set to 'Full Day' when 'Start Date' is not equal to 'End Date'.";
 		public const string ITEM_ALREADY_ASSIGNED_ERROR_WITH_URL_LINK 						= "<span class='resourceErrorDialogItemName'>{0}</span> is currently assigned to <a class='resourceErrorDialogURL' href='{1}' target='_blank'>{2}</a>. If you wish to unallocate this resource, please click the underlined link above to view the conflicting event.";

        public const string GRID_EVENT_VENUE_UNAVAILABILITY_PERIOD_EXISTS                   = "The venue is unavailable for booking on this date and time.";
        public const string GRID_EVENT_EQUIPMENT_UNAVAILABILITY_PERIOD_EXISTS               = "The equipment is unavailable for booking on this date and time.";

        public const int INSTRUCTOR_AVAILABILITY_FREE_DAYS_ID = 998;
        public const string INSTRUCTOR_AVAILABILITY_FREE_DAYS_DESC = "Free Days";

        public const int INSTRUCTOR_AVAILABILITY_DAYTIME_TRAINING_ID = 0;
        public const string INSTRUCTOR_AVAILABILITY_DAYTIME_TRAINING_DESC = "Daytime Training";

        public const int AVAILABILITY_GROUP_NON_WORK_RELATED_ID = 2;
        public const int AVAILABILITY_GROUP_EVENING_TRAINING_ID = 5;

        public static string ACTIVITY_TITLE_ILLEGAL_CHARACTER_ERROR = "Quotes are not allowed. Please use an apostrophe instead";

        public const string SPROC_REPORT_RESOURCE_UTILISATION = "ReportResourceUtilisation";
        public const string SPROC_REPORT_INSTRUCTOR_UTILISATION = "ReportInstructorUtilisation";
        public const string SPROC_REPORT_SECTION_EVENTS = "ReportSectionEvents";
        public const string SPROC_REPORT_SECTION_SIGNOFF = "ReportSectionSignOff";
        public const string SPROC_REPORT_EVENTS_BY_STATUS = "ReportEventsByStatus";
        public const string SPROC_REPORT_EVENTS_BY_VENUE_CATEGORIES = "ReportEventsByVenueCategories";
        public const string SPROC_REPORT_VENUE_CATEGORIES = "ReportVenueCategories";
        public const string SPROC_REPORT_CATERING = "ReportCatering";
        public const string SPROC_REPORT_INSTRUCTOR_ASSIGNMENTS = "ReportInstructorAssignments";
        public const string SPROC_PARAM_FROM = "from";
        public const string SPROC_PARAM_TO = "to";
        public const string SPROC_PARAM_TRAINING_CENTRE_ID = "TrainingCentreID";
        public const string SPROC_PARAM_INSTRUCTOR_ID = "InstructorID";
        public const string SPROC_PARAM_AVAILABILITY_GROUP_ID = "AvailabilityGroupID";
        public const string SPROC_PARAM_TIME_PERIOD = "timePeriod";
        public const string SPROC_PARAM_SECTION_IDS = "SectionIDs";
        public const string SPROC_PARAM_EVENT_STATUS_IDS = "EventStatusIDs";
        public const string SPROC_PARAM_RESOURCE_STATUS_IDS = "ResourceStatusIDs";
        public const string SPROC_PARAM_COUNT_WEEKDAYS = "countWeekdays";
        public const string SPROC_PARAM_COUNT_WEEKENDS = "countWeekends";

        public const string ITRENT_UPLOAD_RADIO_BUTTON_READY_AND_CANCELLED                  = "readyCancelled";
        public const string ITRENT_UPLOAD_RADIO_BUTTON_SCHEDULED_AND_UPDATED                = "scheduledUpdated";
        public const string ITRENT_UPLOAD_RADIO_BUTTON_ALL_READY__AND_SCHEDULED             = "allReadyScheduled";

        public const string ITRENT_UPLOAD_DATE_FORMAT = "yyyyMMdd";
        public const string ITRENT_UPLOAD_AM_START_TIME  = "0900";
        public const string ITRENT_UPLOAD_AM_END_TIME    = "1300";
        public const string ITRENT_UPLOAD_PM_START_TIME  = "1301";
        public const string ITRENT_UPLOAD_PM_END_TIME    = "1700";
        public const int    ITRENT_UPLOAD_ACTIVITY_TITLE_MAX_LENGTH = 100;
        public const int    ITRENT_UPLOAD_EVENT_CANCEL_REASON_MAX_LENGTH = 80;
        public const string EXCEL_TEXT_FORMAT_STRING = "@";
        public const string EXCEL_MIME_TYPE = "application/vnd.ms-excel";
        public const string EXCEL_FILE_EXTENSION = "xlsx";

        public const string ITRENT_UPLOAD_STATUS_CANCELLED = "CANCELLED";

        public const string INSTRUCTOR_INACTIVE_SECTION_NAME = "*INACTIVE";
        public const int INSTRUCTOR_INACTIVE_SECTION_ID = -1;

        public const string RESOURCE_AVAILABILITY_AVAILABLE = "Available";
        public const string RESOURCE_AVAILABILITY_STATUS_UNAVAILABLE = "Unavailable";
        public const string RESOURCE_AVAILABILITY_STATUS_LIMITED = "Limited";

        public const string GRID_INSTRUCTOR_SECTION_HISTORY_OVERLAPPING_DATES_ERROR         = "The chosen dates overlap with another section history record.";
        public const string GRID_INSTRUCTOR_SECTION_HISTORY_GAP_OVERLAPS_EVENTS_ERROR = "You are leaving a gap in the section history, but the instructor has Events in this period.";
        public const string GRID_INSTRUCTOR_SECTION_HISTORY_GAP_OVERLAPS_PERIODS_ERROR = "You are leaving a gap in the section history, but the instructor has Availability records in this period.";
        public const string GRID_INSTRUCTOR_SECTION_HISTORY_CANNOT_DELETE_LAST_RECORD_ERROR = "The instructor must have at least one section history record.";
        public const string GRID_INSTRUCTOR_SECTION_HISTORY_CANNOT_UPDATE_CURRENT_SECTION_ERROR = "The instructor's current section can only be changed in the Edit screen.";
        public const string GRID_INSTRUCTOR_SECTION_HISTORY_CANNOT_MAKE_INACTIVE_ERROR = "The instructor can only be made inactive in the Edit screen.";
        public const string GRID_INSTRUCTOR_SECTION_HISTORY_FUTURE_START_DATE_ERROR = "The Start Date must not be later than today.";
        public const string GRID_INSTRUCTOR_SECTION_HISTORY_FUTURE_END_DATE_ERROR = "The End Date must not be later than yesterday.";

        public const string GRID_ACTIVITY_PART_IN_USE_DELETE_ERROR = "Past events exist that use this activity part, so it may not be deleted.";

        public const string CANNOT_DELETE_INSTRUCTOR_WITH_EVENTS = "The instructor cannot be deleted as they are assigned to events.";
    }
}
