﻿using System;

namespace SFR.TOR.Utility
{
    public class UnauthorisedException : Exception
    {
        public UnauthorisedException(Exception ex = null) : base(ExceptionData.UnauthorisedException, ex) { }
    }

    public class UnauthenticatedException : Exception
    {
        public UnauthenticatedException(Exception ex = null) : base(ExceptionData.UnauthorisedException, ex) { }      
    }    
}
