﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using Microsoft.Practices.Unity;
using SFR.TOR.Web.Extensions;

namespace SFR.TOR.Web.Unity
{
    public class UnityDependencyResolver : IDependencyResolver
    {    
        #region Members        
        private IUnityContainer _container;            
        #endregion        
        #region Ctor        
        public UnityDependencyResolver(IUnityContainer container)
        {
            _container = container;
        }    
    
        #endregion        
        #region IDependencyResolver Members        
        
        public object GetService(Type serviceType)   
        {      
            try
            {
                // Use the per-request child container to resolve types
                return this.GetChildContainer().Resolve(serviceType);
            }
            catch (Exception ex)
            {
                return null;
            }
        }        
        
        public IEnumerable<object> GetServices(Type serviceType)
        {
            try      
            {
                // Use the per-request child container to resolve types
                return this.GetChildContainer().ResolveAll(serviceType);
            }
            catch (Exception ex)
            {
                return new List<object>();
            }
        }

        #endregion
    }
}
