using Cassette.Configuration;
using Cassette.Scripts;
using Cassette.Stylesheets;
using System.IO;

namespace SFR.TOR
{
    /// <summary>
    /// Configures the Cassette asset modules for the web application.
    /// </summary>
    public class CassetteConfiguration : ICassetteConfiguration
    {
        public void Configure(BundleCollection bundles, CassetteSettings settings)
        {
            // TODO: Configure your bundles here...
            // Please read http://getcassette.net/documentation/configuration

            // Create a bundle for each subdirectory under Content/css that contains css and less files.
            // Each bundle will provide a combined minified file to the browser when not debugging.
            //bundles.AddPerSubDirectory<StylesheetBundle>("~/Content/css");
            // Replaced the above line of code with the following code to set up StylesheetBundles.
            // Cassette should respect bundle.txt in the bootstrap folder and only process bootstrap.less and
            // responsive.less. When site.less references the overall bootstrap folder, however, Cassette processes
            // every file. This causes an error, as it processes accordion.less before variables.less, etc.
            // See https://groups.google.com/forum/#!msg/cassette/4vdVp9ZyNU4/So1nTHpdaFwJ
            var files = new[] { "~/Content/css/bootstrap/bootstrap.less", "~/Content/css/bootstrap/responsive.less" };

            bundles.Add<StylesheetBundle>("~/Content/css/bootstrap", files);

            bundles.Add<StylesheetBundle>("~/Content/css/select2");

            bundles.Add<StylesheetBundle>(
                "~/Content/css",
                new FileSearch { SearchOption = System.IO.SearchOption.TopDirectoryOnly });

            // Create a bundle for each subdirectory under Content/js that contains js files.
            // Each bundle will provide a combined minified file to the browser when not debugging.
            //bundles.AddPerSubDirectory<ScriptBundle>("~/Content/js");

            // Could not make AddPerSubDirectory work as expected. The bootstrap scripts depend on jquery, this
            // dependency is defined in bundle.text in the bootstrap folder but Cassette still loaded bootstrap
            // scripts first. We resolve this by explicitly creating separate bundles and adding the reference here.
            // The method also seemed to be unpredictable in how it traversed the folder structure; when starting at
            // Content/js it would create a bundle for head but not for libs or its children.
            bundles.Add<ScriptBundle>("~/Content/js/libs/jquery");
            bundles.Add<ScriptBundle>("~/Content/js/libs/bootstrap", bundle => bundle.AddReference("~/Content/js/libs/jquery"));
            bundles.Add<ScriptBundle>("~/Content/js/head");
            bundles.Add<ScriptBundle>("~/Content/js", new FileSearch { SearchOption = SearchOption.TopDirectoryOnly });

            bundles.Add<ScriptBundle>("~/Content/js/libs/jquery.jqGrid", bundle => bundle.AddReference("~/Content/js/libs/jquery"));
            bundles.Add<ScriptBundle>("~/Content/js/libs/jquery.spinner", bundle => bundle.AddReference("~/Content/js/libs/jquery"));
            bundles.Add<ScriptBundle>("~/Content/js/libs/jquery.UI", bundle => bundle.AddReference("~/Content/js/libs/jquery"));

            bundles.Add<ScriptBundle>("~/Content/js/libs/jquery.ui.timepicker", bundle => bundle.AddReference("~/Content/js/libs/jquery"));

            bundles.Add<ScriptBundle>("~/Content/js/libs/jquery.qtip", bundle => bundle.AddReference("~/Content/js/libs/jquery"));

            bundles.Add<ScriptBundle>("~/Content/js/libs/date.js", bundle => bundle.AddReference("~/Content/js/libs/jquery"));

            bundles.Add<ScriptBundle>("~/Content/js/libs/unload", bundle => bundle.AddReference("~/Content/js/libs/jquery"));

            bundles.Add<ScriptBundle>("~/Content/js/libs/jquery.blockUI", bundle => bundle.AddReference("~/Content/js/libs/jquery"));

            bundles.Add<ScriptBundle>("~/Content/js/libs/knockout", bundle => bundle.AddReference("~/Content/js/libs/jquery"));

            bundles.Add<ScriptBundle>("~/Content/js/libs/select2", bundle => bundle.AddReference("~/Content/js/libs/jquery"));

            // *** TOP TIP: Delete all ".min.js" files now ***
            // Cassette minifies scripts for you. So those files are never used.
        }
    }
}