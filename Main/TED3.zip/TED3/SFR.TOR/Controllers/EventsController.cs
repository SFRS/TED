﻿using System;
using System.Collections.Generic;
using System.Data.Objects.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Web.Mvc;
using AutoMapper;
using IronRuby.Compiler;
using LinqKit;
using Microsoft.Scripting.Utils;
using SFR.TOR.Data;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.Utility;
using SFR.TOR.ViewModels;
using SFR.TOR.Web.Filters;
using Trirand.Web.Mvc;
using EventPartType = SFR.TOR.Utility.EventPartTypeEnum;

namespace SFR.TOR.Web.Controllers
{
    [TORUserAuthorisation]
    public partial class EventsController : BaseController
    {
        public EventsController(ITORUnitOfWork unitOfWork)
            : base(unitOfWork)
        {
        }

        public virtual ActionResult Index(string searchTerms, bool? searchClicked, string[] selectedTrainingCentres)
        {

            if (searchClicked != null)
            {
                ViewBag.SearchClicked = searchClicked;
            }

            var trainingCentres = selectedTrainingCentres != null ? String.Join(",", selectedTrainingCentres) : null;

            //Search on default training centre if not a search clicked
            if (trainingCentres == null && searchClicked == null)
            {
                trainingCentres = TORUser.DefaultTrainingCentreID.ToString();
                selectedTrainingCentres = trainingCentres.Split(',');
            }

            var am = new EventsModel(Url.Action(MVC.Events.GetEventsData(searchTerms, trainingCentres)),
             GetSectionDataForFilter(), GetPriorityDataForFilter(), GetResourceStatusDataForFilter(),
             GetStatusDataForFilter(), GetFinancialYearDataForFilter(),
             GetTrainingCentresForFilters())
            {
                SelectedTrainingCentres = selectedTrainingCentres
            };


            ViewBag.HasWriteAccess = (TORUser.TORRole > TORRole.User);
            ViewBag.HasAdminAccess = (TORUser.TORRole == TORRole.Admin);

            return View(am);
        }


        public virtual JsonResult GetEventsData(string searchTerms, string selectedTrainingCentres)
        {
            var gridModel = new EventsModel(Url.Action(MVC.Events.GetEventsData(searchTerms, selectedTrainingCentres)),
                GetSectionDataForFilter(), GetPriorityDataForFilter(), GetResourceStatusDataForFilter(),
                GetStatusDataForFilter(), GetFinancialYearDataForFilter(), GetTrainingCentresForFilters());

            Expression<Func<Event, bool>> searchPredicate = null;
            Expression<Func<Event, bool>> predicate = PredicateBuilder.False<Event>();
            if (!string.IsNullOrEmpty(searchTerms))
            {
                searchPredicate = PredicateBuilder.False<Event>();
                searchPredicate = searchPredicate.Or(p => p.Description.Contains(searchTerms));
                searchPredicate = searchPredicate.Or(p => p.Activity.Title.Contains(searchTerms));
                searchPredicate = searchPredicate.Or(p => (p.Activity.Code + " "
                                + SqlFunctions.StringConvert((decimal)p.EventNumber).TrimStart() + "/"
                                + SqlFunctions.StringConvert((decimal)p.FinanciaYear).TrimStart().Substring(2, 2)).Contains(searchTerms));
                searchPredicate = searchPredicate.Or(p => p.Activity.Section.Title.Contains(searchTerms));
                searchPredicate = searchPredicate.Or(p => SqlFunctions.StringConvert((decimal)p.FinanciaYear).Contains(searchTerms));
            }

            if (string.IsNullOrWhiteSpace(selectedTrainingCentres))
            {
                selectedTrainingCentres = string.Join(",", GetTrainingCentresForFilters().Select(tc => tc.Value));
            }

            foreach (var selectedTrainingCentre in selectedTrainingCentres.Split(','))
            {
                if (predicate == null)
                    predicate = PredicateBuilder.False<Event>();

                int tcId;
                if (Int32.TryParse(selectedTrainingCentre, out tcId))
                {
                    predicate = predicate.Or(p => p.TrainingCentreID == tcId);
                }
            }


            if (searchPredicate != null)
                predicate = predicate.And(searchPredicate.Expand());


            var eventsList = UnitOfWork.Events.GetEvents(predicate);

            return gridModel.Events.DataBind(eventsList);
        }

        //
        // GET: /Activities/Edit/5
        public virtual ActionResult Edit(int id)
        {
            var e = UnitOfWork.Events.GetEvent(x => x.ID == id);
            var eem = new EventEditModel();

            // Mapper should ensure LastEditedOn is converted to UTC
            Mapper.Map(e, eem);

            ViewBag.IsEventCancelled = (e.StatusID == (int)EventStatusEnum.Cancelled);

            eem.Priorities = GetPriorityData();

            SelectList statusData = GetStatusDataForManualEdit((EventStatusEnum)e.StatusID);

            ViewBag.IsEventCancelled = (e.StatusID == (int)EventStatusEnum.Cancelled);

            eem.StatusData = statusData;

            return View(eem);
        }



        [HttpPost, AjaxResult]
        [TOREditAuthorise]
        public virtual ActionResult Edit(EventEditModel model)
        {
            var e = UnitOfWork.Events.SelectBy(x => x.ID == model.ID);

            // If the status has been manually changed, call UpdateStatus to process this.
            if (e.Status != model.StatusID)
            {
                UnitOfWork.Events.UpdateStatus(e.ID, null, TORUser.FullName, model.StatusID);
            }

            // Mapper should ensure LastEditedOn is converted to UTC
            Mapper.Map(model, e);

            // Pass the same Event object to provide original values for the context. The Event has been assigned the 
            // LastEditedOn value from the client, so by applying that as an original value it will be used for concurrency 
            // checking at commit time. The new LastEditedOn value will be set automatically by the context.
            UnitOfWork.Events.Update(e, e);
            UnitOfWork.Commit();

            model.Priorities = GetPriorityData();
            model.StatusData = GetStatusDataForManualEdit((EventStatusEnum)e.Status);

            var ev = UnitOfWork.Events.GetEvent(x => x.ID == model.ID);
            Mapper.Map(ev, model);

            return View(model);
        }

        public virtual JsonResult GetStatusDataJson(int status)
        {
            var statusData = GetStatusDataForManualEdit((EventStatusEnum)status).Select(x => new { x.Text, x.Value }).ToList();

            return Json(statusData, JsonRequestBehavior.AllowGet);
        }

        [TOREditAuthorise]
        public virtual ActionResult CopyInstructorResources(int fromEventPartID, int SelectedEventPartID)
        {
            var instructorsToCopy = UnitOfWork.InstructorEventPart.SelectFilteredList(x => x.DayPartID == fromEventPartID);


            if (instructorsToCopy != null)
            {
                //get source event part
                var sourceEP = UnitOfWork.EventParts.SelectBy(x => x.ID == fromEventPartID);

                //get the eligible instructors for the source event part
                var sourceInstructors = UnitOfWork.EventPartResources.
                                                    GetInstructorsAvailabilityByDate(sourceEP.Date,
                                                                                    sourceEP.DayType.Value,
                                                                                    sourceEP.Event.ActivityID.Value,
                                                                                    fromEventPartID,
                                                                                    new int[] { })
                                                                                    .ToList()
                                                                                    .Where(x => !x.Free.GetValueOrDefault() && x.EventName.EndsWith("(this event)")).Select(y => y).ToList();

                //get target event part and its eligible instructor list
                var targetEP = UnitOfWork.EventParts.SelectBy(x => x.ID == SelectedEventPartID);
                var targetInstructorIDs = UnitOfWork.EventPartResources.
                                                    GetInstructorsAvailabilityByDate(targetEP.Date,
                                                                                    targetEP.DayType.Value,
                                                                                    targetEP.Event.ActivityID.Value,
                                                                                    SelectedEventPartID,
                                                                                    new int[] { })
                                                                                    .ToList()
                                                                                    .Where(x => x.Free.GetValueOrDefault()).Select(y => y.ID).ToList();

                if (targetInstructorIDs.Count == 0)
                {
                    return Content("No resources free for that period", "text/html");
                }

                int count = 0;
                foreach (var sourceInstructor in sourceInstructors)
                {
                    if (targetInstructorIDs.Contains(sourceInstructor.ID))
                    {
                        //add to target event part
                        var instructorEventPart = new InstructorEventPart()
                            {
                                DayPartID = SelectedEventPartID,
                                InstructorID = sourceInstructor.ID,
                                IsLead = sourceInstructor.SelectedLead.GetValueOrDefault(),
                                IsAssessor = sourceInstructor.SelectedAssessor.GetValueOrDefault(),
                                IsInstructor = sourceInstructor.SelectedInstructor.GetValueOrDefault(),
                                IsShadow = sourceInstructor.SelectedShadow.GetValueOrDefault(),
                                IsSpecialist = sourceInstructor.SelectedSpecialist.GetValueOrDefault()
                            };

                        UnitOfWork.InstructorEventPart.Insert(instructorEventPart);

                        count++;
                    }
                }

                UnitOfWork.Commit();

                //update the event parts resourcing
                UnitOfWork.EventParts.ResetResourceStatus(SelectedEventPartID);
                UnitOfWork.Commit();

                //update the events resourcing
                var ep = UnitOfWork.EventParts.SelectFilteredList(x => x.ID == SelectedEventPartID).First();
                UnitOfWork.Events.ResetResourceStatus(ep.EventID, TORUser.FullName);
                UnitOfWork.Commit();

                string message = string.Format("{0} resources copied", count);

                message = count == sourceInstructors.Count ?
                                        string.Format("{0}.", message) :
                                        string.Format("{0}, {1} unavailable.", message, sourceInstructors.Count() - count);

                return Content(message, "text/html");
            }

            return Content("No resources to copy", "text/html");
        }

        [TOREditAuthorise]
        public virtual ActionResult CopyVenueResources(int fromEventPartID, int SelectedEventPartID)
        {
            //all venues that are included in the activity template
            var venuesToCopy = UnitOfWork.VenueEventParts.SelectFilteredList(x => x.DayPartID == fromEventPartID && x.VenueTagID.HasValue);

            if (venuesToCopy != null)
            {
                //get source event part
                var sourceEP = UnitOfWork.EventParts.SelectBy(x => x.ID == fromEventPartID);

                //get all venue tags for the source event part based on its parent ActivityPart
                var sourceTags = UnitOfWork.VenueTagActivityPart.SelectFilteredList(x => x.ActivityPartID == sourceEP.ActivityPartID);
                var sourceTagIDs = sourceTags.Select(x => x.VenueTagID).ToList();

                //get the selected venues for the source event part
                var sourceVenues = UnitOfWork.EventPartResources.
                                                    GetVenuesAvailabilityByDate(sourceEP, sourceTagIDs, new int[] { }, false) //false = exclude additional venues that are not part of the activity template
                                                    .ToList()
                                                    .Where(x => !x.Free.GetValueOrDefault() && x.EventName.EndsWith("(this event)"))
                                                    .Select(y => y).ToList();

                //get target event part and its eligible instructor list
                var targetEP = UnitOfWork.EventParts.SelectBy(x => x.ID == SelectedEventPartID);

                //get all venue tags for the target event part based on its parent ActivityPart
                var targetTags = UnitOfWork.VenueTagActivityPart.SelectFilteredList(x => x.ActivityPartID == targetEP.ActivityPartID);
                var targetTagIDs = targetTags.Select(x => x.VenueTagID).ToList();

                var targetVenueIDs = UnitOfWork.EventPartResources.
                                                    GetVenuesAvailabilityByDate(targetEP, targetTagIDs, new int[] { })
                                                    .ToList()
                                                    .Where(x => x.Free.GetValueOrDefault())
                                                    .Select(y => y.ID).ToList();

                if (targetVenueIDs.Count == 0)
                {
                    return Content("No venues free for that period", "text/html");
                }

                int count = 0;
                foreach (var sourceVenue in sourceVenues)
                {
                    if (targetVenueIDs.Contains(sourceVenue.ID))
                    {
                        //add to target event part
                        var venueEventPart = new VenueEventPart()
                        {
                            DayPartID = SelectedEventPartID,
                            VenueID = sourceVenue.ID,
                            VenueTagID = sourceVenue.VenueTagID.GetValueOrDefault()
                        };

                        UnitOfWork.VenueEventParts.Insert(venueEventPart);

                        count++;
                    }
                }

                UnitOfWork.Commit();

                //update the event parts resourcing
                UnitOfWork.EventParts.ResetResourceStatus(SelectedEventPartID);
                UnitOfWork.Commit();

                //update the events resourcing
                var ep = UnitOfWork.EventParts.SelectFilteredList(x => x.ID == SelectedEventPartID).First();
                UnitOfWork.Events.ResetResourceStatus(ep.EventID, TORUser.FullName);
                UnitOfWork.Commit();

                string message = string.Format("{0} resources copied", count);

                message = count == sourceVenues.Count ?
                                        string.Format("{0}.", message) :
                                        string.Format("{0}, {1} unavailable or invalid.", message, sourceVenues.Count() - count);

                return Content(message, "text/html");
            }

            return Content("No resources to copy", "text/html");
        }

        [TOREditAuthorise]
        public virtual ActionResult CopyEquipmentResources(int fromEventPartID, int SelectedEventPartID)
        {
            var equipmentToCopy = UnitOfWork.EquipmentEventParts.SelectFilteredList(x => x.DayPartID == fromEventPartID);

            if (equipmentToCopy != null)
            {
                //get source event part
                var sourceEP = UnitOfWork.EventParts.SelectBy(x => x.ID == fromEventPartID);

                //get all venue tags for the source event part based on its parent ActivityPart
                var sourceTags = UnitOfWork.EquipmentTagActivityPart.SelectFilteredList(x => x.ActivityPartID == sourceEP.ActivityPartID);
                var sourceTagIDs = sourceTags.Select(x => x.EquipmentTagID).ToList();

                //get the selected venues for the source event part
                var sourceEquipment = UnitOfWork.EventPartResources.
                                                    GetEquipmentAvailabilityByDate(sourceEP, sourceTagIDs, new int[] {}, false) //false = exclude additional venues that are not part of the activity template
                                                    .ToList()
                                                    .Where(x => !x.Free.GetValueOrDefault() && x.EventName.EndsWith("(this event)"))
                                                    .Select(y => y).ToList();

                //get target event part and its eligible instructor list
                var targetEP = UnitOfWork.EventParts.SelectBy(x => x.ID == SelectedEventPartID);

                //get all venue tags for the target event part based on its parent ActivityPart
                var targetTags = UnitOfWork.EquipmentTagActivityPart.SelectFilteredList(x => x.ActivityPartID == targetEP.ActivityPartID);
                var targetTagIDs = targetTags.Select(x => x.EquipmentTagID).ToList();

                var targetEquipmentIDs = UnitOfWork.EventPartResources.
                                                    GetEquipmentAvailabilityByDate(targetEP, targetTagIDs, new int[] { }, false)
                                                    .ToList()
                                                    .Where(x => x.Free.GetValueOrDefault())
                                                    .Select(y => y.ID).ToList();

                if (targetEquipmentIDs.Count == 0)
                {
                    return Content("No Equipment free for that period", "text/html");
                }

                int count = 0;
                foreach (var equipment in sourceEquipment)
                {
                    if (targetEquipmentIDs.Contains(equipment.ID))
                    {
                        //add to target event part
                        var equipmentEventPart = new EquipmentEventPart()
                        {
                            DayPartID = SelectedEventPartID,
                            EquipmentID = equipment.ID,
                            EquipmentTagID = equipment.EquipmentTagID
                        };

                        UnitOfWork.EquipmentEventParts.Insert(equipmentEventPart);

                        count++;
                    }
                }

                UnitOfWork.Commit();

                //update the event parts resourcing
                UnitOfWork.EventParts.ResetResourceStatus(SelectedEventPartID);
                UnitOfWork.Commit();

                //update the events resourcing
                var ep = UnitOfWork.EventParts.SelectFilteredList(x => x.ID == SelectedEventPartID).First();
                UnitOfWork.Events.ResetResourceStatus(ep.EventID, TORUser.FullName);
                UnitOfWork.Commit();

                string message = string.Format("{0} resources copied", count);

                message = count == sourceEquipment.Count ?
                                        string.Format("{0}.", message) :
                                        string.Format("{0}, {1} unavailable or invalid.", message, sourceEquipment.Count() - count);

                return Content(message, "text/html");
            }

            return Content("No resources to copy", "text/html");
        }

        public virtual ActionResult Summary(int id)
        {
            var e = UnitOfWork.Events.GetEvent(x => x.ID == id);
            var esm = new EventSummaryModel();
            Mapper.Map(e, esm);

            IQueryable<EventPart> eventParts = UnitOfWork.EventParts.SelectFilteredList(x => x.EventID == id);

            int instructorCount;
            int leadCount;
            int assessorCount;
            int shadowCount;
            int specialistCount;

            List<string> instructorNames;
            List<string> leadNames;
            List<string> assessorNames;
            List<string> shadowNames;
            List<string> specialistNames;

            foreach (var ep in eventParts)
            {
                instructorCount = 0;
                leadCount = 0;
                assessorCount = 0;
                shadowCount = 0;
                specialistCount = 0;

                instructorNames = new List<string>();
                leadNames = new List<string>();
                assessorNames = new List<string>();
                shadowNames = new List<string>();
                specialistNames = new List<string>();

                var apil = UnitOfWork.ActivityPartInstructorLevel.SelectBy(x => x.ActivityPartID == ep.ActivityPartID);

                var instructors = UnitOfWork.InstructorEventPart.SelectFilteredList(x => x.DayPartID == ep.ID);
                foreach (var i in instructors)
                {
                    var inst =
                        UnitOfWork.Instructors.SelectFilteredList(ins => ins.ID == i.InstructorID).FirstOrDefault();
                    string trainingCentre = string.Empty;

                    if (inst != null)
                    {
                        trainingCentre = string.Format(" - {0}", GetTrainingCentreName(inst.TrainingCentreID));
                    }

                    if (i.IsInstructor)
                    {
                        instructorCount++;
                        instructorNames.Add(string.Format("{0} {1}{2}", i.Instructor.FirstName, i.Instructor.LastName, trainingCentre));
                    }
                    if (i.IsAssessor)
                    {
                        assessorCount++;
                        assessorNames.Add(string.Format("{0} {1}{2}", i.Instructor.FirstName, i.Instructor.LastName, trainingCentre));
                    }
                    if (i.IsLead)
                    {
                        leadCount++;
                        leadNames.Add(string.Format("{0} {1}{2}", i.Instructor.FirstName, i.Instructor.LastName, trainingCentre));
                    }
                    if (i.IsShadow)
                    {
                        shadowCount++;
                        shadowNames.Add(string.Format("{0} {1}{2}", i.Instructor.FirstName, i.Instructor.LastName, trainingCentre));
                    }
                    if (i.IsSpecialist)
                    {
                        specialistCount++;
                        specialistNames.Add(string.Format("{0} {1}{2}", i.Instructor.FirstName, i.Instructor.LastName, trainingCentre));
                    }
                }

                string date = ep.Date.HasValue ? ep.Date.Value.ToShortDateString() : "";

                esm.EventPartModels.Add(
                    new EventPartSummaryModel()
                        {
                            SummaryTitle = string.Format("{0} ({1} - {2})", ep.Name, date, ep.DayType == 1 ? "Morning" : "Afternoon"),
                            Status = ep.Status,
                            StatusDescription = ep.ResourceStatu.Title,
                            #region - People

                            Instructors = new EventPeopleSummaryModel()
                                {
                                    Title = "Instructors",
                                    Fulfilled = apil.InstructorCount == instructorCount,
                                    SummaryOfNumbers = string.Format("{0} of {1}", instructorCount, apil.InstructorCount),
                                    People = instructorNames
                                },
                            Leads = new EventPeopleSummaryModel()
                            {
                                Title = "Leads",
                                Fulfilled = apil.LeadsCount == leadCount,
                                SummaryOfNumbers = string.Format("{0} of {1}", leadCount, apil.LeadsCount),
                                People = leadNames
                            },
                            Assessors = new EventPeopleSummaryModel()
                            {
                                Title = "Assessors",
                                Fulfilled = apil.AssessorCount == assessorCount,
                                SummaryOfNumbers = string.Format("{0} of {1}", assessorCount, apil.AssessorCount),
                                People = assessorNames
                            },
                            Shadows = new EventPeopleSummaryModel()
                            {
                                Title = "Shadows",
                                Fulfilled = apil.ShadowCount == shadowCount,
                                SummaryOfNumbers = string.Format("{0} of {1}", shadowCount, apil.ShadowCount),
                                People = shadowNames
                            },
                            Specialists = new EventPeopleSummaryModel()
                            {
                                Title = "Specialists",
                                Fulfilled = apil.SpecialistCount == specialistCount,
                                SummaryOfNumbers = string.Format("{0} of {1}", specialistCount, apil.SpecialistCount),
                                People = specialistNames
                            },
                            #endregion

                            Venues = GetVenueSummary(ep),
                            Equipment = GetEquipmentSummary(ep),
                            ID = ep.ID
                        }
                    );
            }

            return View(esm);
        }

        private List<EventEquipmentSummaryModel> GetEquipmentSummary(EventPart ep)
        {
            //get the equipment tags for this activity part
            var etaps = UnitOfWork.EquipmentTagActivityPart.SelectFilteredList(x => x.ActivityPartID == ep.ActivityPartID);

            var eesmList = new List<EventEquipmentSummaryModel>();
            foreach (var etap in etaps)
            {
                var eeps = UnitOfWork.EquipmentEventParts.SelectFilteredList(x => x.DayPartID == ep.ID
                    && x.EquipmentTagID == etap.EquipmentTagID);
                int count = eeps.Count();

                eesmList.Add(
                    new EventEquipmentSummaryModel()
                        {
                            Fulfilled = etap.MinRequired <= count,
                            SummaryOfNumbers = string.Format("{0} of {1}", count, etap.MinRequired),
                            EquipmentCategory = etap.EquipmentTag.Name,
                            Equipment = eeps.Select(x => x.Equipment.Name).ToList()
                        }
                    );
            }

            //get all venues that have been added that are not part of the activity template
            var nonTemplatedEquipment = UnitOfWork.EquipmentEventParts.SelectFilteredList(eep => eep.DayPartID == ep.ID && !eep.EquipmentTagID.HasValue);

            if (nonTemplatedEquipment.Count() > 0)
            {
                var model = new EventEquipmentSummaryModel()
                {
                    Fulfilled = true,
                    SummaryOfNumbers = string.Format("{0} of {1}", nonTemplatedEquipment.Count(), nonTemplatedEquipment.Count()),
                    EquipmentCategory = "Additional Equipment",
                    Equipment = nonTemplatedEquipment.Select(eep => eep.Equipment.Name).ToList()
                };

                eesmList.Add(model);
            }

            return eesmList;
        }

        private List<EventVenueSummaryModel> GetVenueSummary(EventPart ep)
        {
            //get the venue tags for this activity part
            var vtaps = UnitOfWork.VenueTagActivityPart.SelectFilteredList(x => x.ActivityPartID == ep.ActivityPartID);

            var evsmList = new List<EventVenueSummaryModel>();
            foreach (var vtap in vtaps)
            {
                // get the venues for each event part for this tag
                List<VenueEventPart> veps =
                    UnitOfWork.VenueEventParts.SelectFilteredList(x => x.DayPartID == ep.ID && x.VenueTagID == vtap.VenueTagID).
                        ToList();

                int count = veps.Count();

                evsmList.Add(
                    new EventVenueSummaryModel()
                        {
                            Fulfilled = vtap.MinRequired <= count,
                            SummaryOfNumbers = string.Format("{0} of {1}", count, vtap.MinRequired),
                            VenueCategory = vtap.VenueTag.Name,
                            Venues = veps.Select(x => x.Venue.Name).ToList()
                        }
                    );
            }

            //get all venues that have been added that are not part of the activity template
            var nonTemplatedVenues = UnitOfWork.VenueEventParts.SelectFilteredList(vep => vep.DayPartID == ep.ID && !vep.VenueTagID.HasValue);

            if (nonTemplatedVenues.Count() > 0)
            {
                var model = new EventVenueSummaryModel()
                {
                    Fulfilled = true,
                    SummaryOfNumbers = string.Format("{0} of {1}", nonTemplatedVenues.Count(), nonTemplatedVenues.Count()),
                    VenueCategory = "Additional Venues",
                    Venues = nonTemplatedVenues.Select(vep => vep.Venue.Name).ToList()
                };

                evsmList.Add(model);
            }

            return evsmList;
        }

        [TOREditAuthorise, HttpPost]
        public virtual JsonResult EventCancelled(int id, int reasonID, string reason)
        {
            //update the event status
            var e = UnitOfWork.Events.SelectBy(x => x.ID == id);

            if (e.Status == (int)EventStatusEnum.Scheduled ||
                e.Status == (int)EventStatusEnum.Blocked ||  //note: an event can only be blocked if it has previously been scheduled
                e.Status == (int)EventStatusEnum.Complete)
            {
                UnitOfWork.Events.UpdateStatus(e.ID, Trigger.EventCancelled, TORUser.FullName);
                UnitOfWork.Events.Update(e);

                //track cancel history
                UnitOfWork.EventCancelledHistory.Insert(
                    new EventCancelledHistory()
                    {
                        CancelledOn = DateTime.Now,
                        EventID = id,
                        Reason = reason,
                        ReasonID = reasonID
                    });

                //remove event part resources
                var eventParts = e.EventParts.ToList();
                foreach (var eventPart in eventParts)
                {
                    eventPart.Date = null;
                    eventPart.Status = (int)Utility.ResourceStatus.NotResourced;

                    UnitOfWork.InstructorEventPart.DeleteAll(x => x.DayPartID == eventPart.ID);
                    UnitOfWork.VenueEventParts.DeleteAll(x => x.DayPartID == eventPart.ID);
                    UnitOfWork.EquipmentEventParts.DeleteAll(x => x.DayPartID == eventPart.ID);
                }

                //commit all changes
                UnitOfWork.Commit();

                //update event status
                UnitOfWork.Events.ResetResourceStatus(id, TORUser.FullName);
            }
            else
            {
                //otherwise, do a hard delete

                //first remove event part resources
                var eventParts = e.EventParts.ToList();
                foreach (var eventPart in eventParts)
                {
                    eventPart.Date = null;
                    eventPart.Status = (int)Utility.ResourceStatus.NotResourced;

                    UnitOfWork.InstructorEventPart.DeleteAll(x => x.DayPartID == eventPart.ID);
                    UnitOfWork.VenueEventParts.DeleteAll(x => x.DayPartID == eventPart.ID);
                    UnitOfWork.EquipmentEventParts.DeleteAll(x => x.DayPartID == eventPart.ID);

                    UnitOfWork.EventParts.Delete(eventPart);
                }

                UnitOfWork.EventStatusHistory.DeleteAll(x => x.EventID == id);

                UnitOfWork.EventCancelledHistory.DeleteAll(x => x.EventID == id);

                var exports = UnitOfWork.iTrentExportDatas.SelectFilteredList(d => d.EventID == id).Select(d => d.iTrentExport).Distinct().ToList();

                foreach (var export in exports)
                {
                    UnitOfWork.iTrentExportDatas.DeleteAll(d => d.iTrentExportID == export.ID && d.EventID == id);
                    UnitOfWork.iTrentExportErrors.DeleteAll(x => x.iTrentExportID == export.ID && x.EventID == id);
                    UnitOfWork.iTrentImportFailures.DeleteAll(f => f.iTrentExportID == export.ID && f.EventID == id);

                    export.EventsExported = export.iTrentExportDatas.Select(d => d.Event).Distinct().Count();
                    export.ExportErrors = export.iTrentExportErrors.Count;
                    export.UploadErrors = export.iTrentImportFailures.Count;
                }

                UnitOfWork.Events.Delete(e);
            }

            UnitOfWork.Commit();

            return Json(true);
        }

        public virtual ActionResult Days(int id)
        {
            var edm = GetEventDaysModel(id);
            ValidateEventDays(edm);
            ViewBag.HasWriteAccess = (TORUser.TORRole > TORRole.User);
            ViewBag.IsEventCancelled = (edm.StatusID == (int)EventStatusEnum.Cancelled);
            return View(edm);
        }

        private EventDaysModel GetEventDaysModel(int id)
        {
            var e = UnitOfWork.Events.GetEvent(x => x.ID == id);
            var eventParts = UnitOfWork.EventParts.SelectFilteredList(x => x.EventID == id).ToList();

            var edm = new EventDaysModel
                {
                    ResourcesAssigned = UnitOfWork.Events.HasResourceAssigned(id),

                };

            Mapper.Map(e, edm);

            Mapper.Map(eventParts, edm.EventDays);

            var eventDayTypes = UnitOfWork.EventPartTypes.SelectFilteredList(x => x.ID != (int)Utility.EventPartTypeEnum.FullDay);

            foreach (var ed in edm.EventDays)
            {
                ed.DayTypes = GetEventDayTypes(eventDayTypes, ed.DayTypeID);
                ed.StartTime = ed.StartTime.StartsWith("0") ? ed.StartTime.Substring(1) : ed.StartTime;
                ed.StartTime = ed.StartTime.EndsWith(":00")
                                   ? ed.StartTime.Substring(0, ed.StartTime.Length - 3)
                                   : ed.StartTime;

                ed.EndTime = ed.EndTime.StartsWith("0") ? ed.EndTime.Substring(1) : ed.EndTime;
                ed.EndTime = ed.EndTime.EndsWith(":00")
                                   ? ed.EndTime.Substring(0, ed.EndTime.Length - 3)
                                   : ed.EndTime;
            }


            return edm;
        }

        public virtual JsonResult LoadPostponeReasons()
        {
            var reasons = UnitOfWork.PostponeEventReasons.SelectAll().ToList();

            var myReasons = reasons.Select(x => new { ID = x.ID, Name = x.Reason });

            return Json(myReasons, JsonRequestBehavior.AllowGet);
        }

        public virtual JsonResult LoadFinancialYearData()
        {
            var financialYearsSelectList = GetFinancialYearSelectList();

            var financialYears = financialYearsSelectList.Select(x => new { Text = x.Text, Value = x.Value });

            return Json(financialYears, JsonRequestBehavior.AllowGet);
        }

        public virtual JsonResult LoadCancelReasons()
        {
            var reasons = UnitOfWork.CancelEventReasons.SelectAll().OrderBy(r => r.Reason).ToList();

            var myReasons = reasons.Select(x => new { ID = x.ID, Name = x.Reason });

            return Json(myReasons, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [TOREditAuthorise]
        public virtual ActionResult Days(EventDaysModel model)
        {
            ValidateEventDays(model);

            if (ModelState.IsValid)
            {
                List<EventPart> existingEventParts = UnitOfWork.EventParts.SelectFilteredList(x => x.EventID == model.ID).ToList();
                List<EventDayModel> eventDays = model.EventDays.ToList();

                foreach (var eventDayModel in eventDays)
                {
                    var ep = existingEventParts.Single(x => x.ID == eventDayModel.ID);

                    DateTime? newDate = eventDayModel.Date;
                    //DateTime.TryParse(eventDayModel.Date, out newDate);

                    //have we changed the date of this event part?
                    if ((ep.Date.HasValue && ep.Date.Value != newDate) ||
                        (!ep.Date.HasValue && newDate.HasValue))
                    {
                        //remove all resources assigned to the event part since we are changing the date

                        //remove instructors
                        var ieps = UnitOfWork.InstructorEventPart.SelectFilteredList(x => x.DayPartID == eventDayModel.ID).ToList();
                        foreach (var iep in ieps)
                        {
                            UnitOfWork.InstructorEventPart.Delete(iep);
                        }

                        //remove venues
                        var veps = UnitOfWork.VenueEventParts.SelectFilteredList(x => x.DayPartID == eventDayModel.ID).ToList();
                        foreach (var vep in veps)
                        {
                            UnitOfWork.VenueEventParts.Delete(vep);
                        }

                        //remove equipment
                        var eeps = UnitOfWork.EquipmentEventParts.SelectFilteredList(x => x.DayPartID == eventDayModel.ID).ToList();
                        foreach (var eep in eeps)
                        {
                            UnitOfWork.EquipmentEventParts.Delete(eep);
                        }
                    }

                    Mapper.Map(eventDayModel, ep);

                    switch (eventDayModel.DayTypeID)
                    {
                        case 0:
                            ep.DayType = null;
                            break;
                        default:
                            ep.DayType = eventDayModel.DayTypeID;
                            break;
                    }

                    UnitOfWork.EventParts.Update(ep);
                }

                UnitOfWork.Commit();

                //now reset each event parts resource status
                foreach (var eventPart in existingEventParts)
                {
                    UnitOfWork.EventParts.ResetResourceStatus(eventPart.ID);
                }

                UnitOfWork.Commit();

                //now reset the entire events resource status
                UnitOfWork.Events.ResetResourceStatus(model.ID, TORUser.FullName);

                UnitOfWork.Commit();

                //process state change
                UnitOfWork.Events.UpdateStatus(model.ID,
                    //model.EventDays.Count() == model.EventDays.Count(x => x.Date != null && x.Date != "") //will all parts now have dates?
                                               model.EventDays.Count() == model.EventDays.Count(x => x.Date != null) //will all parts now have dates?
                                                   ? Trigger.AllDatesAdded
                                                   : Trigger.DateRemoved, TORUser.FullName);

                UnitOfWork.Commit();
            }


            //fetch the EventDayModel again
            var edm = GetEventDaysModel(model.ID);
            ValidateEventDays(model);
            ViewBag.HasWriteAccess = (TORUser.TORRole > TORRole.User);
            return View(edm);
        }

        /// <summary>
        /// Validates all event part days;
        /// Ensures all dates, start time and end times do not conflict with eachother.
        /// </summary>
        /// <param name="model"></param>
        public virtual void ValidateEventDays(EventDaysModel model)
        {
            int index = 0;

            foreach (var eventDayModel in model.EventDays)
            {
                if (eventDayModel.Date.HasValue)
                {
                    DateTime? currentDate = eventDayModel.Date;
                    int currentDayTypeID = eventDayModel.DayTypeID;

                    if (model.EventDays.Where(x => x.Date == currentDate &&
                                                    x.DayTypeID == currentDayTypeID &&
                                                    x.ID != eventDayModel.ID &&
                                                    x.Date.HasValue)
                                             .Count() > 0)
                    {
                        ModelState.AddModelError(String.Format("EventDays[{0}].Date", index), Constants.EVENT_PART_INVALID_DATE_TIME);
                    }

                    index++;

                }
            }
        }

        public virtual ActionResult Instructors(int id, int? SelectedEventPartID, string[] selectedTrainingCentres, bool? searchClicked)
        {
            var e = UnitOfWork.Events.GetEvent(x => x.ID == id);

            if (SelectedEventPartID == null)
            {
                //get the earliest dated event part
                var eps = UnitOfWork.EventParts.GetEarliestEventPart(id); //todo: replace with first from GetEventParts below
                SelectedEventPartID = eps != null ? eps.ID : 0;
            }


            var trainingCentres = selectedTrainingCentres != null ? String.Join(",", selectedTrainingCentres) : null;
            //Search on default training centre if not a search clicked
            if (trainingCentres == null && (searchClicked == null || !searchClicked.Value))
            {
                trainingCentres = TORUser.DefaultTrainingCentreID.ToString();
                selectedTrainingCentres = trainingCentres.Split(',');
            }

            var eim = new EventInstructorsModel(
                Url.Action(MVC.Events.ActionNames.GetEventsInstructorData,
                    new { id = id, eventPartID = SelectedEventPartID.Value, selectedTrainingCentres = trainingCentres }),
                Url.Action(MVC.Events.ActionNames.InstructorsEdit, new { dayPartID = SelectedEventPartID.Value })
                )
            {
                TrainingCentres = GetTrainingCentresForFilters(),
                SelectedTrainingCentres = selectedTrainingCentres,
            };

            eim.InstructorGrid.Columns[15].Visible = TORUser.TORRole >= TORRole.Editor;       //display edit column only if we are an Editor or higher 

            Mapper.Map(e, eim);

            var eventList = GetEventParts(id);

            if (eventList != null && eventList.Count() != 0)
            {
                eim.EventParts = eventList.Select(x => x).ToList();

                var itemToRemove = eventList.First(x => x.Value == SelectedEventPartID.Value.ToString());

                eventList.Remove(itemToRemove);//remove the currently selected event part for the Copy To list
                eim.CopyToEventPartList = eventList;
            }


            eim.SelectedEventPartID = SelectedEventPartID.Value;

            if (SelectedEventPartID.Value != 0)
            {
                var instructorNumbers = UnitOfWork.EventPartResources.GetInstructorNumbers(SelectedEventPartID.Value);

                Mapper.Map(instructorNumbers, eim);
            }

            return View(eim);
        }

        public virtual JsonResult GetInstructorNumbers(int eventPartID)
        {
            var instructorNumbers = UnitOfWork.EventPartResources.GetInstructorNumbers(eventPartID);

            return Json(instructorNumbers, JsonRequestBehavior.AllowGet);
        }

        [TOREditAuthorise]
        public virtual ActionResult InstructorsEdit(InstructorEventModel instructorEventModel, int dayPartID, string[] selectedTrainingCentres, bool? searchClicked)
        {
            var trainingCentres = selectedTrainingCentres != null ? String.Join(",", selectedTrainingCentres) : null;
            //Search on default training centre if not a search clicked
            if (trainingCentres == null && searchClicked == null)
            {
                trainingCentres = TORUser.DefaultTrainingCentreID.ToString();
            }


            var gridModel = new EventInstructorsModel(
                Url.Action(MVC.Events.GetEventsInstructorData(instructorEventModel.ID, dayPartID, trainingCentres)),
                Url.Action(MVC.Events.ActionNames.InstructorsEdit, new { dayPartID = dayPartID }));

            if (gridModel.InstructorGrid.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                //get any existing record for the instructor for this event part
                InstructorEventPart instructorEventPart = UnitOfWork.InstructorEventPart
                                                        .SelectBy(x => x.InstructorID == instructorEventModel.ID && x.DayPartID == dayPartID);

                //get the event part
                EventPart eventPart = UnitOfWork.EventParts.SelectBy(x => x.ID == dayPartID);

                //get any existing record for this instructor for any other event part on the same date and day portion
                InstructorEventPart otherInstructorEventPart = UnitOfWork.InstructorEventPart
                                                                .SelectBy(x => x.InstructorID == instructorEventModel.ID
                                                                        && x.EventPart.Date == eventPart.Date
                                                                        && x.EventPart.DayType == eventPart.DayType
                                                                        && x.DayPartID != dayPartID);

                if (otherInstructorEventPart != null)
                {
                    return gridModel.InstructorGrid.ShowEditValidationMessage(
                        string.Format(
                            Constants.ITEM_ALREADY_ASSIGNED_ERROR_WITH_URL_LINK,
                            otherInstructorEventPart.Instructor.FirstName + " " + otherInstructorEventPart.Instructor.LastName,
                            Url.Action(MVC.Events.Instructors(otherInstructorEventPart.EventPart.Event.ID, otherInstructorEventPart.EventPart.ID, selectedTrainingCentres, searchClicked)),
                            string.Format("{0} {1} {2} ({3})",
                                otherInstructorEventPart.EventPart.Event.Activity.Title,
                                otherInstructorEventPart.EventPart.Event.Activity.Code,
                                otherInstructorEventPart.EventPart.Event.EventNumber + "/" +
                                otherInstructorEventPart.EventPart.Event.FinanciaYear.ToString().Substring(2, 2),
                                otherInstructorEventPart.EventPart.Name)));
                }

                bool shouldCommit = false;

                //is there an existing record for this person?
                if (instructorEventPart != null)
                {
                    Mapper.Map(instructorEventModel, instructorEventPart);

                    //are all the instructor types false or NULL? if so just delete
                    if (!instructorEventPart.IsLead
                        && !instructorEventPart.IsInstructor
                        && !instructorEventPart.IsAssessor
                        && !instructorEventPart.IsShadow
                        && !instructorEventPart.IsSpecialist)
                    {
                        UnitOfWork.InstructorEventPart.Delete(instructorEventPart);
                    }
                    else
                    {
                        UnitOfWork.InstructorEventPart.Update(instructorEventPart);
                    }

                    shouldCommit = true;
                }
                else if (instructorEventModel.SelectedLead || instructorEventModel.SelectedInstructor ||
                         instructorEventModel.SelectedAssessor || instructorEventModel.SelectedShadow ||
                         instructorEventModel.SelectedSpecialist) //no existing record, create new one
                {
                    // check that the person has no overlapping unavailability period defined
                    var unavailabilePeriods = UnitOfWork.InstructorUnavailablePeriods.SelectFilteredList(p =>
                        p.InstructorID == instructorEventModel.ID &&
                        eventPart.Date >= p.StartDate && (eventPart.Date <= p.EndDate || p.EndDate == null) &&
                        (eventPart.DayType == (int)EventPartType.FullDay ||
                         p.DayTypeID == (int)EventPartType.FullDay ||
                         eventPart.DayType == p.DayTypeID));

                    if (unavailabilePeriods.Any())
                    {
                        return gridModel.InstructorGrid.ShowEditValidationMessage(Constants.GRID_EVENT_INSTRUCTOR_UNAVAILABILITY_PERIOD_EXISTS);
                    }

                    instructorEventPart = new InstructorEventPart() { DayPartID = dayPartID };
                    Mapper.Map(instructorEventModel, instructorEventPart);

                    UnitOfWork.InstructorEventPart.Insert(instructorEventPart);
                    shouldCommit = true;
                }

                if (shouldCommit)
                {
                    UnitOfWork.Commit();

                    UnitOfWork.EventParts.ResetResourceStatus(dayPartID);
                    UnitOfWork.Commit();

                    var ep = UnitOfWork.EventParts.SelectFilteredList(x => x.ID == dayPartID).First();
                    UnitOfWork.Events.ResetResourceStatus(ep.EventID, TORUser.FullName);

                    UnitOfWork.Commit();
                }

            }

           
            return GetEventsInstructorData(instructorEventModel.ID, dayPartID, trainingCentres);
        }


        public virtual JsonResult GetEventsInstructorData(int id, int eventPartID, string selectedTrainingCentres)
        {
            var gridModel = new EventInstructorsModel(Url.Action(MVC.Events.GetEventsInstructorData(id, eventPartID, selectedTrainingCentres)),
                                                      Url.Action(MVC.Events.ActionNames.InstructorsEdit));

            var ep = UnitOfWork.EventParts.SelectBy(x => x.ID == eventPartID);

            int[] ids = { };

            if (!string.IsNullOrWhiteSpace(selectedTrainingCentres))
            {
                ids = selectedTrainingCentres.Split(',').Select(int.Parse).ToArray();
            }

            var eligibleInstructors = UnitOfWork.EventPartResources.
                GetInstructorsAvailabilityByDate(ep.Date, ep.DayType.Value, ep.Event.ActivityID.Value, eventPartID, ids);


            return gridModel.InstructorGrid.DataBind(eligibleInstructors);
        }

        public virtual ActionResult Equipment(int id, int? SelectedEventPartID, string[] selectedTrainingCentres, bool? searchClicked)
        {
            var e = UnitOfWork.Events.GetEvent(x => x.ID == id);

            //int activityPartID = 0;
            EventPart eps = null;
            if (SelectedEventPartID == null)
            {
                //get the earliest dated event part
                eps = UnitOfWork.EventParts.GetEarliestEventPart(id); //todo: replace with first from GetEventParts below
                SelectedEventPartID = eps != null ? eps.ID : 0;
            }
            else
            {
                eps = UnitOfWork.EventParts.SelectBy(x => x.ID == SelectedEventPartID);

            }

            //get the activity part ID for the event part so we can look up what venue tags it needs: todo: combine into GetVenueTags call below
            IQueryable<EquipmentTagModel> equipmentTags = null;
            List<SelectListItem> equipmentTagSelectList = null;
            if (eps != null)
            {
                equipmentTags = UnitOfWork.EquipmentTags.GetEquipmentTagsForActivityPart(eps.ActivityPartID);
                equipmentTagSelectList = GetEquipmentTagsSelectList(equipmentTags);
            }

            var trainingCentres = selectedTrainingCentres != null ? String.Join(",", selectedTrainingCentres) : null;
            //Search on default training centre if not a search clicked
            if (trainingCentres == null && (searchClicked == null || !searchClicked.Value))
            {
                trainingCentres = TORUser.DefaultTrainingCentreID.ToString();
                selectedTrainingCentres = trainingCentres.Split(',');
            }

            Session["selectedTrainingCentresEquipment"] = selectedTrainingCentres;

            var eem = new EventEquipmentModel(Url.Action(MVC.Events.GetEventsEquipmentData(id, SelectedEventPartID.Value, trainingCentres)),
                                           Url.Action("EquipmentEdit", new { dayPartID = SelectedEventPartID.Value }), equipmentTagSelectList) {
                    TrainingCentres = GetTrainingCentresForFilters(),
                    SelectedTrainingCentres = selectedTrainingCentres
                };

            eem.EquipmentGrid.Columns[7].Visible = TORUser.TORRole >= TORRole.Editor;       //display edit column only if we are an Editor or higher 

            Mapper.Map(e, eem);


            var eventList = GetEventParts(id);

            if (eventList != null && eventList.Count() != 0)
            {
                eem.EventParts = eventList.Select(x => x).ToList();

                var itemToRemove = eventList.First(x => x.Value == SelectedEventPartID.Value.ToString());

                eventList.Remove(itemToRemove);//remove the currently selected event part for the Copy To list
                eem.CopyToEventPartList = eventList;
            }

            eem.SelectedEventPartID = SelectedEventPartID.Value;

            eem.EquipmentTags = new List<EquipmentTagModel>();

            if (eps != null)
            {
                foreach (var tag in equipmentTags)
                {
                    eem.EquipmentTags.Add(new EquipmentTagModel()
                        {
                            ID = tag.ID,
                            Name = tag.Name,
                            MinRequired = tag.MinRequired
                        });
                }
            }

            ViewBag.HasWriteAccess = (TORUser.TORRole > TORRole.User);

            return View(eem);

        }

        public virtual ActionResult Venues(int id, int? SelectedEventPartID, string[] selectedTrainingCentres, bool? searchClicked)
        {
            var e = UnitOfWork.Events.GetEvent(x => x.ID == id);

            //int activityPartID = 0;
            EventPart eps = null;
            if (SelectedEventPartID == null)
            {
                //get the earliest dated event part
                eps = UnitOfWork.EventParts.GetEarliestEventPart(id); //todo: replace with first from GetEventParts below
                SelectedEventPartID = eps != null ? eps.ID : 0;
            }
            else
            {
                eps = UnitOfWork.EventParts.SelectBy(x => x.ID == SelectedEventPartID);

            }

            //get the activity part ID for the event part so we can look up what venue tags it needs: todo: combine into GetVenueTags call below

            IQueryable<VenueTagModel> venueTags = null;
            List<SelectListItem> venueTagSelectList = null;
            if (eps != null)
            {
                venueTags = UnitOfWork.VenueTags.GetVenueTagsForActivityPart(eps.ActivityPartID);
                venueTagSelectList = GetVenueTagsSelectList(venueTags);
            }

            var trainingCentres = selectedTrainingCentres != null ? String.Join(",", selectedTrainingCentres) : null;
            //Search on default training centre if not a search clicked
            if (trainingCentres == null && (searchClicked == null || !searchClicked.Value))
            {
                trainingCentres = string.Format("{0},{1}", TORUser.DefaultTrainingCentreID, GetNationalTrainingCentreId());
                selectedTrainingCentres = trainingCentres.Split(',');

            }
            
            Session["selectedTrainingCentresVenues"] = selectedTrainingCentres;
            

            var evm =
                new EventVenuesModel(
                    Url.Action(MVC.Events.GetEventsVenuesData(id, SelectedEventPartID.Value, trainingCentres)),

                    Url.Action("VenuesEdit", new {dayPartID = SelectedEventPartID.Value}), venueTagSelectList)
                {
                    TrainingCentres = GetTrainingCentresForFilters(),
                    SelectedTrainingCentres = selectedTrainingCentres
                };

            evm.VenuesGrid.Columns[8].Visible = TORUser.TORRole >= TORRole.Editor;       //display edit column only if we are an Editor or higher 


            Mapper.Map(e, evm);

            var eventList = GetEventParts(id);

            if (eventList != null && eventList.Count() != 0)
            {
                evm.EventParts = eventList.Select(x => x).ToList();

                var itemToRemove = eventList.First(x => x.Value == SelectedEventPartID.Value.ToString());

                eventList.Remove(itemToRemove);//remove the currently selected event part for the Copy To list
                evm.CopyToEventPartList = eventList;
            }

            evm.SelectedEventPartID = SelectedEventPartID.Value;

            evm.VenueTags = new List<VenueTagModel>();

            if (eps != null)
            {
                foreach (var tag in venueTags)
                {
                    evm.VenueTags.Add(new VenueTagModel()
                        {
                            ID = tag.ID,
                            Name = tag.Name,
                            MinRequired = tag.MinRequired
                        });
                }
            }

            ViewBag.HasWriteAccess = (TORUser.TORRole > TORRole.User);

            return View(evm);
        }

        public virtual PartialViewResult VenuesSummary(int eventPartID)
        {
            var ep = UnitOfWork.EventParts.SelectBy(x => x.ID == eventPartID);

            var e = GetVenueSummary(ep);

            return PartialView(e);
        }

        public virtual PartialViewResult EquipmentSummary(int eventPartID)
        {
            var ep = UnitOfWork.EventParts.SelectBy(x => x.ID == eventPartID);

            var e = GetEquipmentSummary(ep);

            return PartialView(e);
        }

        public virtual JsonResult GetEventsVenuesData(int id, int eventPartID, string selectedTrainingCentres)
        {
            var gridModel = new EventVenuesModel(Url.Action(MVC.Events.GetEventsVenuesData(id, eventPartID, selectedTrainingCentres)),
                                           Url.Action("VenuesEdit", new { dayPartID = eventPartID }), null);

            EventPart ep = UnitOfWork.EventParts.SelectBy(x => x.ID == eventPartID);

            int[] ids = { };

            if (!string.IsNullOrWhiteSpace(selectedTrainingCentres))
            {
                ids = selectedTrainingCentres.Split(',').Select(int.Parse).ToArray();
            }

            //get all venue tags for this event part based on its parent ActivityPart
            var tags = UnitOfWork.VenueTagActivityPart.SelectFilteredList(x => x.ActivityPartID == ep.ActivityPartID);
            var tagIDs = tags.Select(x => x.VenueTagID).ToList();

            //get all venue data for this event part
            var venueData = UnitOfWork.EventPartResources.GetVenuesAvailabilityByDate(ep, tagIDs, ids);

            return gridModel.VenuesGrid.DataBind(venueData);
        }

        [TOREditAuthorise]
        public virtual ActionResult VenuesEdit(VenueEventModel venueEventModel, int dayPartID, string[] selectedTrainingCentres, bool? searchClicked)
        {

             var trainingCentres = selectedTrainingCentres != null ? String.Join(",", selectedTrainingCentres) : null;
            //Search on default training centre if not a search clicked
            if (trainingCentres == null && searchClicked == null)
            {
                trainingCentres = TORUser.DefaultTrainingCentreID.ToString();
            }

            var gridModel = new EventVenuesModel(Url.Action(MVC.Events.GetEventsVenuesData(venueEventModel.ID, dayPartID, trainingCentres)),
                                           Url.Action("VenuesEdit", new { dayPartID = dayPartID }), null);

            if (gridModel.VenuesGrid.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                var venueEventPart = UnitOfWork.VenueEventParts
                                                    .SelectBy(x => x.VenueID == venueEventModel.ID
                                                                && x.DayPartID == dayPartID);

                //get the event part
                EventPart eventPart = UnitOfWork.EventParts.SelectBy(x => x.ID == dayPartID);

                //get any existing record for this venue for any other event part on event part
                VenueEventPart otherVenueEventPart = UnitOfWork.VenueEventParts
                                                                .SelectBy(x => x.VenueID == venueEventModel.ID
                                                                            && x.EventPart.Date == eventPart.Date
                                                                            && x.EventPart.DayType == eventPart.DayType
                                                                            && x.DayPartID != dayPartID);

                if (otherVenueEventPart != null)
                {
                    return gridModel.VenuesGrid.ShowEditValidationMessage(string.Format(Constants.ITEM_ALREADY_ASSIGNED_ERROR_WITH_URL_LINK,
                                    otherVenueEventPart.Venue.Name,
                                    Url.Action(MVC.Events.Venues(otherVenueEventPart.EventPart.Event.ID, otherVenueEventPart.EventPart.ID,selectedTrainingCentres,searchClicked)),
                                    string.Format("{0} {1} {2} ({3})", otherVenueEventPart.EventPart.Event.Activity.Title,
                                                                    otherVenueEventPart.EventPart.Event.Activity.Code,
                                                                    otherVenueEventPart.EventPart.Event.EventNumber + "/" +
                                                                            otherVenueEventPart.EventPart.Event.FinanciaYear.ToString().Substring(2, 2),
                                                                    otherVenueEventPart.EventPart.Name)));
                }

                bool shouldCommit = false;

                //is there an existing record?
                if (venueEventPart != null)
                {
                    Mapper.Map(venueEventModel, venueEventPart);

                    //have we unchecked the booked checkbox?
                    if (!venueEventModel.Booked)
                    {
                        UnitOfWork.VenueEventParts.Delete(venueEventPart);
                    }
                    else
                    {
                        UnitOfWork.VenueEventParts.Update(venueEventPart);
                    }

                    shouldCommit = true;
                }
                else if (venueEventModel.Booked) //no existing record, create new one
                {
                    // check that the venue has no overlapping unavailability period defined
                    var unavailabilePeriods = UnitOfWork.VenueUnavailablePeriod.SelectFilteredList(p =>
                        p.VenueID == venueEventModel.ID &&
                        eventPart.Date >= p.StartDate && (eventPart.Date <= p.EndDate || p.EndDate == null) &&
                        (eventPart.DayType == (int)EventPartType.FullDay ||
                         p.DayTypeID == (int)EventPartType.FullDay ||
                         eventPart.DayType == p.DayTypeID));

                    if (unavailabilePeriods.Any())
                    {
                        return gridModel.VenuesGrid.ShowEditValidationMessage(Constants.GRID_EVENT_VENUE_UNAVAILABILITY_PERIOD_EXISTS);
                    }

                    venueEventPart = new VenueEventPart() { DayPartID = dayPartID };
                    Mapper.Map(venueEventModel, venueEventPart);

                    UnitOfWork.VenueEventParts.Insert(venueEventPart);

                    shouldCommit = true;
                }

                if (shouldCommit)
                {
                    UnitOfWork.Commit();

                    UnitOfWork.EventParts.ResetResourceStatus(dayPartID);

                    UnitOfWork.Commit();

                    var ep = UnitOfWork.EventParts.SelectFilteredList(x => x.ID == dayPartID).First();
                    UnitOfWork.Events.ResetResourceStatus(ep.EventID, TORUser.FullName);

                    UnitOfWork.Commit();
                }
            }

            return GetEventsVenuesData(venueEventModel.ID, dayPartID, trainingCentres);
        }

        public virtual JsonResult GetEventsEquipmentData(int id, int eventPartID, string selectedTrainingCentres)
        {
            var gridModel = new EventEquipmentModel(Url.Action(MVC.Events.GetEventsEquipmentData(id, eventPartID, selectedTrainingCentres)),
                                           Url.Action("EquipmentEdit", new { dayPartID = eventPartID }), null);

            EventPart ep = UnitOfWork.EventParts.SelectBy(x => x.ID == eventPartID);

            int[] ids = { };

            if (!string.IsNullOrWhiteSpace(selectedTrainingCentres))
            {
                ids = selectedTrainingCentres.Split(',').Select(int.Parse).ToArray();
            }


            //get all venue tags for this event part based on its parent ActivityPart
            var tags = UnitOfWork.EquipmentTagActivityPart.SelectFilteredList(x => x.ActivityPartID == ep.ActivityPartID);
            var tagIDs = tags.Select(x => x.EquipmentTagID).ToList();

            //get all venue data for this event part
            var equipmentData = UnitOfWork.EventPartResources.GetEquipmentAvailabilityByDate(ep, tagIDs, ids);

            return gridModel.EquipmentGrid.DataBind(equipmentData);
        }

        public virtual JsonResult GetEquipmentTagsForCategoryDropDown(int equipmentID, int eventPartID)
        {
            //first get event part
            var ep = UnitOfWork.EventParts.SelectBy(x => x.ID == eventPartID);

            //now get all the equipment tags for the activity part that the event part is based on
            var eq = UnitOfWork.EquipmentTagActivityPart.SelectAll().Where(y => y.ActivityPartID == ep.ActivityPartID).Select(x => new { x.EquipmentTag.ID, x.EquipmentTag.Name }).ToList();


            //now get the equipment tags for the equipment
            var eqe = UnitOfWork.EquipmentTagEquipment.SelectAll().Where(y => y.EquipmentID == equipmentID).Select(x => new { x.EquipmentTag.ID, x.EquipmentTag.Name }).ToList();

            var eqeCopy = eqe.ToList();

            foreach (var e in eqe)
            {
                if (!eq.Any(x => x.ID == e.ID))
                {
                    eqeCopy.Remove(e);
                }
            }

            return Json(eqeCopy, JsonRequestBehavior.AllowGet);
        }

        public virtual JsonResult GetEquipmentDropDownData(int eventPartID)
        {
            var eventPart = UnitOfWork.EventParts.SelectBy(x => x.ID == eventPartID);

            //get all the venue IDs that have already been assigned for this day
            var epEquipmentIDsToExclude = UnitOfWork.Equipment.SelectFilteredList(
                e => e.EquipmentEventParts.Any(eep =>
                                                  eep.EventPart.Date == eventPart.Date &&
                                                 (eep.EventPart.DayType == (int)EventPartType.FullDay ||
                                                  eep.EventPart.DayType == eventPart.DayType)))
                .Select(x => x.ID);

            //get all the unavailable venue IDs
            var upEquipmentIDsToExclude = UnitOfWork.EquipmentUnavailablePeriods.SelectFilteredList(
                    eup =>
                               ((eup.StartDate >= eventPart.Date && eup.StartDate <= eventPart.Date) ||
                                (eup.EndDate >= eventPart.Date && eup.EndDate <= eventPart.Date) ||
                                (eventPart.Date >= eup.StartDate && eventPart.Date <= eup.EndDate)) &&
                            (eup.DayTypeID == (int)EventPartType.FullDay || eup.DayTypeID == eventPart.DayType)
                    ).Select(eup => eup.EquipmentID);



            var equipment = UnitOfWork.Equipment.SelectFilteredList(x => !epEquipmentIDsToExclude.Contains(x.ID) &&
                                                                    !upEquipmentIDsToExclude.Contains(x.ID)).ToList();


            var trainCentreIds = new[] { TORUser.ResourceDisplayTrainingCentreID };
            if (Session["selectedTrainingCentresEquipment"] != null)
            {
                var tcids = Session["selectedTrainingCentresEquipment"] as string[];
                if (tcids != null && tcids.Length > 0)
                {
                    trainCentreIds = tcids.Select(int.Parse).ToArray();
                }

                equipment = equipment.Where(e => trainCentreIds.Contains(e.TrainingCentreID)).ToList();
            }

            return Json(equipment.OrderBy(x => x.Name).Select(x => new { x.ID, Title = x.Name }), JsonRequestBehavior.AllowGet);
        }

        public virtual JsonResult GetVenuesDropDownData(int eventPartID)
        {
            var eventPart = UnitOfWork.EventParts.SelectBy(x => x.ID == eventPartID);

            //get all the venue IDs that have already been assigned for this day
            var epVenueIDsToExclude = UnitOfWork.Venues.SelectFilteredList(
                v => v.VenueEventParts.Any(vep =>
                                                  vep.EventPart.Date == eventPart.Date &&
                                                 (vep.EventPart.DayType == (int)EventPartType.FullDay ||
                                                  vep.EventPart.DayType == eventPart.DayType)))
                .Select(x => x.ID);

            //get all the unavailable venue IDs
            var upVenueIDsToExclude = UnitOfWork.VenueUnavailablePeriod.SelectFilteredList(
                    vup => ((vup.StartDate >= eventPart.Date && vup.StartDate <= eventPart.Date) ||
                                (vup.EndDate >= eventPart.Date && vup.EndDate <= eventPart.Date) ||
                                (eventPart.Date >= vup.StartDate && eventPart.Date <= vup.EndDate)) &&
                            (vup.DayTypeID == (int)EventPartType.FullDay || vup.DayTypeID == eventPart.DayType)
                    ).Select(vup => vup.VenueID);

            //get all venues that are part of the activity template

            var venues = UnitOfWork.Venues.SelectFilteredList(x => !epVenueIDsToExclude.Contains(x.ID) &&
                                                                     !upVenueIDsToExclude.Contains(x.ID)).ToList();
                            

            var trainCentreIds = new[] { TORUser.ResourceDisplayTrainingCentreID };
            if (Session["selectedTrainingCentresVenues"] != null)
            {
                var tcids = Session["selectedTrainingCentresVenues"] as string[];
                if (tcids != null && tcids.Length > 0)
                {
                    trainCentreIds = tcids.Select(int.Parse).ToArray();
                }

                venues = venues.Where(v => trainCentreIds.Contains(v.TrainingCentreID)).ToList();
            }
      
            return Json(venues.OrderBy(x => x.Name).Select(x => new { x.ID, Title = x.Name }), JsonRequestBehavior.AllowGet);

        }

        public virtual JsonResult GetVenueTagsForCategoryDropDown(int venueID, int eventPartID)
        {
            //first get event part
            var ep = UnitOfWork.EventParts.SelectBy(x => x.ID == eventPartID);

            //now get all the venue tags for the activity part that the event part is based on
            var eq = UnitOfWork.VenueTagActivityPart.SelectAll().Where(y => y.ActivityPartID == ep.ActivityPartID).Select(x => new { x.VenueTag.ID, x.VenueTag.Name }).ToList();


            //now get the venue tags for the equipment
            var eqe = UnitOfWork.VenueTagVenues.SelectAll().Where(y => y.VenueID == venueID).Select(x => new { x.VenueTag.ID, x.VenueTag.Name }).ToList();

            var eqeCopy = eqe.ToList();

            foreach (var e in eqe)
            {
                if (!eq.Any(x => x.ID == e.ID))
                {
                    eqeCopy.Remove(e);
                }
            }

            return Json(eqeCopy, JsonRequestBehavior.AllowGet);
        }

        public virtual JsonResult GetEquipmentTagsForEventPart(int eventPartID)
        {
            //first get event part
            var ep = UnitOfWork.EventParts.SelectBy(x => x.ID == eventPartID);

            //now get all the equipment tags for the activity part that the event part is based on
            var eq = UnitOfWork.EquipmentTagActivityPart.SelectAll().Where(y => y.ActivityPartID == ep.ActivityPartID).Select(x => new { x.EquipmentTag.ID, x.EquipmentTag.Name }).ToList();

            return Json(eq, JsonRequestBehavior.AllowGet);
        }

        public virtual JsonResult GetVenueTagsForEventPart(int eventPartID)
        {
            //first get event part
            var ep = UnitOfWork.EventParts.SelectBy(x => x.ID == eventPartID);

            //now get all the equipment tags for the activity part that the event part is based on
            var eq = UnitOfWork.VenueTagActivityPart.SelectAll().Where(y => y.ActivityPartID == ep.ActivityPartID).Select(x => new { x.VenueTag.ID, x.VenueTag.Name }).ToList();

            return Json(eq, JsonRequestBehavior.AllowGet);
        }

        [TOREditAuthorise]
        public virtual ActionResult EquipmentEdit(EquipmentEventModel equipmentEventModel, int dayPartID, string[] selectedTrainingCentres, bool? searchClicked)
        {
            var trainingCentres = selectedTrainingCentres != null ? String.Join(",", selectedTrainingCentres) : null;
            //Search on default training centre if not a search clicked
            if (trainingCentres == null && searchClicked == null)
            {
                trainingCentres = TORUser.DefaultTrainingCentreID.ToString();
            }

            var gridModel = new EventEquipmentModel(Url.Action(MVC.Events.GetEventsEquipmentData(equipmentEventModel.ID, dayPartID, trainingCentres)),
                                           Url.Action("EquipmentEdit", new { dayPartID = dayPartID }), null);

            if (gridModel.EquipmentGrid.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                var equipmentEventPart = UnitOfWork.EquipmentEventParts
                                                    .SelectBy(x => x.EquipmentID == equipmentEventModel.ID
                                                                && x.DayPartID == dayPartID);

                //get the event part
                EventPart eventPart = UnitOfWork.EventParts.SelectBy(x => x.ID == dayPartID);

                //get any existing record for this equipment for any other event part on event part
                EquipmentEventPart otherEquipmentEventPart = UnitOfWork.EquipmentEventParts
                                                                .SelectBy(x => x.EquipmentID == equipmentEventModel.ID
                                                                            && x.EventPart.Date == eventPart.Date
                                                                            && x.EventPart.DayType == eventPart.DayType
                                                                            && x.DayPartID != dayPartID);

                if (otherEquipmentEventPart != null)
                {
                    return gridModel.EquipmentGrid.ShowEditValidationMessage(string.Format(Constants.ITEM_ALREADY_ASSIGNED_ERROR_WITH_URL_LINK,
                                    otherEquipmentEventPart.Equipment.Name,
                                    Url.Action(MVC.Events.Equipment(otherEquipmentEventPart.EventPart.Event.ID, otherEquipmentEventPart.EventPart.ID, selectedTrainingCentres, searchClicked)),
                                    string.Format("{0} {1} {2} ({3})",
                                        otherEquipmentEventPart.EventPart.Event.Activity.Title,
                                        otherEquipmentEventPart.EventPart.Event.Activity.Code,
                                        otherEquipmentEventPart.EventPart.Event.EventNumber + "/" +
                                        otherEquipmentEventPart.EventPart.Event.FinanciaYear.ToString().Substring(2, 2),
                                        otherEquipmentEventPart.EventPart.Name)));
                }

                bool shouldCommit = false;

                //is there an existing record?
                if (equipmentEventPart != null)
                {
                    Mapper.Map(equipmentEventModel, equipmentEventPart);

                    //have we unchecked the booked checkbox?
                    if (!equipmentEventModel.Booked)
                    {
                        UnitOfWork.EquipmentEventParts.Delete(equipmentEventPart);
                    }
                    else
                    {
                        UnitOfWork.EquipmentEventParts.Update(equipmentEventPart);
                    }

                    shouldCommit = true;
                }
                else if (equipmentEventModel.Booked) //no existing record, create new one
                {
                    // check that the equuipment has no overlapping unavailability period defined
                    var unavailabilePeriods = UnitOfWork.EquipmentUnavailablePeriods.SelectFilteredList(p =>
                        p.EquipmentID == equipmentEventModel.ID &&
                        eventPart.Date >= p.StartDate && (eventPart.Date <= p.EndDate || p.EndDate == null) &&
                        (eventPart.DayType == (int)EventPartType.FullDay ||
                         p.DayTypeID == (int)EventPartType.FullDay ||
                         eventPart.DayType == p.DayTypeID));

                    if (unavailabilePeriods.Any())
                    {
                        return gridModel.EquipmentGrid.ShowEditValidationMessage(Constants.GRID_EVENT_VENUE_UNAVAILABILITY_PERIOD_EXISTS);
                    }

                    equipmentEventPart = new EquipmentEventPart() { DayPartID = dayPartID };
                    Mapper.Map(equipmentEventModel, equipmentEventPart);

                    UnitOfWork.EquipmentEventParts.Insert(equipmentEventPart);

                    shouldCommit = true;
                }

                if (shouldCommit)
                {
                    UnitOfWork.Commit();

                    UnitOfWork.EventParts.ResetResourceStatus(dayPartID);
                    UnitOfWork.Commit();

                    var ep = UnitOfWork.EventParts.SelectFilteredList(x => x.ID == dayPartID).First();
                    UnitOfWork.Events.ResetResourceStatus(ep.EventID, TORUser.FullName);
                    UnitOfWork.Commit();
                }
            }

            return GetEventsEquipmentData(equipmentEventModel.ID, dayPartID, trainingCentres);
        }

        [HttpPost]
        public virtual ActionResult GenerateEvents(GenerateEventsModel model)
        {
            if (ModelState.IsValid)
            {
                //get highest Event ID for this activity in the given financial year
                int eventNumber =
                    UnitOfWork.Events.HighestEventNumberInFinancialYear(model.ActivityID, model.FinancialYear) + 1;

                //get the activity to base the events on
                var a = UnitOfWork.Activities.SelectBy(x => x.ID == model.ActivityID);
                
                int count = 1;
                while (count <= model.NumberofEvents)
                {
                    //create a new event based on the activity
                    var e = new Event
                    {
                        EventNumber = eventNumber,
                        FinanciaYear = model.FinancialYear,
                        ActivityID = model.ActivityID,
                        PriorityID = model.Priority,
                        Resourced = (int)Utility.ResourceStatus.NotResourced,
                        TotalDays = a.TotalDays,
                        DateCreated = DateTime.UtcNow,
                        DateChoice = model.DateChoice,
                        CreatedBy = TORUser.FullName,
                        iTrentDataStale = true,
                        TrainingCentreID = TORUser.DefaultTrainingCentreID
                    };

                    switch ((DateChoice)model.DateChoice)
                    {
                        case DateChoice.Specific:
                            e.SpecificDate = DateTime.Parse(model.SpecificDate);
                            e.Status = (int)EventStatusEnum.Ready;
                            break;
                        case DateChoice.Between:
                            e.DateRangeStart = DateTime.Parse(model.StartDate);
                            e.DateRangeEnd = DateTime.Parse(model.EndDate);
                            e.Status = (int)EventStatusEnum.NotReady;
                            break;
                        case DateChoice.Any:
                            e.Status = (int)EventStatusEnum.NotReady;
                            break;
                    }


                    UnitOfWork.Events.Insert(e);

                    int apCount = 1;

                    DateTime? tempDate = e.SpecificDate;

                    //generate event parts based activity parts
                    foreach (var ap in a.ActivityParts)
                    {
                        //if the activity day part is half day, default to selecting morning
                        int dayType = apCount % 2 == 0 ? (int)EventPartType.Afternoon : (int)EventPartType.Morning;


                        TimeSpan endTime = apCount % 2 == 0
                                               ? TimeSpan.Parse("17:00")
                                               : TimeSpan.Parse("13:00");

                        TimeSpan startTime = apCount % 2 == 0
                                                 ? TimeSpan.Parse("13:01")
                                                 : TimeSpan.Parse("09:00");

                        var ep = new EventPart()
                            {
                                EventID = e.ID,
                                ActivityPartID = ap.ID,
                                Name = ap.Name,
                                DayType = dayType,
                                Status = (int)Utility.ResourceStatus.NotResourced,
                                StartTime = startTime,
                                EndTime = endTime,
                                Date = tempDate
                            };

                        UnitOfWork.EventParts.Insert(ep);
                        apCount++;

                        //if the force event on specific date option has been set, increment the day (morning/afternoon dependant)
                        if (tempDate != null)
                        {
                            if (apCount % 2 != 0)
                            {
                                tempDate = tempDate.Value.AddDays(1);
                            }
                        }
                    }

                    UnitOfWork.Commit();

                    eventNumber++;
                    Console.WriteLine(count);
                    count++;
                }

                return Json(new
                {
                    success = true,
                });
            }
            else
            {
                string errorMessage = "";

                var errorList = ModelState.Values.ToList();
                foreach (var modelState in errorList)
                {
                    if (modelState.Errors.Count > 0)
                    {
                        foreach (var e in modelState.Errors)
                        {
                            errorMessage = errorMessage + e.ErrorMessage + Environment.NewLine;
                        }
                    }
                }

                return Json(new
                    {
                        success = false,
                        Error = errorMessage
                    });
            }
        }


        [HttpPost]
        public virtual JsonResult BriefSummary(int id)
        {
            var e = UnitOfWork.Events.SelectBy(x => x.ID == id);

            return Json(
                new
                    {
                        EventName = e.Activity.Title,
                        ID = id,
                        TotalParts = e.EventParts.Count(),
                        TotalPartsFullResourced = e.EventParts.Count(y => y.Status == (int)Utility.ResourceStatus.FullyResourced),
                        Status = e.EventStatus.Title,
                        EventCode = e.Activity.Code
                    }

                );
        }

        public virtual ActionResult Audit(int id)
        {
            var eam = new EventAuditModel(Url.Action(MVC.Events.GetAuditData(id)))
                {
                    ID = id
                };

            var e = UnitOfWork.Events.GetEvent(x => x.ID == id);
            Mapper.Map(e, eam);

            return View(eam);
        }

        public virtual JsonResult GetAuditData(int id)
        {
            var gridModel = new EventAuditModel(Url.Action(MVC.Events.GetAuditData(id)));

            IQueryable<EventStatusHistoryModel> eventsList = UnitOfWork.EventStatusHistory.GetEventHistory(id);

            return gridModel.StatusHistoryGrid.DataBind(eventsList);
        }

        [TOREditAuthorise]
        public virtual JsonResult GetEventsPendingExportCounts(int SelectedFinancialYear)
        {
            int readyEvents = UnitOfWork.Events.SelectFilteredList(e =>
                e.Status == (int)EventStatusEnum.Ready &&
                e.iTrentDataStale &&
                e.FinanciaYear == SelectedFinancialYear).Count();

            int cancelledEvents = UnitOfWork.Events.SelectFilteredList(e =>
                e.Status == (int)EventStatusEnum.Cancelled &&
                e.iTrentDataStale &&
                e.FinanciaYear == SelectedFinancialYear).Count();

            int scheduledEvents = UnitOfWork.Events.SelectFilteredList(e =>
                e.Status == (int)EventStatusEnum.Scheduled &&
                e.iTrentDataStale &&
                e.FinanciaYear == SelectedFinancialYear).Count();

            var data = new
            {
                ReadyCount = readyEvents,
                CancelledCount = cancelledEvents,
                ScheduledCount = scheduledEvents
            };

            return Json(data, JsonRequestBehavior.AllowGet);
        }

        [TOREditAuthorise]
        public virtual JsonResult AddEquipmentToEventPart(int equipmentID, int eventPartID)
        {
            bool isAssigned = UnitOfWork.EquipmentEventParts.SelectFilteredList(x => x.EventPart.ID == eventPartID &&
                                                                                 x.EquipmentID == equipmentID).Count() > 0 ? true : false;

            if (!isAssigned)
            {
                var eep = new EquipmentEventPart()
                {
                    DayPartID = eventPartID,
                    EquipmentID = equipmentID
                };

                UnitOfWork.EquipmentEventParts.Insert(eep);

                UnitOfWork.Commit();

                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }

        [TOREditAuthorise]
        public virtual JsonResult AddVenueToEventPart(int eventPartID, int venueID)
        {
            bool isAssigned = UnitOfWork.VenueEventParts.SelectFilteredList(x => x.EventPart.ID == eventPartID &&
                                                                                 x.VenueID == venueID).Count() > 0 ? true : false;

            if (!isAssigned)
            {
                var vep = new VenueEventPart()
                {
                    DayPartID = eventPartID,
                    VenueID = venueID
                };

                UnitOfWork.VenueEventParts.Insert(vep);

                UnitOfWork.Commit();

                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }
    }
}
