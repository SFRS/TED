﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Web.Mvc;
using LinqKit;
using SFR.TOR.Data;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.Utility;
using SFR.TOR.ViewModels;
using SFR.TOR.Web.Filters;
using Trirand.Web.Mvc;
using AutoMapper;
using ActivityPartType = SFR.TOR.Utility.ActivityPartType;
using ActivityStatus = SFR.TOR.Utility.ActivityStatus;
using EventPartType = SFR.TOR.Utility.EventPartTypeEnum;
using System.Text;

namespace SFR.TOR.Web.Controllers
{
	[TORUserAuthorisation]
	public partial class ActivitiesController : BaseController
	{
		public ActivitiesController(ITORUnitOfWork unitOfWork)
			: base(unitOfWork)
		{
		}

		public virtual ActionResult Index(string searchTerms)
		{
			var am = new ActivitiesModel(Url.Action(Actions.GetActivitiesData(searchTerms, "")), GetSectionDataForFilter(), GetActivityStatusDataForFilter())
			{
				FinancialYears = GetFinancialYearSelectList()
			};

			return View(am);
		}

		public virtual JsonResult GetActivitiesData(string searchTerms, string fidx)
		{
			var gridModel = new ActivitiesModel(Url.Action(Actions.GetActivitiesData(searchTerms, fidx)), GetSectionDataForFilter(), GetActivityStatusDataForFilter());

			JQGridState gridState = gridModel.Activities.GetState();
			Session["gridState"] = gridState;

			Expression<Func<Activity, bool>> predicate = null;
			Expression<Func<Activity, bool>> mainPredicate = PredicateBuilder.True<Activity>();

			if (!string.IsNullOrEmpty(searchTerms))
			{
				predicate = PredicateBuilder.False<Activity>();
				predicate = predicate.Or(p => p.Description.Contains(searchTerms));
				predicate = predicate.Or(p => p.Code.Contains(searchTerms));
				predicate = predicate.Or(p => p.Title.Contains(searchTerms));
				predicate = predicate.Or(p => p.Section.Title.Contains(searchTerms));
			}

			//hide Obsolete by default (Status is null) OR if All selected 
			if (gridState.QueryString["Status"] == null ||
				(gridState.QueryString["Status"] != null && gridState.QueryString["Status"] == "All")
			  )
			{
				mainPredicate = mainPredicate.And(p => !p.ActivityStatus.Title.Contains("Obsolete"));
			}

			if (predicate != null)
			{
				mainPredicate = mainPredicate.And(predicate.Expand());
			}

			IQueryable<ActivityModel> activities = UnitOfWork.Activities.GetActivities(mainPredicate);


			return gridModel.Activities.DataBind(activities.AsQueryable());
		}

		public virtual JsonResult GetVenueData(int ActivityPartID)
		{
			var gridModel = new DayVenuesModel(Url.Action(Actions.GetVenueData(ActivityPartID)),
												Url.Action("EditVenueCategory"), ActivityPartID); //todo: convert to T4MVC?


			var venueTagActivityParts = UnitOfWork.VenueTagActivityPart.GetVenueActivityPartView(ActivityPartID);

			return gridModel.DayVenueGrid.DataBind(venueTagActivityParts.AsQueryable());
		}

		[TOREditAuthorise]
		public virtual ActionResult AddVenueCategory(CreateVenueCategoryModel model)
		{
			var v = new VenueTagActivityPart();
			Mapper.Map(model, v);
			UnitOfWork.VenueTagActivityPart.Insert(v);
			UnitOfWork.Commit();

			var activityPart = UnitOfWork.ActivityDayPart.SelectBy(x => x.ID == model.ActivityPartID);

			var affectedEventParts = UnitOfWork.EventParts.SelectFilteredList(
						   PredicateLibrary.FutureEventPartsBasedOnActivityTemplatePredicate(model.ActivityPartID));
			foreach (var affectedEventPart in affectedEventParts)
			{
				UnitOfWork.EventParts.ResetResourceStatus(affectedEventPart.ID);
			}

			UnitOfWork.Commit();

			var affectedEvents = UnitOfWork.Events.SelectFilteredList(
				PredicateLibrary.FutureEventsBasedOnActivityTemplatePredicate(activityPart.ActivityID));
			foreach (var affectedEvent in affectedEvents)
			{
				UnitOfWork.Events.ResetResourceStatus(affectedEvent.ID, TORUser.FullName);
			}
			UnitOfWork.Commit();

			return RedirectToAction(MVC.Activities.Venues(model.ID));
		}

		[TOREditAuthorise]
		public virtual ActionResult AddEquipmentCategory(CreateEquipmentCategoryModel model)
		{
			var e = new EquipmentTagActivityPart();
			Mapper.Map(model, e);
			UnitOfWork.EquipmentTagActivityPart.Insert(e);
			UnitOfWork.Commit();

			var activityPart = UnitOfWork.ActivityDayPart.SelectBy(x => x.ID == model.ActivityPartID);

			var affectedEventParts = UnitOfWork.EventParts.SelectFilteredList(
						   PredicateLibrary.FutureEventPartsBasedOnActivityTemplatePredicate(model.ActivityPartID));
			foreach (var affectedEventPart in affectedEventParts)
			{
				UnitOfWork.EventParts.ResetResourceStatus(affectedEventPart.ID);
			}

			UnitOfWork.Commit();

			var affectedEvents = UnitOfWork.Events.SelectFilteredList(
				PredicateLibrary.FutureEventsBasedOnActivityTemplatePredicate(activityPart.ActivityID));
			foreach (var affectedEvent in affectedEvents)
			{
				UnitOfWork.Events.ResetResourceStatus(affectedEvent.ID, TORUser.FullName);
			}
			UnitOfWork.Commit();

			return RedirectToAction(MVC.Activities.Equipment(model.ID));
		}

		public virtual JsonResult GetEquipmentData(int ActivityPartID)
		{
			var gridModel = new DayEquipmentModel(Url.Action(Actions.GetEquipmentData(ActivityPartID)),
													Url.Action("EquipmentCategory_EditRow"), ActivityPartID);

			var etaps = UnitOfWork.EquipmentTagActivityPart.GetEquipmentActivityPartView(ActivityPartID);

			return gridModel.DayEquipmentGrid.DataBind(etaps);
		}

		public virtual JsonResult GetInstructors(int ActivityID)
		{
			var gridModel = new ResourcesInstructorsModel(
				Url.Action(Actions.GetInstructors(ActivityID)),
				Url.Action(Actions.GetDayParts(ActivityID)),
				Url.Action("EditEligibleInstructorsForActivity", new { ActivityID = ActivityID }),
				Url.Action("EditActivityPartInstructorLevel"),
				GetSectionDataForFilter()
				);

			var instructorActivityDayParts =
				UnitOfWork.EventPartResources.GetAllInstructorActivityDayParts(ActivityID, TORUser.ResourceDisplayTrainingCentreID);

			return gridModel.EligibleInstructors.DataBind(instructorActivityDayParts.AsQueryable());
		}

		public virtual JsonResult GetDayPartsForActivity(int ActivityID)
		{
			var gridModel = new ActivityTemplateDaysModel(
				Url.Action(Actions.GetDayPartsForActivity(ActivityID)),
				Url.Action("EditActivityPart"),
				GetDayItems());

			var activityDayParts = UnitOfWork.ActivityDayPart.SelectFilteredList(x => x.ActivityID == ActivityID);

			return gridModel.ActivityParts.DataBind(activityDayParts);
		}


		//used by Instructors page
		public virtual JsonResult GetDayParts(int ActivityID)
		{
			var gridModel = new ResourcesInstructorsModel(
				Url.Action(Actions.GetInstructors(ActivityID)),
				Url.Action(Actions.GetDayParts(ActivityID)),
				Url.Action("EditEligibleInstructorsForActivity", new { ActivityID = ActivityID }),
				Url.Action("EditActivityPartInstructorLevel"),
				GetSectionDataForFilter()
				);

			var adps = UnitOfWork.ActivityPartInstructorLevel.GetActivityPartInstructorLevelList(ActivityID);

			return gridModel.DayPartInstructorNumbers.DataBind(adps);
		}

		// GET: /Activities/Summary/5
		public virtual ActionResult Summary(int id)
		{
			var a = UnitOfWork.Activities.GetActivity(PredicateLibrary.GetActivityTemplateIDPredicate(id));
			List<ActivityPart> activityDayParts = UnitOfWork.ActivityDayPart.SelectFilteredList(x => x.ActivityID == id).ToList();

			var activityPartSummaries = new List<ActivityPartSummary>();
			Mapper.Map(activityDayParts, activityPartSummaries);

			var asm = new ActivitySummaryModel()
			{
				ActivitiesPartSummaries = activityPartSummaries
			};

			//map Activity object onto the view model
			Mapper.Map(a, asm);

			asm.FinancialYears = GetFinancialYearSelectList();

			return View(asm);
		}

		// POST: /Activities/Create
		[HttpPost]
		[TOREditAuthorise]
		public virtual ActionResult Create(ActivityEditModel model)
		{
			var at = Mapper.Map<ActivityEditModel, Activity>(model);

			UnitOfWork.Activities.Insert(at);

			int days = (int)Math.Floor(model.TotalDays) * 2;

			int count = 1;
			while (count <= days)
			{
				UnitOfWork.ActivityDayPart.Insert(new ActivityPart()
				{
					DayTypeID = (int)ActivityPartType.HalfDay,
					Name = string.Format("Part {0}", count)
				});

				count++;
			}

			//do we have a .5 to deal with?
			if (model.TotalDays * 2 - (double)days > 0)
			{
				UnitOfWork.ActivityDayPart.Insert(new ActivityPart()
				{
					DayTypeID = (int)ActivityPartType.HalfDay,
					Name = string.Format("Part {0}", count)
				});
			}

			UnitOfWork.Commit();

			var adps = UnitOfWork.ActivityDayPart.SelectFilteredList(x => x.ActivityID == at.ID);

			//now create a level row for each activity part
			foreach (var activityPart in adps)
			{
				UnitOfWork.ActivityPartInstructorLevel.Insert(new ActivityPartInstructorLevel()
				{
					ActivityPartID = activityPart.ID,
					InstructorCount = 0,
					LeadsCount = 0,
					ShadowCount = 0,
					AssessorCount = 0,
					SpecialistCount = 0
				});
			}

			UnitOfWork.Commit();

			var buttonClicked = Request["button"];
			switch (buttonClicked)
			{
				case "save":
					return RedirectToAction(MVC.Activities.Edit(at.ID));
				case "saveReturn":
					return RedirectToAction(MVC.Activities.Index());
				case "saveThenNew":
					return RedirectToAction(MVC.Activities.Create());
				default:
					return RedirectToAction(MVC.Activities.Edit(at.ID));
			}
		}

		// GET: /Activities/Create
		public virtual ActionResult Create()
		{
			return View(
				new ActivityEditModel
				{
					SectionData = GetSectionData(),
					ActivityStatusData = GetActivityStatusData(),
					ActivityStatusID = (int)ActivityStatus.Incomplete
				}
			);
		}

		// GET: /Activities/Edit
		public virtual ActionResult Edit(int id)
		{
			//get the activity template by ID
			var a = UnitOfWork.Activities.GetActivity(PredicateLibrary.GetActivityTemplateIDPredicate(id));

			//map to view model
			var aem = Mapper.Map<ActivityModel, ActivityEditModel>(a);
			ViewBag.HasWriteAccess = (TORUser.TORRole > TORRole.User);

			//fill dropdowns
			aem.SectionData = GetSectionData();
			aem.ActivityStatusData = GetActivityStatusData();

			return View(aem);
		}

		// POST: /Activities/Edit
		[HttpPost]
		[TOREditAuthorise]
		public virtual ActionResult Edit(ActivityEditModel model)
		{
			//get the Activity Template to update
			var at = UnitOfWork.Activities.SelectBy(PredicateLibrary.GetActivityTemplateIDPredicate(model.ID));

			if (at.TotalDays < model.TotalDays)
			{
				//increasing the number of days, simply block all future events
				UnitOfWork.Events.ProcessDayCountIncreasedActivityTemplate(at.ID, TORUser.FullName, model.TotalDays);
				
				if (model.ActivityStatusID == (int)ActivityStatus.Complete)
				{
					//set activity status to incomplete as the user needs to add resource data
					model.ActivityStatusID = (int)ActivityStatus.Incomplete;
				}
			}
			else if (at.TotalDays > model.TotalDays)
			{
				//decreasing total days. All events are now simply over resourced
				UnitOfWork.Events.ProcessDayCountReducedActivityTemplate(at.ID, TORUser.FullName, model.TotalDays);

				if (model.ActivityStatusID == (int)ActivityStatus.Complete)
				{
					//set activity status to incomplete as the user may need to adjust resource data
					model.ActivityStatusID = (int)ActivityStatus.Incomplete;
				}
			}

			// If the activity title/code changes, apply the EventIdentificationChanged trigger
			if (!model.Code.Equals(at.Code) || !model.Title.Equals(at.Title))
			{
				var events = UnitOfWork.Events.SelectFilteredList(e => e.ActivityID == model.ID);
				foreach (var e in events)
				{
					UnitOfWork.Events.UpdateStatus(e.ID, Trigger.EventIdentificationChanged, TORUser.FullName);
					UnitOfWork.Events.Update(e);
				}
			}
			//map user input from view model
			Mapper.Map(model, at);

			//update DB
			UnitOfWork.Activities.Update(at);
			UnitOfWork.Commit();

			//get the activity template by ID
			var a = UnitOfWork.Activities.GetActivity(PredicateLibrary.GetActivityTemplateIDPredicate(model.ID));

			//map to view model
			var aem = Mapper.Map<ActivityModel, ActivityEditModel>(a);

			//fill dropdowns
			aem.SectionData = GetSectionData();
			aem.ActivityStatusData = GetActivityStatusData();

			return Content("SAVED", "text/html");
		}

		// GET: /Activities/Instructors/5
		public virtual ActionResult Instructors(int id)
		{
			//get the activity template by ID
			var a = UnitOfWork.Activities.GetActivity(PredicateLibrary.GetActivityTemplateIDPredicate(id));

			var resourcesInstructorsModel = new ResourcesInstructorsModel(
				Url.Action(Actions.GetInstructors(id)),
				Url.Action(Actions.GetDayParts(id)),
				Url.Action("EditEligibleInstructorsForActivity", new { ActivityID = id }),         //todo: convert to T4MVC?
				Url.Action("EditActivityPartInstructorLevel"),                                       //todo: convert to T4MVC?
				GetSectionDataForFilter()
				);

			resourcesInstructorsModel.DayPartInstructorNumbers.Columns[7].Visible = TORUser.TORRole >= TORRole.Editor;  //display edit column only if we are an Editor or higher 
			resourcesInstructorsModel.EligibleInstructors.Columns[8].Visible = TORUser.TORRole >= TORRole.Editor;       //display edit column only if we are an Editor or higher 

			Mapper.Map(a, resourcesInstructorsModel);

			return View(resourcesInstructorsModel);
		}

		// GET: /Activities/Days/5
		public virtual ActionResult Days(int id)
		{
			//get the activity template by ID
			var a = UnitOfWork.Activities.GetActivity(PredicateLibrary.GetActivityTemplateIDPredicate(id));

			var m = new ActivityTemplateDaysModel(
				Url.Action(Actions.GetDayPartsForActivity(id)),
				Url.Action("EditActivityPart", new { ActivityID = id }),         //todo: convert to T4MVC?
				GetDayItems())
			{
				ActivityModel = a,
				DaysAssigned = GetCount(id)
			};

			m.ActivityParts.Columns[3].Visible = TORUser.TORRole >= TORRole.Editor; //display edit column only if we are an Editor or higher 

			return View(m);
		}

		// GET: /Activities/Venues/5
		public virtual ActionResult Venues(int id)
		{
			//get the activity template by ID
			var a = UnitOfWork.Activities.GetActivity(PredicateLibrary.GetActivityTemplateIDPredicate(id));

			IQueryable<ActivityPart> activityParts = UnitOfWork.ActivityDayPart.SelectFilteredList(x => x.ActivityID == id);

			var dayVenueModels = new List<DayVenuesModel>();

			foreach (var activityDayPart in activityParts)
			{
				var dvm = new DayVenuesModel(
					Url.Action(Actions.GetVenueData(activityDayPart.ID)),
					Url.Action("EditVenueCategory"), activityDayPart.ID) //todo: convert to T4MVC?
				{
					Title = activityDayPart.Name
				};

				dvm.DayVenueGrid.Columns[3].Visible = TORUser.TORRole >= TORRole.Editor;       //display edit column only if we are an Editor or higher 

				dayVenueModels.Add(dvm);

			}

			var rvm = new ResourcesVenuesModel()
			{
				DayVenueData = dayVenueModels,
				VenueTags = GetVenueTagsSelectList()
			};
			Mapper.Map(a, rvm);


			return View(rvm);
		}

		public virtual JsonResult GetVenueTagsForDropDown(int activityPartID)
		{

			var existingSelectedTags = UnitOfWork.VenueTagActivityPart.SelectFilteredList(x => x.ActivityPartID == activityPartID).Select(y => y.VenueTagID).ToList();
			var tagsToSelectFrom = UnitOfWork.VenueTags.SelectAll().ToList();

			tagsToSelectFrom.RemoveAll(x => existingSelectedTags.Contains(x.ID));

			return Json(tagsToSelectFrom.Select(x => new { x.ID, x.Name }).OrderBy(x => x.Name).ToList(), JsonRequestBehavior.AllowGet);
		}

		public virtual JsonResult GetEquipmentTagsForDropDown(int activityPartID)
		{

			var existingSelectedTags = UnitOfWork.EquipmentTagActivityPart.SelectFilteredList(x => x.ActivityPartID == activityPartID).Select(y => y.EquipmentTagID).ToList();
			var tagsToSelectFrom = UnitOfWork.EquipmentTags.SelectAll().ToList();

			tagsToSelectFrom.RemoveAll(x => existingSelectedTags.Contains(x.ID));

			return Json(tagsToSelectFrom.Select(x => new { x.ID, x.Name }).OrderBy(x => x.Name).ToList(), JsonRequestBehavior.AllowGet);
		}



		// GET: /Activities/Equipment/5
		public virtual ActionResult Equipment(int id)
		{
			var a = UnitOfWork.Activities.GetActivity(PredicateLibrary.GetActivityTemplateIDPredicate(id));

			IQueryable<ActivityPart> activityParts = UnitOfWork.ActivityDayPart.SelectFilteredList(x => x.ActivityID == id);

			var dayEquipmentModels = new List<DayEquipmentModel>();

			foreach (var activityDayPart in activityParts)
			{
				var dem = new DayEquipmentModel(
					Url.Action(Actions.GetEquipmentData(activityDayPart.ID)),
					Url.Action("EquipmentCategory_EditRow"), activityDayPart.ID) //todo: convert to T4MVC?
				{
					Title = activityDayPart.Name
				};

				dem.DayEquipmentGrid.Columns[3].Visible = TORUser.TORRole >= TORRole.Editor;       //display edit column only if we are an Editor or higher 

				dayEquipmentModels.Add(dem);



			}

			var rem = new ResourcesEquipmentModel()
			{
				DayEquipmentData = dayEquipmentModels,
			};

			Mapper.Map(a, rem);

			return View(rem);
		}

		[HttpPost]
		public double DayPartGetCount(int id)
		{
			//HACK: would prefer to find a better way to do this.
			//      wait to make sure the data has been updated by main row edit
			Thread.Sleep(500);

			return GetCount(id);
		}

		private double GetCount(int id)
		{
			var dayParts = UnitOfWork.ActivityDayPart.SelectFilteredList(x => x.ActivityID == id);

			double count = 0.0;
			foreach (var activityDayPart in dayParts)
			{
				switch (activityDayPart.DayTypeID)
				{
					case 1:
						count = count + 0.5;
						break;
					case 2:
					case 3:
						count = count + 1;
						break;
				}
			}
			return count;
		}
		
		[TOREditAuthorise]
        public virtual ActionResult EditActivityPart(ActivityDayPartModel editedDayPart, int ActivityID)
		{
			var a = UnitOfWork.Activities.GetActivity(PredicateLibrary.GetActivityTemplateIDPredicate(ActivityID));

			var gridModel = new ActivityTemplateDaysModel(
				Url.Action(Actions.GetDayPartsForActivity(ActivityID)),
				Url.Action("EditActivityPart", new { ActivityID = ActivityID }), //todo: convert to T4MVC?
				GetDayItems())
			{
				ActivityModel = a,
				DaysAssigned = GetCount(ActivityID)
			};


			if (gridModel.ActivityParts.AjaxCallBackMode == AjaxCallBackMode.EditRow)
			{
				var activityDayPart = UnitOfWork.ActivityDayPart.SelectBy(x => x.ID == editedDayPart.ID);

				#region - code for dealing with switching from half->full and vice versa
				////has the user changed the day type? eg. morning-> afternoon, then all resources should now be removed
				//if (activityDayPart.DayTypeID != editedDayPart.DayTypeID)
				//{
				//    //we now have to trigger status change in all future events based off this activity
				//    UnitOfWork.Events.ApplyTriggerToMatchingEvents(
				//                        PredicateLibrary.FutureEventsBasedOnActivityTemplatePredicate(activityDayPart.ID), //todo: remove from Service
				//                        Trigger.EventPartDateTypeChanged);

				//    //get all affected Event Parts
				//    var eventParts = UnitOfWork.EventParts.SelectFilteredList(
				//        PredicateLibrary.FutureEventPartsBasedOnActivityTemplatePredicate(activityDayPart.ID)
				//        );

				//    //for all affected event parts, change their day type, remove their resources, and update resourcing status
				//    foreach (var ep in eventParts)
				//    {
				//        UnitOfWork.InstructorEventPart.DeleteAll(x => x.DayPartID == ep.ID);
				//        UnitOfWork.VenueEventParts.DeleteAll(x => x.DayPartID == ep.ID);
				//        UnitOfWork.EquipmentEventParts.DeleteAll(x => x.DayPartID == ep.ID);

				//        ep.DayType = editedDayPart.DayTypeID;
				//        UnitOfWork.EventParts.Update(ep);

				//        //update the event part resource status
				//        UnitOfWork.EventParts.ResetResourceStatus(ep.ID);

				//        //update the event resource status
				//        UnitOfWork.Events.ResetResourceStatus(ep.EventID);
				//    }
				//}
				#endregion

				Mapper.Map(editedDayPart, activityDayPart);

				activityDayPart.DayTypeID = (int)ActivityPartType.HalfDay;

				UnitOfWork.ActivityDayPart.Update(activityDayPart);
				UnitOfWork.Commit();
			}
			else if (gridModel.ActivityParts.AjaxCallBackMode == AjaxCallBackMode.AddRow)
			{
				var activityDayPart = new ActivityPart();
				Mapper.Map(editedDayPart, activityDayPart);
				activityDayPart.DayTypeID = (int)ActivityPartType.HalfDay;

				//how many day parts do we have for this activity?
				var count = UnitOfWork.ActivityDayPart.SelectFilteredList(x => x.ActivityID == ActivityID).Count();

				//Use this count to name the new day part
				activityDayPart.Name = string.Format("Part {0}", count + 1);
				activityDayPart.ActivityID = ActivityID;

				UnitOfWork.ActivityDayPart.Insert(activityDayPart);
				UnitOfWork.Commit();

				//now add ActivityPartInstructorLevel for the new ActivityPart
				UnitOfWork.ActivityPartInstructorLevel.Insert(new ActivityPartInstructorLevel()
					{
						ActivityPartID = activityDayPart.ID,
						InstructorCount = 0,
						LeadsCount = 0,
						ShadowCount = 0,
						AssessorCount = 0,
						SpecialistCount = 0
					});

				//add a new event part based on this activity part to all future events and then block the event
				var events = UnitOfWork.Events.SelectFilteredList(PredicateLibrary.FutureEventsBasedOnActivityTemplatePredicate(ActivityID));

				if (events.Any())
				{
					//block all future events as we now have an extra day that needs resourced
					UnitOfWork.Events.ApplyTriggerToMatchingEvents(
										PredicateLibrary.FutureEventsBasedOnActivityTemplatePredicate(ActivityID),
										Trigger.EventPartAdded, TORUser.FullName);

					int dayType = activityDayPart.DayTypeID == (int)ActivityPartType.FullDay ? (int)EventPartType.FullDay : (int)EventPartType.Morning;
					TimeSpan endTime = dayType == (int)EventPartType.FullDay
										 ? TimeSpan.Parse("17:00")
										 : TimeSpan.Parse("13:00");

					foreach (var e in events)
					{
						UnitOfWork.EventParts.Insert(new EventPart()
						{
							EventID = e.ID,
							ActivityPartID = activityDayPart.ID,
							Name = activityDayPart.Name,
							DayType = dayType,
							Status = (int)Utility.ResourceStatus.NotResourced,
							StartTime = TimeSpan.Parse("09:00"),
							EndTime = endTime
						});
					}
				}

				UnitOfWork.Commit();
			}
			else if (gridModel.ActivityParts.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
			{
				var activityDayPart = UnitOfWork.ActivityDayPart.SelectBy(x => x.ID == editedDayPart.ID);

				// prevent deletion of activity part if any past events exist
				var pastEventPartsExist = activityDayPart.EventParts.Any(ep => ep.Date <= DateTime.Now);

                if (pastEventPartsExist)
                    return gridModel.ActivityParts.ShowEditValidationMessage(Constants.GRID_ACTIVITY_PART_IN_USE_DELETE_ERROR);

				//First, delete all event parts that were based on this activity part
				//get all affected Event Parts
				var eventParts = UnitOfWork.EventParts.SelectFilteredList(
					PredicateLibrary.FutureEventPartsBasedOnActivityTemplatePredicate(activityDayPart.ID)
					);

				//block all future events as we now have one less day
				UnitOfWork.Events.ApplyTriggerToMatchingEvents(
									PredicateLibrary.FutureEventsBasedOnActivityTemplatePredicate(ActivityID),
									Trigger.EventPartRemoved, TORUser.FullName);

				if (eventParts.Any())
				{
					//for all affected event parts, remove their resources, and update resourcing status
					foreach (var ep in eventParts)
					{
						UnitOfWork.InstructorEventPart.DeleteAll(x => x.DayPartID == ep.ID);
						UnitOfWork.VenueEventParts.DeleteAll(x => x.DayPartID == ep.ID);
						UnitOfWork.EquipmentEventParts.DeleteAll(x => x.DayPartID == ep.ID);

						//delete the event part
						UnitOfWork.EventParts.Delete(ep);

						//update the event resource status
						UnitOfWork.Events.ResetResourceStatus(ep.EventID, TORUser.FullName);
					}

					UnitOfWork.Commit();
				}

				//Now delete anything assigned to this activity part
				var apil = UnitOfWork.ActivityPartInstructorLevel.SelectBy(x => x.ActivityPartID == activityDayPart.ID);
				UnitOfWork.ActivityPartInstructorLevel.Delete(apil);

				var vtaps = UnitOfWork.VenueTagActivityPart.SelectFilteredList(x => x.ActivityPartID == activityDayPart.ID).ToList();
				vtaps.ForEach(x => UnitOfWork.VenueTagActivityPart.Delete(x));

				var etaps = UnitOfWork.EquipmentTagActivityPart.SelectFilteredList(x => x.ActivityPartID == activityDayPart.ID).ToList();
				etaps.ForEach(x => UnitOfWork.EquipmentTagActivityPart.Delete(x));

				//delete the Activity part
				UnitOfWork.ActivityDayPart.Delete(activityDayPart);

				UnitOfWork.Commit();

				//finally, recalculate day names
				int count = 1;
				var activityParts = UnitOfWork.ActivityDayPart.SelectFilteredList(x => x.ActivityID == ActivityID).OrderBy(x => x.ID).ToList();
				activityParts.ForEach(x => x.Name = string.Format("Part {0}", count++));
				activityParts.ForEach(x => UnitOfWork.ActivityDayPart.Update(x));
				UnitOfWork.Commit();
			}

            return null;
		}

		[TOREditAuthorise]
		public virtual ActionResult EditActivityPartInstructorLevel(ActivityPartInstructorLevelModel model)
		{
			var gridModel = new ResourcesInstructorsModel("", "", "", "", null);

			if (!ModelState.IsValid)
			{
				var combinedError = String.Join("<br>", ModelState.Keys.SelectMany(key => ModelState[key].Errors).Select(e => e.ErrorMessage));
				return gridModel.DayPartInstructorNumbers.ShowEditValidationMessage(combinedError);
			}

			var apil = UnitOfWork.ActivityPartInstructorLevel.SelectBy(x => x.ID == model.ID);

			//first get the activity part so we can get its ID
			var activityPart = UnitOfWork.ActivityDayPart.SelectBy(x => x.ID == apil.ActivityPartID);

			//has a count increased? if so, we need to block any future events
			if (model.InstructorCount > apil.InstructorCount ||
				model.AssessorCount > apil.AssessorCount ||
				model.LeadsCount > apil.LeadsCount ||
				model.ShadowCount > apil.ShadowCount ||
				model.SpecialistCount > apil.SpecialistCount
				)
			{

				//now use the activity parts ActivityID to find all future events and block them
				UnitOfWork.Events.ApplyTriggerToMatchingEvents(
					PredicateLibrary.FutureEventsBasedOnActivityTemplatePredicate(activityPart.ActivityID),
					Trigger.InstructorRequirementIncreased, TORUser.FullName);

			}

			if (model.InstructorCount < apil.InstructorCount ||
				model.AssessorCount < apil.AssessorCount ||
				model.LeadsCount < apil.LeadsCount ||
				model.ShadowCount < apil.ShadowCount ||
				model.SpecialistCount < apil.SpecialistCount
				)
			{
				//now use the activity parts ActivityID to find all future events and block them
				UnitOfWork.Events.ApplyTriggerToMatchingEvents(
					PredicateLibrary.FutureEventsBasedOnActivityTemplatePredicate(activityPart.ActivityID),
					Trigger.InstructorRequirementDecreased, TORUser.FullName);
			}

			Mapper.Map(model, apil);

			UnitOfWork.ActivityPartInstructorLevel.Update(apil);

			var affectedEventParts = UnitOfWork.EventParts.SelectFilteredList(
				   PredicateLibrary.FutureEventPartsBasedOnActivityTemplatePredicate(apil.ActivityPartID));

			var affectedEventPartIDs = affectedEventParts.Select(ep => ep.ID);

			//remove the instructors from the event part where the count == 0 (no instructors required)
			UnitOfWork.InstructorEventPart.DeleteAll(iep => 
				affectedEventPartIDs.Contains(iep.DayPartID) && 
				((iep.IsInstructor && model.InstructorCount == 0) ||
				 (iep.IsAssessor && model.AssessorCount == 0) ||
				 (iep.IsLead && model.LeadsCount == 0) ||
				 (iep.IsShadow && model.ShadowCount == 0) ||
				 (iep.IsSpecialist && model.SpecialistCount == 0)));

			foreach (var affectedEventPart in affectedEventParts)
			{
				UnitOfWork.EventParts.ResetResourceStatus(affectedEventPart.ID);
			}

			UnitOfWork.Commit();

			var affectedEvents = UnitOfWork.Events.SelectFilteredList(
				PredicateLibrary.FutureEventsBasedOnActivityTemplatePredicate(activityPart.ActivityID));
			foreach (var affectedEvent in affectedEvents)
			{
				UnitOfWork.Events.ResetResourceStatus(affectedEvent.ID, TORUser.FullName);
			}
			UnitOfWork.Commit();

			return RedirectToAction(MVC.Activities.ActionNames.Instructors, new { id = activityPart.ActivityID });
		}

        [TOREditAuthorise]
        public void EditEligibleInstructorsForActivity(InstructorActivityModel editedIAM, int ActivityID)
        {
            var eifa = UnitOfWork.EligibleInstructorsForActivity
                        .SelectBy(x => x.InstructorID == editedIAM.ID && x.ActivityTemplateID == ActivityID);

            var instructorID = editedIAM.ID;
            if (eifa != null)
            {

                bool eligibilityRemoved =
                  (eifa.IsLead && !editedIAM.IsLead) ||
                  (eifa.IsInstructor && !editedIAM.IsInstructor) ||
                  (eifa.IsAssessor && !editedIAM.IsAssessor) ||
                  (eifa.IsShadow && !editedIAM.IsShadow) ||
                  (eifa.IsSpecialist && !editedIAM.IsSpecialist);

                if (eligibilityRemoved)
                {
                    //user is removing at least one of the instructors eligibilities, find affected InstructorEventParts
                    var ieps = UnitOfWork.InstructorEventPart.GetInstructorEventParts(
                        iep => iep.InstructorID == instructorID &&
                               iep.EventPart.ActivityPart.ActivityID == eifa.ActivityTemplateID)
                        .ToList()
                        .Where(iep => ((iep.IsLead.Value && !editedIAM.IsLead) ||
                                       (iep.IsInstructor.Value && !editedIAM.IsInstructor) ||
                                       (iep.IsAssessor.Value && !editedIAM.IsAssessor) ||
                                       (iep.IsShadow.Value && !editedIAM.IsShadow) ||
                                       (iep.IsSpecialist.Value && !editedIAM.IsSpecialist)))
                        .ToList();

                    if (ieps.Count > 0)
                    {
                        var iepIDs = ieps.Select(iep => iep.ID);

                        //delete the mapping
                        UnitOfWork.InstructorEventPart.DeleteAll(iep => iepIDs.Contains(iep.ID));
                        UnitOfWork.Commit();

                        //process all matches
                        foreach (var iep in ieps)
                        {
                            //reset the event parts resourcing status
                            UnitOfWork.EventParts.ResetResourceStatus(iep.EventPartID);
                            UnitOfWork.Commit();

                            //reset the events resourcing status
                            UnitOfWork.Events.ResetResourceStatus(iep.EventID, TORUser.FullName);
                            UnitOfWork.Commit();
                        }
                    }
                }

                Mapper.Map(editedIAM, eifa);
                UnitOfWork.EligibleInstructorsForActivity.Update(eifa);
            }
            else
            {
                eifa = Mapper.Map<InstructorActivityModel, EligibleInstructorsForActivity>(editedIAM);

                eifa.ActivityTemplateID = ActivityID;
                UnitOfWork.EligibleInstructorsForActivity.Insert(eifa);
            }

            UnitOfWork.Commit();
        }

		[TOREditAuthorise]
		public virtual ActionResult EquipmentCategory_EditRow(EditEquipmentCategoryModel model)
		{
			var gridModel = new DayEquipmentModel("", "", 0);

			if (!ModelState.IsValid && gridModel.DayEquipmentGrid.AjaxCallBackMode != AjaxCallBackMode.DeleteRow)
			{
				var combinedError = String.Join("<br>", ModelState.Keys.SelectMany(key => ModelState[key].Errors).Select(e => e.ErrorMessage));
				return gridModel.DayEquipmentGrid.ShowEditValidationMessage(combinedError);
			}

			var etap = UnitOfWork.EquipmentTagActivityPart.SelectBy(x => x.ID == model.ID);

			//first get the activity part so we can get its ID
			var activityPart = UnitOfWork.ActivityDayPart.SelectBy(x => x.ID == etap.ActivityPartID);

			if (gridModel.DayEquipmentGrid.AjaxCallBackMode == AjaxCallBackMode.EditRow)
			{
				if (model.MinRequired > etap.MinRequired)
				{
					//now use the activity parts ActivityID to find all future events and block them
					UnitOfWork.Events.ApplyTriggerToMatchingEvents(
						PredicateLibrary.FutureEventsBasedOnActivityTemplatePredicate(activityPart.ActivityID),
						Trigger.EquipmentMinNumberIncreased, TORUser.FullName);

					//get all affected Event Parts
					var eventParts = UnitOfWork.EventParts.SelectFilteredList(
						PredicateLibrary.FutureEventPartsBasedOnActivityTemplatePredicate(activityPart.ID)
						);

					//update the resource status for each affected event part
					foreach (var eventPart in eventParts)
					{
						eventPart.Status = (int)Utility.ResourceStatus.PartResourced;
						UnitOfWork.EventParts.Update(eventPart);
					}
				}
				else if (model.MinRequired < etap.MinRequired)
				{
					//now use the activity parts ActivityID to find all future events and block them
					UnitOfWork.Events.ApplyTriggerToMatchingEvents(
						PredicateLibrary.FutureEventsBasedOnActivityTemplatePredicate(activityPart.ActivityID),
						Trigger.EquipmentMinNumberDecreased, TORUser.FullName);
				}

				Mapper.Map(model, etap);
				UnitOfWork.EquipmentTagActivityPart.Update(etap);

			}
			else if (gridModel.DayEquipmentGrid.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
			{
				UnitOfWork.EquipmentTagActivityPart.Delete(etap);

				var affectedEventParts = UnitOfWork.EventParts.SelectFilteredList(
							PredicateLibrary.FutureEventPartsBasedOnActivityTemplatePredicate(activityPart.ID));

				var affectedEventPartIDs = affectedEventParts.Select(ep => ep.ID);

				var affectedEvents = UnitOfWork.Events.SelectFilteredList(
							PredicateLibrary.FutureEventsBasedOnActivityTemplatePredicate(activityPart.ActivityID));

				UnitOfWork.EquipmentEventParts.DeleteAll(eep =>
					affectedEventPartIDs.Contains(eep.DayPartID) && eep.EquipmentTagID == etap.EquipmentTagID);

				UnitOfWork.Commit();

				foreach (var affectedEventPart in affectedEventParts)
				{
					UnitOfWork.EventParts.ResetResourceStatus(affectedEventPart.ID);
				}

				foreach (var affectedEvent in affectedEvents)
				{
					UnitOfWork.Events.ResetResourceStatus(affectedEvent.ID, TORUser.FullName);
				}
			}

			UnitOfWork.Commit();

			return null;
		}

		[TOREditAuthorise]
		public virtual ActionResult EditVenueCategory(EditVenueCategoryModel model)
		{
			var gridModel = new DayVenuesModel("", "", 0);

			if (!ModelState.IsValid && gridModel.DayVenueGrid.AjaxCallBackMode != AjaxCallBackMode.DeleteRow)
			{
				var combinedError = String.Join("<br>", ModelState.Keys.SelectMany(key => ModelState[key].Errors).Select(e => e.ErrorMessage));
				return gridModel.DayVenueGrid.ShowEditValidationMessage(combinedError);
			}

			var vtap = UnitOfWork.VenueTagActivityPart.SelectBy(x => x.ID == model.ID);

			//get the activity part so we can get its ID
			var activityPart = UnitOfWork.ActivityDayPart.SelectBy(x => x.ID == vtap.ActivityPartID);

			if (gridModel.DayVenueGrid.AjaxCallBackMode == AjaxCallBackMode.EditRow)
			{
				if (model.MinRequired > vtap.MinRequired)
				{
					//now use the activity parts ActivityID to find all future events and block them
					UnitOfWork.Events.ApplyTriggerToMatchingEvents(
						PredicateLibrary.FutureEventsBasedOnActivityTemplatePredicate(activityPart.ActivityID),
						Trigger.VenueMinNumberIncreased, TORUser.FullName);

					//get all affected Event Parts
					var eventParts = UnitOfWork.EventParts.SelectFilteredList(
						PredicateLibrary.FutureEventPartsBasedOnActivityTemplatePredicate(activityPart.ID)
						);

					//update the resource status for each affected event part
					foreach (var eventPart in eventParts)
					{
						UnitOfWork.EventParts.ResetResourceStatus(eventPart.ID);
					}
				}
				else if (model.MinRequired < vtap.MinRequired)
				{

					//now use the activity parts ActivityID to find all future events and block them
					UnitOfWork.Events.ApplyTriggerToMatchingEvents(
						PredicateLibrary.FutureEventsBasedOnActivityTemplatePredicate(activityPart.ActivityID),
						Trigger.VenueMinNumberDecreased, TORUser.FullName);
				}

				Mapper.Map(model, vtap);
				UnitOfWork.VenueTagActivityPart.Update(vtap);


				var affectedEventParts = UnitOfWork.EventParts.SelectFilteredList(
						   PredicateLibrary.FutureEventPartsBasedOnActivityTemplatePredicate(activityPart.ID));
				foreach (var affectedEventPart in affectedEventParts)
				{
					UnitOfWork.EventParts.ResetResourceStatus(affectedEventPart.ID);
				}

				UnitOfWork.Commit();

				var affectedEvents = UnitOfWork.Events.SelectFilteredList(
					PredicateLibrary.FutureEventsBasedOnActivityTemplatePredicate(activityPart.ActivityID));
				foreach (var affectedEvent in affectedEvents)
				{
					UnitOfWork.Events.ResetResourceStatus(affectedEvent.ID, TORUser.FullName);
				}
			}
			else if (gridModel.DayVenueGrid.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
			{
				UnitOfWork.VenueTagActivityPart.Delete(vtap);

				var affectedEventParts = UnitOfWork.EventParts.SelectFilteredList(
							PredicateLibrary.FutureEventPartsBasedOnActivityTemplatePredicate(activityPart.ID));

				var affectedEventPartIDs = affectedEventParts.Select(ep => ep.ID);

				var affectedEvents = UnitOfWork.Events.SelectFilteredList(
							PredicateLibrary.FutureEventsBasedOnActivityTemplatePredicate(activityPart.ActivityID));

				UnitOfWork.VenueEventParts.DeleteAll(vep => 
					affectedEventPartIDs.Contains(vep.DayPartID) && vep.VenueTagID == vtap.VenueTagID);

				UnitOfWork.Commit();

				foreach (var affectedEventPart in affectedEventParts)
				{
					UnitOfWork.EventParts.ResetResourceStatus(affectedEventPart.ID);
				}

				foreach (var affectedEvent in affectedEvents)
				{
					UnitOfWork.Events.ResetResourceStatus(affectedEvent.ID, TORUser.FullName);
				}

			}

			UnitOfWork.Commit();
			
			return null;
		}
	}
}
