﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using AutoMapper;
using SFR.TOR.Data;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;
using SFR.TOR.Web.Filters;
using Trirand.Web.Mvc;
using Venue = SFR.TOR.Data.Venue;
using SFR.TOR.Utility;

namespace SFR.TOR.Web.Controllers
{
    [TORUserAuthorisation]
    public partial class VenuesController : BaseController
    {        
        public VenuesController(ITORUnitOfWork unitOfWork): base(unitOfWork)
        {
        }

        public virtual ActionResult Create()
        {
            return View(
                new VenuesCreateModel()
                {
                    TrainingCentreData = GetTrainingCentres(0),
                    VenueGroups = GetAllVenueGroups(0)
                }
            );
        }
        
        [HttpPost]
        [TOREditAuthorise]
        public virtual ActionResult Create(VenuesCreateModel model, string button)
        {
            Venue v = Mapper.Map<VenuesCreateModel, Venue>(model);

            UnitOfWork.Venues.Insert(v);
            UnitOfWork.Commit();
            
            switch (button)
            {
                case "save":
                    return RedirectToAction(MVC.Venues.Edit(v.ID));
                case "saveReturn":
                    return RedirectToAction(MVC.Resources.Venues());
                case "saveThenNew":
                    return RedirectToAction(MVC.Venues.Create());
                default:
                    return RedirectToAction(MVC.Venues.Edit(v.ID));
            }
        }
       
        public virtual ActionResult Edit(int id)
        {
            VenueModel v = UnitOfWork.Venues.GetVenue(id);

            var vem = Mapper.Map<VenueModel, VenuesEditModel>(v);

            vem.TrainingCentres = GetTrainingCentres(v.TrainingCentreID);
             //vem.VenueGroups = GetAllVenueGroups(vem.VenueGroupID);
            vem.VenueGroups = GetAllVenueGroups(v.VenueGroupID);

            return View(vem);
        }

        [HttpPost]
        [TOREditAuthorise]
        public virtual ActionResult Edit(VenuesEditModel model)
        {
            var v = UnitOfWork.Venues.SelectBy(x => x.ID == model.ID);

            Mapper.Map(model, v);

            UnitOfWork.Venues.Update(v);
            UnitOfWork.Commit();
            model.Name = v.Name;
            // Added D Scott for Venues Edit select list
            model.TrainingCentres = GetTrainingCentres(v.TrainingCentreID);
            //
            model.VenueGroups = GetAllVenueGroups(model.VenueGroupID);

            return View(model);
        }

        public virtual ActionResult Availability(int id)
        {
            Venue i = UnitOfWork.Venues.SelectBy(x => x.ID == id);

            var ieam = new VenueUnavailabilityModel(Url.Action(Actions.GetVenueAvailabilityData(id)),
                Url.Action(MVC.Venues.ActionNames.EditAvailability, new { venueID = id }))
            {
                Name = i.Name,
                ID = id
            };

            ieam.Unavailability.Columns[ieam.Unavailability.Columns.Count - 1].Visible = TORUser.TORRole >= TORRole.Editor;
            ieam.Unavailability.ToolBarSettings.ShowAddButton = TORUser.TORRole >= TORRole.Editor;

            return View(ieam);
        }

        public virtual JsonResult GetVenueAvailabilityData(int id)
        {
            var gridModel = new VenueUnavailabilityModel(Url.Action(Actions.GetVenueAvailabilityData(id)),
                Url.Action(MVC.Venues.ActionNames.EditAvailability));

            var venueUnavailablePeriods = UnitOfWork.VenueUnavailablePeriod.GetUnavailabilityReasons(id);

            return gridModel.Unavailability.DataBind(venueUnavailablePeriods.AsQueryable());
        }

        [HttpGet]
        public virtual JsonResult EditAvailabilityCheck(VenueEditAvailabilityModel model)
        {
            //get all instance of the venue against an event part within the given range
            List<VenueEventPart> veps = GetAffectedVenueEventParts(model);

            List<string> affectedEventCodes = veps.Select(iep => iep.EventPart.Event.EventCode).Distinct().OrderBy(s => s).ToList();

            return Json(new
            {
                EventCount = affectedEventCodes.Count,
                EventCodes = affectedEventCodes
            }, JsonRequestBehavior.AllowGet);
        }

        private List<VenueEventPart> GetAffectedVenueEventParts(VenueEditAvailabilityModel model)
        {
            List<VenueEventPart> veps;
            veps = UnitOfWork.VenueEventParts.SelectFilteredList(
                PredicateLibrary.GetVenueEventPartInADateRange(model.VenueID, model.StartDate, model.EndDate, model.DayTypeID)
                ).ToList();

            return veps;
        }

        [TOREditAuthorise]
        public virtual ActionResult EditAvailability(VenueEditAvailabilityModel model)
        {
            var gridModel = new VenueUnavailabilityModel(Url.Action(Actions.GetVenueAvailabilityData(model.VenueID)),
                Url.Action(MVC.Venues.ActionNames.EditAvailability));

            //Validation
            if (gridModel.Unavailability.AjaxCallBackMode == AjaxCallBackMode.AddRow ||
                gridModel.Unavailability.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                if (model.EndDate != null && model.EndDate < model.StartDate)
                {
                    return gridModel.Unavailability.ShowEditValidationMessage(Constants.GRID_OBJECT_AVAILABILITY_START_DATE_EARLIER_THAN_END_DATE_ERROR);
                }

                //validate dates & day type
                if (!(model.StartDate.Equals(model.EndDate)) && model.DayTypeID != (int)SFR.TOR.Utility.EventPartTypeEnum.FullDay)
                {
                    return gridModel.Unavailability.ShowEditValidationMessage(Constants.GRID_VENUES_AVAILABILITY_INVALID_DAY_TYPE_ERROR);
                }

                // Validate against pre-existing unavailable periods
                var today = DateTime.Now.Date;

                //Get all periods between dates where the day type matches what was chosen, or is a full day.

                var data = UnitOfWork.VenueUnavailablePeriod.SelectFilteredList(p =>
                                ((p.StartDate >= model.StartDate && p.StartDate <= model.EndDate) ||
                                ((p.EndDate ?? today) >= model.StartDate && (p.EndDate ?? today) <= model.EndDate) ||
                                (model.StartDate >= p.StartDate && model.StartDate <= (p.EndDate ?? today))) &&
                                p.Venue.ID == model.VenueID &&
                                ((p.DayTypeID == model.DayTypeID || p.DayTypeID == (int)SFR.TOR.Utility.EventPartTypeEnum.FullDay) ||
                                (model.DayTypeID == (int)SFR.TOR.Utility.EventPartTypeEnum.FullDay)) &&
                                model.ID != p.ID); //exclude current record if we are editing

                //If any records exist, then there is a conflict in day types/dates
                if (data.Count() > 0)
                    return gridModel.Unavailability.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_AVAILABILITY_CONFLICTING_DATES_ERROR);

            }
            if (gridModel.Unavailability.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                var vup = UnitOfWork.VenueUnavailablePeriod.SelectBy(x => x.ID == model.ID);

                //does a record exist for this unavailability?
                if (vup != null)
                {
                    ProcessVenueUnavailabilityForEvents(model, vup);

                    //update the record
                    Mapper.Map(model, vup);
                    UnitOfWork.VenueUnavailablePeriod.Update(vup);
                }
                else
                {
                    //insert a new record
                    vup = Mapper.Map<VenueEditAvailabilityModel, VenueUnavailablePeriod>(model);
                    UnitOfWork.VenueUnavailablePeriod.Insert(vup);
                    UnitOfWork.Commit();

                    ProcessVenueUnavailabilityForEvents(model);
                }
            }
            else if (gridModel.Unavailability.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                //insert a new record
                VenueUnavailablePeriod iup = Mapper.Map<VenueEditAvailabilityModel, VenueUnavailablePeriod>(model);
                UnitOfWork.VenueUnavailablePeriod.Insert(iup);
                UnitOfWork.Commit();
                ProcessVenueUnavailabilityForEvents(model);
            }
            else if (gridModel.Unavailability.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                var vup = UnitOfWork.VenueUnavailablePeriod.SelectBy(x => x.ID == model.ID);
                UnitOfWork.VenueUnavailablePeriod.Delete(vup);
            }

            UnitOfWork.Commit();
            return RedirectToAction(MVC.Venues.ActionNames.GetVenueAvailabilityData, new { id = model.VenueID });
        }

        private void ProcessVenueUnavailabilityForEvents(VenueEditAvailabilityModel model, VenueUnavailablePeriod vup)
        {
            //only process where the dates have moved past original boundaries
            if (model.StartDate < vup.StartDate || model.EndDate > vup.EndDate)
            {
                ProcessVenueUnavailabilityForEvents(model);
            }
        }

        private void ProcessVenueUnavailabilityForEvents(VenueEditAvailabilityModel model)
        {
            //get all instance of the venue against an event part within the given range
            List<VenueEventPart> veps = GetAffectedVenueEventParts(model);

            int eventID = 0;

            //delete each instance and update the parent events status
            foreach (var vep in veps)
            {
                eventID = vep.EventPart.EventID;
                UnitOfWork.VenueEventParts.Delete(vep);
                UnitOfWork.Commit();
                UnitOfWork.EventParts.ResetResourceStatus(vep.DayPartID);
                UnitOfWork.Commit();
                UnitOfWork.Events.ResetResourceStatus(eventID, TORUser.FullName);
                UnitOfWork.Commit();
            }
        }


        public virtual JsonResult GetVenuesUnavailableReasons()
        {
            var reasons = UnitOfWork.VenueUnavailableReason.SelectAll().Select(x => new { x.ID, x.Reason }).ToList();

            return Json(reasons, JsonRequestBehavior.AllowGet);
        }

        public virtual JsonResult GetVenueTagsJson()
        {
            var reasons = UnitOfWork.VenueTags.SelectAll().Select(x => new { x.ID, x.Name }).ToList();

            return Json(reasons, JsonRequestBehavior.AllowGet);
        }


        public virtual ActionResult Categories(int id)
        {
            var v = UnitOfWork.Venues.SelectBy(x => x.ID == id);

            var iam = new VenueCategoriesModel(Url.Action(Actions.GetVenueCategories(id)),
                Url.Action(MVC.Venues.ActionNames.EditVenueCategory, new { venueID = id }), base.GetEquipmentTags())
            {
                ID = id,
                Name = v.Name
            };

            iam.VenueCategories.Columns[iam.VenueCategories.Columns.Count - 1].Visible = TORUser.TORRole >= TORRole.Editor;
            iam.VenueCategories.ToolBarSettings.ShowAddButton = TORUser.TORRole >= TORRole.Editor;

            return View(iam);
        }


        public virtual JsonResult GetVenueCategories(int id)
        {
            var gridModel = new VenueCategoriesModel(Url.Action(Actions.GetVenueCategories(id)),
                Url.Action(MVC.Venues.ActionNames.EditVenueCategory, new { venueID = id }), base.GetVenueTags());

            IQueryable<VenueTagVenueModel> venueTags = UnitOfWork.VenueTagVenues.GetVenueTags(id);

            return gridModel.VenueCategories.DataBind(venueTags.AsQueryable());
        }

        [HttpGet]
        public virtual JsonResult EditVenueCategoryCheck(VenueTagVenueModel model)
        {
            var vte = UnitOfWork.VenueTagVenues.SelectBy(x => x.ID == model.ID);

            //get all  instance of Venue tags being used for this venue in events in the future
            var veps = UnitOfWork.VenueEventParts.SelectFilteredList(x => 
                x.VenueTagID == vte.VenueTagID &&
                x.EventPart.Date > DateTime.Now &&
                x.VenueID == vte.VenueID
            ).ToList();

            List<string> affectedEventCodes = veps.Select(iep => iep.EventPart.Event.EventCode).Distinct().OrderBy(s => s).ToList();

            return Json(new
            {
                EventCount = affectedEventCodes.Count,
                EventCodes = affectedEventCodes
            }, JsonRequestBehavior.AllowGet);
        }

        [TOREditAuthorise, HttpPost]
        public virtual JsonResult EditVenueCategory(VenueTagVenueModel model, int venueID)
        {
            var gridModel = new VenueCategoriesModel(Url.Action(Actions.GetVenueCategories(venueID)),
                Url.Action(MVC.Venues.ActionNames.EditVenueCategory, new { venueID = venueID }), base.GetVenueTags());

            //in insert mode so add row
            if (gridModel.VenueCategories.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                var ete = Mapper.Map<VenueTagVenueModel, VenueTagVenue>(model);
                UnitOfWork.VenueTagVenues.Insert(ete);
            }
            //in delete mode, so remove the matching row
            else if (gridModel.VenueCategories.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                var vte = UnitOfWork.VenueTagVenues.SelectBy(x => x.ID == model.ID);
                
                
                //get all  instance of Venue tags being used for this venue in events in the future
                var veps = UnitOfWork.VenueEventParts.SelectFilteredList(x => 
                                                                                x.VenueTagID == vte.VenueTagID && 
                                                                                x.EventPart.Date > DateTime.Now &&
                                                                                x.VenueID == vte.VenueID
                                                                            ).ToList();
                
                //delete them all
                foreach (var vep in veps)
                {
                    int eventID = vep.EventPart.EventID;
                    int eventPartID = vep.EventPart.ID;
                    UnitOfWork.VenueEventParts.Delete(vep);
                    UnitOfWork.Commit();
    
                    //update the event parts resource status
                    UnitOfWork.EventParts.ResetResourceStatus(eventPartID);
                    UnitOfWork.Commit();

                    //update their events resource status
                    UnitOfWork.Events.ResetResourceStatus(eventID, TORUser.FullName);
                    UnitOfWork.Commit();

                }
                
                UnitOfWork.VenueTagVenues.Delete(vte);

                UnitOfWork.Commit();
            }

            UnitOfWork.Commit();

            return Json(true);
        }
    }
}
