﻿using System.Web.Mvc;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.Web.Filters;

namespace SFR.TOR.Web.Controllers
{
    [TORUserAuthorisation]
    public partial class HomeController : BaseController
    {        
        public HomeController(ITORUnitOfWork unitOfWork): base(unitOfWork)
        {
        }

        public virtual ActionResult Index()
        {
            return View();
        }

        public virtual ActionResult About()
        {
            return View();
        }
    }
}
