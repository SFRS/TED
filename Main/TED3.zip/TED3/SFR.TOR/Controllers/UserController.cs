﻿using System.Linq;
using System.Web.Mvc;
using AutoMapper;
using SFR.TOR.Data;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;
using SFR.TOR.Web.Filters;

namespace SFR.TOR.Web.Controllers
{
    [TORUserAuthorisation]
    public partial class UserController : BaseController
    {
        public UserController(ITORUnitOfWork unitOfWork): base(unitOfWork)
        {
            UnitOfWork = unitOfWork;
        }

        public virtual ActionResult Preferences()
        {
            var user = UnitOfWork.Users.SelectBy(x => x.ID == TORUser.ID);

            var up = Mapper.Map<User, UserPreferencesEditModel>(user);

            up.TrainingCentreData = GetTrainingCentres(user.DefaultTrainingCentreID);

            return View(up);
        }

        [HttpPost]
        public virtual ActionResult Preferences(UserPreferencesEditModel model)
        {
            model.ID = TORUser.ID;

            var user = UnitOfWork.Users.SelectBy(x => x.ID == model.ID);
            Mapper.Map(model, user);

            UnitOfWork.Users.Update(user);
            UnitOfWork.Commit();

            model.TrainingCentreData = GetTrainingCentres(user.DefaultTrainingCentreID);

            TORUser.DefaultTrainingCentreID = model.DefaultTrainingCentreID;

            return View(model);
        }

        public virtual JsonResult GetTrainingCentres()
        {
            var trainingCentres = UnitOfWork.TrainingCentres.SelectAll().Select(x => new { x.ID, x.Name });

            return Json(trainingCentres, JsonRequestBehavior.AllowGet);
        }
    }
}
