﻿using System;
using System.Data.Objects;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using AutoMapper;
using LinqKit;
using SFR.TOR.Data;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;
using SFR.TOR.Web.Filters;
using Trirand.Web.Mvc;
using SFR.TOR.Utility;
using System.Text;
using System.Collections.Generic;
using System.Data.Objects.SqlClient;
using System.IO;
using OfficeOpenXml;

namespace SFR.TOR.Web.Controllers
{
    [TORAdminAuthorise]
    public partial class AdminController : BaseController 
    {
        public AdminController(ITORUnitOfWork unitOfWork) : base(unitOfWork)
        {
            UnitOfWork = unitOfWork;
        }

        public virtual ActionResult Index()
        {            
            return View();
        }

        #region Instructor Unavailable Reason Groups

        public virtual ActionResult InstructorUnavailableReasonGroups()
        {
            var groupsModel = new InstructorUnavailableReasonGroupsModel(Url.Action(Actions.GetInstructorUnavailableReasonGroups()), Url.Action("EditInstructorUnavailableReasonGroup"));
            return View(groupsModel);
        }

        public virtual JsonResult GetInstructorUnavailableReasonGroups()
        {
            var gridModel = new InstructorUnavailableReasonGroupsModel(Url.Action(Actions.GetInstructorUnavailableReasonGroups()), Url.Action("EditInstructorUnavailableReasonGroup"));

            var vgs = UnitOfWork.InstructorUnavailableReasonGroups.SelectAll().OrderBy(i=>i.Title);

            return gridModel.InstructorUnavailableReasonGroups.DataBind(vgs.AsQueryable()); 
        }

        public virtual ActionResult EditInstructorUnavailableReasonGroup(InstructorUnavailableReasonGroupModel model)
        {
            var gridModel = new InstructorUnavailableReasonGroupsModel("", "");

            // Display an error if the user tries to edit or delete one of the groups required for reporting
            if (Enum.GetValues(typeof(SFR.TOR.Utility.ReportInstructorAvailabilityGroups)).Cast<Int32>().Any(g => g == model.ID))
            {
                return gridModel.InstructorUnavailableReasonGroups.ShowEditValidationMessage(Constants.GRID_GROUP_UNABLE_TO_DELETE_UNEDITABLE_GROUP_ERROR);
            }

            if (gridModel.InstructorUnavailableReasonGroups.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                int matchingInstructorUnavailableCount = UnitOfWork.UnavailableReasons.SelectFilteredList(x => x.UnavailableReasonGroupID == model.ID).Count();

                if (matchingInstructorUnavailableCount == 0)
                {
                    var iurg = UnitOfWork.InstructorUnavailableReasonGroups.SelectBy(x => x.ID == model.ID);
                    UnitOfWork.InstructorUnavailableReasonGroups.Delete(iurg);
                }
                else
                    return gridModel.InstructorUnavailableReasonGroups.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_UNAVAILABLE_REASON_UNABLE_TO_DELETE_ERROR);
            }

            UnitOfWork.Commit();

            return RedirectToAction(MVC.Admin.ActionNames.InstructorUnavailableReasonGroups);
        }

        public virtual JsonResult GetInstructorUnavailableReasonGroupsData()
        {
            var reasons = UnitOfWork.InstructorUnavailableReasonGroups.SelectAll().Select(x => new { x.ID, x.Title }).ToList();

            return Json(reasons, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region Venue Groups

        public virtual ActionResult VenueGroups()
        {
            var groupsModel = new VenueGroupsModel(Url.Action(Actions.GetVenueGroups()), Url.Action("EditVenueGroup"));

            return View(groupsModel);
        }

        public virtual JsonResult GetVenueGroups()
        {
            var gridModel = new VenueGroupsModel(Url.Action(Actions.GetVenueGroups()), Url.Action("EditVenueGroup"));

            var vgs = UnitOfWork.VenueGroups.GetVenueGroups().OrderBy(vg=>vg.Title);

            return gridModel.VenueGroups.DataBind(vgs.AsQueryable()); 
        }

        public virtual JsonResult GetVenueGroupsData()
        {
            var venueGroups = UnitOfWork.VenueGroups.SelectAll().Select(x => new { x.ID, x.Title }).ToList();

            return Json(venueGroups, JsonRequestBehavior.AllowGet);
        }

        public virtual ActionResult EditVenueGroup(VenueGroupModel model)
        {
            var gridModel = new VenueGroupsModel("", "");

            if (gridModel.VenueGroups.AjaxCallBackMode == AjaxCallBackMode.AddRow ||
                gridModel.VenueGroups.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                int matchingVenueGroupsCount = UnitOfWork.VenueGroups.SelectFilteredList(x => x.Title == model.Title).Count();

                if (matchingVenueGroupsCount > 0)
                    return gridModel.VenueGroups.ShowEditValidationMessage(Constants.GRID_VENUE_GROUP_ITEM_ALREADY_EXISTS_ERROR);
            }

            if (gridModel.VenueGroups.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                UnitOfWork.VenueGroups.Insert(new VenueGroup() { Title = model.Title });
            }
            else if (gridModel.VenueGroups.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                var eg = UnitOfWork.VenueGroups.SelectBy(x => x.ID == model.ID);
                eg.Title = model.Title;
                UnitOfWork.VenueGroups.Update(eg);     
            }
            else if (gridModel.VenueGroups.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                int matchingVenuesUsingGroupCount = UnitOfWork.Venues.SelectFilteredList(x => x.VenueGroupID == model.ID).Count();

                if (matchingVenuesUsingGroupCount == 0)
                {
                    var eg = UnitOfWork.VenueGroups.SelectBy(x => x.ID == model.ID);
                    UnitOfWork.VenueGroups.Delete(eg);
                }
                else
                {
                    return gridModel.VenueGroups.ShowEditValidationMessage(Constants.GRID_VENUE_GROUP_UNABLE_TO_DELETE_ERROR);
                }
            }

            UnitOfWork.Commit();

            return RedirectToAction(MVC.Admin.ActionNames.VenueGroups);
        }

        #endregion

        #region Equipment Groups

        public virtual ActionResult EquipmentGroups()
        {
            var groupsModel = new EquipmentGroupsModel(Url.Action(Actions.GetEquipmentGroups()), Url.Action("EditEquipmentGroup"));

            return View(groupsModel);
        }

        public virtual JsonResult GetEquipmentGroups()
        {
            var gridModel = new EquipmentGroupsModel(Url.Action(Actions.GetEquipmentGroups()), Url.Action("EditEquipmentGroup"));

            var egs = UnitOfWork.EquipmentGroups.GetEquipmentGroups().OrderBy(eg=>eg.Title);
            //var pps = UnitOfWork.Pinchpoints.GetPinchpoints(trainingCentreID);

            return gridModel.EquipmentGroups.DataBind(egs.AsQueryable()); 
        }

        public virtual JsonResult GetEquipmentGroupsData()
        {
            var equipmentGroups = UnitOfWork.EquipmentGroups.SelectAll().Select(x => new { x.ID, x.Title }).ToList();

            return Json(equipmentGroups, JsonRequestBehavior.AllowGet);
        }

        public virtual ActionResult EditEquipmentGroup(EquipmentGroupModel model)
        {
            var gridModel = new EquipmentGroupsModel("", "");
            
            // Validate
            if (gridModel.EquipmentGroups.AjaxCallBackMode == AjaxCallBackMode.AddRow ||
                gridModel.EquipmentGroups.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                if (UnitOfWork.EquipmentGroups.SelectFilteredList(x =>
                                                    x.Title.Trim().Equals(model.Title.Trim())).Count() > 0)
                    return gridModel.EquipmentGroups.ShowEditValidationMessage(Constants.GRID_GROUP_ITEM_ALREADY_EXISTS_ERROR);
            }

            if (gridModel.EquipmentGroups.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                UnitOfWork.EquipmentGroups.Insert(new EquipmentGroup() { Title = model.Title });
            }
            else if (gridModel.EquipmentGroups.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                var eg = UnitOfWork.EquipmentGroups.SelectBy(x => x.ID == model.ID);
                eg.Title = model.Title;
                UnitOfWork.EquipmentGroups.Update(eg);
            }
            else if (gridModel.EquipmentGroups.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                int equipmentCountForGroup = UnitOfWork.Equipment.SelectFilteredList(x => x.EquipmentGroupID == model.ID).Count();

                if (equipmentCountForGroup == 0)
                {
                    var eg = UnitOfWork.EquipmentGroups.SelectBy(x => x.ID == model.ID);
                    UnitOfWork.EquipmentGroups.Delete(eg);
                }
                else
                {
                    return gridModel.EquipmentGroups.ShowEditValidationMessage(Constants.GRID_GROUP_UNABLE_TO_DELETE_ERROR);
                }
            }

            UnitOfWork.Commit();

            return RedirectToAction(MVC.Admin.ActionNames.EquipmentGroups);
        }

        #endregion

        #region Pinchpoints

        public virtual ActionResult Pinchpoints()
        {
            var pps = new PinchPointsModel(Url.Action(Actions.GetPinchPoints(TORUser.CurrentTrainingCentreID)), Url.Action("EditPinchPoint"));

            return View(pps);        
        }

        public virtual ActionResult PinchpointReasons()
        {
            var pps = new PinchPointReasonsModel(Url.Action(Actions.GetPinchPointReasons()), Url.Action("EditPinchPointReason"), GetPinchpointTypesForFilter());

            return View(pps);
        } 

        public virtual JsonResult GetPinchPoints(int trainingCentreID) 
        {
            var gridModel = new PinchPointsModel(Url.Action(Actions.GetPinchPoints(trainingCentreID)), Url.Action("EditPinchPoint"));

            var pps = UnitOfWork.Pinchpoints.GetPinchpoints(trainingCentreID);

            return gridModel.Pinchpoints.DataBind(pps.AsQueryable()); 
        }

        public virtual JsonResult GetPinchPointReasons()
        {
            var gridModel = new PinchPointReasonsModel(Url.Action(Actions.GetPinchPointReasons()), Url.Action("EditPinchPointReason"), GetPinchpointTypesForFilter());

            var pps = UnitOfWork.PinchpointReasons.GetPinchpointReasons();

            return gridModel.PinchpointReasons.DataBind(pps.AsQueryable());
        }

        public virtual void EditPinchPoint(PinchpointModel model) 
        {
            var gridModel = new PinchPointsModel("", "");

            if (gridModel.Pinchpoints.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                var pp = Mapper.Map<PinchpointModel, Pinchpoint>(model);
                pp.TrainingCentreID = TORUser.CurrentTrainingCentreID;
                UnitOfWork.Pinchpoints.Insert(pp);
                 
            }
            else if (gridModel.Pinchpoints.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                var pp = UnitOfWork.Pinchpoints.SelectBy(x => x.ID == model.ID);

                Mapper.Map(model, pp);
                UnitOfWork.Pinchpoints.Update(pp);
            }
            else if (gridModel.Pinchpoints.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                var pp = UnitOfWork.Pinchpoints.SelectBy(x => x.ID == model.ID);

                UnitOfWork.Pinchpoints.Delete(pp);
            }

            UnitOfWork.Commit();
        }

        public virtual ActionResult EditPinchPointReason(PinchPointReasonModel model)
        {
            var gridModel = new PinchPointReasonsModel("", "", GetPinchpointTypesForFilter());

            // Validate
            if (gridModel.PinchpointReasons.AjaxCallBackMode == AjaxCallBackMode.AddRow ||
                gridModel.PinchpointReasons.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                int matchingPinchpointReasonsCount = UnitOfWork.PinchpointReasons.SelectFilteredList(x => x.Reason == model.Reason).Count();
                
                var pinchpointReason = UnitOfWork.PinchpointReasons.SelectBy(x => x.ID == model.ID);

                if ((pinchpointReason != null) && pinchpointReason.TypeID != model.TypeID &&
                    pinchpointReason.Reason == model.Reason)
                {
                    //Do nothing.. let the user edit the type
                }
                else
                    if (matchingPinchpointReasonsCount > 0) //Make sure there are no duplicate reasons
                    {
                        return gridModel.PinchpointReasons.ShowEditValidationMessage(Constants.GRID_PINCHPOINT_REASON_ITEM_ALREADY_EXISTS_ERROR);
                    }
            }

            if (gridModel.PinchpointReasons.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                var ppr = Mapper.Map<PinchPointReasonModel, PinchpointReason>(model);                
                UnitOfWork.PinchpointReasons.Insert(ppr);
            }
            else if (gridModel.PinchpointReasons.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                var ppr = UnitOfWork.PinchpointReasons.SelectBy(x => x.ID == model.ID);

                Mapper.Map(model, ppr);
                UnitOfWork.PinchpointReasons.Update(ppr);
            }
            else if (gridModel.PinchpointReasons.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                int matchingPinchPointReasonsCount = UnitOfWork.Pinchpoints.SelectFilteredList(x => x.PinchpointReason.ID == model.ID).Count();

                if (matchingPinchPointReasonsCount == 0)
                {
                    var ppr = UnitOfWork.PinchpointReasons.SelectBy(x => x.ID == model.ID);
                    UnitOfWork.PinchpointReasons.Delete(ppr);
                }
                else
                    return gridModel.PinchpointReasons.ShowEditValidationMessage(Constants.GRID_PINCHPOINT_REASON_UNABLE_TO_DELETE_ERROR);
            }

            UnitOfWork.Commit();

            return RedirectToAction(MVC.Admin.ActionNames.PinchpointReasons);
        }

        public virtual JsonResult GetPinchpointReasonsData()
        {
            var reasons = UnitOfWork.PinchpointReasons.SelectAll().Select(x => new { x.ID, x.Reason}).ToList();

            return Json(reasons, JsonRequestBehavior.AllowGet);
        }

        public virtual JsonResult GetPinchpointTypeData()
        {
            var reasons = UnitOfWork.PinchpointTypes.SelectAll().Select(x => new { x.ID, x.TypeName }).ToList();

            return Json(reasons, JsonRequestBehavior.AllowGet);
        }

        public virtual ActionResult GetInstructorCalendarPinchpoints(DateTime startDate, bool showWeekend)
        {
            startDate = startDate.Date; //remove time component
          
            var inner = PredicateBuilder.False<Pinchpoint>();
            inner = inner.Or(p => p.StartDate >= startDate && p.StartDate <= EntityFunctions.AddDays(startDate, 7));
            inner = inner.Or(p => p.EndDate >= startDate && p.EndDate <= EntityFunctions.AddDays(startDate, 7));

            //main 
            Expression<Func<Pinchpoint, bool>> predicate = PredicateBuilder.True<Pinchpoint>();
            predicate = predicate.And(x => x.TrainingCentreID == TORUser.CurrentTrainingCentreID); 
            predicate = predicate.And(x => x.PinchpointReason.TypeID == 2 || x.PinchpointReason.TypeID == 3);
            predicate = predicate.And(inner.Expand());

            //get pinchpoints for this time period
            var pps = UnitOfWork.Pinchpoints.SelectFilteredList(predicate);

            //process any pinchpoints for this period
            if (pps.Any())
            {
                string startRow = "<tr><th></th><th colspan='2' align='right'>PINCHPOINTS</th>";

                //if (!showingWeekend)
                //{
                //    startRow += "<th></th><th></th>";
                //}
                string endRow = "</tr>";

                string day1 = createDayCell(startDate, pps, showWeekend);
                string day2 = createDayCell(startDate.AddDays(1), pps, showWeekend);
                string day3 = createDayCell(startDate.AddDays(2), pps, showWeekend);
                string day4 = createDayCell(startDate.AddDays(3), pps, showWeekend);
                string day5 = createDayCell(startDate.AddDays(4), pps, showWeekend);
                string day6 = createDayCell(startDate.AddDays(5), pps, showWeekend);
                string day7 = createDayCell(startDate.AddDays(6), pps, showWeekend);

                return Content(string.Format("{0}{1}{2}{3}{4}{5}{6}{7}{8}", 
                                                startRow, day1, day2, day3, day4, day5, day6, day7, endRow));    
            }

            return Content("");
        }

        public virtual ActionResult GetVenuesCalendarPinchpoints(DateTime startDate, bool showWeekend)
        {
            startDate = startDate.Date; //remove time component

            var inner = PredicateBuilder.False<Pinchpoint>();
            inner = inner.Or(p => p.StartDate >= startDate && p.StartDate <= EntityFunctions.AddDays(startDate, 7));
            inner = inner.Or(p => p.EndDate >= startDate && p.EndDate <= EntityFunctions.AddDays(startDate, 7));

            //main 
            Expression<Func<Pinchpoint, bool>> predicate = PredicateBuilder.True<Pinchpoint>();
            predicate = predicate.And(x => x.TrainingCentreID == TORUser.CurrentTrainingCentreID);
            predicate = predicate.And(x => x.PinchpointReason.TypeID == 1 || x.PinchpointReason.TypeID == 2);
            predicate = predicate.And(inner.Expand());

            //get pinchpoints for this time period
            var pps = UnitOfWork.Pinchpoints.SelectFilteredList(predicate);

            //process any pinchpoints for this period
            if (pps.Any())
            {
                string startRow = "<tr><th></th>";
                string endRow = "</tr>";

                string day1 = createDayCell(startDate, pps, showWeekend);
                string day2 = createDayCell(startDate.AddDays(1), pps, showWeekend);
                string day3 = createDayCell(startDate.AddDays(2), pps, showWeekend);
                string day4 = createDayCell(startDate.AddDays(3), pps, showWeekend);
                string day5 = createDayCell(startDate.AddDays(4), pps, showWeekend);
                string day6 = createDayCell(startDate.AddDays(5), pps, showWeekend);
                string day7 = createDayCell(startDate.AddDays(6), pps, showWeekend);

                return Content(string.Format("{0}{1}{2}{3}{4}{5}{6}{7}{8}",
                                                startRow, day1, day2, day3, day4, day5, day6, day7, endRow));
            }

            return Content("");
        }

        public virtual ActionResult GetEventsCalendarPinchpoints(DateTime startDate, bool showWeekend)
        {
            startDate = startDate.Date; //remove time component
            
            var inner = PredicateBuilder.False<Pinchpoint>();
            inner = inner.Or(p => p.StartDate >= startDate && p.StartDate <= EntityFunctions.AddDays(startDate, 7));
            inner = inner.Or(p => p.EndDate >= startDate && p.EndDate <= EntityFunctions.AddDays(startDate, 7));

            //main 
            Expression<Func<Pinchpoint, bool>> predicate = PredicateBuilder.True<Pinchpoint>();
            predicate = predicate.And(x => x.TrainingCentreID == TORUser.CurrentTrainingCentreID);
            predicate = predicate.And(inner.Expand());

            //get pinchpoints for this time period
            var pps = UnitOfWork.Pinchpoints.SelectFilteredList(predicate);

            //process any pinchpoints for this period
            if (pps.Any())
            {
                string startRow = "<tr>";
                string endRow = "</tr>";

                string day1 = createDayCell(startDate, pps, showWeekend);
                string day2 = createDayCell(startDate.AddDays(1), pps, showWeekend);
                string day3 = createDayCell(startDate.AddDays(2), pps, showWeekend);
                string day4 = createDayCell(startDate.AddDays(3), pps, showWeekend);
                string day5 = createDayCell(startDate.AddDays(4), pps, showWeekend);
                string day6 = createDayCell(startDate.AddDays(5), pps, showWeekend);
                string day7 = createDayCell(startDate.AddDays(6), pps, showWeekend);

                return Content(string.Format("{0}{1}{2}{3}{4}{5}{6}{7}{8}",
                                                startRow, day1, day2, day3, day4, day5, day6, day7, endRow));
            }

            return Content("");
        }

        private static string createDayCell(DateTime date, IQueryable<Pinchpoint> pps, bool showWeekend)
        {
            string blankTDDay = "<th></th><th></th>"; //am and pm cells
            string ppthDay = "<th colspan='2' class='{0}'>&nbsp;</th>";

            if (
                (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday) && showWeekend
                || //otherwise, if it's a weekday always display
                ((date.DayOfWeek == DayOfWeek.Monday || date.DayOfWeek == DayOfWeek.Tuesday ||
                  date.DayOfWeek == DayOfWeek.Wednesday || date.DayOfWeek == DayOfWeek.Thursday ||
                  date.DayOfWeek == DayOfWeek.Friday))
                )
            {

                var pred = PredicateBuilder.False<Pinchpoint>();
                pred = pred.Or(p => p.StartDate <= date && p.EndDate >= date);
                pred = pred.Or(p => p.StartDate == date);

                //var pp = pps.FirstOrDefault(x => x.StartDate <= date && x.EndDate >= date);
                var pp = pps.FirstOrDefault(pred);


                //do we have a pinch point for this date
                if (pp != null)
                {
                    string css = "";
                    switch (pp.PinchpointReason.TypeID) //depending on reason, set the CSS class
                    {
                        case 1: //training centre events
                            css = "pinchpointGreen";
                            break;
                        case 2: //public holidays
                            css = "pinchpointGrey";
                            break;
                        case 3: //staffing 
                            css = "pinchpointRed";
                            break;
                        default:
                            return blankTDDay;
                    }

                    //return the styled html
                    return string.Format(ppthDay, css);
                }

                //return unstyled html
                return blankTDDay;
                
            }
            else
            {
                return ""; // we don't even want blank cells as this will break the weekend offsetting
            }
        }

        #endregion

        #region Group Calendar 

        public virtual ActionResult GroupCalendar(int? SelectedYear)
        {
            if (SelectedYear == null)
            {
                SelectedYear = DateTime.Now.Year;
            }

            var grid = new GroupCalendarModel(Url.Action(Actions.GetGroupCalendar(SelectedYear.Value)), Url.Action("EditGroupCalendar"));

            grid.Years = GetGroupCalendarYears(SelectedYear.Value);

            grid.SelectedYear = SelectedYear.Value;
                
            return View(grid);
        }

        public virtual JsonResult GetGroupCalendar(int year)
        {            
            var startOfYear = new DateTime(year, 1, 1);
            var endOfYear = new DateTime(year, 12, 31);

            //first check if we have any data set up for the year
            var dataCount = UnitOfWork.GroupCalendars.SelectFilteredList(x => x.GroupDate.Year == year && x.TrainingCentreID == TORUser.CurrentTrainingCentreID).Count();            
            
            if (dataCount == 0)
            {
                //create the dataset
                DateTime dateWalker = startOfYear;
                while (dateWalker <= endOfYear)
                {
                    UnitOfWork.GroupCalendars.Insert(new GroupCalendar()
                        {
                            Title = "",
                            GroupDate = dateWalker,
                            TrainingCentreID = TORUser.CurrentTrainingCentreID
                        });
                    dateWalker = dateWalker.AddDays(1);
                }

                UnitOfWork.Commit();
            }

            var groupCalendarData = UnitOfWork.GroupCalendars.GetGroupCalendar(startOfYear, endOfYear, TORUser.CurrentTrainingCentreID);

            var grid = new GroupCalendarModel(Url.Action(Actions.GetGroupCalendar()), Url.Action("EditGroupCalendar"));

            return grid.GroupCalendarGrid.DataBind(groupCalendarData.AsQueryable());
        }

        public virtual void EditGroupCalendar(GroupCalendarItemModel model)
        {
            var gridModel = new GroupCalendarModel(Url.Action(Actions.GetGroupCalendar()), Url.Action("EditGroupCalendar"));

            if (gridModel.GroupCalendarGrid.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                var ppr = Mapper.Map<GroupCalendarItemModel, GroupCalendar>(model);
                UnitOfWork.GroupCalendars.Insert(ppr);

            }
            else if (gridModel.GroupCalendarGrid.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                var ppr = UnitOfWork.GroupCalendars.SelectBy(x => x.ID == model.ID);

                Mapper.Map(model, ppr);
                UnitOfWork.GroupCalendars.Update(ppr);
            }
            else if (gridModel.GroupCalendarGrid.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                var ppr = UnitOfWork.GroupCalendars.SelectBy(x => x.ID == model.ID);
                UnitOfWork.GroupCalendars.Delete(ppr);
            }

            UnitOfWork.Commit();
        }

        public virtual ActionResult GetCalendarData(DateTime startDate, bool showWeekend)
        {
            startDate = startDate.Date; //remove time component

            //get pinchpoints for this time period
            var groupData = UnitOfWork.GroupCalendars
                .SelectFilteredList(x =>
                    x.TrainingCentreID == TORUser.CurrentTrainingCentreID &&
                    x.GroupDate >= startDate &&
                    x.GroupDate <= EntityFunctions.AddDays(startDate, 7)                    
            );

            //process group calendar data for this period
            if (groupData.Any())
            {
                string startRow = "<tr id='GroupHeader' role='rowheader'><th></th><th colspan='2' align='right'><div class='ui-th-div-ie'>GROUP SYSTEM</div></th>";
                string endRow = "</tr>";

                string day1 = createGroupCell(startDate, groupData, showWeekend);
                string day2 = createGroupCell(startDate.AddDays(1), groupData, showWeekend);
                string day3 = createGroupCell(startDate.AddDays(2), groupData, showWeekend);
                string day4 = createGroupCell(startDate.AddDays(3), groupData, showWeekend);
                string day5 = createGroupCell(startDate.AddDays(4), groupData, showWeekend);
                string day6 = createGroupCell(startDate.AddDays(5), groupData, showWeekend);
                string day7 = createGroupCell(startDate.AddDays(6), groupData, showWeekend);

                return Content(string.Format("{0}{1}{2}{3}{4}{5}{6}{7}{8}",
                                                startRow, day1, day2, day3, day4, day5, day6, day7, endRow));
            }

            return Content("");

        }

        public virtual ActionResult GetCalendarDataForEventOverview(DateTime startDate, bool showWeekend)
        {
            startDate = startDate.Date; //remove time component

            //get pinchpoints for this time period
            var groupData = UnitOfWork.GroupCalendars
                .SelectFilteredList(x =>
                    x.TrainingCentreID == TORUser.CurrentTrainingCentreID &&
                    x.GroupDate >= startDate &&
                    x.GroupDate <= EntityFunctions.AddDays(startDate, 7)
            );

            //process group calendar data for this period
            if (groupData.Any())
            {
                string startRow = "<tr id='GroupHeader' role='rowheader'>";
                string endRow = "</tr>";

                string day1 = createGroupCell(startDate, groupData, showWeekend);
                string day2 = createGroupCell(startDate.AddDays(1), groupData, showWeekend);
                string day3 = createGroupCell(startDate.AddDays(2), groupData, showWeekend);
                string day4 = createGroupCell(startDate.AddDays(3), groupData, showWeekend);
                string day5 = createGroupCell(startDate.AddDays(4), groupData, showWeekend);
                string day6 = createGroupCell(startDate.AddDays(5), groupData, showWeekend);
                string day7 = createGroupCell(startDate.AddDays(6), groupData, showWeekend);

                return Content(string.Format("{0}{1}{2}{3}{4}{5}{6}{7}{8}",
                                                startRow, day1, day2, day3, day4, day5, day6, day7, endRow));
            }

            return Content("");

        }

        public virtual ActionResult GetCalendarDataForVenueOverview(DateTime startDate, bool showWeekend)
        {
            startDate = startDate.Date; //remove time component

            //get pinchpoints for this time period
            var groupData = UnitOfWork.GroupCalendars
                .SelectFilteredList(x =>
                    x.TrainingCentreID == TORUser.CurrentTrainingCentreID &&
                    x.GroupDate >= startDate &&
                    x.GroupDate <= EntityFunctions.AddDays(startDate, 7)
            );

            //process group calendar data for this period
            if (groupData.Any())
            {
                string startRow = "<tr id='GroupHeader' role='rowheader'><th colspan='2' align='right'><div class='ui-th-div-ie'>GROUP SYSTEM</div></th>";
                
                string endRow = "</tr>";

                string day1 = createGroupCell(startDate, groupData, showWeekend);
                string day2 = createGroupCell(startDate.AddDays(1), groupData, showWeekend);
                string day3 = createGroupCell(startDate.AddDays(2), groupData, showWeekend);
                string day4 = createGroupCell(startDate.AddDays(3), groupData, showWeekend);
                string day5 = createGroupCell(startDate.AddDays(4), groupData, showWeekend);
                string day6 = createGroupCell(startDate.AddDays(5), groupData, showWeekend);
                string day7 = createGroupCell(startDate.AddDays(6), groupData, showWeekend);

                return Content(string.Format("{0}{1}{2}{3}{4}{5}{6}{7}{8}",
                                                startRow, day1, day2, day3, day4, day5, day6, day7, endRow));
            }

            return Content("");

        }

        public virtual ActionResult GetCalendarDataForEquipmentOverview(DateTime startDate, bool showWeekend)
        {
            startDate = startDate.Date; //remove time component

            //get pinchpoints for this time period
            var groupData = UnitOfWork.GroupCalendars
                .SelectFilteredList(x =>
                    x.TrainingCentreID == TORUser.CurrentTrainingCentreID &&
                    x.GroupDate >= startDate &&
                    x.GroupDate <= EntityFunctions.AddDays(startDate, 7)
            );

            //process group calendar data for this period
            if (groupData.Any())
            {
                string startRow = "<tr id='GroupHeader' role='rowheader'><th colspan='2' align='right'><div class='ui-th-div-ie'>GROUP SYSTEM</div></th>"; 
                
                string endRow = "</tr>";

                string day1 = createGroupCell(startDate, groupData, showWeekend);
                string day2 = createGroupCell(startDate.AddDays(1), groupData, showWeekend);
                string day3 = createGroupCell(startDate.AddDays(2), groupData, showWeekend);
                string day4 = createGroupCell(startDate.AddDays(3), groupData, showWeekend);
                string day5 = createGroupCell(startDate.AddDays(4), groupData, showWeekend);
                string day6 = createGroupCell(startDate.AddDays(5), groupData, showWeekend);
                string day7 = createGroupCell(startDate.AddDays(6), groupData, showWeekend);

                return Content(string.Format("{0}{1}{2}{3}{4}{5}{6}{7}{8}",
                                                startRow, day1, day2, day3, day4, day5, day6, day7, endRow));
            }

            return Content("");

        }

        private static string createGroupCell(DateTime date, IQueryable<GroupCalendar> groupData, bool showWeekend)
        {
            if (
                (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday) && showWeekend
                || //otherwise, if it's a weekday always display
                ((date.DayOfWeek == DayOfWeek.Monday || date.DayOfWeek == DayOfWeek.Tuesday ||
                  date.DayOfWeek == DayOfWeek.Wednesday || date.DayOfWeek == DayOfWeek.Thursday ||
                  date.DayOfWeek == DayOfWeek.Friday))
                )
            {
                string groupCell = "<td colspan='2' align='center'>{0}</td>";

                var g = groupData.FirstOrDefault(x => x.GroupDate <= date && x.GroupDate >= date );

                //group data may not be set up yet
                if (g == null)
                {
                    //return the styled html
                    return string.Format(groupCell, "&nbsp;");                    
                }
                else
                {
                    return string.Format(groupCell, g.Title == "" ? "&nbsp;" : g.Title);
                }                
            }
            else
            {
                return "&nbsp;";
            }

        }

        #endregion

        #region Venue Categories

        public virtual ActionResult VenueCategories()
        {
            var vc = new VenueCategoryAdminModel(Url.Action(Actions.GetVenueCategories()), Url.Action("EditVenueCategories"));

            return View(vc);
        }

        public virtual JsonResult GetVenueCategories()
        {
            var gridModel = new VenueCategoryAdminModel(Url.Action(Actions.GetVenueCategories()), Url.Action("EditVenueCategories"));

            var vcs = UnitOfWork.VenueTags.SelectAll().OrderBy(v=>v.Name);

            return gridModel.VenueCategories.DataBind(vcs.AsQueryable());
        }

        public virtual ActionResult EditVenueCategories(VenueCategoryModel model)
        {
            var gridModel = new VenueCategoryAdminModel(Url.Action(Actions.GetVenueCategories()), Url.Action("EditVenueCategories"));

            if (gridModel.VenueCategories.AjaxCallBackMode == AjaxCallBackMode.AddRow ||
                gridModel.VenueCategories.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                int matchingVenueCatagoryCount = UnitOfWork.VenueTags.SelectFilteredList(x => x.Name.Trim().Equals(model.Name.Trim())).Count();
                
                if (matchingVenueCatagoryCount > 0)
                    return gridModel.VenueCategories.ShowEditValidationMessage(Constants.GRID_VENUE_CATEGORY_ITEM_ALREADY_EXISTS_ERROR);
            }

            if (gridModel.VenueCategories.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                var vc = Mapper.Map<VenueCategoryModel, VenueTag>(model);
                UnitOfWork.VenueTags.Insert(vc);
            }
            else if (gridModel.VenueCategories.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                var vc = UnitOfWork.VenueTags.SelectBy(x => x.ID == model.ID);

                Mapper.Map(model, vc);
                UnitOfWork.VenueTags.Update(vc);
            }
            else if (gridModel.VenueCategories.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                int venueTagVenueCount = UnitOfWork.VenueTagVenues.SelectFilteredList(x => x.VenueTagID == model.ID).Count();
                int venueTagActivityCount = UnitOfWork.VenueTagActivityPart.SelectFilteredList(x => x.VenueTagID == model.ID).Count();
                
                if (venueTagVenueCount == 0 && venueTagActivityCount == 0)
                {
                    var vt = UnitOfWork.VenueTags.SelectBy(x => x.ID == model.ID);
                    UnitOfWork.VenueTags.Delete(vt);
                }
                else
                {
                    return gridModel.VenueCategories.ShowEditValidationMessage(Constants.GRID_VENUE_CATEGORY_UNABLE_TO_DELETE);
                }
            }

            UnitOfWork.Commit();

            return RedirectToAction(MVC.Admin.ActionNames.VenueCategories);
        }

        #endregion

        #region Equipment Categories

        public virtual ActionResult EquipmentCategories()
        {
            var ec = new EquipmentCategoryAdminModel(Url.Action(Actions.GetEquipmentCategories()), Url.Action("EditEquipmentCategories"));

            return View(ec);
        }

        public virtual JsonResult GetEquipmentCategories()
        {
            var gridModel = new EquipmentCategoryAdminModel(Url.Action(Actions.GetVenueCategories()), Url.Action("EditVenueCategories"));

            var vcs = UnitOfWork.EquipmentTags.SelectAll().OrderBy(et=>et.Name);

            return gridModel.EquipmentCategories.DataBind(vcs.AsQueryable());
        }
        
        public virtual ActionResult EditEquipmentCategories(EquipmentCategoryModel model)
        {
            var gridModel = new EquipmentCategoryAdminModel(Url.Action(Actions.GetEquipmentCategories()), Url.Action("EditEquipmentCategories"));

            if (gridModel.EquipmentCategories.AjaxCallBackMode == AjaxCallBackMode.AddRow ||
                gridModel.EquipmentCategories.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                int matchingEquipmentTagsCount = UnitOfWork.EquipmentTags.SelectFilteredList(x => x.Name == model.Name).Count();

                if (matchingEquipmentTagsCount > 0)
                {
                    return gridModel.EquipmentCategories.ShowEditValidationMessage(Constants.GRID_EQUIPMENT_CATEGORY_ITEM_ALREADY_EXISTS_ERROR);
                }
            }

            if(gridModel.EquipmentCategories.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                var vc = Mapper.Map<EquipmentCategoryModel, EquipmentTag>(model);
                UnitOfWork.EquipmentTags.Insert(vc);
            }        
            else if (gridModel.EquipmentCategories.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                var vc = UnitOfWork.EquipmentTags.SelectBy(x => x.ID == model.ID);
                Mapper.Map(model, vc);
                UnitOfWork.EquipmentTags.Update(vc);
            }
            else if (gridModel.EquipmentCategories.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                int matchingEquipmentTagEquipmentCount = UnitOfWork.Equipment.SelectFilteredList(x => x.EquipmentTagEquipments.Any(e => e.EquipmentTagID == model.ID)).Count();
                int matchingEquipmentTagActivityPartCount = UnitOfWork.EquipmentTagActivityPart.SelectFilteredList(x => x.EquipmentTagID == model.ID).Count();

                if (matchingEquipmentTagEquipmentCount == 0 && matchingEquipmentTagActivityPartCount == 0)
                {
                    var ec = UnitOfWork.EquipmentTags.SelectBy(x => x.ID == model.ID);
                    UnitOfWork.EquipmentTags.Delete(ec);
                }
                else
                {
                    return gridModel.EquipmentCategories.ShowEditValidationMessage(Constants.GRID_EQUIPMENT_CATEGORY_UNABLE_TO_DELETE_ERROR);
                }
            }

            UnitOfWork.Commit();

            return RedirectToAction(MVC.Admin.ActionNames.EquipmentCategories);
        }

        #endregion

        #region Instructor Availability Reasons

        public virtual ActionResult InstructorAvailabilityReasons()
        {
            var vc = new InstructorAvailabilityReasonsModel(Url.Action(Actions.GetInstructorAvailabilityReasons()), Url.Action("EditInstructorAvailabilityReasons"));

            return View(vc);
        }

        public virtual JsonResult GetInstructorAvailabilityReasons()
        {
            var gridModel = new InstructorAvailabilityReasonsModel(Url.Action(Actions.GetInstructorAvailabilityReasons()), Url.Action("EditInstructorAvailabilityReasons"));

            var iurs = UnitOfWork.UnavailableReasons.SelectAll().OrderBy(u=>u.Reason);

            return gridModel.InstructorAvailabilityReasonsGrid.DataBind(iurs.AsQueryable());
        }

        public virtual ActionResult EditInstructorAvailabilityReasons(InstructorUnavailableReasonModel model)
        {
            var gridModel = new InstructorAvailabilityReasonsModel(Url.Action(Actions.GetInstructorAvailabilityReasons()), Url.Action("EditInstructorAvailabilityReasons"));

            // Validate
            if (gridModel.InstructorAvailabilityReasonsGrid.AjaxCallBackMode == AjaxCallBackMode.AddRow ||
                gridModel.InstructorAvailabilityReasonsGrid.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                int matchingUnavailableReasonsCount = UnitOfWork.UnavailableReasons.SelectFilteredList(x => x.Reason == model.Reason).Count();

                var availableReason = UnitOfWork.UnavailableReasons.SelectBy(x => x.ID == model.ID);

                if ((availableReason != null) && availableReason.UnavailableReasonGroupID != model.UnavailableReasonGroupID &&
                    availableReason.Reason == model.Reason)
                {
                    //Do nothing.. let the user edit the group
                }
                else
                    if (matchingUnavailableReasonsCount > 0)
                    {
                        return gridModel.InstructorAvailabilityReasonsGrid.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_AVAILABILITY_REASON_ITEM_ALREADY_EXISTS_ERROR);
                    }
            }

            if (gridModel.InstructorAvailabilityReasonsGrid.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                var ur = Mapper.Map<InstructorUnavailableReasonModel, UnavailableReason>(model);
                UnitOfWork.UnavailableReasons.Insert(ur);
            }
            else if (gridModel.InstructorAvailabilityReasonsGrid.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                var ur = new UnavailableReason()
                {
                    ID = model.ID,
                    Reason = model.Reason,
                    UnavailableReasonGroupID = model.UnavailableReasonGroupID
                };
                UnitOfWork.UnavailableReasons.Update(ur);
            }
            else if (gridModel.InstructorAvailabilityReasonsGrid.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                int unavailableInstructorsForReason = UnitOfWork.InstructorUnavailablePeriods.SelectFilteredList(e => e.UnavailableReasonID == model.ID).Count();

                if (unavailableInstructorsForReason == 0)
                {
                    var ur = UnitOfWork.UnavailableReasons.SelectBy(x => x.ID == model.ID);
                    UnitOfWork.UnavailableReasons.Delete(ur);
                }
                else
                {
                    return gridModel.InstructorAvailabilityReasonsGrid.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_AVAILABLE_REASON_UNABLE_TO_DELETE_ERROR);
                }
            }

            UnitOfWork.Commit();

            return RedirectToAction(MVC.Admin.ActionNames.InstructorAvailabilityReasons);
        }

        #endregion

        #region Venue Availability Reasons

        public virtual ActionResult VenueAvailabilityReasons()
        {
            var vc = new VenueAvailabilityReasonsModel(Url.Action(Actions.GetVenueAvailabilityReasons()), Url.Action("EditVenueAvailabilityReasons"));

            return View(vc);
        }

        public virtual JsonResult GetVenueAvailabilityReasons()
        {
            var gridModel = new VenueAvailabilityReasonsModel(Url.Action(Actions.GetVenueAvailabilityReasons()), Url.Action("EditVenueAvailabilityReasons"));

            var vurs = UnitOfWork.VenueUnavailableReason.SelectAll().OrderBy(v=>v.Reason);

            return gridModel.VenueAvailabilityReasonsGrid.DataBind(vurs.AsQueryable());
        }

        public virtual ActionResult EditVenueAvailabilityReasons(VenueUnavailableReasonModel model)
        {
            var gridModel = new VenueAvailabilityReasonsModel(Url.Action(Actions.GetVenueAvailabilityReasons()), Url.Action("EditVenueAvailabilityReasons"));

            // Validate
            if (gridModel.VenueAvailabilityReasonsGrid.AjaxCallBackMode == AjaxCallBackMode.AddRow ||
               gridModel.VenueAvailabilityReasonsGrid.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                int matchingVenueAvailabilityReasons = UnitOfWork.VenueUnavailableReason.SelectFilteredList(x => x.Reason == model.Reason).Count();

                if (matchingVenueAvailabilityReasons > 0)
                    return gridModel.VenueAvailabilityReasonsGrid.ShowEditValidationMessage(Constants.GRID_VENUE_AVAILABILITY_ITEM_ALREADY_EXISTS_ERROR);
            }

            if (gridModel.VenueAvailabilityReasonsGrid.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                var ur = Mapper.Map<VenueUnavailableReasonModel, VenuesUnavailableReason>(model);
                UnitOfWork.VenueUnavailableReason.Insert(ur);
            }
            else if (gridModel.VenueAvailabilityReasonsGrid.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                var ur = UnitOfWork.VenueUnavailableReason.SelectBy(x => x.ID == model.ID);
                ur.Reason = model.Reason;
                UnitOfWork.VenueUnavailableReason.Update(ur);
            }
            else if (gridModel.VenueAvailabilityReasonsGrid.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                int matchingVenueAvailabilityReasonCount = UnitOfWork.Venues.SelectFilteredList(x => x.VenueUnavailablePeriods.Any(e => e.VenuesUnavailableReason.ID == model.ID)).Count();

                if (matchingVenueAvailabilityReasonCount == 0)
                {
                    var vur = UnitOfWork.VenueUnavailableReason.SelectBy(e => e.ID == model.ID);
                    UnitOfWork.VenueUnavailableReason.Delete(vur);
                }
                else
                {
                    return gridModel.VenueAvailabilityReasonsGrid.ShowEditValidationMessage(Constants.GRID_VENUE_UNAVAILABLE_UNABLE_TO_DELETE_ERROR);
                }
            }

            UnitOfWork.Commit();

            return RedirectToAction(MVC.Admin.ActionNames.VenueAvailabilityReasons);
        }

        #endregion

        #region Equipment Availability Reasons 

        public virtual ActionResult EquipmentAvailabilityReasons()
        {
            var vc = new EquipmentAvailabilityReasonsModel(Url.Action(Actions.GetEquipmentAvailabilityReasons()), Url.Action("EditEquipmentAvailabilityReasons"));

            return View(vc);
        }

        public virtual JsonResult GetEquipmentAvailabilityReasons()
        {
            var gridModel = new EquipmentAvailabilityReasonsModel(Url.Action(Actions.GetEquipmentAvailabilityReasons()), Url.Action("EditEquipmentAvailabilityReasons"));

            var eurs = UnitOfWork.EquipmentUnavailableReasons.SelectAll().OrderBy(e=>e.Reason);

            return gridModel.EquipmentAvailabilityReasonGrid.DataBind(eurs.AsQueryable());
        }

        public virtual ActionResult EditEquipmentAvailabilityReasons(EquipmentUnavailableReasonModel model)
        {
            var gridModel = new EquipmentAvailabilityReasonsModel(Url.Action(Actions.GetEquipmentAvailabilityReasons()), Url.Action("EditEquipmentAvailabilityReasons"));

            // Validate
            if (gridModel.EquipmentAvailabilityReasonGrid.AjaxCallBackMode == AjaxCallBackMode.AddRow ||
                gridModel.EquipmentAvailabilityReasonGrid.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                int matchingEquipmentAvailabilityReasonCount = UnitOfWork.EquipmentUnavailableReasons.SelectFilteredList(x => x.Reason == model.Reason).Count();

                if (matchingEquipmentAvailabilityReasonCount > 0)
                {
                    return gridModel.EquipmentAvailabilityReasonGrid.ShowEditValidationMessage(Constants.GRID_EQUIPMENT_AVAILABILITY_ITEM_ALREADY_EXISTS_ERROR);
                }
            }

            if (gridModel.EquipmentAvailabilityReasonGrid.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                var ur = Mapper.Map<EquipmentUnavailableReasonModel, EquipmentUnavailableReason>(model);
                UnitOfWork.EquipmentUnavailableReasons.Insert(ur);
            }
            else if (gridModel.EquipmentAvailabilityReasonGrid.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                var ear = UnitOfWork.EquipmentUnavailableReasons.SelectBy(x => x.ID == model.ID);
                ear.Reason = model.Reason;
                UnitOfWork.EquipmentUnavailableReasons.Update(ear);
            }
            else if (gridModel.EquipmentAvailabilityReasonGrid.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                int matchingEquipmentCount = UnitOfWork.Equipment.SelectFilteredList(x => x.EquipmentUnavailablePeriods.Any(e => e.EquipmentUnavailableReasonID == model.ID)).Count();

                if (matchingEquipmentCount == 0)
                {
                    var eur = UnitOfWork.EquipmentUnavailableReasons.SelectBy(x => x.ID == model.ID);
                    UnitOfWork.EquipmentUnavailableReasons.Delete(eur);
                }
                else
                {
                    return gridModel.EquipmentAvailabilityReasonGrid.ShowEditValidationMessage(Constants.GRID_EQUIPMENT_AVAILABILITY_REASON_UNABLE_TO_DELETE_ERROR);
                }
            }

            UnitOfWork.Commit();

            return RedirectToAction(MVC.Admin.ActionNames.EquipmentAvailabilityReasons);
        }

        #endregion

        #region Instructor Sections

        public virtual ActionResult InstructorSections()
        {
            var vc = new InstructorSectionsModel(Url.Action(Actions.GetInstructorSections()), Url.Action("EditInstructorSections"));

            return View(vc);
        }

        public virtual JsonResult GetInstructorSections()
        {
            var gridModel = new InstructorSectionsModel(Url.Action(Actions.GetInstructorSections()), Url.Action("EditInstructorSections"));

            var sections = UnitOfWork.Sections.SelectAll().OrderBy(s=>s.Title);

            return gridModel.InstructorSectionsGrid.DataBind(sections.AsQueryable());
        }

        public virtual ActionResult EditInstructorSections(InstructorSectionModel model)
        {
            var gridModel = new InstructorSectionsModel(Url.Action(Actions.GetInstructorSections()), Url.Action("EditInstructorSections"));

            // Validate
            if (gridModel.InstructorSectionsGrid.AjaxCallBackMode == AjaxCallBackMode.AddRow ||
                gridModel.InstructorSectionsGrid.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                if (UnitOfWork.Sections.SelectFilteredList(x =>
                                                    x.Title.Trim().Equals(model.Title.Trim())).Count() > 0)
                    return gridModel.InstructorSectionsGrid.ShowEditValidationMessage(Constants.GRID_GROUP_ITEM_ALREADY_EXISTS_ERROR);
            }

            if (gridModel.InstructorSectionsGrid.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                var newSection = new Section()
                {
                    Title = model.Title
                };
                UnitOfWork.Sections.Insert(newSection);
            }
            else if (gridModel.InstructorSectionsGrid.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                var s = UnitOfWork.Sections.SelectBy(x => x.ID == model.ID);
                s.Title = model.Title;
                UnitOfWork.Sections.Update(s);
            }
            else if (gridModel.InstructorSectionsGrid.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                int instructorsForSection = UnitOfWork.Instructors.SelectFilteredList(x => x.SectionID == model.ID).Count();
                int eventsForSection = UnitOfWork.Events.SelectFilteredList(x => x.Activity.SectionID == model.ID).Count();
                int activitiesForSection = UnitOfWork.Activities.SelectFilteredList(x => x.SectionID == model.ID).Count();

                if (instructorsForSection == 0 && eventsForSection == 0 && activitiesForSection == 0)
                {
                    var sectionToDelete = UnitOfWork.Sections.SelectBy(x => x.ID == model.ID);
                    UnitOfWork.Sections.Delete(sectionToDelete);
                }
                else
                {
                    return gridModel.InstructorSectionsGrid.ShowEditValidationMessage(Constants.GRID_SECTION_UNABLE_TO_DELETE_ERROR);
                }
            }

            UnitOfWork.Commit();

            return RedirectToAction(MVC.Admin.ActionNames.InstructorSections);
        }
        
        #endregion

        #region Instructor Groups

        public virtual ActionResult InstructorGroups()
        {
            var vc = new InstructorGroupsModel(Url.Action(Actions.GetInstructorGroups()), Url.Action("EditInstructorGroups"));

            return View(vc);
        }

        public virtual JsonResult GetInstructorGroups()
        {
            var gridModel = new InstructorGroupsModel(Url.Action(Actions.GetInstructorGroups()), Url.Action("EditInstructorGroups"));

            var groups = UnitOfWork.Groups.SelectAll().OrderBy(g=>g.Name);

            return gridModel.InstructorGroupsGrid.DataBind(groups.AsQueryable());
        }
        
        public virtual ActionResult EditInstructorGroups(InstructorGroupModel model)
        {
            var gridModel = new InstructorGroupsModel(Url.Action(Actions.GetInstructorGroups()), Url.Action("EditInstructorGroups"));

            // Validate
            if (gridModel.InstructorGroupsGrid.AjaxCallBackMode == AjaxCallBackMode.AddRow ||
                gridModel.InstructorGroupsGrid.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                if (UnitOfWork.Groups.SelectFilteredList(x =>
                                                    x.Name.Trim().Equals(model.Name.Trim())).Count() > 0)
                    return gridModel.InstructorGroupsGrid.ShowEditValidationMessage(Constants.GRID_GROUP_ITEM_ALREADY_EXISTS_ERROR);
            }

            if (gridModel.InstructorGroupsGrid.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                var newGroup = new Group()
                {
                    Name = model.Name
                };
                UnitOfWork.Groups.Insert(newGroup);
            }
            else if (gridModel.InstructorGroupsGrid.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                var g = UnitOfWork.Groups.SelectBy(x => x.ID == model.ID);
                g.Name = model.Name;
                UnitOfWork.Groups.Update(g);
            }
            else if (gridModel.InstructorGroupsGrid.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                int instructorsInGroup = UnitOfWork.Instructors.SelectFilteredList(x => x.GroupID == model.ID).Count();
               
                if (instructorsInGroup == 0)
                {
                    var sectionToDelete = UnitOfWork.Groups.SelectBy(x => x.ID == model.ID);
                    UnitOfWork.Groups.Delete(sectionToDelete);
                }
                else
                {
                    return gridModel.InstructorGroupsGrid.ShowEditValidationMessage(Constants.GRID_GROUP_UNABLE_TO_DELETE_ERROR);
                }
            }

            UnitOfWork.Commit();

            return RedirectToAction(MVC.Admin.ActionNames.InstructorGroups);
        }
        
        #endregion

        #region Training Centres

        public virtual ActionResult TrainingCentres()
        {
            var vc = new TrainingCentresModel(Url.Action(Actions.GetTrainingCentres()), Url.Action("EditTrainingCentres"));

            return View(vc);
        }

        public virtual JsonResult GetTrainingCentres()
        {
            var gridModel = new TrainingCentresModel(Url.Action(Actions.GetTrainingCentres()), Url.Action("EditTrainingCentres"));

            var tcs = UnitOfWork.TrainingCentres.SelectFilteredList(tc=>tc.Name != "National").OrderBy(t=>t.Name);

            return gridModel.TrainingCentresGrid.DataBind(tcs.AsQueryable());
        }

        public virtual ActionResult EditTrainingCentres(TrainingCentreModel model)
        {
            var gridModel = new TrainingCentresModel(Url.Action(Actions.GetTrainingCentres()), Url.Action("EditTrainingCentres"));

            // Validate
            if (gridModel.TrainingCentresGrid.AjaxCallBackMode == AjaxCallBackMode.AddRow ||
                gridModel.TrainingCentresGrid.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                if (UnitOfWork.TrainingCentres.SelectFilteredList(x =>
                                                    x.Name.Trim().Equals(model.Name.Trim())).Count() > 0)
                    return gridModel.TrainingCentresGrid.ShowEditValidationMessage(Constants.GRID_GROUP_ITEM_ALREADY_EXISTS_ERROR);
            }

            if (gridModel.TrainingCentresGrid.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                var newTC = new TrainingCentre()
                {
                    Name = model.Name
                };
                UnitOfWork.TrainingCentres.Insert(newTC);
            }
            else if (gridModel.TrainingCentresGrid.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                var tc = UnitOfWork.TrainingCentres.SelectBy(x => x.ID == model.ID);
                tc.Name = model.Name;
                UnitOfWork.TrainingCentres.Update(tc);
            }
            else if (gridModel.TrainingCentresGrid.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                int instructorsInTrainingCentre = UnitOfWork.Instructors.SelectFilteredList(x => x.TrainingCentreID == model.ID).Count();
                int equipmentForTrainingCentre = UnitOfWork.Equipment.SelectFilteredList(x => x.TrainingCentreID == model.ID).Count();
                int venuesInTrainingCentre = UnitOfWork.Venues.SelectFilteredList(x => x.TrainingCentreID == model.ID).Count();
                int groupCalendarForTrainingCentre = UnitOfWork.GroupCalendars.SelectFilteredList(x => x.TrainingCentreID == model.ID).Count();
                int pinchPointsForTrainingCentre = UnitOfWork.Pinchpoints.SelectFilteredList(x => x.TrainingCentreID == model.ID).Count();

                if (instructorsInTrainingCentre == 0 &&
                        equipmentForTrainingCentre == 0 &&
                            venuesInTrainingCentre == 0 &&
                                groupCalendarForTrainingCentre == 0 &&
                                    pinchPointsForTrainingCentre == 0)
                {
                    //delete any User table references
                    var usersInTrainingCentre = UnitOfWork.Users.SelectFilteredList(x => x.DefaultTrainingCentreID == model.ID);
                    UnitOfWork.Users.DeleteAll(x => x.DefaultTrainingCentreID == model.ID);
                    
                    var tcToDelete = UnitOfWork.TrainingCentres.SelectBy(x => x.ID == model.ID);
                    UnitOfWork.TrainingCentres.Delete(tcToDelete);
                }
                else
                {
                    return gridModel.TrainingCentresGrid.ShowEditValidationMessage(Constants.GRID_GROUP_TRAINING_CENTRE_UNABLE_TO_DELETE);
                }
            }

            UnitOfWork.Commit();

            return RedirectToAction(MVC.Admin.ActionNames.TrainingCentres);
        }
        
        #endregion

        #region iTrent Export

        [HttpPost, AjaxRequest(ajaxAllowed: true, nonAjaxAllowed: false), AjaxResult]
        public virtual ActionResult CreateiTrentExport(ITrentUploadModel model)
        {
            // Don't assume we can trust client-side validation, so check the model is valid
            if (!ModelState.IsValid)
                return View(MVC.Admin.Views.ExportForITrentModalDialog, model);

            // Fetch events to export
            var events = UnitOfWork.Events.SelectFilteredList(PredicateLibrary.GetEventsToExportPredicate(model.SelectedFinancialYear, model.SelectedITrentExportType)).ToList();

            // Don't assume the client checked that some events are available for export, so set the property again
            model.EventsFound = events.Count > 0;

            // Don't assume the client checked that no pending export alraedy exists, so set the property again
            model.PendingExportFound = UnitOfWork.iTrentExports.SelectFilteredList(
                ite => ite.iTrentExportStatusID == (int)iTrentExportStatusEnum.Pending).Count() > 0;

            // Revalidate the model after setting the properties
            TryValidateModel(model);

            // Check whether the model is valid after revalidating
            if (!ModelState.IsValid)
                return View(MVC.Admin.Views.ExportForITrentModalDialog, model);

            // Create the iTrentExport and obtain its ID. Also creates iTrentExportData records and marks Events as non-stale.
            var newExport = ProcessEventsForiTrentExport(events, model.SelectedFinancialYear, model.Title, model.SelectedITrentExportType.Value);

            // Redirect to the main iTrentExport view and tell it to open the newly created export
            return RedirectToAction(MVC.Admin.ActionNames.iTrentExport, MVC.Admin.Name, new { id = newExport.ID });
        }

        private DateTime ParseiTrentDate(string date)
        {
            return new DateTime(Convert.ToInt32(date.Substring(0, 4)), Convert.ToInt32(date.Substring(4, 2)), Convert.ToInt32(date.Substring(6, 2)));
        }

        // Private class for use in ProcessEventsForiTrentExport
        private class iTrentExportVenue
        {
            internal Event Event { get; set; }
            internal Venue Venue { get; set; }
            internal DateTime StartDate { get; set; }
            internal EventPartTypeEnum StartDayType { get; set; }
            internal DateTime EndDate { get; set; }
            internal EventPartTypeEnum EndDayType { get; set; }
        }

        // Private class for use in ProcessEventsForiTrentExport
        private class iTrentExportInstructor
        {
            internal Event Event { get; set; }
            internal Instructor Instructor { get; set; }
            internal DateTime StartDate { get; set; }
            internal EventPartTypeEnum StartDayType { get; set; }
            internal DateTime EndDate { get; set; }
            internal EventPartTypeEnum EndDayType { get; set; }
        }

        private iTrentExport ProcessEventsForiTrentExport(List<Event> events, int financialYear, string exportTitle, iTrentExportTypeEnum exportType)
        {
            var iTrentExportEventDataList = new List<iTrentExportData>();
            var iTrentExportVenueDataList = new List<iTrentExportVenue>();
            var iTrentExportInstructorDataList = new List<iTrentExportInstructor>();
            var iTrentExportErrors = new List<iTrentExportError>();

            foreach (var e in events)
            {
                try
                {
                    var eventParts = e.EventParts.Where(ep => ep.Date.HasValue).OrderBy(ep => ep.Date).ThenBy(ep => ep.DayType).ToList();
                    var venueEventParts = eventParts.SelectMany(ep => ep.VenueEventParts).OrderBy(vep => vep.EventPart.Date).ThenBy(vep => vep.EventPart.DayType).ToList();
                    var instructorEventParts = eventParts.SelectMany(iep => iep.InstructorEventParts).OrderBy(iep => iep.EventPart.Date).ThenBy(iep => iep.EventPart.DayType).ToList();

                    #region Event
                    
                    // Cancelled events might not have any event parts with dates assigned
                    var firstEventPart = eventParts.FirstOrDefault();
                    var lastEventPart = eventParts.LastOrDefault();

                    string cancelReason = null;
                    string cancelDate = null;

                    if (e.Status == (int)EventStatusEnum.Cancelled)
                    {
                        var cancelHistory = e.EventCancelledHistories.OrderByDescending(x => x.CancelledOn).FirstOrDefault();

                        if (cancelHistory != null)
                        {
                            cancelReason = cancelHistory.CancelEventReason != null ? cancelHistory.CancelEventReason.Reason : cancelHistory.Reason;

                            if (cancelReason.Length > Constants.ITRENT_UPLOAD_EVENT_CANCEL_REASON_MAX_LENGTH)
                                cancelReason = cancelReason.Substring(0, Constants.ITRENT_UPLOAD_EVENT_CANCEL_REASON_MAX_LENGTH);

                            cancelDate = cancelHistory.CancelledOn.ToString(Constants.ITRENT_UPLOAD_DATE_FORMAT);
                        }
                    }

                    var exportedEvent = new iTrentExportData
                    {
                        EventID = e.ID,
                        ActivityCode = e.Activity.Code,

                        ActivityName = e.Activity.Title.Length <= Constants.ITRENT_UPLOAD_ACTIVITY_TITLE_MAX_LENGTH ?
                            e.Activity.Title : 
                            e.Activity.Title.Substring(0, Constants.ITRENT_UPLOAD_ACTIVITY_TITLE_MAX_LENGTH),

                        EventCode = e.GetEventCode(),
                        StartDate = firstEventPart != null ? firstEventPart.Date.ToString(Constants.ITRENT_UPLOAD_DATE_FORMAT) : null,

                        StartTime = firstEventPart != null ? (firstEventPart.DayType == (int)EventPartTypeEnum.Afternoon ?
                            Constants.ITRENT_UPLOAD_PM_START_TIME :
                            Constants.ITRENT_UPLOAD_AM_START_TIME) : null,

                        EndDate = lastEventPart != null ? lastEventPart.Date.ToString(Constants.ITRENT_UPLOAD_DATE_FORMAT) : null,

                        EndTime = lastEventPart != null ? (lastEventPart.DayType == (int)EventPartTypeEnum.Morning ?
                            Constants.ITRENT_UPLOAD_AM_END_TIME :
                            Constants.ITRENT_UPLOAD_PM_END_TIME) : null,

                        Status = e.Status == (int)EventStatusEnum.Cancelled ? Constants.ITRENT_UPLOAD_STATUS_CANCELLED : null,
                        CancelReason = cancelReason,
                        CancelDate = cancelDate
                    };

                    iTrentExportEventDataList.Add(exportedEvent);

                    #endregion

                    if (e.Status != (int)EventStatusEnum.Cancelled) // No venues or instructors when event is cancelled.
                    {
                        #region Venues

                        // Combine adjacent VenueEventPart records. The records we loop around must be in Date & DayType order
                        foreach (var vep in venueEventParts)
                        {
                            var ep = vep.EventPart;

                            // Look for a venue record that is adjacent to this one
                            var adjacent = (
                                from rec in iTrentExportVenueDataList
                                let startDayDiff = (rec.StartDate - ep.Date.Value).Days
                                let endDayDiff = (rec.EndDate - ep.Date.Value).Days
                                let startsSameDay = startDayDiff == 0 && ep.DayType == (int)EventPartTypeEnum.Morning && rec.StartDayType == EventPartTypeEnum.Afternoon
                                let startsDayAfter = startDayDiff == 1 && ep.DayType == (int)EventPartTypeEnum.Afternoon && rec.StartDayType == EventPartTypeEnum.Morning
                                let endsSameDay = endDayDiff == 0 && ep.DayType == (int)EventPartTypeEnum.Afternoon && rec.EndDayType == EventPartTypeEnum.Morning
                                let endsDayBefore = endDayDiff == -1 && ep.DayType == (int)EventPartTypeEnum.Morning && rec.EndDayType == EventPartTypeEnum.Afternoon
                                where vep.EventPart.EventID == rec.Event.ID && vep.VenueID == rec.Venue.ID && (startsSameDay || startsDayAfter || endsSameDay || endsDayBefore)
                                select new
                                {
                                    AdjacentRecord = rec,
                                    StartsLaterSameDay = startsSameDay, // Does the adjacent record start later on the same day the current record starts?
                                    StartsDayAfter = startsDayAfter, // Does the adjacent record start on the morning following the afternoon the current record starts?
                                    EndsEarlierSameDay = endsSameDay, // Does the adjacent record end earlier on the same day the current record ends?
                                    EndsDayBefore = endsDayBefore // Does the adjacent record end on the afternoon prior to the morning the current record ends?
                                }).FirstOrDefault();

                            if (adjacent == null)
                            {
                                // No adjacent venue record was found, insert a new record
                                iTrentExportVenueDataList.Add(new iTrentExportVenue
                                {
                                    Event = e,
                                    Venue = vep.Venue,
                                    StartDate = ep.Date.Value,
                                    StartDayType = (EventPartTypeEnum)ep.DayType.Value,
                                    EndDate = ep.Date.Value,
                                    EndDayType = (EventPartTypeEnum)ep.DayType.Value
                                });
                            }
                            else
                            {
                                // An adjacent venue record was found, update it with the details of the current record
                                if (adjacent.StartsLaterSameDay)
                                {
                                    adjacent.AdjacentRecord.StartDayType = (EventPartTypeEnum)ep.DayType.Value;
                                }
                                else if (adjacent.StartsDayAfter)
                                {
                                    adjacent.AdjacentRecord.StartDate = ep.Date.Value;
                                    adjacent.AdjacentRecord.StartDayType = (EventPartTypeEnum)ep.DayType.Value;
                                }
                                else if (adjacent.EndsEarlierSameDay)
                                {
                                    adjacent.AdjacentRecord.EndDayType = (EventPartTypeEnum)ep.DayType.Value;
                                }
                                else if (adjacent.EndsDayBefore)
                                {
                                    adjacent.AdjacentRecord.EndDate = ep.Date.Value;
                                    adjacent.AdjacentRecord.EndDayType = (EventPartTypeEnum)ep.DayType.Value;
                                }
                            }
                        }

                        #endregion

                        #region Instructors

                        // Combine adjacent InstructorEventParts records. The records we loop around must be in Date & DayType order
                        foreach (var iep in instructorEventParts)
                        {
                            var ep = iep.EventPart;

                            // Look for an instructor record that is adjacent to this one
                            var adjacent = (
                                from rec in iTrentExportInstructorDataList
                                let startDayDiff = (rec.StartDate - ep.Date.Value).Days
                                let endDayDiff = (rec.EndDate - ep.Date.Value).Days
                                let startsSameDay = startDayDiff == 0 && ep.DayType == (int)EventPartTypeEnum.Morning && rec.StartDayType == EventPartTypeEnum.Afternoon
                                let startsDayAfter = startDayDiff == 1 && ep.DayType == (int)EventPartTypeEnum.Afternoon && rec.StartDayType == EventPartTypeEnum.Morning
                                let endsSameDay = endDayDiff == 0 && ep.DayType == (int)EventPartTypeEnum.Afternoon && rec.EndDayType == EventPartTypeEnum.Morning
                                let endsDayBefore = endDayDiff == -1 && ep.DayType == (int)EventPartTypeEnum.Morning && rec.EndDayType == EventPartTypeEnum.Afternoon
                                where iep.EventPart.EventID == rec.Event.ID && iep.InstructorID == rec.Instructor.ID && (startsSameDay || startsDayAfter || endsSameDay || endsDayBefore)
                                select new
                                {
                                    AdjacentRecord = rec,
                                    StartsLaterSameDay = startsSameDay, // Does the adjacent record start later on the same day the current record starts?
                                    StartsDayAfter = startsDayAfter, // Does the adjacent record start on the morning following the afternoon the current record starts?
                                    EndsEarlierSameDay = endsSameDay, // Does the adjacent record end earlier on the same day the current record ends?
                                    EndsDayBefore = endsDayBefore // Does the adjacent record end on the afternoon prior to the morning the current record ends?
                                }).FirstOrDefault();

                            if (adjacent == null)
                            {
                                // No adjacent venue record was found, insert a new record
                                iTrentExportInstructorDataList.Add(new iTrentExportInstructor
                                {
                                    Event = e,
                                    Instructor = iep.Instructor,
                                    StartDate = ep.Date.Value,
                                    StartDayType = (EventPartTypeEnum)ep.DayType.Value,
                                    EndDate = ep.Date.Value,
                                    EndDayType = (EventPartTypeEnum)ep.DayType.Value
                                });
                            }
                            else
                            {
                                // An adjacent venue record was found, update it with the details of the current record
                                if (adjacent.StartsLaterSameDay)
                                {
                                    adjacent.AdjacentRecord.StartDayType = (EventPartTypeEnum)ep.DayType.Value;
                                }
                                else if (adjacent.StartsDayAfter)
                                {
                                    adjacent.AdjacentRecord.StartDate = ep.Date.Value;
                                    adjacent.AdjacentRecord.StartDayType = (EventPartTypeEnum)ep.DayType.Value;
                                }
                                else if (adjacent.EndsEarlierSameDay)
                                {
                                    adjacent.AdjacentRecord.EndDayType = (EventPartTypeEnum)ep.DayType.Value;
                                }
                                else if (adjacent.EndsDayBefore)
                                {
                                    adjacent.AdjacentRecord.EndDate = ep.Date.Value;
                                    adjacent.AdjacentRecord.EndDayType = (EventPartTypeEnum)ep.DayType.Value;
                                }
                            }
                        }

                        #endregion
                    }
                }
                catch (Exception ex)
                {
                    //Something catastrophic went wrong; so exclude the event and carry on.
                    iTrentExportErrors.Add(new iTrentExportError
                    {
                        Event = e,
                        ErrorMessage = ex.GetFullMessage()
                    });

                    continue;
                }
            }

            var newExport = new iTrentExport
            {
                Title = exportTitle,
                ExportDate = DateTime.Now,
                iTrentExportStatusID = (int)iTrentExportStatusEnum.Pending,
                iTrentExportTypeID = (int)exportType,
                FinancialYear = financialYear,
                EventsExported = iTrentExportEventDataList.Count,
                ExportErrors = iTrentExportErrors.Count,
                EventsUploaded = 0,
                UploadErrors = 0
            };

            UnitOfWork.iTrentExports.Insert(newExport);

            iTrentExportEventDataList.ForEach(edl =>
            {
                edl.iTrentExport = newExport;
                UnitOfWork.Events.UpdateStatus(edl.EventID, Trigger.ITrentExportCreated, TORUser.FullName);
                UnitOfWork.iTrentExportDatas.Insert(edl);
            });

            iTrentExportVenueDataList.ForEach(vdl =>
            {
                UnitOfWork.iTrentExportDatas.Insert(
                    new iTrentExportData
                    {
                        iTrentExport = newExport,
                        EventID = vdl.Event.ID,
                        EventCode = vdl.Event.GetEventCode(),
                        VenueName = vdl.Venue.Name,
                        VenueStartDate = vdl.StartDate.ToString(Constants.ITRENT_UPLOAD_DATE_FORMAT),
                        VenueStartTime = vdl.StartDayType == EventPartTypeEnum.Afternoon ? Constants.ITRENT_UPLOAD_PM_START_TIME : Constants.ITRENT_UPLOAD_AM_START_TIME,
                        VenueEndDate = vdl.EndDate.ToString(Constants.ITRENT_UPLOAD_DATE_FORMAT),
                        VenueEndTime = vdl.EndDayType == EventPartTypeEnum.Morning ? Constants.ITRENT_UPLOAD_AM_END_TIME : Constants.ITRENT_UPLOAD_PM_END_TIME
                    }
                );
            });

            iTrentExportInstructorDataList.ForEach(idl =>
            {
                UnitOfWork.iTrentExportDatas.Insert(
                    new iTrentExportData
                    {
                        iTrentExport = newExport,
                        EventID = idl.Event.ID,
                        EventCode = idl.Event.GetEventCode(),
                        ExternalPRForename1 = idl.Instructor.FirstName,
                        ExternalPRSurname = idl.Instructor.LastName,
                        PRStartDate = idl.StartDate.ToString(Constants.ITRENT_UPLOAD_DATE_FORMAT),
                        PRStartTime = idl.StartDayType == EventPartTypeEnum.Afternoon ? Constants.ITRENT_UPLOAD_PM_START_TIME : Constants.ITRENT_UPLOAD_AM_START_TIME,
                        PREndDate = idl.EndDate.ToString(Constants.ITRENT_UPLOAD_DATE_FORMAT),
                        PREndTime = idl.EndDayType == EventPartTypeEnum.Morning ? Constants.ITRENT_UPLOAD_AM_END_TIME : Constants.ITRENT_UPLOAD_PM_END_TIME
                    }
                );
            });

            iTrentExportErrors.ForEach(err =>
            {
                err.iTrentExport = newExport;
                UnitOfWork.iTrentExportErrors.Insert(err);
            });

            UnitOfWork.Commit();

            return newExport;
        }

        public virtual JsonResult HasPendingITrentExports()
        {
            bool hasPendingExports = UnitOfWork.iTrentExports
                                        .SelectFilteredList(x => x.iTrentExportStatusID == (int)iTrentExportStatusEnum.Pending)
                                        .Count() > 0 ? true : false;
            return Json(hasPendingExports, JsonRequestBehavior.AllowGet);
        }

        public virtual ActionResult iTrentExport(int? id = null)
        {
            var ite = new iTrentExportsModel(Url.Action(Actions.GetiTrentExports()), Url.Action("EditiTrentExport"));

            ite.SelectedITrentExportID = id;
            ite.iTrentUploadModel.FinancialYearsSelectList = GetFinancialYearSelectList();
            ite.iTrentUploadModel.ITrentUploadTypes = UnitOfWork.iTrentExportTypes.SelectAll().ToList().Select(t => new SelectListItem { Value = t.ID.ToString(), Text = t.Title });
            
            ViewBag.HasWriteAccess = (TORUser.TORRole > TORRole.User);
            ViewBag.HasAdminAccess = (TORUser.TORRole == TORRole.Admin);

            return View(ite);
        }

        public virtual JsonResult GetiTrentExports()
        {
            var gridModel = new iTrentExportsModel(Url.Action(Actions.GetiTrentExports()), Url.Action("EditITrentExport"));
            var itrentExports = UnitOfWork.iTrentExports.GetITrentExports();
            return gridModel.iTrentExportsGrid.DataBind(itrentExports.AsQueryable());
        }

        public virtual ActionResult EditITrentExport(iTrentExportModel model)
        {
            var gridModel = new iTrentExportsModel("", "");

            if (gridModel.iTrentExportsGrid.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                var iTrentExport = UnitOfWork.iTrentExports.SelectBy(x => x.ID == model.ID);

                if (iTrentExport.iTrentExportStatusID == (int)iTrentExportStatusEnum.Uploaded)
                    //throw new Exception("Uploaded exports cannot be deleted.");
                    return gridModel.iTrentExportsGrid.ShowEditValidationMessage("Uploaded exports cannot be deleted.");

                var events = iTrentExport.iTrentExportDatas.Select(d => d.Event).Distinct().ToList();

                foreach (var e in events)
                {
                    UnitOfWork.Events.UpdateStatus(e.ID, Trigger.ITrentExportDeleted, TORUser.FullName);
                }

                //Remove all data/errors and import failures before deleting the export record
                UnitOfWork.iTrentExportDatas.DeleteAll(x => x.iTrentExportID == model.ID);
                UnitOfWork.iTrentExportErrors.DeleteAll(x => x.iTrentExportID == model.ID);
                UnitOfWork.iTrentImportFailures.DeleteAll(x => x.iTrentExportID == model.ID);
                UnitOfWork.iTrentExports.Delete(iTrentExport);

                UnitOfWork.Commit();
            }

            return RedirectToAction(MVC.Admin.Actions.iTrentExport());
        }

        public virtual JsonResult GetITrentExport(int SelectedExportID)
        {
            var ie = UnitOfWork.iTrentExports.GetITrentExportDetails(SelectedExportID);

            if (ie == null)
                throw new Exception("The requested iTrent Export was not found.");

            return Json(ie, JsonRequestBehavior.AllowGet);
        }

        [HttpPost, AjaxResult]
        public virtual ActionResult ConfirmITrentExport(int id)
        {
            var export = UnitOfWork.iTrentExports.SelectBy(x => x.ID == id);
            export.iTrentExportStatusID = (int)iTrentExportStatusEnum.Uploaded;
            UnitOfWork.iTrentExports.Update(export);

            var exportedEvents = export.iTrentExportDatas.Select(d => d.Event).Distinct().ToList();

            // Get IDs of Events that failed to be imported into iTrent. Ignore failures that related to resources only
            // i.e. where some of the event's venues or instructors did not import ok but the event itself did.
            var failedUploadEventIDs = export.iTrentImportFailures.Where(f => !f.ResourceFailureOnly)
                .Select(f => f.EventID).ToList();

            var uploadedEvents = exportedEvents.Where(e => !failedUploadEventIDs.Contains(e.ID));
            var failedEvents = exportedEvents.Where(e => failedUploadEventIDs.Contains(e.ID));

            foreach (Event e in uploadedEvents)
            {
                UnitOfWork.Events.UpdateStatus(e.ID, Trigger.EventUploadedToITrent, TORUser.FullName);
            }

            foreach (Event e in failedEvents)
            {
                UnitOfWork.Events.UpdateStatus(e.ID, Trigger.EventFailedToUploadToITrent, TORUser.FullName);
            }

            export.EventsUploaded = uploadedEvents.Count();

            UnitOfWork.Commit();

            return RedirectToAction(MVC.Admin.iTrentExport(id));
        }

        public virtual FileContentResult DownloadITrentExport(int id)
        {
            var iTrentExportColumns = new List<string> {
                "ACTIVITY_CODE", "ACTIVITY_NAME", "EVENT_CODE", "START_DATE", "START_TIME", "END_DATE", "END_TIME",
                "STATUS", "CANCEL_REASON", "CANCEL_DATE", "VENUE_NAME", "VENUE_START_DATE", "VENUE_START_TIME", 
                "VENUE_END_DATE", "VENUE_END_TIME", "PR_PER_REF_NO", "EXTERNAL_PR_FORENAME1", "EXTERNAL_PR_SURNAME", 
                "PR_START_DATE", "PR_START_TIME", "PR_END_DATE", "PR_END_TIME" }.AsReadOnly();

            var iTrentExport = UnitOfWork.iTrentExports.SelectBy(x => x.ID == id);

            if (iTrentExport == null)
                throw new Exception("The requested iTrent Export was not found.");

            var exportData = iTrentExport.iTrentExportDatas
                .OrderBy(d => d.EventCode)
                .ThenBy(d => d.StartDate ?? "ZZZ") // Use "ZZZ" to emulate a "NULLS LAST" sort order
                .ThenBy(d => d.VenueName ?? "ZZZ")
                .ThenBy(d => d.ExternalPRSurname ?? "ZZZ")
                .ThenBy(d => d.ExternalPRForename1 ?? "ZZZ").ToList();

            var excel = new ExcelPackage();
            ExcelWorksheet sheet = excel.Workbook.Worksheets.Add("Data");
            int row = 1;

            // Output the column headings and formats
            for (int col = 1; col <= iTrentExportColumns.Count; col++)
            {
                sheet.Cells[row, col].Value = iTrentExportColumns[col - 1];
                sheet.Column(col).Style.Numberformat.Format = Constants.EXCEL_TEXT_FORMAT_STRING;
                sheet.Column(col).AutoFit();
            }

            // Output the rows of data
            exportData.ForEach(d => {
                var values = new List<string> {
                    d.ActivityCode, d.ActivityName, d.EventCode, d.StartDate, d.StartTime, d.EndDate, d.EndTime,
                    d.Status, d.CancelReason, d.CancelDate, d.VenueName, d.VenueStartDate, d.VenueStartTime,
                    d.VenueEndDate, d.VenueEndTime, d.PRPerRefNo, d.ExternalPRForename1, d.ExternalPRSurname,
                    d.PRStartDate, d.PRStartTime, d.PREndDate, d.PREndTime
                };
                
                row++;
                int col = 0;

                values.ForEach(v => {
                    col++;
                    sheet.Cells[row, col].Value = v;
                });
            });

            char[] invalidChars = Path.GetInvalidFileNameChars();
            string filename = System.Text.RegularExpressions.Regex.Replace(iTrentExport.Title, new String(invalidChars), "-");

            return File(
                excel.GetAsByteArray(),
                Constants.EXCEL_MIME_TYPE,
                String.Format("{0}.{1}", filename, Constants.EXCEL_FILE_EXTENSION)
            );
        }

        [HttpPost]
        public virtual JsonResult InsertITrentImportFailure(int iTrentExportID, string EventCode, bool ResourceFailuresOnly, string Comments)
        {
            var iTrentExport = UnitOfWork.iTrentExports.SelectBy(ite => ite.ID == iTrentExportID);

            if (iTrentExport == null)
                throw new Exception("Could not find the specified iTrent Export");

            if (iTrentExport.iTrentExportStatusID == (int)iTrentExportStatusEnum.Uploaded)
                throw new Exception("This export has already been marked as Uploaded, cannot make further changes.");

            var failedEvent = UnitOfWork.Events.SelectBy(e => e.EventCode == EventCode);
            bool eventInserted = false;
            bool failureAlreadyExists = false;
            bool eventWasExported = true;

            if (failedEvent != null)
            {
                failureAlreadyExists = iTrentExport.iTrentImportFailures.Any(f => f.EventID == failedEvent.ID);
                eventWasExported = iTrentExport.iTrentExportDatas.Any(d => d.EventID == failedEvent.ID);

                if (!failureAlreadyExists && eventWasExported)
                {
                    var importFailure = new iTrentImportFailure
                    {
                        EventID = failedEvent.ID,
                        ResourceFailureOnly = ResourceFailuresOnly,
                        Comments = Comments
                    };

                    UnitOfWork.iTrentImportFailures.Insert(importFailure);
                    iTrentExport.iTrentImportFailures.Add(importFailure);
                    iTrentExport.UploadErrors = iTrentExport.iTrentImportFailures.Count;

                    UnitOfWork.Commit();
                    eventInserted = true;
                }
            }

            var importFails = iTrentExport.iTrentImportFailures.OrderBy(f => f.Event.EventCode).ToList();

            var returnData = new
            {
                EventCode = EventCode,
                EventInserted = eventInserted,
                EventNotFound = failedEvent == null,
                EventWasExported = eventWasExported,
                EventAlreadyRecorded = failureAlreadyExists,
                FailedImports = importFails.Select(f => new
                {
                    ID = f.ID,
                    EventCode = f.Event.GetEventCode(),
                    Comments = f.Comments,
                    ResourceFailureOnly = f.ResourceFailureOnly
                })
            };

            return Json(returnData);
        }

        [HttpPost]
        public virtual JsonResult DeleteITrentImportFailures(int iTrentExportID, int[] iTrentImportFailureID = null)
        {
            if (iTrentImportFailureID == null || iTrentImportFailureID.Length == 0)
                throw new Exception("No import failures were selected");

            var iTrentExport = UnitOfWork.iTrentExports.SelectBy(ite => ite.ID == iTrentExportID);

            if (iTrentExport == null)
                throw new Exception("Could not find the specified iTrent Export");

            if (iTrentExport.iTrentExportStatusID == (int)iTrentExportStatusEnum.Uploaded)
                throw new Exception("This export has already been marked as Uploaded, cannot make further changes.");

            var failures = UnitOfWork.iTrentImportFailures.SelectFilteredList(f => iTrentImportFailureID.Contains(f.ID)).ToList();

            string eventCodes = "";

            foreach (var failure in failures)
            {
                eventCodes += ", " + failure.Event.EventCode;
                UnitOfWork.iTrentImportFailures.Delete(failure);
            }

            iTrentExport.UploadErrors = iTrentExport.iTrentImportFailures.Count;

            UnitOfWork.Commit();

            eventCodes = eventCodes.Substring(2);

            var importFails = iTrentExport.iTrentImportFailures.OrderBy(f => f.Event.EventCode).ToList();

            var returnData = new
            {
                EventCode = eventCodes,
                EventRemoved = true,
                FailedImports = importFails.Select(f => new
                {
                    ID = f.ID,
                    EventCode = f.Event.GetEventCode(),
                    Comments = f.Comments,
                    ResourceFailureOnly = f.ResourceFailureOnly
                })
            };

            return Json(returnData);
        }

        [HttpGet]
        public virtual JsonResult GetFailedITrentData(int SelectedITrentExportID)
        {
            var iTrentExport = UnitOfWork.iTrentExports.SelectBy(ite => ite.ID == SelectedITrentExportID);
            
            if (iTrentExport == null)
                throw new Exception("Could not find the specified iTrent Export");

            var exportFails = iTrentExport.iTrentExportErrors.OrderBy(e => e.Event.EventCode).ToList();
            var importFails = iTrentExport.iTrentImportFailures.OrderBy(f => f.Event.EventCode).ToList();
            
            var returnData = new
            {
                FailedExports = exportFails.Select(f => new 
                {
                    EventCode = f.Event.GetEventCode(),
                    ErrorMessage = f.ErrorMessage
                }),
                FailedImports = importFails.Select(f => new
                {
                    ID = f.ID,
                    EventCode = f.Event.GetEventCode(),
                    Comments = f.Comments,
                    ResourceFailureOnly = f.ResourceFailureOnly
                })
            };

            return Json(returnData, JsonRequestBehavior.AllowGet);
        }

        #endregion

    }
}
