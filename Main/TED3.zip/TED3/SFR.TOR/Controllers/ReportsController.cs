﻿using System.Web.Mvc;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.Web.Filters;
using SFR.TOR.ViewModels;
using System;
using System.Collections.Generic;
using LinqKit;
using System.Linq.Expressions;
using SFR.TOR.Data;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using SFR.TOR.Utility;

namespace SFR.TOR.Web.Controllers
{
    [TORUserAuthorisation]
    public partial class ReportsController : BaseController
    {
        public ReportsController(ITORUnitOfWork unitOfWork)
            : base(unitOfWork)
        {
        }

        public virtual ActionResult Index()
        {
            var reportIndexModel = new ReportIndexModel
                {
                    Reports = GetAllReports()
                };

            return View(reportIndexModel);
        }

        #region Views

        public virtual ActionResult Catering()
        {
            var cateringModel = new CateringReportParamModel
            {
                FromDate = DateTime.Now,
                ToDate = DateTime.Now.AddMonths(1),
                RunReport = false,
                SelectedReport = Constants.REPORT_NAME_CATERING,
                Reports = GetAllReports()
            };

            return View(cateringModel);
        }

        public virtual ActionResult EventsByStatus()
        {
            var eventsModel = new EventReportParamModel
                {
                    FromDate = DateTime.Now,
                    ToDate = DateTime.Now.AddMonths(1),
                    SelectedReport = Constants.REPORT_NAME_EVENTS,
                    Reports = GetAllReports(),
                    EventStatuses = GetAllEventStatuses(),
                    EventResourceStatuses = GetAllEventResourceStatuses(),
                    AllSections = GetAllSections()
                };

            return View(eventsModel);
        }

        public virtual ActionResult ResourceUtilisation()
        {
            var resourceUtilisationModel = new ResourceUtilisationParamModel
            {
                FromDate = DateTime.Now,
                ToDate = DateTime.Now.AddMonths(1),
                SelectedReport = Constants.REPORT_NAME_RESOURCE_UTILISATION,
                Reports = GetAllReports(),
                AvailabilityReasons = GetAllAvailabilityReasons(false) // Exclude Engaged In Events option
            };

            return View(resourceUtilisationModel);
        }

        public virtual ActionResult InstructorUtilisation()
        {
            var resourceUtilisationModel = new InstructorUtilisationParamModel
            {
                FromDateList = GetDateRange(),
                SelectedReport = Constants.REPORT_NAME_INSTRUCTOR_UTILISATION,
                Reports = GetAllReports(),
                AvailabilityReasons = GetAllAvailabilityReasons(true), // include Engaged In Events option
                MonthYearTimePeriodList = GetYearMonthTimePeriodSelectList()
            };

            return View(resourceUtilisationModel);
        }

        public virtual ActionResult VenueCategories()
        {
            var venueCategoriesModel = new VenueCategoriesReportParamModel
            {
                SelectedReport = Constants.REPORT_NAME_VENUE_CATEGORIES,
                Reports = GetAllReports()
            };

            return View(venueCategoriesModel);
        }

        public virtual ActionResult EventsByVenueGroup()
        {
            var venueCategoriesModel = new VenueCategoriesReportParamModel
            {
                FromDate = DateTime.Now,
                ToDate = DateTime.Now.AddMonths(1),
                SelectedReport = Constants.REPORT_NAME_EVENTS_BY_VENUE_GROUP,
                Reports = GetAllReports()
            };

            return View(venueCategoriesModel);
        }

        public virtual ActionResult InstructorAssignments()
        {
            var instructorAssignmentsModel = new InstructorAssignmentsReportParamModel
            {
                FromDate = DateTime.Now,
                ToDate = DateTime.Now.AddMonths(1),
                SelectedReport = Constants.REPORT_NAME_INSTRUCTOR_ASSIGNMENTS,
                Reports = GetAllReports()
            };

            return View(instructorAssignmentsModel);
        }

        public virtual ActionResult TORSection()
        {
            var torSectionModel = new TORSectionReportParamModel
            {
                FromDate = DateTime.Now,
                ToDate = DateTime.Now.AddMonths(1),
                SelectedReport = Constants.REPORT_NAME_TOR_SECTION,
                Reports = GetAllReports(),
                AllSections = GetAllSections()
            };

            return View(torSectionModel);
        }

        public virtual ActionResult TORSectionSignOff()
        {
            var torSectionSignOffModel = new TORSectionSignOffReportParamModel
            {
                FromDate = DateTime.Now,
                ToDate = DateTime.Now.AddDays(7),
                AllSections = GetAllSections(),
                SelectedReport = Constants.REPORT_NAME_TOR_SECTION_SIGN_OFF,
                Reports = GetAllReports()
            };

            return View(torSectionSignOffModel);
        }

        #region Not Yet Implemented

        public virtual ActionResult FacilitiesManagement()
        {
            return View();
        }

        public virtual ActionResult Caretaking()
        {
            return View();
        }

        public virtual ActionResult FiregroundTechnician()
        {
            return View();
        }

        public virtual ActionResult TrainingCentreFacilities()
        {
            return View();
        }

        public virtual ActionResult ReceptionDesk()
        {
            return View();
        }

        #endregion

        #endregion

        #region PostBacks

        [HttpPost]
        public virtual ActionResult Catering(CateringReportParamModel model)
        {
            model.RunReport = ModelState.IsValid;
            model.SelectedReport = Constants.REPORT_NAME_CATERING;
            model.Reports = GetAllReports();

            return View(model);
        }

        [HttpPost]
        public virtual ActionResult EventsByStatus(EventReportParamModel model)
        {
            model.RunReport = ModelState.IsValid;
            model.SelectedReport = Constants.REPORT_NAME_EVENTS;
            model.Reports = GetAllReports();
            model.EventStatuses = GetAllEventStatuses();
            model.EventResourceStatuses = GetAllEventResourceStatuses();
            model.AllSections = GetAllSections();

            if (model.SelectedEventStatuses != null)
                foreach (var status in model.SelectedEventStatuses)
                    model.SelectedEventStatusesString += status + ",";

            if (model.SelectedEventResourceStatuses != null)
                foreach (var status in model.SelectedEventResourceStatuses)
                    model.SelectedEventResourceStatusesString += status + ",";

            if (model.SelectedSection != null)
                foreach (var section in model.SelectedSection)
                    model.SelectedSectionString += section + ",";

            return View(model);
        }

        [HttpPost]
        public virtual ActionResult ResourceUtilisation(ResourceUtilisationParamModel model)
        {
            model.RunReport = ModelState.IsValid;
            model.SelectedReport = Constants.REPORT_NAME_RESOURCE_UTILISATION;
            model.Reports = GetAllReports();
            model.AvailabilityReasons = GetAllAvailabilityReasons(false); //exclude Engaged In Events option

            return View(model);
        }

        [HttpPost]
        public virtual ActionResult InstructorUtilisation(InstructorUtilisationParamModel model)
        {
            model.RunReport = ModelState.IsValid;
            model.SelectedReport = Constants.REPORT_NAME_INSTRUCTOR_UTILISATION;
            model.Reports = GetAllReports();
            model.FromDateList = GetDateRange();
            model.AvailabilityReasons = GetAllAvailabilityReasons(true); // Include Engaged In Events option
            model.MonthYearTimePeriodList = GetYearMonthTimePeriodSelectList();

            if (model.SelectedDate != null)
                foreach (var instructor in model.SelectedDate)
                    model.SelectedDateString = instructor.ToString();

            //if (model.SelectedAvailabilityReason != null)
                

            return View(model);
        }

        [HttpPost]
        public virtual ActionResult InstructorAssignments(InstructorAssignmentsReportParamModel model)
        {
            model.RunReport = ModelState.IsValid;
            model.SelectedReport = Constants.REPORT_NAME_INSTRUCTOR_ASSIGNMENTS;
            model.Reports = GetAllReports();

            if (model.SelectedInstructor > 0)
                //foreach (var instructor in model.SelectedInstructor)
                model.SelectedInstructorString = model.SelectedInstructor.ToString();

            return View(model);
        }

        [HttpPost]
        public virtual ActionResult VenueCategories(BaseReportParamModel model)
        {
            model.RunReport = true; //no parameters to validate
            model.SelectedReport = Constants.REPORT_NAME_VENUE_CATEGORIES;
            model.Reports = GetAllReports();

            return View(model);
        }

        [HttpPost]
        public virtual ActionResult EventsByVenueGroup(VenueCategoriesReportParamModel model)
        {
            model.RunReport = ModelState.IsValid;
            model.SelectedReport = Constants.REPORT_NAME_EVENTS_BY_VENUE_GROUP;
            model.Reports = GetAllReports();

            return View(model);
        }

        [HttpPost]
        public virtual ActionResult TORSection(TORSectionReportParamModel model)
        {
            model.RunReport = ModelState.IsValid;
            model.SelectedReport = Constants.REPORT_NAME_TOR_SECTION;
            model.Reports = GetAllReports();
            model.AllSections = GetAllSections();

            if (model.SelectedSection != null)
                foreach (var section in model.SelectedSection)
                    model.SelectedSectionString += section.ToString() + ",";

            return View(model);
        }

        [HttpPost]
        public virtual ActionResult TORSectionSignOff(TORSectionSignOffReportParamModel model)
        {
            model.RunReport = ModelState.IsValid;
            model.SelectedReport = Constants.REPORT_NAME_TOR_SECTION_SIGN_OFF;
            model.Reports = GetAllReports();
            model.AllSections = GetAllSections();

            if (model.SelectedSection != null)
                foreach (var section in model.SelectedSection)
                    model.SelectedSectionString += section.ToString() + ",";

            return View(model);
        }

        #region Not Yet Implemented

        [HttpPost]
        public virtual ActionResult FacilitiesManagement(object model)
        {
            throw new NotImplementedException();
        }

        [HttpPost]
        public virtual ActionResult Caretaking(object model)
        {
            throw new NotImplementedException();
        }

        [HttpPost]
        public virtual ActionResult FiregroundTechnician(object model)
        {
            throw new NotImplementedException();
        }

        [HttpPost]
        public virtual ActionResult TrainingCentreFacilities(object model)
        {
            throw new NotImplementedException();
        }

        [HttpPost]
        public virtual ActionResult ReceptionDesk(object model)
        {
            throw new NotImplementedException();
        }

        #endregion

        #endregion

        #region Run Reports

        public virtual RedirectResult RunCatering(DateTime fromDate, DateTime toDate)
        {
            return Redirect(String.Format("{0}?{1}={2}&{3}={4:yyyy-MM-dd}&{5}={6:yyyy-MM-dd}&{7}={8}",
                                            Constants.REPORT_VIEWER_URL,
                                            Constants.QUERY_STRING_REPORT_NAME,
                                            Constants.REPORT_NAME_CATERING,
                                            Constants.QUERY_STRING_REPORT_FROM_DATE,
                                            fromDate,
                                            Constants.QUERY_STRING_REPORT_TO_DATE,
                                            toDate,
                                            Constants.QUERY_STRING_REPORT_TRAINING_CENTRE_ID,
                                            TORUser.CurrentTrainingCentreID));
        }

        public virtual ActionResult RunEventsByStatus(DateTime fromDate, DateTime toDate, string SelectedEventStatuses, string SelectedEventResourceStatuses, string SelectedSections, string ReportDaysToCount)
        {
            return Redirect(String.Format("{0}?{1}={2}&{3}={4:yyyy-MM-dd}&{5}={6:yyyy-MM-dd}&{7}={8}&{9}={10}&{11}={12}&{13}={14}&{15}={16}",
                                          Constants.REPORT_VIEWER_URL,
                                          Constants.QUERY_STRING_REPORT_NAME,
                                          Constants.REPORT_NAME_EVENTS,
                                          Constants.QUERY_STRING_REPORT_FROM_DATE,
                                          fromDate,
                                          Constants.QUERY_STRING_REPORT_TO_DATE,
                                          toDate,
                                          Constants.QUERY_STRING_REPORT_SELECTED_EVENT_STATUSES,
                                          SelectedEventStatuses,
                                          Constants.QUERY_STRING_REPORT_SELECTED_EVENT_RESOURCE_STATUSES,
                                          SelectedEventResourceStatuses,
                                          Constants.QUERY_STRING_REPORT_SELECTED_SECTIONS,
                                          SelectedSections,
                                          Constants.QUERY_STRING_REPORT_DAYS_TO_COUNT,
                                          ReportDaysToCount,
                                          Constants.QUERY_STRING_REPORT_TRAINING_CENTRE_ID,
                                          TORUser.CurrentTrainingCentreID));
        }

        public virtual ActionResult RunResourceUtilisation(DateTime fromDate, DateTime toDate, int SelectedAvailabilityReason, string ReportDaysToCount)
        {
            return Redirect(String.Format("{0}?{1}={2}&{3}={4:yyyy-MM-dd}&{5}={6:yyyy-MM-dd}&{7}={8}&{9}={10}&{11}={12}",
                                           Constants.REPORT_VIEWER_URL,
                                           Constants.QUERY_STRING_REPORT_NAME,
                                           Constants.REPORT_NAME_RESOURCE_UTILISATION,
                                           Constants.QUERY_STRING_REPORT_FROM_DATE,
                                           fromDate,
                                           Constants.QUERY_STRING_REPORT_TO_DATE,
                                           toDate,
                                           Constants.QUERY_STRING_REPORT_SELECTED_AVAILABILITY_REASON,
                                           SelectedAvailabilityReason,
                                           Constants.QUERY_STRING_REPORT_DAYS_TO_COUNT,
                                           ReportDaysToCount,
                                           Constants.QUERY_STRING_REPORT_TRAINING_CENTRE_ID,
                                           TORUser.CurrentTrainingCentreID));
        }

        public virtual ActionResult RunInstructorUtilisation(string SelectedDate, string SelectedAvailabilityReason, bool EveningOnlyEvents, string SelectedTimePeriod, string ReportDaysToCount)
        {
            return Redirect(String.Format("{0}?{1}={2}&{3}={4:yyyy-MM-dd}&{5}={6:yyyy-MM-dd}&{7}={8}&{9}={10}&{11}={12}&{13}={14}&{15}={16}",
                                           Constants.REPORT_VIEWER_URL,
                                          Constants.QUERY_STRING_REPORT_NAME,
                                          Constants.REPORT_NAME_INSTRUCTOR_UTILISATION,
                                          Constants.QUERY_STRING_REPORT_FROM_DATE,
                                          SelectedDate,
                                          Constants.QUERY_STRING_REPORT_TO_DATE,
                                          SelectedDate,
                                          Constants.QUERY_STRING_REPORT_SELECTED_AVAILABILITY_REASON,
                                          SelectedAvailabilityReason,
                                          Constants.QUERY_STRING_REPORT_EVENING_EVENTS_ONLY,
                                          EveningOnlyEvents,
                                          Constants.QUERY_STRING_REPORT_SELECTED_TIME_PERIOD,
                                          SelectedTimePeriod,
                                          Constants.QUERY_STRING_REPORT_DAYS_TO_COUNT,
                                          ReportDaysToCount,
                                          Constants.QUERY_STRING_REPORT_TRAINING_CENTRE_ID,
                                          TORUser.CurrentTrainingCentreID));
        }

        public virtual ActionResult RunInstructorAssignments(DateTime fromDate, DateTime toDate, string SelectedInstructors, string ReportDaysToCount)
        {
            return Redirect(String.Format("{0}?{1}={2}&{3}={4:yyyy-MM-dd}&{5}={6:yyyy-MM-dd}&{7}={8}&{9}={10}&{11}={12}",
                                          Constants.REPORT_VIEWER_URL,
                                          Constants.QUERY_STRING_REPORT_NAME,
                                          Constants.REPORT_NAME_INSTRUCTOR_ASSIGNMENTS,
                                          Constants.QUERY_STRING_REPORT_FROM_DATE,
                                          fromDate,
                                          Constants.QUERY_STRING_REPORT_TO_DATE,
                                          toDate,
                                          Constants.QUERY_STRING_REPORT_SELECTED_INSTRUCTORS,
                                          SelectedInstructors,
                                          Constants.QUERY_STRING_REPORT_DAYS_TO_COUNT,
                                          ReportDaysToCount,
                                          Constants.QUERY_STRING_REPORT_TRAINING_CENTRE_ID,
                                          TORUser.CurrentTrainingCentreID));
        }

        public virtual ActionResult RunVenueCategories()
        {
            return Redirect(String.Format("{0}?{1}={2}&{3}={4:yyyy-MM-dd}&{5}={6:yyyy-MM-dd}&{7}={8}",
                                           Constants.REPORT_VIEWER_URL,
                                           Constants.QUERY_STRING_REPORT_NAME,
                                           Constants.REPORT_NAME_VENUE_CATEGORIES,
                                           Constants.QUERY_STRING_REPORT_FROM_DATE,
                                           DateTime.MaxValue,
                                           Constants.QUERY_STRING_REPORT_TO_DATE,
                                           DateTime.MaxValue,
                                           Constants.QUERY_STRING_REPORT_TRAINING_CENTRE_ID,
                                           TORUser.CurrentTrainingCentreID));
        }

        public virtual ActionResult RunEventsByVenueGroup(DateTime fromDate, DateTime toDate)
        {
            return Redirect(String.Format("{0}?{1}={2}&{3}={4:yyyy-MM-dd}&{5}={6:yyyy-MM-dd}&{7}={8}",
                                           Constants.REPORT_VIEWER_URL,
                                           Constants.QUERY_STRING_REPORT_NAME,
                                           Constants.REPORT_NAME_EVENTS_BY_VENUE_GROUP,
                                           Constants.QUERY_STRING_REPORT_FROM_DATE,
                                           fromDate,
                                           Constants.QUERY_STRING_REPORT_TO_DATE,
                                           toDate,
                                           Constants.QUERY_STRING_REPORT_TRAINING_CENTRE_ID,
                                           TORUser.CurrentTrainingCentreID));
        }

        public virtual ActionResult RunTORSection(DateTime fromDate, DateTime toDate, string SelectedSection, string ReportDaysToCount)
        {
            return Redirect(String.Format("{0}?{1}={2}&{3}={4:yyyy-MM-dd}&{5}={6:yyyy-MM-dd}&{7}={8}&{9}={10}&{11}={12}",
                                           Constants.REPORT_VIEWER_URL,
                                           Constants.QUERY_STRING_REPORT_NAME,
                                           Constants.REPORT_NAME_TOR_SECTION,
                                           Constants.QUERY_STRING_REPORT_FROM_DATE,
                                           fromDate,
                                           Constants.QUERY_STRING_REPORT_TO_DATE,
                                           toDate,
                                           Constants.QUERY_STRING_REPORT_SELECTED_SECTIONS,
                                           SelectedSection,
                                           Constants.QUERY_STRING_REPORT_DAYS_TO_COUNT,
                                           ReportDaysToCount,
                                           Constants.QUERY_STRING_REPORT_TRAINING_CENTRE_ID,
                                           TORUser.CurrentTrainingCentreID));
        }

        public virtual ActionResult RunTORSectionSignOff(DateTime fromDate, DateTime toDate, string SelectedSection, string ReportDaysToCount)
        {
            return Redirect(String.Format("{0}?{1}={2}&{3}={4:yyyy-MM-dd}&{5}={6:yyyy-MM-dd}&{7}={8}&{9}={10}&{11}={12}",
                                           Constants.REPORT_VIEWER_URL,
                                           Constants.QUERY_STRING_REPORT_NAME,
                                           Constants.REPORT_NAME_TOR_SECTION_SIGN_OFF,
                                           Constants.QUERY_STRING_REPORT_FROM_DATE,
                                           fromDate,
                                           Constants.QUERY_STRING_REPORT_TO_DATE,
                                           toDate,
                                           Constants.QUERY_STRING_REPORT_SELECTED_SECTIONS,
                                           SelectedSection,
                                           Constants.QUERY_STRING_REPORT_DAYS_TO_COUNT,
                                           ReportDaysToCount,
                                           Constants.QUERY_STRING_REPORT_TRAINING_CENTRE_ID,
                                           TORUser.CurrentTrainingCentreID));
        }

        #region Not Yet Implemented

        public virtual ActionResult RunFacilitiesManagement(DateTime fromDate, DateTime toDate)
        {
            throw new NotImplementedException();
        }

        public virtual ActionResult RunCaretaking(DateTime fromDate, DateTime toDate)
        {
            throw new NotImplementedException();
        }

        public virtual ActionResult RunFiregroundTechnician(DateTime fromDate, DateTime toDate)
        {
            throw new NotImplementedException();
        }

        public virtual ActionResult RunTrainingCentreFacilities(DateTime fromDate, DateTime toDate)
        {
            throw new NotImplementedException();
        }

        public virtual ActionResult RunReceptionDesk(DateTime fromDate, DateTime toDate)
        {
            throw new NotImplementedException();
        }

        #endregion

        #endregion

        #region Data Helpers

        /// <summary>
        /// Returns a list of instructor unavailable reason groups
        /// </summary>
        /// <returns></returns>
        public IEnumerable<SelectListItem> GetAllAvailabilityReasons(bool includeEngagedInEvents)
        {
            var reasons = UnitOfWork.InstructorUnavailableReasonGroups.SelectAll()
                .AsEnumerable()
                .Select(ur =>
                    new SelectListItem
                    {
                        Text = ur.Title,
                        Value = ur.ID.ToString()
                    })
                    .OrderBy(x => x.Text)
                    .ToList();

            if (includeEngagedInEvents)
            {
                reasons.Add(new SelectListItem
                {
                    Text = Constants.INSTRUCTOR_AVAILABILITY_DAYTIME_TRAINING_DESC,
                    Value = Constants.INSTRUCTOR_AVAILABILITY_DAYTIME_TRAINING_ID.ToString()
                });
            }

            return reasons;
        }

        /// <summary>
        /// Returns a list of reports in use by the system
        /// </summary>
        /// <returns></returns>
        public List<SelectListItem> GetAllReports()
        {
            List<SelectListItem> reports = new List<SelectListItem>()
            {
                new SelectListItem { Text = "Catering Report",                  Value = Constants.REPORT_NAME_CATERING },
                new SelectListItem { Text = "Events By Status",                 Value = Constants.REPORT_NAME_EVENTS },
                new SelectListItem { Text = "Resource Utilisation Report",      Value = Constants.REPORT_NAME_RESOURCE_UTILISATION },
                new SelectListItem { Text = "Instructor Utilisation Report",    Value = Constants.REPORT_NAME_INSTRUCTOR_UTILISATION },
                new SelectListItem { Text = "Venues Assigned to Categories",    Value = Constants.REPORT_NAME_VENUE_CATEGORIES},
                new SelectListItem { Text = "Events By Venue Group",            Value = Constants.REPORT_NAME_EVENTS_BY_VENUE_GROUP},
                new SelectListItem { Text = "Instructor Assignments",           Value = Constants.REPORT_NAME_INSTRUCTOR_ASSIGNMENTS},
                new SelectListItem { Text = "Section Events Report",            Value = Constants.REPORT_NAME_TOR_SECTION },
                new SelectListItem { Text = "Section Sign Off Report",          Value = Constants.REPORT_NAME_TOR_SECTION_SIGN_OFF }
            };

            return reports.OrderBy(x => x.Text).ToList();
        }

        /// <summary>
        /// Returns a list of sections
        /// </summary>
        /// <returns></returns>
        private IEnumerable<SelectListItem> GetAllSections()
        {
            return UnitOfWork.Sections.SelectAll()
                .AsEnumerable()
                .Select(r =>
                    new SelectListItem
                        {
                            Text = r.Title,
                            Value = r.ID.ToString()
                        })
                .ToList()
                .OrderBy(x => x.Text);
        }

        /// <summary>
        /// Returns a list of event statuses
        /// </summary>
        /// <returns></returns>
        public IEnumerable<SelectListItem> GetAllEventStatuses()
        {
            return UnitOfWork.EventStatus.SelectAll()
                .AsEnumerable()
                .Select(r => 
                    new SelectListItem 
                        { 
                            Text = r.Title, 
                            Value = r.ID.ToString()
                        }
                )
                .ToList()
                .OrderBy(x => x.Text);
        }

        /// <summary>
        /// Returns a list of event resources
        /// </summary>
        /// <returns></returns>
        public IEnumerable<SelectListItem> GetAllEventResourceStatuses()
        {
            return UnitOfWork.ResourceStatus.SelectAll()
                .AsEnumerable()
                .Select(r =>
                    new SelectListItem
                    {
                        Text = r.Title,
                        Value = r.ID.ToString()
                    }
                )
                .ToList()
                .OrderBy(x => x.Text);
        }

        /// <summary>
        /// Returns a list of instructors based on the currently selected training centre
        /// </summary>
        /// <returns></returns>
        public IEnumerable<SelectListItem> GetAllInstructors()
        {
            return UnitOfWork.Instructors.SelectFilteredList(x => x.TrainingCentreID == TORUser.CurrentTrainingCentreID)
                .AsEnumerable()
                .OrderBy(x => x.LastName)
                .Select(r =>
                    new SelectListItem
                    {
                        Text = string.Format("{0}, {1}", r.LastName, r.FirstName),
                        Value = r.ID.ToString()
                    }
                )
                .ToList();
                
        }

        /// <summary>
        /// Returns a list of instructors where first name and second name contains the search term
        /// </summary>
        /// <param name="Term"></param>
        /// <returns></returns>
        public virtual JsonResult SearchInstructors(string Term)
        {
            var instructors = UnitOfWork.Instructors.SelectFilteredList(x => x.TrainingCentreID == TORUser.CurrentTrainingCentreID)
                .ToList()
                .Where(x => (string.Format("{0} {1}", x.FirstName, x.LastName).ToLower().Contains(Term.Trim().ToLower()))) 
                .OrderBy(x => x.LastName)
                .Select(r =>
                    new
                    {
                        label = string.Format("{0} {1}", r.FirstName, r.LastName), 
                        id = r.ID
                    }
                )
                .ToList();

            Response.CacheControl = "no-cache"; // stop IE from caching the result
            return Json(instructors.ToArray(), JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Returns a list of SelectListItem of Dates from DateTime.Now - 1 year & DateTime.Now + 1 year, in 'MMMM yyyy' format
        /// </summary>
        /// <returns></returns>
        public List<SelectListItem> GetDateRange()
        {
            var today = DateTime.Now;
            var aYearAgo = DateTime.Now.AddYears(-1);
            var aYearAway = DateTime.Now.AddYears(1);

            return Enumerable.Range(0, (aYearAway.Year - aYearAgo.Year) * 12 + (aYearAway.Month - aYearAgo.Month + 1))
                     .Select(m => new DateTime(aYearAgo.Year, aYearAgo.Month, 1).AddMonths(m))
                     .Select(r => new SelectListItem
                     {
                         Text = r.ToString("MMMM yyyy"),
                         Value = r.ToString(),
                         Selected = (today.Month == r.Month && today.Year == r.Year)
                     }).ToList();
        }

        /// <summary>
        /// returns a SelectListItem enumerable with 'Yearly' and 'Monthly' options
        /// </summary>
        /// <returns></returns>
        public IEnumerable<SelectListItem> GetYearMonthTimePeriodSelectList()
        {
            var items = Enum.GetValues(typeof(TimePeriods)).Cast<TimePeriods>().Select(tp =>
                new SelectListItem { Text = tp.GetDescription(), Value = ((int)tp).ToString() }
            );

            return items;
        }

        #endregion

    }
}
