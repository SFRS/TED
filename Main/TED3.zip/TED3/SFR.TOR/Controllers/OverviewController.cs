﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using SFR.TOR.Data;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.Utility;
using SFR.TOR.ViewModels;
using SFR.TOR.Web.Filters;

namespace SFR.TOR.Web.Controllers
{
    [TORUserAuthorisation]
    public partial class OverviewController : BaseController
    {
        public OverviewController(ITORUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }

        public virtual ActionResult Events(bool? showWeekend, string datepicker, string[] selectedSection,
            string[] selectedStatus, string[] selectedTrainingCentres, DateTime? startDate, bool? searchClicked)
        {
            if (searchClicked != null)
            {
                ViewBag.SearchClicked = searchClicked;
            }


            var date = ProcessDates(ref datepicker, ref startDate, showWeekend.GetValueOrDefault());

            var sections = selectedSection != null ? String.Join(",", selectedSection) : null;
            var statuses = selectedStatus != null ? String.Join(",", selectedStatus) : null;
            var trainingCentres = selectedTrainingCentres != null ? String.Join(",", selectedTrainingCentres) : null;

            //Search on default training centre if not a search clicked
            if (trainingCentres == null && searchClicked == null)
            {
                trainingCentres = TORUser.DefaultTrainingCentreID.ToString();
                selectedTrainingCentres = trainingCentres.Split(',');
            }

            var ecm = new EventsCalendarModel(Url.Action(MVC.Overview.ActionNames.GetEventsCalendarData,
                new
                {
                    showWeekend = showWeekend,
                    datepicker = datepicker,
                    selectedSection = sections,
                    selectedStatus = statuses,
                    selectedTrainingCentres = trainingCentres,
                    startDate = startDate
                }),
                GetDates(date), showWeekend.HasValue && showWeekend.Value)
            {
                Sections = GetSectionData(),
                TrainingCentres = GetTrainingCentresForFilters(),
                StatusData = GetStatusData(),
                SelectedSection = selectedSection,
                SelectedStatus = selectedStatus,
                SelectedTrainingCentres = selectedTrainingCentres,
                ShowFilterBar = searchClicked.HasValue && searchClicked.Value
            };

            ModelState.Clear();

            return View(ecm);
        }

        public virtual ActionResult Instructors(bool? showWeekend, string datepicker, string[] selectedSection,
            string[] selectedStatus, string[] selectedTrainingCentres, string[] selectedItemID, DateTime? startDate,
            bool? searchClicked, string[] selectedGroup)
        {
            var date = ProcessDates(ref datepicker, ref startDate, showWeekend.GetValueOrDefault());

            var instructorData =
                UnitOfWork.Instructors.SelectAll()
                    .OrderBy(i => i.LastName)
                    .ThenBy(i => i.FirstName)
                    .Select(i => new {ID = i.ID, Name = i.LastName + ", " + i.FirstName})
                    .ToList();
            var instructorList = new MultiSelectList(instructorData, "ID", "Name");

            var sections = selectedSection != null ? String.Join(",", selectedSection) : null;
            var statuses = selectedStatus != null ? String.Join(",", selectedStatus) : null;
            var groups = selectedGroup != null ? String.Join(",", selectedGroup) : null;
            var instructors = selectedItemID != null ? String.Join(",", selectedItemID) : null;
            var trainingCentres = selectedTrainingCentres != null ? String.Join(",", selectedTrainingCentres) : null;
            //Search on default training centre if not a search clicked
            if (trainingCentres == null && searchClicked == null)
            {
                trainingCentres = TORUser.DefaultTrainingCentreID.ToString();
                selectedTrainingCentres = trainingCentres.Split(',');
            }
            var icm =
                new InstructorsCalendarModel(
                    Url.Action(MVC.Overview.ActionNames.GetInstructorCalendarData,
                        new
                        {
                            showWeekend = showWeekend,
                            datepickerSelection = datepicker,
                            selectedSection = sections,
                            selectedStatus = statuses,
                            selectedTrainingCentres = trainingCentres,
                            startDate = startDate,
                            selectedGroup = groups,
                            selectedInstructorID = instructors
                            
                        }), GetDates(date),
                    showWeekend.HasValue && showWeekend.Value)
                {
                    Sections = GetSectionData(),
                    TrainingCentres = GetTrainingCentresForFilters(),
                    StatusData = GetStatusData(),
                    GroupData = GetGroupData(),
                    SelectedGroup = selectedGroup,
                    SelectedSection = selectedSection,
                    SelectedStatus = selectedStatus,
                    SelectedTrainingCentres = selectedTrainingCentres,
                    SelectedItemID = selectedItemID,
                    ItemData = instructorList,
                    ShowFilterBar = searchClicked.HasValue && searchClicked.Value
                };

            ModelState.Clear();

            return View(icm);
        }

        public virtual ActionResult Venues(bool? showWeekend, string datepicker, string[] selectedSection,
            string[] selectedStatus, string[] selectedTrainingCentres, string[] selectedItemID, DateTime? startDate,
            bool? searchClicked, string[] selectedGroup)
        {
            var date = ProcessDates(ref datepicker, ref startDate, showWeekend.GetValueOrDefault());

            var venueData =
                UnitOfWork.Venues.SelectAll().OrderBy(v => v.Name).Select(v => new {ID = v.ID, Name = v.Name}).ToList();
            var venueList = new MultiSelectList(venueData, "ID", "Name");

            var sections = selectedSection != null ? String.Join(",", selectedSection) : null;
            var statuses = selectedStatus != null ? String.Join(",", selectedStatus) : null;
            var groups = selectedGroup != null ? String.Join(",", selectedGroup) : null;
            var venues = selectedItemID != null ? String.Join(",", selectedItemID) : null;
            var trainingCentres = selectedTrainingCentres != null ? String.Join(",", selectedTrainingCentres) : null;
            //Search on default training centre if not a search clicked
            if (trainingCentres == null && searchClicked == null)
            {
                trainingCentres = string.Format("{0},{1}", TORUser.DefaultTrainingCentreID, GetNationalTrainingCentreId());
                selectedTrainingCentres = trainingCentres.Split(',');
            }
            var vcm =
                new VenuesCalendarModel(
                    Url.Action(MVC.Overview.ActionNames.GetVenueCalendarData,
                        new
                        {
                            showWeekend = showWeekend,
                            datepicker = datepicker,
                            selectedSection = sections,
                            selectedStatus = statuses,
                            startDate = startDate,
                            selectedGroup = groups,
                            selectedTrainingCentres = trainingCentres,
                            selectedVenueID = venues
                        }), GetDates(date), showWeekend.HasValue && showWeekend.Value)
                {
                    Sections = GetSectionData(),
                    TrainingCentres = GetTrainingCentresForFilters(),
                    StatusData = GetStatusData(),
                    GroupData = GetVenuesGroupData(),
                    SelectedGroup = selectedGroup,
                    SelectedSection = selectedSection,
                    SelectedStatus = selectedStatus,
                    SelectedTrainingCentres = selectedTrainingCentres,
                    SelectedItemID = selectedItemID,
                    ItemData = venueList,
                    ShowFilterBar = searchClicked.HasValue && searchClicked.Value
                };

            ModelState.Clear();

            return View(vcm);
        }

        public virtual ActionResult Equipment(bool? showWeekend, string datepicker, string[] selectedSection,
            string[] selectedStatus, string[] selectedTrainingCentres, string[] selectedItemID, DateTime? startDate, bool? searchClicked,
            string[] selectedGroup)
        {
            var date = ProcessDates(ref datepicker, ref startDate, showWeekend.GetValueOrDefault());

            var equipmentData =
                UnitOfWork.Equipment.SelectAll()
                    .OrderBy(e => e.Name)
                    .Select(e => new {ID = e.ID, Name = e.Name})
                    .ToList();
            var equipmentList = new MultiSelectList(equipmentData, "ID", "Name");

            var sections = selectedSection != null ? String.Join(",", selectedSection) : null;
            var statuses = selectedStatus != null ? String.Join(",", selectedStatus) : null;
            var groups = selectedGroup != null ? String.Join(",", selectedGroup) : null;
            var equipment = selectedItemID != null ? String.Join(",", selectedItemID) : null;
            var trainingCentres = selectedTrainingCentres != null ? String.Join(",", selectedTrainingCentres) : null;
            //Search on default training centre if not a search clicked
            if (trainingCentres == null && searchClicked == null)
            {
                trainingCentres = TORUser.DefaultTrainingCentreID.ToString();
                selectedTrainingCentres = trainingCentres.Split(',');
            }
            var ecm =
                new EquipmentCalendarModel(
                    Url.Action(MVC.Overview.ActionNames.GetEquipmentCalendarData,
                        new
                        {
                            showWeekend = showWeekend,
                            datepicker = datepicker,
                            selectedSection = sections,
                            selectedStatus = statuses,
                            startDate = startDate,
                            selectedGroup = groups,
                            selectedTrainingCentres = trainingCentres,
                            selectedEquipmentID = equipment
                        }), GetDates(date),
                    showWeekend.HasValue && showWeekend.Value)
                {
                    Sections = GetSectionData(),
                    StatusData = GetStatusData(),
                    SelectedGroup = selectedGroup,
                    TrainingCentres = GetTrainingCentresForFilters(),
                    GroupData = GetEquipmentGroupData(),
                    SelectedSection = selectedSection,
                    SelectedStatus = selectedStatus,
                    SelectedTrainingCentres = selectedTrainingCentres,
                    SelectedItemID = selectedItemID,
                    ItemData = equipmentList,
                    ShowFilterBar = searchClicked.HasValue && searchClicked.Value
                };

            ModelState.Clear();

            return View(ecm);
        }

        private DateTime? ProcessDates(ref string datepicker, ref DateTime? startDate, bool showWeekend)
        {
            var datePickerDT = FormatDate(datepicker);

            DateTime? date = null;
            var buttonClicked = Request["button"];
            if (buttonClicked != null)
            {
                switch (buttonClicked)
                {
                    case "next":
                        date = startDate.Value.AddDays(7);
                        break;
                    case "previous":
                        date = startDate.Value.AddDays(-7);
                        break;
                    case "tomorrow":
                        if (startDate.Value.DayOfWeek == DayOfWeek.Friday && !showWeekend)
                            date = startDate.Value.AddDays(3);
                        else
                            date = startDate.Value.AddDays(1);
                        break;
                    case "yesterday":
                        if (startDate.Value.DayOfWeek == DayOfWeek.Monday && !showWeekend)
                            date = startDate.Value.AddDays(-3);
                        else
                            date = startDate.Value.AddDays(-1);
                        break;
                    case "today":
                        date = DateTime.Now.Date;
                        break;
                }
            }
            else
            {
                date = datePickerDT;
            }

            startDate = GetStartDate(date);
            datepicker = startDate.Value.ToString("dd/MM/yyyy");
            return date;
        }

        public virtual JsonResult GetInstructorCalendarData(int page, int rows, string sord, string sidx,
            bool? showWeekend, string datepickerSelection, string selectedSection, string selectedStatus,
            string selectedTrainingCentres, DateTime? startDate, string selectedGroup, string selectedInstructorID)
        {
            var datePickerDT = FormatDate(datepickerSelection);

            var totalRows = 0;

            var date = datePickerDT ?? startDate;
            var endDate = date.Value.AddDays(6);

            var calendarData = UnitOfWork.Calendars.GetInstructorCalendarView(date, page, rows, sord,
                sidx == "" ? "Name" : sidx, selectedSection, selectedStatus, out totalRows,
                selectedTrainingCentres, selectedGroup, selectedInstructorID,
                showWeekend.HasValue && showWeekend.Value);

            var ids = calendarData.Select(x => x.ID).ToList();

            var iups =
                UnitOfWork.InstructorUnavailablePeriods.SelectFilteredList(
                    PredicateLibrary.GetInstructorUnavailablePeriodsPredicate(ids, (date).GetValueOrDefault(), endDate));

            var jsonList = new List<JsonRow>();
            calendarData.ForEach(x => jsonList.Add(new JsonRow(x)));

            if (iups != null)
            {
                foreach (var iup in iups)
                {
                    const int day1AMCellIndex = 3;
                    const int day7PMCellIndex = 16;

                    var instructorRow = jsonList.FirstOrDefault(x => x.id == iup.InstructorID.ToString());

                    if (instructorRow == null)
                        continue;

                    // If the period starts before the first date on the calendar, use the latter instead.
                    var periodStartToUse = iup.StartDate < date.Value ? date.Value : iup.StartDate;

                    // How many days does the period cover? If the period is open-ended then assume 100 days.
                    var periodDays = iup.EndDate.HasValue ? (iup.EndDate.Value - periodStartToUse).Days + 1 : 100;

                    // How many calendar cells does the period cover? If the period type is FullDay then double the number of days.
                    // Otherwise, the period type is Morning or Afternoon, so use 1 cell.
                    var periodCells = iup.DayTypeID == (int) EventPartTypeEnum.FullDay ? periodDays*2 : 1;

                    // The cell index that the period starts on is the index of the Day 1 AM cell plus an offset.
                    // The offset is double the difference in days between the calendar start date and the period start date,
                    // plus 1 if the period type is Afternoon.
                    var periodStartCellIndex =
                        day1AMCellIndex +
                        (periodStartToUse - date.Value).Days*2 +
                        (iup.DayTypeID == (int) EventPartTypeEnum.Afternoon ? 1 : 0);

                    // The cell index that the period ends on is the start index plus the number of cells the period covers, minus 1.
                    // If the cell index is greater than the Day 7 PM cell index, set it to that index.
                    var periodEndCellIndex = periodStartCellIndex + periodCells - 1;
                    periodEndCellIndex = periodEndCellIndex > day7PMCellIndex ? day7PMCellIndex : periodEndCellIndex;

                    for (var i = periodStartCellIndex; i <= periodEndCellIndex; i++)
                    {
                        var comments = !string.IsNullOrEmpty(iup.Comments) ? ": " + iup.Comments : "";
                        var reason = "UNAVAILABLE" + iup.UnavailableReason.Reason + comments;
                        instructorRow.cell[i] = reason;
                    }
                }
            }

            ModelState.Clear();

            return Json(new
            {
                page = page,
                rows = jsonList.ToArray(),
                records = totalRows,
                total = (totalRows + rows - 1)/rows //gets the total number of pages we need to display
            }, JsonRequestBehavior.AllowGet);
        }

        public virtual JsonResult GetVenueCalendarData(int page, int rows, string sord, string sidx, bool? showWeekend,
            string datepicker, string selectedSection, string selectedStatus, string selectedTrainingCentres,
            DateTime? startDate, string selectedGroup, string selectedVenueID)
        {
            var datePickerDT = FormatDate(datepicker);

            var totalRows = 0;
            var date = datePickerDT ?? startDate;
            var endDate = date.Value.AddDays(6);

            if (sidx.Equals("GroupName"))
                sidx = "GroupTitle";

            var calendarData = UnitOfWork.Calendars.GetVenueCalendarView(date, page, rows, sord,
                sidx == "" ? "GroupTitle" : sidx, selectedSection, selectedStatus, out totalRows,
                selectedTrainingCentres, selectedGroup, selectedVenueID,
                showWeekend.HasValue && showWeekend.Value);

            var jsonList = new List<VenueJsonRow>();
            calendarData.ForEach(x => jsonList.Add(new VenueJsonRow(x)));

            var ids = calendarData.Select(x => x.ID).ToList();

            var vups =
                UnitOfWork.VenueUnavailablePeriod.SelectFilteredList(
                    PredicateLibrary.GetVenueUnavailablePeriodsPredicate(ids, (date).GetValueOrDefault(), endDate));

            if (vups != null)
            {
                foreach (var vup in vups)
                {
                    const int day1AMCellIndex = 2;
                    const int day7PMCellIndex = 15;

                    var venueRow = jsonList.FirstOrDefault(x => x.id == vup.VenueID.ToString());

                    if (venueRow == null)
                        continue;

                    // If the period starts before the first date on the calendar, use the latter instead.
                    var periodStartToUse = vup.StartDate < date.Value ? date.Value : vup.StartDate;

                    // How many days does the period cover? If the period is open-ended then assume 100 days.
                    var periodDays = vup.EndDate.HasValue ? (vup.EndDate.Value - periodStartToUse).Days + 1 : 100;

                    // How many calendar cells does the period cover? If the period type is FullDay then double the number of days.
                    // Otherwise, the period type is Morning or Afternoon, so use 1 cell.
                    var periodCells = vup.DayTypeID == (int) EventPartTypeEnum.FullDay ? periodDays*2 : 1;

                    // The cell index that the period starts on is the index of the Day 1 AM cell plus an offset.
                    // The offset is double the difference in days between the calendar start date and the period start date,
                    // plus 1 if the period type is Afternoon.
                    var periodStartCellIndex =
                        day1AMCellIndex +
                        (periodStartToUse - date.Value).Days*2 +
                        (vup.DayTypeID == (int) EventPartTypeEnum.Afternoon ? 1 : 0);

                    // The cell index that the period ends on is the start index plus the number of cells the period covers, minus 1.
                    // If the cell index is greater than the Day 7 PM cell index, set it to that index.
                    var periodEndCellIndex = periodStartCellIndex + periodCells - 1;
                    periodEndCellIndex = periodEndCellIndex > day7PMCellIndex ? day7PMCellIndex : periodEndCellIndex;

                    for (var i = periodStartCellIndex; i <= periodEndCellIndex; i++)
                    {
                        var comments = !string.IsNullOrEmpty(vup.Comments) ? ": " + vup.Comments : "";
                        var reason = "UNAVAILABLE" + vup.VenuesUnavailableReason.Reason + comments;
                        venueRow.cell[i] = reason;
                    }
                }
            }


            return Json(new
            {
                page = page,
                rows = jsonList.ToArray(),
                records = totalRows,
                total = (totalRows + rows - 1)/rows //gets the total number of pages we need to display
            }, JsonRequestBehavior.AllowGet);
        }

        public virtual JsonResult GetEquipmentCalendarData(int page, int rows, string sord, string sidx,
            bool? showWeekend, string datepicker, string selectedSection, string selectedStatus,
            string selectedTrainingCentres, DateTime? startDate, string selectedGroup, string selectedEquipmentID)
        {
            var datePickerDT = FormatDate(datepicker);

            var totalRows = 0;
            var date = datePickerDT ?? startDate;
            var endDate = date.Value.AddDays(6);

            if (sidx.Equals("GroupName"))
                sidx = "GroupTitle";

            var calendarData = UnitOfWork.Calendars.GetEquipmentCalendarView(date, page, rows, sord,
                sidx == "" ? "GroupTitle" : sidx, selectedSection, selectedStatus, out totalRows,
                selectedTrainingCentres, selectedGroup, selectedEquipmentID,
                showWeekend.HasValue && showWeekend.Value);

            var jsonList = new List<EquipmentJsonRow>();
            calendarData.ForEach(x => jsonList.Add(new EquipmentJsonRow(x)));

            var ids = calendarData.Select(x => x.ID).ToList();

            var eups =
                UnitOfWork.EquipmentUnavailablePeriods.SelectFilteredList(
                    PredicateLibrary.GetEquipmentUnavailablePeriodsPredicate(ids, (date).GetValueOrDefault(), endDate));

            if (eups != null)
            {
                foreach (var eup in eups)
                {
                    const int day1AMCellIndex = 2;
                    const int day7PMCellIndex = 15;

                    var equipmentRow = jsonList.FirstOrDefault(x => x.id == eup.EquipmentID.ToString());

                    if (equipmentRow == null)
                        continue;

                    // If the period starts before the first date on the calendar, use the latter instead.
                    var periodStartToUse = eup.StartDate < date.Value ? date.Value : eup.StartDate;

                    // How many days does the period cover? If the period is open-ended then assume 100 days.
                    var periodDays = eup.EndDate.HasValue ? (eup.EndDate.Value - periodStartToUse).Days + 1 : 100;

                    // How many calendar cells does the period cover? If the period type is FullDay then double the number of days.
                    // Otherwise, the period type is Morning or Afternoon, so use 1 cell.
                    var periodCells = eup.DayTypeID == (int) EventPartTypeEnum.FullDay ? periodDays*2 : 1;

                    // The cell index that the period starts on is the index of the Day 1 AM cell plus an offset.
                    // The offset is double the difference in days between the calendar start date and the period start date,
                    // plus 1 if the period type is Afternoon.
                    var periodStartCellIndex =
                        day1AMCellIndex +
                        (periodStartToUse - date.Value).Days*2 +
                        (eup.DayTypeID == (int) EventPartTypeEnum.Afternoon ? 1 : 0);

                    // The cell index that the period ends on is the start index plus the number of cells the period covers, minus 1.
                    // If the cell index is greater than the Day 7 PM cell index, set it to that index.
                    var periodEndCellIndex = periodStartCellIndex + periodCells - 1;
                    periodEndCellIndex = periodEndCellIndex > day7PMCellIndex ? day7PMCellIndex : periodEndCellIndex;

                    for (var i = periodStartCellIndex; i <= periodEndCellIndex; i++)
                    {
                        var comments = !string.IsNullOrEmpty(eup.Comments) ? ": " + eup.Comments : "";
                        var reason = "UNAVAILABLE" + eup.EquipmentUnavailableReason.Reason + comments;
                        equipmentRow.cell[i] = reason;
                    }
                }
            }

            return Json(new
            {
                page = page,
                rows = jsonList.ToArray(),
                records = totalRows,
                total = (totalRows + rows - 1)/rows //gets the total number of pages we need to display
            }, JsonRequestBehavior.AllowGet);
        }

        public virtual JsonResult GetEventsCalendarData(int page, int rows, string sord, string sidx, bool? showWeekend,
            string datepicker, string selectedSection, string selectedStatus, string selectedTrainingCentres,
            DateTime? startDate)
        {
            var totalRows = 0;

            var calendarData = UnitOfWork.Calendars.GetEventsCalendarView(startDate, page, rows, selectedSection,
                selectedStatus, out totalRows, selectedTrainingCentres,
                showWeekend.HasValue && showWeekend.Value);
            var jsonList = new List<EventJsonRow>();
            calendarData.ForEach(x => jsonList.Add(new EventJsonRow(x)));

            return Json(new
            {
                page = page,
                rows = jsonList.ToArray(),
                records = totalRows,
                total = (totalRows + rows - 1)/rows //gets the total number of pages we need to display
            }, JsonRequestBehavior.AllowGet);
        }

        #region - Helper methods

        private DateTime GetStartDate(DateTime? date)
        {
            //use parameter start date if we have one            
            return date.HasValue ? date.Value : DateTime.UtcNow.AddDays((int) DateTime.UtcNow.DayOfWeek*-1 + 1);
        }

        private List<DateTime> GetDates(DateTime? date)
        {
            var startDate = GetStartDate(date);

            var dates = new List<DateTime>();
            var day = startDate;
            var dayCount = 1;

            while (dayCount <= 7)
            {
                dates.Add(day);

                day = day.AddDays(1);
                dayCount++;
            }
            return dates;
        }

        private DateTime? FormatDate(string datepicker)
        {
            DateTime? datePickerDT = null;

            if (!string.IsNullOrEmpty(datepicker))
            {
                var year = Convert.ToInt32(datepicker.Substring(6));
                var month = Convert.ToInt32(datepicker.Substring(3, 2));
                var day = Convert.ToInt32(datepicker.Substring(0, 2));
                datePickerDT = new DateTime(year, month, day);
            }
            return datePickerDT;
        }

        #endregion
    }
}