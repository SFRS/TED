﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web.Mvc;
using AutoMapper;
using LinqKit;
using SFR.TOR.Data;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;
using SFR.TOR.Web.Filters;
using Trirand.Web.Mvc;
using SFR.TOR.Utility;

namespace SFR.TOR.Web.Controllers
{
    [TORUserAuthorisation]
    public partial class InstructorController : BaseController
    {
        
        public InstructorController(ITORUnitOfWork unitOfWork): base(unitOfWork)
        {
        }
        
        public virtual ActionResult Create()
        {
            return View(
                new InstructorEditModel
                {
                    SectionData = GetSectionData(),
                    TrainingCentreData = GetTrainingCentres(0),
                    GroupData = GetGroupData()
                }
            );
        }

        [HttpPost]
        [TOREditAuthorise]
        public virtual ActionResult Create(InstructorEditModel model, string button)
        {
            Instructor i = Mapper.Map<InstructorEditModel, Instructor>(model);

            UnitOfWork.Instructors.Insert(i);
            UnitOfWork.Commit();

            //create a new InstructorSectionHistory record for the new instructor.
            var ish = new InstructorSectionHistory()
            {
                InstructorID = i.ID,
                SectionID = i.SectionID.Value,
                StartDate = DateTime.Now
            };

            UnitOfWork.InstructorSectionHistories.Insert(ish);
            UnitOfWork.Commit();

            switch (button)
            {
                case "save":
                    return RedirectToAction(MVC.Instructor.Edit(i.ID));
                case "saveReturn":
                    return RedirectToAction(MVC.Resources.Instructors());
                case "saveThenNew":
                    return RedirectToAction(MVC.Instructor.Create());
                default:
                    return RedirectToAction(MVC.Instructor.Edit(i.ID));
            }

        }

        public virtual ActionResult Edit(int id)
        {
            Instructor i = UnitOfWork.Instructors.SelectBy(x => x.ID == id);

            var iem = Mapper.Map<Instructor, InstructorEditModel>(i);

            iem.SectionData = GetSectionData(includeInactiveSection: true);
            iem.TrainingCentreData = GetTrainingCentres(i.TrainingCentreID);
            iem.GroupData = GetGroupData();
            iem.Name = i.FirstName + " " + i.LastName;
            iem.HasEvents = i.InstructorEventParts.Count > 0;

            return View(iem);
        }

        [HttpPost, AjaxResult]
        public virtual ActionResult Delete(int id)
        {
            Instructor i = UnitOfWork.Instructors.SelectBy(x => x.ID == id);

            var eventPartCount = i.InstructorEventParts.Count;

            if (eventPartCount > 0)
                throw new Exception(Constants.CANNOT_DELETE_INSTRUCTOR_WITH_EVENTS);

            UnitOfWork.EligibleInstructorsForActivity.DeleteAll(e => e.InstructorID == id);
            UnitOfWork.InstructorUnavailablePeriods.DeleteAll(p => p.InstructorID == id);
            UnitOfWork.InstructorSectionHistories.DeleteAll(h => h.InstructorID == id);
            UnitOfWork.Instructors.Delete(i);
            UnitOfWork.Commit();

            return RedirectToAction(MVC.Resources.ActionNames.Instructors, MVC.Resources.Name);
        }

        /// <summary>
        /// Following a change to the instructor's current section, this method updates the instructor's
        /// section history records and, if they are now retired, removes them from events and availability
        /// periods from this date forward.
        /// </summary>
        /// <param name="instructorID"></param>
        /// <param name="sectionID"></param>
        private void ProcessInstructorSectionHistory(int instructorID, int sectionID)
        {
            var instructor = UnitOfWork.Instructors.SelectBy(x => x.ID == instructorID);

            var latestHistories = instructor.InstructorSectionHistories.OrderByDescending(h => h.StartDate).Take(2).ToList();
            var latestHistory = latestHistories.FirstOrDefault();
            var previousHistory = latestHistories.LastOrDefault();

            DateTime today = DateTime.Now.Date;
            DateTime infinity = new DateTime(2999, 12, 31);

            if (latestHistory == null)
            {
                // no history record found, insert a new one
                latestHistory = new InstructorSectionHistory
                {
                    SectionID = sectionID,
                    InstructorID = instructorID,
                    StartDate = today
                };

                UnitOfWork.InstructorSectionHistories.Insert(latestHistory);
                UnitOfWork.Commit();
                return;
            }

            // If the history record starts in the future, or ends on today's date or later, we have a problem.
            if (latestHistory.StartDate > today || latestHistory.EndDate >= today)
                throw new Exception(String.Format("Section History record {0} for instructor ID {1} is later than expected.", latestHistory.ID, instructorID));

            if (sectionID == Constants.INSTRUCTOR_INACTIVE_SECTION_ID) // instructor is being made inactive
            {
                if (latestHistory.StartDate == today)
                {
                    // latest history record only started today, delete it
                    UnitOfWork.InstructorSectionHistories.Delete(latestHistory);
                }
                else if (latestHistory.EndDate == null)
                {
                    // latest history record is open-ended, so end it as of yesterday
                    latestHistory.EndDate = today.AddDays(-1);
                }
                else
                {
                    // no action, instructor has no open history records
                }

                // remove the instructor from events from today onwards
                ProcessInstructorUnavailabilityForEvents(new InstructorEditAvailabilityModel
                {
                    InstructorID = instructorID,
                    StartDate = today,
                    EndDate = null,
                    DayTypeID = (int)EventPartTypeEnum.FullDay
                });

                // Find availability periods that end today or in the future
                var periods = instructor.InstructorUnavailablePeriods.Where(p => (p.EndDate ?? infinity) >= today).ToList();

                foreach (var period in periods)
                {
                    // If the period starts in the past, end it as of yesterday. Otherwise, delete it.
                    if (period.StartDate < today)
                    {
                        period.EndDate = today.AddDays(-1);
                    }
                    else
                    {
                        UnitOfWork.InstructorUnavailablePeriods.Delete(period);
                    }
                }
            }
            else if (sectionID == latestHistory.SectionID) // new section is the same as the last one
            {
                if (latestHistory.EndDate == null)
                {
                    // no action, there's already an open history record for this section
                }
                else if (latestHistory.EndDate == DateTime.Now.Date.AddDays(-1))
                {
                    // history record with the same section id ends yesterday, reopen it
                    latestHistory.EndDate = null;
                }
                else
                {
                    // history record ends before yesterday, insert a new one
                    var newHistory = new InstructorSectionHistory
                    {
                        SectionID = sectionID,
                        InstructorID = instructorID,
                        StartDate = DateTime.Now.Date
                    };

                    UnitOfWork.InstructorSectionHistories.Insert(newHistory);
                }
            }
            else // new section is different to the old one
            {
                if (latestHistory.StartDate == DateTime.Now.Date) // does the latest history record start today?
                {
                    if (previousHistory != null && previousHistory.SectionID == sectionID &&
                        previousHistory.EndDate == DateTime.Now.Date.AddDays(-1))
                    {
                        // latest history record only started today, and the previous record has the section id 
                        // we are moving to, so delete the latest record and reopen the previous one
                        UnitOfWork.InstructorSectionHistories.Delete(latestHistory);
                        UnitOfWork.Commit(); // need an extra Commit here to avoid violating the unique key on EndDate
                        previousHistory.EndDate = null;
                    }
                    else
                    {
                        // latest history record only started today, just change its section id
                        latestHistory.SectionID = sectionID;
                    }
                }
                else // latest history record started in the past
                {
                    if (latestHistory.EndDate == null)
                    {
                        // latest history record is open-ended, set it to end yesterday
                        latestHistory.EndDate = DateTime.Now.Date.AddDays(-1);
                    }

                    // create a new history record with the new section id, starting today
                    var newHistory = new InstructorSectionHistory
                    {
                        SectionID = sectionID,
                        InstructorID = instructorID,
                        StartDate = DateTime.Now.Date
                    };

                    UnitOfWork.InstructorSectionHistories.Insert(newHistory);
                }
            }

            UnitOfWork.Commit();
        }

        [HttpPost]
        [TOREditAuthorise]
        public virtual ActionResult Edit(InstructorEditModel model)
        {
            if (!ModelState.IsValid)
            {
                return RedirectToAction(MVC.Instructor.ActionNames.Edit, new { id = model.ID });
            }

            var i = UnitOfWork.Instructors.SelectBy(x => x.ID == model.ID);

            Mapper.Map(model, i);

            UnitOfWork.Instructors.Update(i);
            UnitOfWork.Commit();

            ProcessInstructorSectionHistory(model.ID, model.SectionID);

            model.SectionData = GetSectionData(includeInactiveSection: true);
            model.GroupData = GetGroupData();
            model.TrainingCentreData = GetTrainingCentres(i.TrainingCentreID);
            model.Name = i.FirstName + " " + i.LastName;
            model.HasEvents = i.InstructorEventParts.Count > 0;

            return RedirectToAction(MVC.Instructor.ActionNames.Edit, new { id = model.ID });
        }

        public virtual ActionResult Eligibility(int id)
        {
            Instructor i = UnitOfWork.Instructors.SelectBy(x => x.ID == id);

            var iam = new InstructorActivitiesModel(Url.Action(Actions.GetEligibilityData(id)),
                Url.Action(MVC.Instructor.ActionNames.EditEligibility, new { instructorID = id }))
                {
                    ID = id,
                    Name = i.FirstName + " " + i.LastName
                };

            iam.Activities.Columns[iam.Activities.Columns.Count - 1].Visible = TORUser.TORRole >= TORRole.Editor;
            iam.Activities.ToolBarSettings.ShowAddButton = TORUser.TORRole >= TORRole.Editor;

            return View(iam);
        }

        public virtual JsonResult GetEligibilityData(int id)
        {
            var gridModel = new InstructorActivitiesModel(Url.Action(Actions.GetEligibilityData(id)),
                Url.Action(MVC.Instructor.ActionNames.EditEligibility, new { instructorID = id }));

            var instructorEligibility = UnitOfWork.EligibleInstructorsForActivity.GetEligibilityForInstructor(id); 

            return gridModel.Activities.DataBind(instructorEligibility.AsQueryable());
        }

        [TOREditAuthorise]
        public virtual ActionResult EditEligibility(InstructorEligibilityModel model, int instructorID)
        {
            
            var eifa = UnitOfWork.EligibleInstructorsForActivity
                        .SelectBy(x => x.InstructorID == instructorID && x.ActivityTemplateID == model.ID);

            //does a record exist for this instructor/activity eligibility?
            if (eifa != null)
            {
                bool eligibilityRemoved =
                    (eifa.IsLead && !model.IsLead.Value) ||
                    (eifa.IsInstructor && !model.IsInstructor.Value) ||
                    (eifa.IsAssessor && !model.IsAssessor.Value) ||
                    (eifa.IsShadow && !model.IsShadow.Value) ||
                    (eifa.IsSpecialist && !model.IsSpecialist.Value);

                if (eligibilityRemoved)
                {
                    //user is removing at least one of the instructors eligibilities, find affected InstructorEventParts
                    var ieps = UnitOfWork.InstructorEventPart.GetInstructorEventParts(
                        iep => iep.InstructorID == instructorID &&
                               iep.EventPart.ActivityPart.ActivityID == eifa.ActivityTemplateID)
                        .ToList()
                        .Where(iep => ((iep.IsLead.Value && !model.IsLead.Value) ||
                                       (iep.IsInstructor.Value && !model.IsInstructor.Value) ||
                                       (iep.IsAssessor.Value && !model.IsAssessor.Value) ||
                                       (iep.IsShadow.Value && !model.IsShadow.Value) ||
                                       (iep.IsSpecialist.Value && !model.IsSpecialist.Value)))
                        .ToList();

                    if (ieps.Count > 0)
                    {
                        var iepIDs = ieps.Select(iep => iep.ID);

                        //delete the mapping
                        UnitOfWork.InstructorEventPart.DeleteAll(iep => iepIDs.Contains(iep.ID));
                        UnitOfWork.Commit();

                        //process all matches
                        foreach (var iep in ieps)
                        {
                            //reset the event parts resourcing status
                            UnitOfWork.EventParts.ResetResourceStatus(iep.EventPartID);
                            UnitOfWork.Commit();

                            //reset the events resourcing status
                            UnitOfWork.Events.ResetResourceStatus(iep.EventID, TORUser.FullName);
                            UnitOfWork.Commit();
                        }
                    }
                }

                //update the record
                Mapper.Map(model, eifa);
                UnitOfWork.EligibleInstructorsForActivity.Update(eifa);
            }
            else
            {
                //insert a new record
                eifa = Mapper.Map<InstructorEligibilityModel, EligibleInstructorsForActivity>(model);
                eifa.InstructorID = instructorID;   
                UnitOfWork.EligibleInstructorsForActivity.Insert(eifa);
            }

            UnitOfWork.Commit();
            return RedirectToAction(MVC.Instructor.ActionNames.GetEligibilityData, new { id = instructorID });
        }

        public virtual ActionResult Availability(int id)
        {
            Instructor i = UnitOfWork.Instructors.SelectBy(x => x.ID == id);

            var ieam = new InstructorUnavailabilityModel(Url.Action(Actions.GetAvailabilityData(id)),
                Url.Action(MVC.Instructor.ActionNames.EditAvailability, new { instructorID = id }))
                {
                    Name = i.FirstName + " " + i.LastName,
                    ID = id
                };

            ieam.Unavailability.Columns[ieam.Unavailability.Columns.Count - 1].Visible = TORUser.TORRole >= TORRole.Editor;
            ieam.Unavailability.ToolBarSettings.ShowAddButton = TORUser.TORRole >= TORRole.Editor;
            
            return View(ieam);
        }

        public virtual JsonResult GetAvailabilityData(int id)
        {
            Thread.Sleep(250); //hack just wait a second til the page ajax calls finish for seving dropdown data

            var gridModel = new InstructorUnavailabilityModel(Url.Action(Actions.GetAvailabilityData(id)),
                Url.Action(MVC.Instructor.ActionNames.EditAvailability));

            var instructorUnavailablePeriods = UnitOfWork.InstructorUnavailablePeriods.GetUnavailabilityReasons(id);

            return gridModel.Unavailability.DataBind(instructorUnavailablePeriods.AsQueryable());
        }

        [HttpGet]
        public virtual JsonResult EditAvailabilityCheck(InstructorEditAvailabilityModel model)
        {
            //get all instance of the instructor against an event part within the given range
            List<InstructorEventPart> ieps = GetAffectedInstructorEventParts(model);

            List<string> affectedEventCodes = ieps.Select(iep => iep.EventPart.Event.EventCode).Distinct().OrderBy(s => s).ToList();

            return Json(new
            {
                EventCount = affectedEventCodes.Count,
                EventCodes = affectedEventCodes
            }, JsonRequestBehavior.AllowGet);
        }

        private List<InstructorEventPart> GetAffectedInstructorEventParts(InstructorEditAvailabilityModel model)
        {
            List<InstructorEventPart> ieps;
            ieps = UnitOfWork.InstructorEventPart.SelectFilteredList(
                PredicateLibrary.GetInstructorEventPartInADateRange(model.InstructorID, model.StartDate, model.EndDate, model.DayTypeID)
                ).ToList();

            return ieps;
        }

        [TOREditAuthorise]
        public virtual ActionResult EditAvailability(InstructorEditAvailabilityModel model)
        {
            var gridModel = new InstructorUnavailabilityModel(Url.Action(Actions.GetAvailabilityData(model.InstructorID)),
                Url.Action(MVC.Instructor.ActionNames.EditAvailability));

            #region Validation

            //Validation
            if (gridModel.Unavailability.AjaxCallBackMode == AjaxCallBackMode.EditRow ||
                gridModel.Unavailability.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                // Validate end date is less than the start date
                if (model.EndDate != null && model.EndDate < model.StartDate)
                {
                    return gridModel.Unavailability.ShowEditValidationMessage(Constants.GRID_OBJECT_AVAILABILITY_START_DATE_EARLIER_THAN_END_DATE_ERROR);
                }

                //periods spaning more than 1 day must be FULL DAY day type.
                if (!(model.StartDate.Equals(model.EndDate)) && model.DayTypeID != (int)SFR.TOR.Utility.EventPartTypeEnum.FullDay)
                {
                    return gridModel.Unavailability.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_AVAILABILITY_INVALID_DAY_TYPE_ERROR);
                }

                //validate evening training and day type
                var eveningEventsUnavailableReasonIDs = UnitOfWork.UnavailableReasons.SelectFilteredList(x =>
                        x.UnavailableReasonGroupID == (int)SFR.TOR.Utility.InstructorUnavailableReasonGroups.EVENING_TRAINING)
                        .Select(x => x.ID)
                        .ToList();

                // validate back shift reasons must be a FULL DAY.
                if (eveningEventsUnavailableReasonIDs.Contains(model.UnavailableReasonID) && model.DayTypeID != (int)SFR.TOR.Utility.EventPartTypeEnum.FullDay)
                {
                    return gridModel.Unavailability.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_AVAILABILITY_EVENING_TRAINING_PERIOD_ERROR);
                }

                // Validate against pre-existing unavailable periods
                var today = DateTime.Now.Date;

                //Get all periods between dates where the day type matches what was chosen, or is a full day.
                
                var data = UnitOfWork.InstructorUnavailablePeriods.SelectFilteredList(p =>
                                ((p.StartDate >= model.StartDate && p.StartDate <= model.EndDate) ||
                                ((p.EndDate ?? today) >= model.StartDate && (p.EndDate ?? today) <= model.EndDate) ||
                                (model.StartDate >= p.StartDate && model.StartDate <= (p.EndDate ?? today))) &&
                                p.Instructor.ID == model.InstructorID &&
                                ((p.DayTypeID == model.DayTypeID || p.DayTypeID == (int)SFR.TOR.Utility.EventPartTypeEnum.FullDay) ||
                                (model.DayTypeID == (int)SFR.TOR.Utility.EventPartTypeEnum.FullDay)) &&
                                model.ID != p.ID); //exclude current record if we are editing
                
                //If any records exist, then there is a conflict in day types/dates
                if (data.Count() > 0)
                    return gridModel.Unavailability.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_AVAILABILITY_CONFLICTING_DATES_ERROR);
            
                //validate against open ended availability periods. Ensure new periods cannot be created before the start date.
                
                //get open ended periods
                var overlappingPeriods = UnitOfWork.InstructorUnavailablePeriods.SelectFilteredList(x => x.InstructorID == model.InstructorID && (model.ID != x.ID) &&
                                                    ((!x.EndDate.HasValue && !model.EndDate.HasValue) ||
                                                      (!model.EndDate.HasValue && x.StartDate >= model.StartDate) ||
                                                      (!x.EndDate.HasValue && model.StartDate >= x.StartDate)
                                                    ));
                if (overlappingPeriods.Count() > 0)
                {
                    return gridModel.Unavailability.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_AVAILABILITY_CONFLICTING_DATES_ERROR);
                }

            }

            #endregion

            var callbackMode = gridModel.Unavailability.AjaxCallBackMode;

            if (gridModel.Unavailability.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                var iup = UnitOfWork.InstructorUnavailablePeriods.SelectBy(x => x.ID == model.ID);

                //does a record exist for this unavailability?
                if (iup != null)
                {
                    ProcessInstructorUnavailabilityForEvents(model, iup);

                    //update the record
                    Mapper.Map(model, iup);

                    UnitOfWork.InstructorUnavailablePeriods.Update(iup);                    
                }
                else
                {
                    //insert a new record
                    iup = Mapper.Map<InstructorEditAvailabilityModel, InstructorUnavailablePeriod>(model);
                    UnitOfWork.InstructorUnavailablePeriods.Insert(iup);
                    ProcessInstructorUnavailabilityForEvents(model);
                }
            }
            else if (gridModel.Unavailability.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                //insert a new record
                InstructorUnavailablePeriod iup = Mapper.Map<InstructorEditAvailabilityModel, InstructorUnavailablePeriod>(model);

                UnitOfWork.InstructorUnavailablePeriods.Insert(iup);
                
                UnitOfWork.Commit();
                
                //now remove the instructor from any events in this period
                ProcessInstructorUnavailabilityForEvents(model);
            }
            else if (gridModel.Unavailability.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                var iup = UnitOfWork.InstructorUnavailablePeriods.SelectBy(x => x.ID == model.ID);

                UnitOfWork.InstructorUnavailablePeriods.Delete(iup);
            }

            UnitOfWork.Commit();
            return RedirectToAction(MVC.Instructor.ActionNames.GetAvailabilityData, new { id = model.InstructorID });
        }
        
        private void ProcessInstructorUnavailabilityForEvents(InstructorEditAvailabilityModel model, InstructorUnavailablePeriod iup)
        {
            //only process where the dates have moved past original boundaries
            if (model.StartDate < iup.StartDate || model.EndDate > iup.EndDate)
            {
                ProcessInstructorUnavailabilityForEvents(model);
            }
        }

        private void ProcessInstructorUnavailabilityForEvents(InstructorEditAvailabilityModel model)
        {
            //get all instance of the instructor against an event part within the given range
            List<InstructorEventPart> ieps = GetAffectedInstructorEventParts(model);

            int eventID = 0;

            //delete each instance and update the parent events status
            foreach (var iep in ieps)
            {
                eventID = iep.EventPart.EventID;
                UnitOfWork.InstructorEventPart.Delete(iep);
                UnitOfWork.Commit();
                UnitOfWork.EventParts.ResetResourceStatus(iep.DayPartID);
                UnitOfWork.Commit();
                UnitOfWork.Events.ResetResourceStatus(eventID, TORUser.FullName);
                UnitOfWork.Commit();
            }
        }

        public virtual ActionResult SectionHistory(int id)
        {
            var instructor = UnitOfWork.Instructors.SelectBy(x => x.ID == id);

            var ishm = new InstructorSectionHistoryModel(Url.Action(Actions.GetSectionHistoriesForInstructorData(id)),
                                                         Url.Action(MVC.Instructor.ActionNames.EditSectionHistory, new { instructorID = id }))
                                                         {
                                                             ID = id,
                                                             Name = instructor.FirstName + " " + instructor.LastName
                                                         };

            //Only admins can make changes here.. everybody else should be a User to view the information
            ishm.SectionHistory.ToolBarSettings.ShowAddButton = (TORUser.TORRole > TORRole.Editor);
            ishm.SectionHistory.Columns[4].Visible = (TORUser.TORRole > TORRole.Editor);

            return View(ishm);
        }

        public virtual JsonResult GetSectionHistoriesForInstructorData(int id)
        {
            Thread.Sleep(250); //hack just wait a second til the page ajax calls finish for seving dropdown data

            var gridModel = new InstructorSectionHistoryModel(Url.Action(Actions.GetSectionHistoriesForInstructorData(id)),
                                                          Url.Action(MVC.Instructor.ActionNames.EditSectionHistory, new { id = id }));

            var instructorSectionHistory = UnitOfWork.InstructorSectionHistories.GetInstructorSectionHistory(id);

            return gridModel.SectionHistory.DataBind(instructorSectionHistory.AsQueryable());
        }

        [TORAdminAuthorise]
        public virtual ActionResult EditSectionHistory(InstructorSectionHistoryEditModel model, int instructorID)
        {
            var gridModel = new InstructorSectionHistoryModel(Url.Action(Actions.GetSectionHistoriesForInstructorData(model.InstructorID)),
                Url.Action(MVC.Instructor.ActionNames.EditSectionHistory));

            var instructor = UnitOfWork.Instructors.SelectBy(i => i.ID == instructorID);
            DateTime infinity = new DateTime(2999, 12, 31);

            #region Validation

            var callbackMode = gridModel.SectionHistory.AjaxCallBackMode;

            //Validation
            if (callbackMode == AjaxCallBackMode.EditRow || callbackMode == AjaxCallBackMode.AddRow)
            {
                // Validate end date is less than the start date
                if (model.EndDate != null && model.EndDate < model.StartDate)
                    return gridModel.SectionHistory.ShowEditValidationMessage(Constants.GRID_OBJECT_AVAILABILITY_START_DATE_EARLIER_THAN_END_DATE_ERROR);

                // Start Date must not be later than today
                if (model.StartDate > DateTime.Now.Date)
                    return gridModel.SectionHistory.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_SECTION_HISTORY_FUTURE_START_DATE_ERROR);

                // End Date must not be today or later
                if (model.EndDate >= DateTime.Now.Date)
                    return gridModel.SectionHistory.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_SECTION_HISTORY_FUTURE_END_DATE_ERROR);

                if (callbackMode == AjaxCallBackMode.EditRow)
                {
                    var sectionHistoryRow = UnitOfWork.InstructorSectionHistories.SelectBy(x => x.ID == model.ID);

                    if (sectionHistoryRow.EndDate == null)
                    {
                        // The user is editing an open-ended section history record.
                        // Don't let them change the section or set an End Date - this should be done elsewhere.
                        if (sectionHistoryRow.SectionID != model.SectionID)
                            return gridModel.SectionHistory.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_SECTION_HISTORY_CANNOT_UPDATE_CURRENT_SECTION_ERROR);

                        if (model.EndDate != null)
                            return gridModel.SectionHistory.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_SECTION_HISTORY_CANNOT_MAKE_INACTIVE_ERROR);
                    }
                    else if (model.EndDate == null)
                    {
                        // The user is trying to remove the end date from a record - this equates to changing the user's
                        // current section, which should be done elsewhere.
                        return gridModel.SectionHistory.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_SECTION_HISTORY_CANNOT_UPDATE_CURRENT_SECTION_ERROR);
                    }

                    // Is the period being squeezed at either or both ends? If so, we are leaving a gap - check this is acceptable.
                    if (model.StartDate > sectionHistoryRow.StartDate || model.EndDate < sectionHistoryRow.EndDate)
                    {
                        var eventOverlap = instructor.InstructorEventParts.Any(iep =>
                            (iep.EventPart.Date >= sectionHistoryRow.StartDate && iep.EventPart.Date < model.StartDate) ||
                            (iep.EventPart.Date > model.EndDate && iep.EventPart.Date <= sectionHistoryRow.EndDate));

                        // Don't allow a gap to be created if the instructor has events overlapping it.
                        // This enforces consistency, it would be problematic for reporting otherwise.
                        if (eventOverlap)
                            return gridModel.SectionHistory.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_SECTION_HISTORY_GAP_OVERLAPS_EVENTS_ERROR);

                        var periodOverlap = instructor.InstructorUnavailablePeriods.Any(p =>
                            (p.StartDate >= sectionHistoryRow.StartDate && p.StartDate <= model.StartDate) ||
                            (p.EndDate >= sectionHistoryRow.StartDate && p.EndDate <= model.StartDate) ||
                            (sectionHistoryRow.StartDate >= p.StartDate && sectionHistoryRow.StartDate <= (p.EndDate ?? infinity)) ||
                            (p.StartDate >= model.EndDate && p.StartDate <= sectionHistoryRow.EndDate) ||
                            (p.EndDate >= model.EndDate && p.EndDate <= sectionHistoryRow.EndDate) ||
                            (sectionHistoryRow.EndDate >= p.StartDate && sectionHistoryRow.EndDate <= (p.EndDate ?? infinity)));

                        // Don't allow a gap to be created if the instructor has unavailability peridos overlapping it.
                        if (periodOverlap)
                            return gridModel.SectionHistory.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_SECTION_HISTORY_GAP_OVERLAPS_PERIODS_ERROR);
                    }
                }
                else // AddRow
                {
                    // Don't let the user insert an open-ended section history record, as their current section should be changed elsewhere.
                    if (model.EndDate == null)
                        return gridModel.SectionHistory.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_SECTION_HISTORY_CANNOT_UPDATE_CURRENT_SECTION_ERROR);
                }
            }
            else if (callbackMode == AjaxCallBackMode.DeleteRow)
            {
                //Instructor section history must have at least 1 record, so prevent the user from deleting if we are on the last record.
                if (UnitOfWork.InstructorSectionHistories.SelectFilteredList(x => x.InstructorID == model.InstructorID).Count() == 1)
                    return gridModel.SectionHistory.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_SECTION_HISTORY_CANNOT_DELETE_LAST_RECORD_ERROR);

                var sectionHistoryRow = UnitOfWork.InstructorSectionHistories.SelectBy(x => x.ID == model.ID);

                // Don't allow an open-ended record to be deleted, that would make the instructor inactive and should be handled elsewhere.
                if (sectionHistoryRow.EndDate == null)
                    return gridModel.SectionHistory.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_SECTION_HISTORY_CANNOT_MAKE_INACTIVE_ERROR);

                var eventOverlap = instructor.InstructorEventParts.Any(iep =>
                    iep.EventPart.Date >= sectionHistoryRow.StartDate &&
                    iep.EventPart.Date <= (sectionHistoryRow.EndDate ?? infinity));

                // Don't allow a history record to be deleted if the instructor has events overlapping it.
                // This enforces consistency, it would be problematic for reporting otherwise.
                if (eventOverlap)
                    return gridModel.SectionHistory.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_SECTION_HISTORY_GAP_OVERLAPS_EVENTS_ERROR);

                var periodOverlap = instructor.InstructorUnavailablePeriods.Any(p =>
                    ((p.StartDate >= sectionHistoryRow.StartDate && p.StartDate <= (sectionHistoryRow.EndDate ?? infinity)) ||
                    (p.EndDate >= sectionHistoryRow.StartDate && p.EndDate <= (sectionHistoryRow.EndDate ?? infinity)) ||
                    (sectionHistoryRow.StartDate >= p.StartDate && sectionHistoryRow.StartDate <= (p.EndDate ?? infinity))));

                // Don't allow a history record to be deleted if the instructor has unavailability periods overlapping it.
                if (periodOverlap)
                    return gridModel.SectionHistory.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_SECTION_HISTORY_GAP_OVERLAPS_PERIODS_ERROR);
            }

            #endregion

            // Tidy up overlaps with other section history records
            if (callbackMode == AjaxCallBackMode.EditRow || callbackMode == AjaxCallBackMode.AddRow)
            {
                var concreteEndDate = (model.EndDate ?? infinity);

                var historyOverlapsToDelete = instructor.InstructorSectionHistories.Where(h => h.ID != model.ID &&
                    model.StartDate <= h.StartDate && concreteEndDate >= (h.EndDate ?? infinity)).ToList();

                // these periods have been completely overlapped by the supplied period, delete them
                historyOverlapsToDelete.ForEach(h => UnitOfWork.InstructorSectionHistories.Delete(h));

                var historyOverlapsToUpdate = instructor.InstructorSectionHistories.Where(h => 
                    h.ID != model.ID && 
                    ((model.StartDate >= h.StartDate && model.StartDate <= (h.EndDate ?? infinity)) ||
                     (concreteEndDate >= h.StartDate && concreteEndDate <= (h.EndDate ?? infinity)))).ToList();

                // these periods have been partially overlapped by the supplied period, update them
                foreach (var h in historyOverlapsToUpdate)
                {
                    if (model.StartDate > h.StartDate && concreteEndDate < (h.EndDate ?? infinity))
                    {
                        // The supplied period falls entirely within an existing period, which must therefore break into two.
                        // Insert a new record to represent the later remaining part of the existing period.
                        var newSectionHistory = new InstructorSectionHistory
                        {
                            InstructorID = h.InstructorID,
                            SectionID = h.SectionID,
                            StartDate = model.EndDate.Value.AddDays(1),
                            EndDate = h.EndDate
                        };

                        UnitOfWork.InstructorSectionHistories.Insert(newSectionHistory);

                        // Update the existing record to represent the earlier remaining part of the existing period.
                        h.EndDate = model.StartDate.AddDays(-1);
                    }
                    else if (concreteEndDate >= h.StartDate && concreteEndDate <= (h.EndDate ?? infinity))
                    {
                        // Update the existing period to start after the supplied period ends
                        h.StartDate = model.EndDate.Value.AddDays(1);
                    }
                    else if (model.StartDate >= h.StartDate && model.StartDate <= (h.EndDate ?? infinity))
                    {
                        // Update the existing period to end before the supplied period starts
                        h.EndDate = model.StartDate.AddDays(-1);
                    }
                }

                // If any overlaps were dealt with, commit now before the supplied period is inserted/updated/deleted.
                // This aims to avoid unique key violations which can occur if all changes are committed at once,
                // since we can't control the order in which Entity Framework emits the SQL within a single commit.
                if (historyOverlapsToDelete.Count > 0 || historyOverlapsToUpdate.Count > 0)
                {
                    UnitOfWork.Commit();
                }
            }

            if (callbackMode == AjaxCallBackMode.EditRow)
            {
                var sectionHistoryRow = UnitOfWork.InstructorSectionHistories.SelectBy(x => x.ID == model.ID);

                sectionHistoryRow.SectionID = model.SectionID;
                sectionHistoryRow.StartDate = model.StartDate;
                sectionHistoryRow.EndDate = model.EndDate;
                UnitOfWork.InstructorSectionHistories.Update(sectionHistoryRow);
            }
            else if (callbackMode == AjaxCallBackMode.AddRow)
            {
                //Create the new section history record
                var newSectionHistory = new InstructorSectionHistory
                {
                    InstructorID = model.InstructorID,
                    SectionID = model.SectionID,
                    StartDate = model.StartDate,
                    EndDate = model.EndDate
                };

                UnitOfWork.InstructorSectionHistories.Insert(newSectionHistory);
            }
            else if (callbackMode == AjaxCallBackMode.DeleteRow)
            {
                var sectionHistoryRow = UnitOfWork.InstructorSectionHistories.SelectBy(x => x.ID == model.ID);
                UnitOfWork.InstructorSectionHistories.Delete(sectionHistoryRow);
            }

            UnitOfWork.Commit();
            return new RedirectResult(Url.Action(Actions.GetSectionHistoriesForInstructorData(model.InstructorID)));
        }

        public virtual JsonResult GetInstructorReasons()
        {
            var reasons = UnitOfWork.UnavailableReasons.SelectAll().Select(x => new { x.ID, x.Reason }).ToList();

            return Json(reasons, JsonRequestBehavior.AllowGet);
        }

        public virtual JsonResult GetSectionDataForGrid()
        {
            bool includeRetiredSections = false;
            var sections = GetSectionData(includeRetiredSections);
            return Json(sections, JsonRequestBehavior.AllowGet);
        }

        public virtual JsonResult GetDayTypes()
        {
            var reasons = UnitOfWork.EventPartTypes.SelectAll().Select(x => new { x.ID, x.Title }).OrderByDescending(x => x.ID).ToList();

            return Json(reasons, JsonRequestBehavior.AllowGet);
        }
    }
}
