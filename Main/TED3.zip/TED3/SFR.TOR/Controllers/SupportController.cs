﻿using System.Web.Mvc;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.Web.Filters;

namespace SFR.TOR.Web.Controllers
{
    [TORUserAuthorisation]
    public partial class SupportController : BaseController
    {

        public SupportController(ITORUnitOfWork unitOfWork): base(unitOfWork)
        {            
        }

        public virtual ActionResult Index()
        {
            return View();
        }

    }
}
