﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using AutoMapper;
using SFR.TOR.Data;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;
using SFR.TOR.Web.Filters;
using Trirand.Web.Mvc;
using Equipment = SFR.TOR.Data.Equipment;
using SFR.TOR.Utility;

namespace SFR.TOR.Web.Controllers
{
    [TORUserAuthorisation]
    public partial class EquipmentController : BaseController
    {
        public EquipmentController(ITORUnitOfWork unitOfWork): base(unitOfWork)
        {
        }

        public virtual ActionResult Categories(int id)
        {
            Equipment e = UnitOfWork.Equipment.SelectBy(x => x.ID == id);

            var iam = new EquipmentCategoriesModel(Url.Action(Actions.GetEquipmentCategories(id)),
                Url.Action(MVC.Equipment.ActionNames.EditEquipmentCategory, new { equipmentID = id }), base.GetEquipmentTags())
            {
                ID = id,
                Name = e.Name
            };

            iam.EquipmentCategories.Columns[iam.EquipmentCategories.Columns.Count - 1].Visible = TORUser.TORRole >= TORRole.Editor;
            iam.EquipmentCategories.ToolBarSettings.ShowAddButton = TORUser.TORRole >= TORRole.Editor;

            return View(iam);
        }

        public virtual JsonResult GetEquipmentCategories(int id)
        {
            var gridModel = new EquipmentCategoriesModel(Url.Action(Actions.GetEquipmentCategories(id)),
                Url.Action(MVC.Equipment.ActionNames.EditEquipmentCategory, new { equipmentID = id }), base.GetEquipmentTags());

            IQueryable<EquipmentTagEquipmentModel> equipmentTags = UnitOfWork.EquipmentTagEquipment.GetEquipmentTags(id);

            return gridModel.EquipmentCategories.DataBind(equipmentTags.AsQueryable());
        }

        [HttpGet]
        public virtual JsonResult EditEquipmentCategoryCheck(EquipmentTagEquipmentModel model)
        {
            var ete = UnitOfWork.EquipmentTagEquipment.SelectBy(x => x.ID == model.ID);

            //get all  instance of Equipment tags being used for this equipment in events in the future
            var eeps = UnitOfWork.EquipmentEventParts.SelectFilteredList(x =>
                x.EquipmentTagID == ete.EquipmentTagID &&
                x.EventPart.Date > DateTime.Now &&
                x.EquipmentID == ete.EquipmentID
            ).ToList();

            List<string> affectedEventCodes = eeps.Select(iep => iep.EventPart.Event.EventCode).Distinct().OrderBy(s => s).ToList();

            return Json(new
            {
                EventCount = affectedEventCodes.Count,
                EventCodes = affectedEventCodes
            }, JsonRequestBehavior.AllowGet);
        }

        [TOREditAuthorise, HttpPost]
        public virtual JsonResult EditEquipmentCategory(EquipmentTagEquipmentModel model, int equipmentID)
        {         
            var gridModel = new EquipmentCategoriesModel(Url.Action(Actions.GetEquipmentCategories(equipmentID)),
                Url.Action(MVC.Equipment.ActionNames.EditEquipmentCategory, new { equipmentID = equipmentID }), base.GetEquipmentTags());

            //in insert mode so add row
            if (gridModel.EquipmentCategories.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                var ete = Mapper.Map<EquipmentTagEquipmentModel, EquipmentTagEquipment>(model);
                UnitOfWork.EquipmentTagEquipment.Insert(ete);
            }
            //in delete mode, so remove the matching row
            else if (gridModel.EquipmentCategories.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                EquipmentTagEquipment ete = UnitOfWork.EquipmentTagEquipment.SelectBy(x => x.ID == model.ID);

                //get all  instance of equipment tags being used for this equipment in events in the future
                var eeps = UnitOfWork.EquipmentEventParts.SelectFilteredList(x =>
                                                                                x.EquipmentTagID == ete.EquipmentTagID &&
                                                                                x.EventPart.Date > DateTime.Now &&
                                                                                x.EquipmentID == ete.EquipmentID
                                                                            ).ToList();

                //delete them all
                foreach (var eep in eeps)
                {
                    int eventID = eep.EventPart.EventID;
                    int eventPartID = eep.EventPart.ID;
                    UnitOfWork.EquipmentEventParts.Delete(eep);
                    UnitOfWork.Commit();

                    //update the event parts resource status
                    UnitOfWork.EventParts.ResetResourceStatus(eventPartID);
                    UnitOfWork.Commit();

                    //update their events resource status
                    UnitOfWork.Events.ResetResourceStatus(eventID, TORUser.FullName);
                    UnitOfWork.Commit();

                }                
                
                UnitOfWork.EquipmentTagEquipment.Delete(ete);
                
            }

            UnitOfWork.Commit();

            return Json(true);
        }

        public virtual ActionResult Create()
        {
            return View(
                new EquipmentEditModel()
                {
                    TrainingCentreData = GetTrainingCentres(0),
                    EquipmentGroupData = GetEquipmentGroupData(0)
                }
            );
        }

        [HttpPost]
        [TOREditAuthorise]
        public virtual ActionResult Create(EquipmentEditModel model, string button)
        {
            Equipment e = Mapper.Map<EquipmentEditModel, Equipment>(model);

            UnitOfWork.Equipment.Insert(e);
            UnitOfWork.Commit();
            
            switch (button)
            {
                case "save":
                    return RedirectToAction(MVC.Equipment.Edit(e.ID));
                case "saveReturn":
                    return RedirectToAction(MVC.Resources.Equipment());
                case "saveThenNew":
                    return RedirectToAction(MVC.Equipment.Create());
                default:
                    return RedirectToAction(MVC.Equipment.Edit(e.ID));
            }
        }

        public virtual ActionResult Edit(int id)
        {
            var e = UnitOfWork.Equipment.GetEquipment(id);

            var eem = Mapper.Map<EquipmentModel, EquipmentEditModel>(e);

            eem.TrainingCentreData = GetTrainingCentres(e.TrainingCentreID);
            eem.EquipmentGroupData = GetEquipmentGroupData(e.EquipmentGroupID.HasValue ? e.EquipmentGroupID.Value : 0);

            return View(eem);
        }
       
        [HttpPost]
        public virtual ActionResult Edit(EquipmentEditModel model)
        {
            var e = UnitOfWork.Equipment.SelectBy(x => x.ID == model.ID);

            Mapper.Map(model, e);

            UnitOfWork.Equipment.Update(e);
            UnitOfWork.Commit();
            model.Name = e.Name;

            model.TrainingCentreData = GetTrainingCentres(e.TrainingCentreID);
            model.EquipmentGroupData = GetEquipmentGroupData(e.EquipmentGroupID);

            return View(model);
        }

        
        public virtual ActionResult Availability(int id)
        {
            Equipment equipment = UnitOfWork.Equipment.SelectBy(x => x.ID == id);

            var ieam = new EquipmentUnavailabilityModel(Url.Action(Actions.GetAvailabilityData(id)),
                Url.Action(MVC.Equipment.ActionNames.EditAvailability, new { EquipmentID = id }))
            {
                Name = equipment.Name,
                ID = id
            };

            ieam.Unavailability.Columns[ieam.Unavailability.Columns.Count - 1].Visible = TORUser.TORRole >= TORRole.Editor;
            ieam.Unavailability.ToolBarSettings.ShowAddButton = TORUser.TORRole >= TORRole.Editor;

            return View(ieam);
        }

        public virtual JsonResult GetAvailabilityData(int id)
        {
            var gridModel = new EquipmentUnavailabilityModel(Url.Action(Actions.GetAvailabilityData(id)),
                Url.Action(MVC.Equipment.ActionNames.EditAvailability));

            var equipmentUnavailablePeriods = UnitOfWork.EquipmentUnavailablePeriods.GetUnavailabilityReasons(id);

            return gridModel.Unavailability.DataBind(equipmentUnavailablePeriods.AsQueryable());
        }

        [HttpGet]
        public virtual JsonResult EditAvailabilityCheck(EquipmentEditAvailabilityModel model)
        {
            //get all instance of the equipment against an event part within the given range
            List<EquipmentEventPart> eeps = GetAffectedEquipmentEventParts(model);

            List<string> affectedEventCodes = eeps.Select(eep => eep.EventPart.Event.EventCode).Distinct().OrderBy(s => s).ToList();

            return Json(new
            {
                EventCount = affectedEventCodes.Count,
                EventCodes = affectedEventCodes
            }, JsonRequestBehavior.AllowGet);
        }

        private List<EquipmentEventPart> GetAffectedEquipmentEventParts(EquipmentEditAvailabilityModel model)
        {
            List<EquipmentEventPart> eeps;
            eeps = UnitOfWork.EquipmentEventParts.SelectFilteredList(
                PredicateLibrary.GetEquipmentEventPartInADateRange(model.EquipmentID, model.StartDate, model.EndDate, model.DayTypeID)
                ).ToList();

            return eeps;
        }

        [TOREditAuthorise]
        public virtual ActionResult EditAvailability(EquipmentEditAvailabilityModel model)
        {
            var gridModel = new EquipmentUnavailabilityModel(Url.Action(Actions.GetAvailabilityData(model.EquipmentID)),
                Url.Action(MVC.Equipment.ActionNames.EditAvailability));

            //Validation
            if (gridModel.Unavailability.AjaxCallBackMode == AjaxCallBackMode.EditRow ||
                gridModel.Unavailability.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                //validate start date before end date
                if (model.EndDate != null && model.EndDate < model.StartDate)
                {
                    return gridModel.Unavailability.ShowEditValidationMessage(Constants.GRID_OBJECT_AVAILABILITY_START_DATE_EARLIER_THAN_END_DATE_ERROR);
                }

                //validate dates & day type
                if (!(model.StartDate.Equals(model.EndDate)) && model.DayTypeID != (int)SFR.TOR.Utility.EventPartTypeEnum.FullDay)
                {
                    return gridModel.Unavailability.ShowEditValidationMessage(Constants.GRID_EQUIPMENT_AVAILABILITY_INVALID_DAY_TYPE_ERROR);
                }

                // Validate against pre-existing unavailable periods
                var today = DateTime.Now.Date;

                //Get all periods between dates where the day type matches what was chosen, or is a full day.

                var data = UnitOfWork.EquipmentUnavailablePeriods.SelectFilteredList(p =>
                                ((p.StartDate >= model.StartDate && p.StartDate <= model.EndDate) ||
                                ((p.EndDate ?? today) >= model.StartDate && (p.EndDate ?? today) <= model.EndDate) ||
                                (model.StartDate >= p.StartDate && model.StartDate <= (p.EndDate ?? today))) &&
                                p.Equipment.ID == model.EquipmentID &&
                                ((p.DayTypeID == model.DayTypeID || p.DayTypeID == (int)SFR.TOR.Utility.EventPartTypeEnum.FullDay) ||
                                (model.DayTypeID == (int)SFR.TOR.Utility.EventPartTypeEnum.FullDay)) &&
                                model.ID != p.ID); //exclude current record if we are editing

                //If any records exist, then there is a conflict in day types/dates
                if (data.Count() > 0)
                    return gridModel.Unavailability.ShowEditValidationMessage(Constants.GRID_INSTRUCTOR_AVAILABILITY_CONFLICTING_DATES_ERROR);

            }

            if (gridModel.Unavailability.AjaxCallBackMode == AjaxCallBackMode.EditRow)
            {
                var eup = UnitOfWork.EquipmentUnavailablePeriods.SelectBy(x => x.ID == model.ID);

                //does a record exist for this unavailability?
                if (eup != null)
                {
                    ProcessEquipmentUnavailabilityForEvents(model, eup);

                    //update the record
                    Mapper.Map(model, eup);
                    UnitOfWork.EquipmentUnavailablePeriods.Update(eup);
                }
                else
                {
                    //insert a new record
                    eup = Mapper.Map<EquipmentEditAvailabilityModel, EquipmentUnavailablePeriod>(model);
                    UnitOfWork.EquipmentUnavailablePeriods.Insert(eup);
                    ProcessEquipmentUnavailabilityForEvents(model);
                }
            }
            else if (gridModel.Unavailability.AjaxCallBackMode == AjaxCallBackMode.AddRow)
            {
                //insert a new record
                EquipmentUnavailablePeriod eup = Mapper.Map<EquipmentEditAvailabilityModel, EquipmentUnavailablePeriod>(model);
                UnitOfWork.EquipmentUnavailablePeriods.Insert(eup);
                UnitOfWork.Commit();

                //now remove the equipment from any events in this period
                ProcessEquipmentUnavailabilityForEvents(model);
            }
            else if (gridModel.Unavailability.AjaxCallBackMode == AjaxCallBackMode.DeleteRow)
            {
                var eup = UnitOfWork.EquipmentUnavailablePeriods.SelectBy(x => x.ID == model.ID);
                UnitOfWork.EquipmentUnavailablePeriods.Delete(eup);
            }

            UnitOfWork.Commit();

            return RedirectToAction(MVC.Equipment.ActionNames.GetAvailabilityData, new { id = model.EquipmentID });
        }

        private void ProcessEquipmentUnavailabilityForEvents(EquipmentEditAvailabilityModel model, EquipmentUnavailablePeriod eup)
        {
            //only process where the dates have moved past original boundaries
            if (model.StartDate < eup.StartDate || model.EndDate > eup.EndDate)
            {
                ProcessEquipmentUnavailabilityForEvents(model);
            }
        }

        private void ProcessEquipmentUnavailabilityForEvents(EquipmentEditAvailabilityModel model)
        {
            //get all instance of the equipment against an event part within the given range
            List<EquipmentEventPart> ieps;
            ieps = UnitOfWork.EquipmentEventParts.SelectFilteredList(
                PredicateLibrary.GetEquipmentEventPartInADateRange(model.EquipmentID, model.StartDate, model.EndDate, model.DayTypeID)
                ).ToList();

            //get all instance of the equipment against an event part within the given range
            List<EquipmentEventPart> eeps = GetAffectedEquipmentEventParts(model);

            int eventID = 0;

            //delete each instance and update the parent events status
            foreach (var eep in eeps)
            {
                eventID = eep.EventPart.EventID;
                UnitOfWork.EquipmentEventParts.Delete(eep);
                UnitOfWork.Commit();
                UnitOfWork.EventParts.ResetResourceStatus(eep.DayPartID);
                UnitOfWork.Commit();
                UnitOfWork.Events.ResetResourceStatus(eventID, TORUser.FullName);
                UnitOfWork.Commit();
            }
        }

        public virtual JsonResult GetEquipmentTagsJson()
        {
            var reasons = UnitOfWork.EquipmentTags.SelectAll().Select(x => new { x.ID, x.Name }).ToList();

            return Json(reasons, JsonRequestBehavior.AllowGet);
        }

        

        public virtual JsonResult GetEquipmentUnavailableReasons()
        {
            var reasons = UnitOfWork.EquipmentUnavailableReasons.SelectAll().Select(x => new { x.ID, x.Reason }).ToList();

            return Json(reasons, JsonRequestBehavior.AllowGet);
        }
        
    }
}