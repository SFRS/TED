﻿using System;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using LinqKit;
using SFR.TOR.Data;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;
using SFR.TOR.Web.Filters;
using Trirand.Web.Mvc;
using SFR.TOR.Utility;

namespace SFR.TOR.Web.Controllers
{
    [TORUserAuthorisation]
    public partial class ResourcesController : BaseController
    {

        public ResourcesController(ITORUnitOfWork unitOfWork): base(unitOfWork)
        {            
        }


        public virtual ActionResult Index()
        {
            return View();
        }

        public virtual JsonResult GetInstructorsData(string searchTerms)
        {
            bool includeInactiveSection = true;
            var gridModel = new InstructorsModel(Url.Action(Actions.GetInstructorsData(searchTerms)), GetSectionDataForFilter(includeInactiveSection), GetTrainingCentresForFilters(), GetResourceAvailabilityForFilters(), GetInstructorGroupDataForFilter());

            Expression<Func<Instructor, bool>> searchTermPredicate = null;
            Expression<Func<Instructor, bool>> predicate = null;

            predicate = PredicateBuilder.True<Instructor>();
            if (TORUser.ResourceDisplayTrainingCentreID != -1)
            {
                predicate = predicate.And(p => p.TrainingCentreID == TORUser.ResourceDisplayTrainingCentreID);
            }
            
            if (!string.IsNullOrEmpty(searchTerms))
            {
                searchTermPredicate = PredicateBuilder.False<Instructor>();
                searchTermPredicate = searchTermPredicate.Or(p => p.FirstName.Contains(searchTerms));
                searchTermPredicate = searchTermPredicate.Or(p => p.LastName.Contains(searchTerms));
                searchTermPredicate = searchTermPredicate.Or(p => p.Section.Title.Contains(searchTerms));

                predicate = predicate.And(searchTermPredicate.Expand()); 
            }

            JQGridState gridState = gridModel.InstructorGrid.GetState();
            Session["gridState"] = gridState;

            IQueryable<InstructorModel> instructors = UnitOfWork.Instructors.GetInstructors(predicate);

            return gridModel.InstructorGrid.DataBind(instructors.AsQueryable());
        }

        public virtual ActionResult Instructors(string searchTerms)
        {
            bool includeInactiveOption = true;
            var gridModel = new InstructorsModel(Url.Action(Actions.GetInstructorsData(searchTerms)), GetSectionDataForFilter(includeInactiveOption), GetTrainingCentresForFilters(), GetResourceAvailabilityForFilters(), GetInstructorGroupDataForFilter());

            return View(gridModel);
        }

        public virtual JsonResult GetVenuesData(string searchTerms)
        {
            var gridModel = new VenuesModel(Url.Action(Actions.GetVenuesData(searchTerms)), GetTrainingCentresForFilters(), GetResourceAvailabilityForFilters(), GetVenuesGroupDataForFilter());

            Expression<Func<Venue, bool>> predicate = PredicateBuilder.True<Venue>(); ;
            Expression<Func<Venue, bool>> searchTermPredicate = PredicateBuilder.False<Venue>();
            
            if (TORUser.ResourceDisplayTrainingCentreID != -1)
            {
                predicate = predicate.And(p => p.TrainingCentreID == TORUser.ResourceDisplayTrainingCentreID);
            }

            if (!string.IsNullOrEmpty(searchTerms))
            {
                searchTermPredicate = searchTermPredicate.Or(p => p.Name.Contains(searchTerms));
                predicate = predicate.And(searchTermPredicate.Expand()); 
            }

            JQGridState gridState = gridModel.VenuesGrid.GetState();
            Session["gridState"] = gridState;

            IQueryable<VenueModel> venues = UnitOfWork.Venues.GetVenues(predicate);

            return gridModel.VenuesGrid.DataBind(venues.AsQueryable());
        }

        public virtual ActionResult Venues(string searchTerms)
        {
            var gridModel = new VenuesModel(Url.Action(Actions.GetVenuesData(searchTerms)), GetTrainingCentresForFilters(), GetResourceAvailabilityForFilters(), GetVenuesGroupDataForFilter());
            return View(gridModel);
        }

        public virtual JsonResult GetEquipmentData(string searchTerms)
        {
            var gridModel = new EquipmentsModel(Url.Action(Actions.GetEquipmentData(searchTerms)), GetTrainingCentresForFilters(), GetResourceAvailabilityForFilters(), GetEquipmentGroupDataForFilter());

            Expression<Func<Data.Equipment, bool>> predicate = PredicateBuilder.True<Data.Equipment>(); ;
            Expression<Func<Data.Equipment, bool>> searchTermPredicate = PredicateBuilder.False<Data.Equipment>();

            if (TORUser.ResourceDisplayTrainingCentreID != -1)
            {
                predicate = predicate.And(p => p.TrainingCentreID == TORUser.ResourceDisplayTrainingCentreID);                
            }

            if (!string.IsNullOrEmpty(searchTerms))
            {
                searchTermPredicate = searchTermPredicate.Or(p => p.Name.Contains(searchTerms));
                predicate = predicate.And(searchTermPredicate.Expand()); 
            }

            JQGridState gridState = gridModel.EquipmentGrid.GetState();
            Session["gridState"] = gridState;

            IQueryable<EquipmentModel> equipment = UnitOfWork.Equipment.GetEquipment(predicate);

            return gridModel.EquipmentGrid.DataBind(equipment.AsQueryable());
        }

        public virtual ActionResult Equipment(string searchTerms)
        {
            var gridModel = new EquipmentsModel(Url.Action(Actions.GetEquipmentData(searchTerms)), GetTrainingCentresForFilters(), GetResourceAvailabilityForFilters(), GetEquipmentGroupDataForFilter());
            return View(gridModel);
        }
    }
}
