﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Web.Routing;
using AutoMapper;
using NLog;
using SFR.TOR.Data;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;
using SFR.TOR.Web.Filters;
using ActivityStatus = SFR.TOR.Data.ActivityStatus;
using EventPartType = SFR.TOR.Data.EventPartType;
using SFR.TOR.Utility;
using SFR.TOR.Utility.Security;
using System.Text;
using SFR.TOR.Web.Json;

namespace SFR.TOR.Web.Controllers
{
    /// <summary>
    /// base controller class which contains some common functionality
    /// </summary>
    [TORAuthentication]
    public abstract partial class BaseController : Controller
    {
        public ITORUnitOfWork UnitOfWork { get; set; }

        internal static Logger Logger = NLog.LogManager.GetCurrentClassLogger();

        protected BaseController(ITORUnitOfWork unitOfWork)
        {
            UnitOfWork = unitOfWork;
        }

        protected override void Initialize(RequestContext requestContext)
        {
            ValidateRequest = false;

            base.Initialize(requestContext);
        }

        protected override JsonResult Json(object data, string contentType, Encoding contentEncoding, JsonRequestBehavior behavior)
        {
            return new JsonDotNetResult
            {
                Data = data,
                ContentType = contentType,
                ContentEncoding = contentEncoding,
                JsonRequestBehavior = behavior
            };
        }

        public TORUser TORUser
        {
            get
            {
                TORUser u = UnitOfWork.Session.User;

                //does the user exist in our DB? if not, add them. Cope if duplicate entries exist for the username
                User user = UnitOfWork.Users.SelectFilteredList(x => x.UserName == u.UserName).FirstOrDefault();
                if (user == null)
                {
                    user = new User()
                        {
                            UserName = u.UserName,
                            DefaultTrainingCentreID = 1,
                            DefaultShowAllResources = false
                        };

                    UnitOfWork.Users.Insert(user);
                    UnitOfWork.Commit();
                }

                Mapper.Map(user, u);

                var trainingCentre = UnitOfWork.TrainingCentres.SelectAll()
                                .FirstOrDefault(tc => tc.ID == u.DefaultTrainingCentreID);

                u.DefaultTrainingCentreName = trainingCentre != null ? trainingCentre.Name : string.Empty;

                return u;
            }
            set
            {
                UnitOfWork.Session.User = value;
            }
        }

        #region - Helper methods

        public List<SelectListItem> GetFinancialYearSelectList()
        {
            var sl = new List<SelectListItem>();

            int currentYear = DateTime.Now.Year;
            DateTime startofFinancialYear = DateTime.Parse("1/4/" + currentYear);
            // If we're before 1st April then start from 2 years ago, else start from last year.
            // Ensures that the list always contains the previous financial year.
            int startYear = DateTime.Now < startofFinancialYear ? currentYear - 2 : currentYear - 1;
            int endYear = startYear + 3;

            for (int year = startYear; year <= endYear; year++)
            {
                var yearText = string.Format("{0}/{1}", year, (year + 1).ToString().Substring(2, 2));
                var yearStart = DateTime.Parse("1/4/" + year);
                var nextYearStart = DateTime.Parse("1/4/" + (year + 1));
                var isCurrentYear = DateTime.Now > yearStart && DateTime.Now < nextYearStart;
                sl.Add(new SelectListItem() { Text = yearText, Value = year.ToString(), Selected = isCurrentYear });
            }

            return sl;
        }



        /// <summary>
        /// Returns a list of section data
        /// </summary>
        /// <returns>a list of section data</returns>
        protected SelectList GetSectionData(bool includeInactiveSection = false)
        {
            IQueryable<Section> sectionData = UnitOfWork.Sections.SelectAll();

            var sections = sectionData.Select(x => new
            {
                x.ID,
                x.Title
            }).ToArray().ToList();

            if (includeInactiveSection)
            {
                sections.Add(new
                {
                    ID = Constants.INSTRUCTOR_INACTIVE_SECTION_ID,
                    Title = Constants.INSTRUCTOR_INACTIVE_SECTION_NAME
                });
            }

            return new SelectList(sections.OrderBy(s => s.Title), "ID", "Title");
        }


        /// <summary>
        /// Returns a list of section data
        /// </summary>
        /// <returns>a list of section data</returns>
        protected SelectList GetSectionDataForFilter(bool includeInactiveSection = false)
        {
            IQueryable<Section> sectionData = UnitOfWork.Sections.SelectAll();

            var sections = sectionData.Select(x => new
            {
                ID = x.Title,
                x.Title
            }).ToArray().ToList();

            if (includeInactiveSection)
            {
                sections.Add(new
                {
                    ID = Constants.INSTRUCTOR_INACTIVE_SECTION_NAME,
                    Title = Constants.INSTRUCTOR_INACTIVE_SECTION_NAME
                });
            }

            return new SelectList(sections.OrderBy(s => s.Title), "ID", "Title");
        }


        /// <summary>
        /// Returns a list of instructor status data
        /// </summary>
        /// <returns>a list of section data</returns>
        protected SelectList GetGroupData()
        {
            IQueryable<Group> groupData = UnitOfWork.Groups.SelectAll();

            var sections = groupData.OrderBy(g => g.Name).Select(x => new
            {
                x.ID,
                x.Name
            }).ToArray().ToList();

            return new SelectList(sections, "ID", "Name");
        }

        /// <summary>
        /// Returns a list of instructor status data
        /// </summary>
        /// <returns>a list of section data</returns>
        protected SelectList GetInstructorGroupDataForFilter()
        {
            IQueryable<Group> groupData = UnitOfWork.Groups.SelectAll();

            var sections = groupData.OrderBy(g => g.Name).Select(x => new
            {
                ID = x.Name,
                Name = x.Name
            }).ToArray().ToList();

            return new SelectList(sections, "ID", "Name");
        }

        /// <summary>
        /// Return a list of Venue Group data
        /// </summary>
        /// <returns></returns>
        protected SelectList GetVenuesGroupData()
        {
            IQueryable<VenueGroup> groupData = UnitOfWork.VenueGroups.SelectAll();

            var groups = groupData.Select(x => new
            {
                x.ID,
                x.Title
            }).ToArray().ToList();

            var groupList = new SelectList(groups, "ID", "Title");
            return groupList;
        }


        /// <summary>
        /// Return a list of Venue Group data
        /// </summary>
        /// <returns></returns>
        protected SelectList GetVenuesGroupDataForFilter()
        {
            IQueryable<VenueGroup> groupData = UnitOfWork.VenueGroups.SelectAll();

            var groups = groupData.Select(x => new
            {
                ID = x.Title,
                Title = x.Title
            }).ToArray().ToList();

            var groupList = new SelectList(groups, "ID", "Title");
            return groupList;
        }

        /// <summary>
        /// Return a list of Equipment Group data
        /// </summary>
        /// <returns></returns>
        protected SelectList GetEquipmentGroupData()
        {
            IQueryable<EquipmentGroup> groupData = UnitOfWork.EquipmentGroups.SelectAll();

            var groups = groupData.Select(x => new
            {
                x.ID,
                x.Title
            }).ToArray().ToList();

            var groupList = new SelectList(groups, "ID", "Title");
            return groupList;
        }

        /// <summary>
        /// Return a list of Equipment Group data
        /// </summary>
        /// <returns></returns>
        protected SelectList GetEquipmentGroupDataForFilter()
        {
            IQueryable<EquipmentGroup> groupData = UnitOfWork.EquipmentGroups.SelectAll();

            var groups = groupData.Select(x => new
            {
                ID = x.Title,
                Title = x.Title
            }).ToArray().ToList();

            var groupList = new SelectList(groups, "ID", "Title");
            return groupList;
        }

        /// <summary>
        /// Returns a list of Activity Status data
        /// </summary>
        /// <returns>a list of Activity Status data</returns>
        protected SelectList GetActivityStatusData()
        {
            IQueryable<ActivityStatus> activityStatusData = UnitOfWork.ActivityStatus.SelectAll();

            var statusData = activityStatusData.Select(x => new
            {
                x.ID,
                x.Title
            }).ToArray().ToList();

            return new SelectList(statusData, "ID", "Title");
        }

        /// <summary>
        /// Returns a list of Activity Status data
        /// </summary>
        /// <returns>a list of Activity Status data</returns>
        protected SelectList GetActivityStatusDataForFilter()
        {
            IQueryable<ActivityStatus> activityStatusData = UnitOfWork.ActivityStatus.SelectAll();

            var statusData = activityStatusData.Select(x => new
            {
                ID = x.Title,
                x.Title
            }).ToArray().ToList();

            return new SelectList(statusData, "ID", "Title");
        }

        /// <summary>
        /// Returns a list of status data
        /// </summary>
        /// <returns>a list of status data</returns>
        protected SelectList GetStatusData()
        {
            var statusData = UnitOfWork.EventStatus.SelectAll();

            var status = statusData.Select(x => new
            {
                x.ID,
                x.Title
            }).ToArray().ToList();

            return new SelectList(status, "ID", "Title");
        }

        /// <summary>
        /// Returns a list of status data
        /// </summary>
        /// <returns>a list of status data</returns>
        protected SelectList GetStatusDataForManualEdit(EventStatusEnum currentStatus)
        {
            var statusData = UnitOfWork.EventStatus.SelectAll().ToList();

            switch (currentStatus)
            {
                case EventStatusEnum.NotReady:
                case EventStatusEnum.Complete:
                case EventStatusEnum.Scheduled:
                case EventStatusEnum.Cancelled:
                    statusData.RemoveAll(x => x.ID != (int)currentStatus);
                    break;
                case EventStatusEnum.Ready:
                    statusData.RemoveAll(x => x.ID != (int)EventStatusEnum.Ready && x.ID != (int)EventStatusEnum.Scheduled);
                    break;
                case EventStatusEnum.Blocked:
                    statusData.RemoveAll(x => x.ID != (int)EventStatusEnum.Scheduled && x.ID != (int)EventStatusEnum.Blocked);
                    break;
            }

            var status = statusData.Select(x => new
            {
                x.ID,
                x.Title
            }).ToArray().ToList();

            return new SelectList(status, "ID", "Title");
        }

        /// <summary>
        /// Returns a list of status data
        /// </summary>
        /// <returns>a list of status data</returns>
        protected SelectList GetStatusDataForFilter()
        {
            var statusData = UnitOfWork.EventStatus.SelectAll();

            var status = statusData.Select(x => new
            {
                ID = x.Title,
                x.Title
            }).ToArray().ToList();

            return new SelectList(status, "ID", "Title");
        }

        /// <summary>
        /// Returns a list of financial years
        /// </summary>
        /// <returns>a list of status data</returns>
        protected SelectList GetFinancialYearDataForFilter()
        {
            var fySelectList = GetFinancialYearSelectList();
            return new SelectList(fySelectList, "Value", "Text");
        }



        protected List<SelectListItem> GetDayItems()
        {
            var list = new List<SelectListItem>();

            var dayItems = UnitOfWork.ActivityPartTypes.SelectAll();

            foreach (var dayType in dayItems)
            {
                list.Add(new SelectListItem()
                             {
                                 Value = dayType.ID.ToString(),
                                 Text = dayType.Title
                             });
            }

            return list;
        }

        protected List<SelectListItem> GetAbsenceReasons()
        {
            var list = new List<SelectListItem>();

            var reasons = UnitOfWork.UnavailableReasons.SelectAll();

            foreach (var reason in reasons)
            {
                list.Add(new SelectListItem()
                {
                    Value = reason.ID.ToString(),
                    Text = reason.Reason
                });
            }

            return list;
        }


        protected List<SelectListItem> GetGroupCalendarYears(int year)
        {
            var list = new List<SelectListItem>();

            int count = DateTime.Now.Year - 1; //start with last year so we can alwats see last years group calendar

            while (count <= DateTime.Now.Year + 9)
            {
                list.Add(new SelectListItem()
                {
                    Value = count.ToString(),
                    Text = count.ToString(),
                    Selected = count == year
                });
                count++;
            }

            return list;
        }

        protected List<SelectListItem> GetVenueTagsSelectList()
        {
            var list = new List<SelectListItem>();

            var venueTags = UnitOfWork.VenueTags.SelectAll();

            foreach (var venueTag in venueTags)
            {
                list.Add(new SelectListItem()
                {
                    Value = venueTag.ID.ToString(),
                    Text = venueTag.Name
                });
            }

            return list;
        }

        protected List<SelectListItem> GetEquipmentTags()
        {
            var list = new List<SelectListItem>();

            var equipmentTags = UnitOfWork.EquipmentTags.SelectAll();

            foreach (var equipmentTag in equipmentTags)
            {
                list.Add(new SelectListItem()
                {
                    Value = equipmentTag.ID.ToString(),
                    Text = equipmentTag.Name
                });
            }

            return list;
        }

        protected List<SelectListItem> GetVenueTags()
        {
            var list = new List<SelectListItem>();

            var equipmentTags = UnitOfWork.VenueTags.SelectAll();

            foreach (var equipmentTag in equipmentTags)
            {
                list.Add(new SelectListItem()
                {
                    Value = equipmentTag.ID.ToString(),
                    Text = equipmentTag.Name
                });
            }

            return list;
        }

        protected List<SelectListItem> GetEventParts(int eventID)
        {
            var list = new List<SelectListItem>();

            var eventTags = UnitOfWork.EventParts.SelectFilteredList(x => x.EventID == eventID && x.Date != null).OrderBy(y => y.Date);

            foreach (var eventTag in eventTags)
            {
                string date = eventTag.Date.HasValue ? eventTag.Date.Value.ToShortDateString() : "No Date Scheduled";

                list.Add(new SelectListItem()
                {
                    Value = eventTag.ID.ToString(),
                    Text = string.Format("{0} ({1} - {2}) ", eventTag.Name, date, eventTag.DayType == 1 ? "Morning" : "Afternoon")
                });
            }

            return list;
        }

        protected List<SelectListItem> GetVenueTagsSelectList(IQueryable<VenueTagModel> venueTags)
        {
            var list = new List<SelectListItem>();

            foreach (var venueTag in venueTags)
            {
                list.Add(new SelectListItem()
                {
                    Value = venueTag.ID.ToString(),
                    Text = venueTag.Name
                });
            }

            return list;
        }

        protected List<SelectListItem> GetEquipmentTagsSelectList(IQueryable<EquipmentTagModel> equipmentTags)
        {
            var list = new List<SelectListItem>();

            foreach (var equipmentTag in equipmentTags)
            {
                list.Add(new SelectListItem()
                {
                    Value = equipmentTag.ID.ToString(),
                    Text = equipmentTag.Name
                });
            }

            return list;
        }

        /// <summary>
        /// Returns a list of priority data
        /// </summary>
        /// <returns>a list of priority data</returns>
        protected SelectList GetPriorityData()
        {
            IQueryable<EventPriority> statusData = UnitOfWork.EventPriorities.SelectAll();

            var status = statusData.Select(x => new
            {
                x.ID,
                x.Title
            }).ToArray().ToList();

            //add initial "select"option
            status.Insert(0, new
            {
                ID = 0,
                Title = "Select"
            });

            return new SelectList(status, "ID", "Title");
        }

        /// <summary>
        /// Returns a list of priority data
        /// </summary>
        /// <returns>a list of priority data</returns>
        protected SelectList GetPriorityDataForFilter()
        {
            var priorityData = UnitOfWork.EventPriorities.SelectAll();

            var status = priorityData.Select(x => new
                {
                    ID = x.Title,
                    x.Title
                }).ToArray().ToList();

            return new SelectList(status, "ID", "Title");
        }


        /// <summary>
        /// Returns a list of priority data
        /// </summary>
        /// <returns>a list of priority data</returns>
        protected SelectList GetPinchpointTypesForFilter()
        {
            var priorityData = UnitOfWork.PinchpointTypes.SelectAll();

            var status = priorityData.Select(x => new
            {
                ID = x.TypeName,
                Title = x.TypeName
            }).ToArray().ToList();

            return new SelectList(status, "ID", "Title");
        }

        /// <summary>
        /// Returns a list of resource status data
        /// </summary>
        /// <returns>a list of resource status data</returns>
        protected SelectList GetResourceStatusDataForFilter()
        {
            var resourceStatusData = UnitOfWork.ResourceStatus.SelectAll();

            var status = resourceStatusData.Select(x => new
            {
                ID = x.Title,
                x.Title
            }).ToArray().ToList();

            return new SelectList(status, "ID", "Title");
        }

        protected SelectList GetEventDayTypes(IQueryable<EventPartType> eventDayTypes, int selectedID)
        {
            var edts = eventDayTypes.Select(x => new
            {
                x.ID,
                x.Title
            }).ToArray().ToList();

            return new SelectList(edts, "ID", "Title", selectedID.ToString());
        }

        protected SelectList GetTrainingCentres(int selectedID)
        {
            IQueryable<TrainingCentre> trainingCentres = UnitOfWork.TrainingCentres.SelectAll();

            var tcs = trainingCentres.Select(x => new
            {
                x.ID,
                x.Name
            }).ToArray().ToList();

            return new SelectList(tcs, "ID", "Name", selectedID.ToString());
        }

        protected string GetTrainingCentreName(int id)
        {
            var trainingCentre = UnitOfWork.TrainingCentres.SelectFilteredList(tc=>tc.ID == id).FirstOrDefault();
            if (trainingCentre == null)
                return string.Empty;

            return trainingCentre.Name;
        }

        protected int GetNationalTrainingCentreId()
        {
            var trainingCentre = UnitOfWork.TrainingCentres.SelectFilteredList(tc => tc.Name == "National").FirstOrDefault();
            if (trainingCentre == null)
                return -1;

            return trainingCentre.ID;
        }

        protected SelectList GetEquipmentGroupData(int selectedID)
        {
            IQueryable<EquipmentGroup> equipmentGroups = UnitOfWork.EquipmentGroups.SelectAll().OrderBy(eg => eg.Title);

            var tcs = equipmentGroups.Select(x => new
            {
                x.ID,
                x.Title
            }).ToArray().ToList();

            return new SelectList(tcs, "ID", "Title", selectedID.ToString());
        }

        protected SelectList GetAllVenueGroups(int selected)
        {
            IQueryable<VenueGroup> venueGroups = UnitOfWork.VenueGroups.SelectAll().OrderBy(vg=>vg.Title);

            var tcs = venueGroups.Select(x => new
            {
                x.ID,
                x.Title
            }).ToArray().ToList();

            return new SelectList(tcs, "ID", "Title", selected);
        }

        protected SelectList GetTrainingCentresForFilters()
        {
            IQueryable<TrainingCentre> trainingCentres = UnitOfWork.TrainingCentres.SelectAll().OrderBy(tc=> tc.Name);

            var tcs = trainingCentres.Select(x => new
            {
                x.ID,
                x.Name,
            }).ToArray().ToList();

            var tcSelectList = new SelectList(tcs, "ID", "Name");
           
            return tcSelectList;
        }

        protected SelectList GetVenueGroupsForFilters()
        {
            IQueryable<VenueGroup> venueGroups = UnitOfWork.VenueGroups.SelectAll().OrderBy(v => v.Title);

            var vg = venueGroups.Select(x => new
            {
                x.ID,
                x.Title
            });

            return new SelectList(vg, "ID", "Title");
        }

        protected SelectList GetResourceAvailabilityForFilters()
        {
            var list = new[]
            { 
                new { ID = Constants.RESOURCE_AVAILABILITY_AVAILABLE, Name = Constants.RESOURCE_AVAILABILITY_AVAILABLE },
                new { ID = Constants.RESOURCE_AVAILABILITY_STATUS_UNAVAILABLE, Name = Constants.RESOURCE_AVAILABILITY_STATUS_UNAVAILABLE } ,
                new { ID = Constants.RESOURCE_AVAILABILITY_STATUS_LIMITED, Name = Constants.RESOURCE_AVAILABILITY_STATUS_LIMITED } 
            }.ToList();

            return new SelectList(list, "ID", "Name");
        }

        protected List<SelectListItem> GetVenueUnavailabilityReasons()
        {
            var list = new List<SelectListItem>();

            var reasons = UnitOfWork.VenueUnavailableReason.SelectAll();

            foreach (var reason in reasons)
            {
                list.Add(new SelectListItem()
                {
                    Value = reason.ID.ToString(),
                    Text = reason.Reason
                });
            }

            return list;
        }

        #endregion

    }
}
