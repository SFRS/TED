﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using SFR.TOR.Web.Json;

namespace SFR.TOR.Web.Filters
{
    /// <summary>
    /// When applied to an action method, this filter converts Redirect and View results to JSON.
    /// For a Redirect, the JSON contains the target URL. For a View result, the JSON contains the model and any model state errors.
    /// </summary>
    public class AjaxResultAttribute : ActionFilterAttribute
    {
        private const string CONTENT_TYPE_APPLICATION_JSON = "application/json";

        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            if (!filterContext.HttpContext.Request.IsAjaxRequest())
                return;

            var isRedirect = filterContext.Result is RedirectResult || filterContext.Result is RedirectToRouteResult;
            var isView = filterContext.Result is ViewResultBase;

            if (isRedirect)
            {
                var url = "/";

                if (filterContext.Result is RedirectResult)
                {
                    var result = filterContext.Result as RedirectResult;
                    url = UrlHelper.GenerateContentUrl(result.Url, filterContext.HttpContext);
                }
                else
                {
                    var result = filterContext.Result as RedirectToRouteResult;
                    url = UrlHelper.GenerateUrl(result.RouteName, null, null, result.RouteValues, RouteTable.Routes, filterContext.RequestContext, false);
                }

                filterContext.HttpContext.Response.StatusCode = (int)HttpStatusCode.OK;

                filterContext.Result = new JsonResult
                {
                    Data = new { Redirect = url },
                    ContentEncoding = System.Text.Encoding.UTF8,
                    ContentType = CONTENT_TYPE_APPLICATION_JSON,
                    JsonRequestBehavior = JsonRequestBehavior.AllowGet
                };
            }
            else if (isView)
            {
                var oldResult = filterContext.Result as ViewResultBase;
                ModelStateDictionary modelState = oldResult.ViewData.ModelState;

                dynamic resultData;

                if (modelState.IsValid)
                {
                    resultData = new { Model = oldResult.Model };
                }
                else
                {
                    resultData = new
                    {
                        Model = oldResult.Model,
                        ModelErrors = from ms in modelState
                                      let ec = ms.Value.Errors
                                      where ec.Count > 0
                                      select new
                                      {
                                          Name = ms.Key,
                                          Errors = ec.Select(e => e.ErrorMessage).Union(
                                          ec.Where(e => e.Exception != null).Select(e => e.Exception.Message))
                                      }
                    };
                }

                filterContext.Result = new JsonDotNetResult
                {
                    Data = resultData,
                    ContentEncoding = System.Text.Encoding.UTF8,
                    ContentType = CONTENT_TYPE_APPLICATION_JSON,
                    JsonRequestBehavior = JsonRequestBehavior.AllowGet
                };
            }
            else
            {
                // Just return the result to the client unchanged
            }
        }
    }
}