﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SFR.TOR.Web.Filters
{
    /// <summary>
    /// When a RedirectResult or RedirectToRouteResult is returned from an action, anything in the ViewData.ModelState dictionary will be copied into TempData.
    /// When a ViewResultBase is returned from an action, any ModelState entries that were previously copied to TempData will be copied back to the ModelState dictionary.
    /// </summary>
    public class PreserveModelStateOnRedirectAttribute : ActionFilterAttribute
    {
        public const string TempDataKey = "ModelState";

        /// <summary>
        /// When a RedirectToRouteResult is returned from an action, anything in the ViewData.ModelState dictionary will be copied into TempData.
        /// When a ViewResultBase is returned from an action, any ModelState entries that were previously copied to TempData will be copied back to the ModelState dictionary.
        /// </summary>
        /// <param name="filterContext"></param>
        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            var controller = filterContext.Controller;
            var modelState = controller.ViewData.ModelState;
            var tempData = controller.TempData;
            var controllerName = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName;
            var actionName = filterContext.ActionDescriptor.ActionName;
            var result = filterContext.Result;

            if (result is ViewResultBase)
            {
                //If there are failures in tempdata, copy them to the modelstate
                CopyTempDataToModelState(modelState, tempData, controllerName, actionName);
                return;
            }

            //If we're redirecting and there are errors, put them in tempdata instead (so they can later be copied back to modelstate)
            if ((result is RedirectToRouteResult || result is RedirectResult) && !modelState.IsValid)
            {
                CopyModelStateToTempData(modelState, tempData, controllerName, actionName);
            }
        }

        private void CopyTempDataToModelState(ModelStateDictionary modelState, TempDataDictionary tempData, string controllerName, string actionName)
        {
            string key = GetKey(controllerName, actionName);

            if (!tempData.ContainsKey(key)) return;

            var fromTempData = tempData[key] as ModelStateDictionary;
            if (fromTempData == null) return; // No ModelStateDictionary found against the key, so nothing to merge

            modelState.Merge(fromTempData);
        }

        private static void CopyModelStateToTempData(ModelStateDictionary modelState, TempDataDictionary tempData, string controllerName, string actionName)
        {
            string key = GetKey(controllerName, actionName);
            tempData[key] = modelState;
        }

        private static string GetKey(string controllerName, string actionName)
        {
            return controllerName + actionName + TempDataKey;
        }
    }
}