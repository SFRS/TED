using System.Web.Mvc;
using SFR.TOR.Utility;
using SFR.TOR.Web.Controllers;
using SFR.TOR.Utility.Security;

namespace SFR.TOR.Web.Filters
{
    public class TOREditAuthoriseAttribute : ActionFilterAttribute
    {
        /// <summary>
        /// Called by the ASP.NET MVC framework before the action method executes.
        /// </summary>
        /// <param name="filterContext">The filter context.</param>
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (!filterContext.IsChildAction)
            {
                if (filterContext.RequestContext.HttpContext.Request.IsAuthenticated)
                {
                    TORUser torUser = (filterContext.Controller as BaseController).TORUser;

                    if (torUser.TORRole < TORRole.Editor)
                    {
                        throw new UnauthorisedException();
                    }
                }
            }
        }
    }
}