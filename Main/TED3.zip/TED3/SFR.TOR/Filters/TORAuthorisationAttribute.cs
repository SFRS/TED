﻿using System.Web.Mvc;
using SFR.TOR.Utility;
using SFR.TOR.Web.Controllers;
using SFR.TOR.Utility.Security;

namespace SFR.TOR.Web.Filters
{
    public class TORAuthenticationAttribute : ActionFilterAttribute
    {
        /// <summary>
        /// Called by the ASP.NET MVC framework before the action method executes.
        /// </summary>
        /// <param name="filterContext">The filter context.</param>
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (!filterContext.IsChildAction)
            {
                if (filterContext.RequestContext.HttpContext.Request.IsAuthenticated)
                {                    
                    //only fill user data for non ajax requests
                    if (!filterContext.RequestContext.HttpContext.Request.IsAjaxRequest())
                    {
                        //user is authenticated, but need to make sure they are in basic TOR role
                        TORUser torUser = (filterContext.Controller as BaseController).TORUser;
                        filterContext.HttpContext.Session["UserFullName"] = torUser.FullName;                        
                    }                    
                }                
                else
                {
                    throw new UnauthenticatedException();
                }
            }
        }
    }

    

}