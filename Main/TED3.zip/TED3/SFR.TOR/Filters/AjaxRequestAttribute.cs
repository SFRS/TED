﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;

namespace SFR.TOR.Web.Filters
{
    /// <summary>
    /// Represents an attribute that is used to restrict an action method so that the method is blocked from
    /// handling Ajax requests, or non-Ajax requests, or both (in which case see NonActionAttribute).
    /// </summary>
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
    public class AjaxRequestAttribute : FilterAttribute, IAuthorizationFilter
    {
        /// <summary>
        /// Initializes a new instance of the SFR.TOR.Web.Filters.AjaxRequestAttribute class.
        /// </summary>
        /// <param name="ajaxAllowed">Sets whether Ajax requests are allowed</param>
        /// <param name="nonAjaxAllowed">Sets whether non-Ajax requests are allowed</param>
        public AjaxRequestAttribute(bool ajaxAllowed, bool nonAjaxAllowed)
        {
            this.AjaxAllowed = ajaxAllowed;
            this.NonAjaxAllowed = nonAjaxAllowed;
        }

        /// <summary>
        /// Gets whether Ajax requests are allowed
        /// </summary>
        public virtual bool AjaxAllowed { get; protected set; }

        /// <summary>
        /// Gets whether non-Ajax requests are allowed
        /// </summary>
        public virtual bool NonAjaxAllowed { get; protected set; }

        public void OnAuthorization(AuthorizationContext filterContext)
        {
            var isAjaxRequest = filterContext.HttpContext.Request.IsAjaxRequest();

            if (isAjaxRequest && !AjaxAllowed)
                throw new InvalidOperationException("This action method cannot be invoked with Ajax requests.");

            if (!isAjaxRequest && !NonAjaxAllowed)
                throw new InvalidOperationException("This action method cannot be invoked with non-Ajax requests.");
        }
    }
}