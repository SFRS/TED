// @reference libs/bootstrap

/* The above comment is a reference that tells Cassette to ensure that the jquery and bootstrap
 * folders' bundles are executed in the browser before this script. The bundle.txt files in
 * those folders tell Cassette what order to load the various jquery and bootstrap files in;
 * without a bundle.txt file we would need to edit each file to add reference comments. */

/* Contains general scripts that may be used in any page. 
 * If this file starts to get large it can be split into page-specific files. */

/* The following code is the Garber-Irish implementation, a way to run relevant JavaScript on page-load
 * based on the MVC action that produced the page. It's an unobtrusive approach, which means that the
 * code to call the relevant JavaScript functions is all here instead of being hardcoded into the HTML.
 * All this code needs from the page is data-controller and data-action attributes on the body tag.
 * Since JavaScript is case-sensitive, the controller and action names we use here must be an exact match.
 * http://viget.com/inspire/extending-paul-irishs-comprehensive-dom-ready-execution */

UIALLSCHEDULER = {
    common: {
        init: function () {
            // application-wide code

            window.BlockPage = function () {
                if ($.blockUI)
                    $.blockUI({ baseZ: 2000 }); // ensure the blocker appears in front of other elements
            };

            window.UnblockPage = function () {
                if ($.unblockUI)
                    $.unblockUI();
            };

            // Display a modal dialog with the error message
            window.ajax_ProcessError = function (xhr, status, error) {
                window.BlockWithMessage(xhr.responseText, 'Error', 'ErrorPopup');
            };

            // Display a modal dialog with the error message
            window.BlockWithMessage = function (messageText, heading, popupClass) {
                window.UnblockPage();
                if ($.blockUI) {
                    var $popup = $('<div class="' + (popupClass || 'MessagePopup') + '"><h1>' + (heading || 'Success') + ' </h1><p>' + messageText + '</p><button>OK</button></div>');
                    $popup.find('button').click(window.UnblockPage);
                    $.blockUI({ message: $popup, baseZ: 2000 });
                }
                else {
                    alert(heading + ': ' + messageText);
                }
            };

            window.onerror = function errorHandler(msg, url, line) {
                console.log(arguments);
                window.UnblockPage();
                window.BlockWithMessage(msg, 'Error', 'ErrorPopup');
                return true;
            }

            window.ajax_ProcessSuccess = (function ()
            {
                function getValidationSummary(form, createSummary) {
                    // Look for a Validation Summary control within the form. If one does not exist, create it.
                    var $summ = $(form).find('*[data-valmsg-summary="true"]');

                    if ($summ.length == 0 && createSummary)
                    {
                        // Could not find a Validation Summary, so append one to the form
                        $summ = $('<div class="validation-summary-valid" data-valmsg-summary="true"><ul></ul></div>');
                        $summ.appendTo(form);
                    }

                    return $summ;
                }

                function getValidationList(summary) {
                    // Look for a list within the Validation Summary. If one does not exist, create it.
                    var $list = $(summary).children('ul');

                    if ($list.length == 0) {
                        $list = $('<ul></ul>');
                        $list.appendTo(summary);
                    }

                    return $list;
                }

                function getResponseValidationErrors(data) {
                    // Does the response contain any model (validation) errors?
                    if (data && data.ModelErrors && data.ModelErrors.length > 0)
                        return data.ModelErrors;
                    return null;
                }

                function getResponseModel(data) {
                    // Does the response contain any model (validation) errors?
                    if (data && data.Model && $(data.Model).length > 0)
                        return data.Model;
                    return null;
                }

                function UpdateModel(data, form)
                {
                    var model = getResponseModel(data);
                    var viewModel = $(form).data("ViewModel");

                    // Check that we have a response model, a ViewModel and that Knockout is available
                    if (!model || !viewModel || typeof ko === "undefined")
                        return false;

                    // Update the viewModel from the response model. Knockout will update any form fields bound to viewModel.
                    ko.mapping.fromJS(model, viewModel);

                    // The page has been refreshed from the server, dismiss any warning about unsaved changes.
                    if (setConfirmUnload)
                        setConfirmUnload(false);

                    return true;
                }

                function CheckValidationErrorResponse(data, form, createSummary, summaryElement) {
                    var errors = getResponseValidationErrors(data);
                    var $summ = summaryElement || getValidationSummary(form, createSummary);
                    var $list = getValidationList($summ);

                    // Clear the error list within the Validation Summary
                    $list.html('');

                    // Mark form fields (and their validation messages) as valid to begin with
                    $(form).find(".input-validation-error")
                          .removeClass("input-validation-error");

                    $(form).find(".field-validation-error")
                           .removeClass("field-validation-error")
                           .addClass("field-validation-valid");

                    if (!errors)
                    {
                        // No validation errors were found in the response, mark the Validation Summary as valid and exit
                        if ($summ.length)
                            $summ.removeClass("validation-summary-errors").addClass("validation-summary-valid");

                        return false;
                    }

                    // For each validation error in the response...
                    $.each(errors, function (i, item) {
                        var $val, $input, errorList = "";
                        if (item.Name) {
                            // Mark the field's validation message as denoting an error
                            $val = $(form).find(".field-validation-valid, .field-validation-error")
                                          .filter("[data-valmsg-for=" + item.Name + "]")
                                          .removeClass("field-validation-valid")
                                          .addClass("field-validation-error");

                            $input = $(form).find("*[name='" + item.Name + "']");

                            // If no validation message exists for the field, and the field is not hidden, create a validation message
                            if (!$input.is(":hidden") && !$val.length)
                            {
                                $input.parent().append("<span class='field-validation-error' data-valmsg-for='" + item.Name + "' data-valmsg-replace='false'>*</span>");
                            }

                            // Mark the form field as invalid
                            $input.removeClass("valid").addClass("input-validation-error");
                        }

                        // Populate the error list within the Validation Summary
                        $.each(item.Errors, function (c, err) {
                            errorList += "<li>" + err + "</li>";
                        });

                        $list.append(errorList);
                    });

                    // Mark the Validation Summary as containing errors
                    if ($summ.length)
                        $summ.removeClass('validation-summary-valid').addClass('validation-summary-errors');

                    return true;
                }

                return function (data, status, xhr, formId, createValidationSummary, successMessageOrCallback) {
                    if (data) {
                        if (data.Redirect) {
                            location.href = data.Redirect;
                            return;
                        }

                        var form = $('#' + formId);
                        UpdateModel(data, form);
                        CheckValidationErrorResponse(data, form, createValidationSummary);
                    }

                    window.UnblockPage();
                    
                    if (!successMessageOrCallback)
                        return;

                    if (typeof successMessageOrCallback === 'function') {
                        successMessageOrCallback(data);
                    }
                    else {
                        window.BlockWithMessage(successMessageOrCallback);
                    }
                };
            })();
        }
    },

    Home: {
        init: function () {
            // controller-wide code
        },

        Index: function () {
            // action-specific code
        }
    },
    
    Events: {
        init: function () {
            // controller-wide code
        },

        Index: function () {
            // action-specific code
        }
    }

};

UTIL = {
    exec: function (controller, action) {
        var namespace = UIALLSCHEDULER;
        action = (action === undefined) ? "init" : action;

        if (controller !== "" && namespace[controller] && typeof namespace[controller][action] == "function") {
            namespace[controller][action]();
        }
    },

    init: function () {
        var body = document.body;
        var controller = body.getAttribute("data-controller");
        var action = body.getAttribute("data-action");

        UTIL.exec("common");
        UTIL.exec(controller);
        UTIL.exec(controller, action);
    }
};

$(document).ready(UTIL.init);
/* END: Garber-Irish */
