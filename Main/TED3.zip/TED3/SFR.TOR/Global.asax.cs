﻿using System;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using AutoMapper;
using Microsoft.Practices.Unity;
using SFR.TOR.Data;
using SFR.TOR.Data.Services;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;
using SFR.TOR.Web.Filters;
using SFR.TOR.Web.Json;
using SFR.TOR.Utility;
using SFR.TOR.Utility.Security;
using SFR.TOR.Web.Unity;
using SFR.TOR.Web.Extensions;

namespace SFR.TOR.Web
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class MvcApplication : System.Web.HttpApplication
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new TORAuthenticationAttribute());
            filters.Add(new TORHandleErrorAttribute());
            filters.Add(new PreserveModelStateOnRedirectAttribute());
        }

        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            routes.IgnoreRoute("favicon.ico");

            //routes.MapRoute(
            //    "Instructor", // Route name
            //    "Resources/Instructor/{action}/{id}", // URL with parameters
            //    new { controller = "Instructor", action = "Edit", id = UrlParameter.Optional } // Parameter defaults
            //);

            //routes.MapRoute(
            //    "Venue", // Route name
            //    "Resources/Venue/{action}/{id}", // URL with parameters
            //    new { controller = "Venue", action = "Edit", id = UrlParameter.Optional } // Parameter defaults
            //);

            //routes.MapRoute(
            //    "Equipment", // Route name
            //    "Resources/Equipment/{action}/{id}", // URL with parameters
            //    new { controller = "Equipment", action = "Edit", id = UrlParameter.Optional } // Parameter defaults
            //);

            routes.MapRoute(
                "Default", // Route name
                "{controller}/{action}/{id}", // URL with parameters
                new { controller = "Home", action = "Index", id = UrlParameter.Optional } // Parameter defaults
            );

            

        }

        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();

            RegisterGlobalFilters(GlobalFilters.Filters);
            RegisterRoutes(RouteTable.Routes);

            SetupJsonProvider();
            SetupAutomapper();
            DependencyResolver.SetResolver(this.GetDependencyResolver());

            //load EFProfiler in debug mode
            #if DEBUG
           // HibernatingRhinos.Profiler.Appender.EntityFramework.EntityFrameworkProfiler.Initialize(); 
            #endif    
        }

        protected void Application_EndRequest(object sender, EventArgs e)
        {
            /* The request has ended, so dispose of the context's dependency resolver. */
            ((HttpApplication)sender).Context.DisposeDependencyResolver();
        }

        // Use the JSON.NET library to deserialize incoming JSON data
        // https://gist.github.com/DalSoft/1588818
        private void SetupJsonProvider()
        {
            ValueProviderFactories.Factories.Remove(ValueProviderFactories.Factories.OfType<JsonValueProviderFactory>().FirstOrDefault());
            ValueProviderFactories.Factories.Add(new JsonDotNetValueProviderFactory());
        }

        private void SetupAutomapper()
        {
            Mapper.CreateMap<ActivityModel, ActivityEditModel>();
            Mapper.CreateMap<ActivityModel, ResourcesInstructorsModel>();
            Mapper.CreateMap<ActivityModel, ResourcesEquipmentModel>();

            Mapper.CreateMap<ActivityModel, ResourcesVenuesModel>();

            Mapper.CreateMap<ActivityModel, ActivitySummaryModel>();
                
            Mapper.CreateMap<Activity, ActivityModel>()
                .ForMember(dest => dest.Section, opt => opt.MapFrom(origin => origin.Section.Title))
                //.ForMember(dest => dest.Status, opt => opt.MapFrom(origin => origin.ActivityStatus.Title))
                ;

            Mapper.CreateMap<Activity, ActivityEditModel>();
            Mapper.CreateMap<ActivityEditModel, Activity>();
            Mapper.CreateMap<Activity, ResourcesInstructorsModel>();
            Mapper.CreateMap<InstructorActivityModel, EligibleInstructorsForActivity>()
                .ForMember(dest => dest.InstructorID, opt => opt.MapFrom(origin => origin.ID))
                .ForMember(x => x.ID, opt => opt.Ignore());

            Mapper.CreateMap<ActivityDayPartModel, ActivityPart>();

            Mapper.CreateMap<ActivityPart, DayVenuesModel>();

            Mapper.CreateMap<ActivityPartInstructorLevel, ActivityPartInstructorLevelModel>()
                .ForMember(dest => dest.Name, opt => opt.MapFrom(origin => origin.ActivityPart.Name));

            Mapper.CreateMap<ActivityPartInstructorLevelModel, ActivityPartInstructorLevel>()
                .ForMember(x => x.ID, opt => opt.Ignore());

            Mapper.CreateMap<Activity, ActivitySummaryModel>()
                .ForMember(dest => dest.Section, opt => opt.MapFrom(origin => origin.Section.Title));
                
            Mapper.CreateMap<CreateVenueCategoryModel, VenueTagActivityPart>()
                .ForMember(x => x.ID, opt => opt.Ignore());

            Mapper.CreateMap<CreateEquipmentCategoryModel, EquipmentTagActivityPart>()
                .ForMember(x => x.ID, opt => opt.Ignore());

            Mapper.CreateMap<EditVenueCategoryModel, VenueTagActivityPart>()
                .ForMember(x => x.ID, opt => opt.Ignore());


            Mapper.CreateMap<EditEquipmentCategoryModel, EquipmentTagActivityPart>()
                .ForMember(x => x.ID, opt => opt.Ignore());

            Mapper.CreateMap<ActivityPart, ActivityPartSummary>()
                .ForMember(dest => dest.EquipmentTags, opt => opt.MapFrom(origin => origin.EquipmentTagActivityParts))
                .ForMember(dest => dest.VenueTags, opt => opt.MapFrom(origin => origin.VenueTagActivityParts))
                .ForMember(dest => dest.PeopleLevels, opt => opt.MapFrom(origin => origin.ActivityPartInstructorLevels))                
                ;

            Mapper.CreateMap<EquipmentTagActivityPart, EquipmentDayPartModel>()
                .ForMember(dest => dest.Name, opt => opt.MapFrom(origin => origin.EquipmentTag.Name))
                .ForMember(dest => dest.MinRequired, opt => opt.MapFrom(origin => origin.MinRequired));

            Mapper.CreateMap<VenueTagActivityPart, VenueDayPartModel>()
                .ForMember(dest => dest.Name, opt => opt.MapFrom(origin => origin.VenueTag.Name))
                .ForMember(dest => dest.MinRequired, opt => opt.MapFrom(origin => origin.MinRequired));

            Mapper.CreateMap<ActivityPartInstructorLevel, ActivityPartInstructorLevelModel>()
                .ForMember(dest => dest.Name, opt => opt.MapFrom(origin => origin.ActivityPart.Name))
                .ForMember(dest => dest.InstructorCount, opt => opt.MapFrom(origin => origin.InstructorCount))
                .ForMember(dest => dest.ShadowCount, opt => opt.MapFrom(origin => origin.ShadowCount))
                .ForMember(dest => dest.AssessorCount, opt => opt.MapFrom(origin => origin.AssessorCount))
                .ForMember(dest => dest.LeadsCount, opt => opt.MapFrom(origin => origin.LeadsCount))
                .ForMember(dest => dest.SpecialistCount, opt => opt.MapFrom(origin => origin.SpecialistCount));

            Mapper.CreateMap<EventModel, EventEditModel>();

            Mapper.CreateMap<Event, EventModel>()
                .ForMember(dest => dest.Title, opt => opt.MapFrom(origin => origin.Activity.Title))
                .ForMember(dest => dest.Section, opt => opt.MapFrom(origin => origin.Activity.Section.Title))
                .ForMember(dest => dest.Priority, opt => opt.MapFrom(origin => origin.PriorityID))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(origin => origin.EventStatus.Title))
                .ForMember(dest => dest.StatusID, opt => opt.MapFrom(origin => origin.Status))
                .ForMember(dest => dest.SpecificDate, opt => opt.MapFrom(origin => origin.SpecificDate.HasValue ? origin.SpecificDate.Value.ToShortDateString() : ""))
                .ForMember(dest => dest.StartDate, opt => opt.MapFrom(origin => origin.DateRangeStart.HasValue ? origin.DateRangeStart.Value.ToShortDateString() : ""))
                .ForMember(dest => dest.EndDate, opt => opt.MapFrom(origin => origin.DateRangeEnd.HasValue ? origin.DateRangeEnd.Value.ToShortDateString() : ""))
                .ForMember(dest => dest.TrainingCentreId, opt => opt.MapFrom(origin => origin.TrainingCentreID))
                .ForMember(dest => dest.LastEditedOn, opt => opt.MapFrom(origin => origin.LastEditedOn.ToUniversalSpecifyKind()))
                ;
                //.ForMember(dest => dest.EventStatus, opt => opt.MapFrom(origin => origin.Status));

            Mapper.CreateMap<iTrentExport, iTrentExportModel>()
                .ForMember(dest => dest.iTrentExportDate, opt => opt.MapFrom(origin => origin.ExportDate.ToLocalSpecifyKind()))
                .ForMember(dest => dest.FinancialYear, opt => opt.MapFrom(origin => ExtensionMethods.FormatFinancialYear(origin.FinancialYear)))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(origin => origin.iTrentExportStatus.Title))
                .ForMember(dest => dest.StatusID, opt => opt.MapFrom(origin => origin.iTrentExportStatusID))
                .ForMember(dest => dest.Type, opt => opt.MapFrom(origin => origin.iTrentExportType.Title))
                .ForMember(dest => dest.TypeID, opt => opt.MapFrom(origin => origin.iTrentExportTypeID))
                .ForMember(dest => dest.FileDownloadURL, opt => opt.MapFrom(origin => MVCExtensions.GetiTrentFileDownloadURL(origin.ID)));

            Mapper.CreateMap<EventEditModel, Event>().ForAllMembers(opt => opt.Ignore());
            Mapper.CreateMap<EventEditModel, Event>()
                .ForMember(dest => dest.Notes, opt => opt.MapFrom(origin => origin.Notes))
                .ForMember(dest => dest.Description, opt => opt.MapFrom(origin => origin.Description))
                .ForMember(dest => dest.PriorityID, opt => opt.MapFrom(origin => origin.Priority))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(origin => origin.StatusID))
                .ForMember(dest => dest.LastEditedOn, opt => opt.MapFrom(origin => origin.LastEditedOn.ToUniversalSpecifyKind()))
                ;
            
            Mapper.CreateMap<EventModel, EventDaysModel>();

            Mapper.CreateMap<EventModel, Event>();

            Mapper.CreateMap<EventPart, EventDayModel>()
                .ForMember(dest => dest.Date, opt => opt.MapFrom(origin => origin.Date.HasValue ? origin.Date.Value.ToShortDateString() : ""))
                .ForMember(dest => dest.ResourceStatus, opt => opt.MapFrom(origin => origin.ResourceStatu.Title))
                .ForMember(dest => dest.DayTypeID, opt => opt.MapFrom(origin => origin.DayType))                
                ;

            Mapper.CreateMap<EventDayModel, EventPart>()
                .ForAllMembers(opt => opt.Ignore());
            Mapper.CreateMap<EventDayModel, EventPart>()
                //.ForMember(dest => dest.Date, opt => opt.MapFrom(origin => origin.Date == "" ? null : origin.Date))
                .ForMember(dest => dest.Date, opt => opt.MapFrom(origin => origin.Date))
                .ForMember(dest => dest.Notes, opt => opt.MapFrom(origin => origin.Notes))
                .ForMember(dest => dest.StartTime, opt => opt.MapFrom(origin => origin.StartTime))
                .ForMember(dest => dest.EndTime, opt => opt.MapFrom(origin => origin.EndTime))
                .ForMember(dest => dest.DayType, opt => opt.MapFrom(origin => origin.DayTypeID))
                ;

            Mapper.CreateMap<EventModel, EventSummaryModel>();
            Mapper.CreateMap<EventModel, EventInstructorsModel>();

            Mapper.CreateMap<InstructorEventModel, InstructorEventPart>()
                .ForMember(dest => dest.InstructorID, opt => opt.MapFrom(origin => origin.ID))
                .ForMember(dest => dest.IsAssessor, opt => opt.MapFrom(origin => origin.SelectedAssessor))
                .ForMember(dest => dest.IsInstructor, opt => opt.MapFrom(origin => origin.SelectedInstructor))
                .ForMember(dest => dest.IsLead, opt => opt.MapFrom(origin => origin.SelectedLead))
                .ForMember(dest => dest.IsShadow, opt => opt.MapFrom(origin => origin.SelectedShadow))
                .ForMember(dest => dest.IsSpecialist, opt => opt.MapFrom(origin => origin.SelectedSpecialist))
                .ForMember(dest => dest.ID, opt => opt.Ignore());


            Mapper.CreateMap<InstructorNumbersModel, EventInstructorsModel>();

            Mapper.CreateMap<EventModel, EventVenuesModel>();

            Mapper.CreateMap<VenueEventModel, VenueEventPart>()
                .ForMember(dest => dest.VenueID, opt => opt.MapFrom(origin => origin.ID))
                .ForMember(dest => dest.ID, opt => opt.Ignore())
                .ForMember(dest => dest.VenueTag, opt => opt.Ignore())
                //.ForMember(dest => dest.VenueTagID, opt => opt.MapFrom(origin => origin.VenueTag))
                ;

            Mapper.CreateMap<EquipmentEventModel, EquipmentEventPart>()
                .ForMember(dest => dest.EquipmentID, opt => opt.MapFrom(origin => origin.ID))
                .ForMember(dest => dest.ID, opt => opt.Ignore())
                .ForMember(dest => dest.EquipmentTag, opt => opt.Ignore())
                //.ForMember(dest => dest.EquipmentTagID, opt => opt.MapFrom(origin => origin.EquipmentTag))
                ;

            Mapper.CreateMap<EventModel, EventEquipmentModel>();

            Mapper.CreateMap<Instructor, InstructorEditModel>()
                .ForMember(dest => dest.SectionID, opt => opt.MapFrom(origin => origin.SectionID ?? Constants.INSTRUCTOR_INACTIVE_SECTION_ID));

            Mapper.CreateMap<InstructorEditModel, Instructor>()
                .ForMember(dest => dest.SectionID, opt => opt.MapFrom(origin => origin.SectionID == Constants.INSTRUCTOR_INACTIVE_SECTION_ID ? null : (int?)origin.SectionID));

            Mapper.CreateMap<InstructorEligibilityModel, EligibleInstructorsForActivity>()
                .ForMember(dest => dest.ActivityTemplateID, opt => opt.MapFrom(origin => origin.ID))
                .ForMember(dest => dest.ID, opt => opt.Ignore())
                ;

            Mapper.CreateMap<InstructorEditAvailabilityModel, InstructorUnavailablePeriod>()
                .ForMember(dest => dest.UnavailableReason, opt => opt.Ignore())
                ;


            Mapper.CreateMap<VenuesEditModel, Venue>();

            Mapper.CreateMap<VenuesCreateModel, Venue>();
            

            Mapper.CreateMap<TORUser, SFR.TOR.Data.User>();
            Mapper.CreateMap<SFR.TOR.Data.User, TORUser>();

            Mapper.CreateMap<SFR.TOR.Data.User, UserPreferencesEditModel>();
            Mapper.CreateMap<UserPreferencesEditModel, SFR.TOR.Data.User>();
            
            Mapper.CreateMap<Venue, VenuesEditModel>();

            Mapper.CreateMap<VenueModel, VenuesEditModel>();
            
            Mapper.CreateMap<VenueEditAvailabilityModel, VenueUnavailablePeriod>();
            
            Mapper.CreateMap<EquipmentEditModel, SFR.TOR.Data.Equipment>();
            Mapper.CreateMap<SFR.TOR.Data.Equipment, EquipmentEditModel>();

            Mapper.CreateMap<EquipmentModel, EquipmentEditModel>();
            
            Mapper.CreateMap<EquipmentEditAvailabilityModel, EquipmentUnavailablePeriod>();

            Mapper.CreateMap<EquipmentTagEquipmentModel, EquipmentTagEquipment>();

            Mapper.CreateMap<VenueTagVenueModel, VenueTagVenue>();

            Mapper.CreateMap<PinchpointModel, Pinchpoint>(); 

            Mapper.CreateMap<PinchPointReasonModel, PinchpointReason>();

            Mapper.CreateMap<GroupCalendarItemModel, GroupCalendar>()
                .ForMember(dest => dest.GroupDate, opt => opt.Ignore());

            Mapper.CreateMap<EventModel, EventAuditModel>();

            Mapper.CreateMap<VenueCategoryModel, VenueTag>();

            Mapper.CreateMap<EquipmentCategoryModel, EquipmentTag>();

            Mapper.CreateMap<InstructorUnavailableReasonModel, UnavailableReason>()
                .ForMember(dest => dest.ID, opt => opt.Ignore())
                ;

            Mapper.CreateMap<VenueUnavailableReasonModel, VenuesUnavailableReason>()
                .ForMember(dest => dest.ID, opt => opt.Ignore())
                ;

            Mapper.CreateMap<EquipmentUnavailableReasonModel, EquipmentUnavailableReason>()
                .ForMember(dest => dest.ID, opt => opt.Ignore())
                ;  
            
        }
    }
}