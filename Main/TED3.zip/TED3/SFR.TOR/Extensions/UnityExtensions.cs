﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SFR.TOR.Web.Unity;
using Microsoft.Practices.Unity;
using System.Reflection;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.Data.Services;
using SFR.TOR.Utility.Security;

namespace SFR.TOR.Web.Extensions
{
    public static class UnityExtensions
    {
        private const string containerKey = "UnityContainer";

        public static IDependencyResolver GetDependencyResolver(this HttpApplication app)
        {
            var container = app.GetUnityContainer();
            return new UnityDependencyResolver(container);
        }

        private static IUnityContainer GetUnityContainer(this HttpApplication app, bool createIfNotExists = true)
        {
            var container = app.Application[containerKey] as IUnityContainer;

            if (container == null && createIfNotExists)
            {
                container = CreateParentUnityContainer();
                app.SetUnityContainer(container);
            }

            return container;
        }

        private static IUnityContainer CreateParentUnityContainer()
        {
            var container = new UnityContainer();

            // Define an inline function to make the rest of this function neater
            Func<LifetimeManager> LM = () => { return new HierarchicalLifetimeManager(); };

            container.RegisterType<ITORUnitOfWork, TORUnitOfWork>(LM())
                     .RegisterType<ITORSession, TORSession>(LM());

            container.RegisterControllers();

            return container;
        }

        /// <summary>
        /// Registers all controllers in the calling assembly. See Unity.MVC3 NuGet package for details.
        /// </summary>
        /// <param name="container"></param>
        public static void RegisterControllers(this IUnityContainer container)
        {
            var controllerTypes = (from t in Assembly.GetCallingAssembly().GetTypes()
                                   where typeof(IController).IsAssignableFrom(t) && !t.IsAbstract
                                   select t).ToList();

            controllerTypes.ForEach(t => container.RegisterType(t));
        }

        private static void SetUnityContainer(this HttpApplication app, IUnityContainer container)
        {
            app.Application[containerKey] = container;
        }

        public static IUnityContainer GetUnityContainer(this HttpContext context, bool createIfNotExists = true)
        {
            var childContainer = context.Items[containerKey] as IUnityContainer;

            if (childContainer == null && createIfNotExists)
            {
                var parent = context.ApplicationInstance.GetUnityContainer();

                if (parent == null)
                    throw new InvalidOperationException("Could not retrieve a parent UnityContainer");

                childContainer = CreateChildUnityContainer(parent);
                context.SetUnityContainer(childContainer);
            }

            return childContainer;
        }

        public static IUnityContainer GetChildContainer(this UnityDependencyResolver resolver)
        {
            return HttpContext.Current.GetUnityContainer();
        }

        private static IUnityContainer CreateChildUnityContainer(IUnityContainer parent)
        {
            // Create a Unity child container
            var child = parent.CreateChildContainer();

            child.RegisterInstance<HttpContextBase>(new HttpContextWrapper(HttpContext.Current));

            return child;
        }

        private static void SetUnityContainer(this HttpContext context, IUnityContainer container)
        {
            context.Items[containerKey] = container;
        }

        public static void DisposeDependencyResolver(this HttpApplication app)
        {
            var container = app.GetUnityContainer(createIfNotExists: false);

            if (container != null)
                container.Dispose();
        }

        public static void DisposeDependencyResolver(this HttpContext context)
        {
            /* The request has ended, so get the child container and dispose it. */
            var childContainer = context.GetUnityContainer(createIfNotExists: false);

            if (childContainer != null)
                childContainer.Dispose();
        }
    }
}