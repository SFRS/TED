﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using SFR.TOR.ViewModels;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.Utility;
using SFR.TOR.Utility.Security;
using System.Text.RegularExpressions;
using SFR.TOR.Web.Filters;
using System.Linq.Expressions;
using LinqKit;
using SFR.TOR.Data;

namespace SFR.TOR.Web
{
    [TORUserAuthorisation]
    public partial class ReportViewer : Page
    {
        // For query string parameters that may contain multiple int values,
        // use this function to parse them into a typed list of distinct values
        private IEnumerable<int> ParseQueryStringIntegers(string fieldName)
        {
            return Request.QueryString[fieldName]
                .Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Where(id => { int temp; return Int32.TryParse(id, out temp); })
                .Select(id => Int32.Parse(id)).Distinct().ToList();
        }

        #region Parameters

        protected string ReportName
        {
            get { return Request.QueryString[Constants.QUERY_STRING_REPORT_NAME]; }
        }

        protected string FromDate
        {
            get { return Request.QueryString[Constants.QUERY_STRING_REPORT_FROM_DATE]; }
        }

        protected string ToDate
        {
            get { return Request.QueryString[Constants.QUERY_STRING_REPORT_TO_DATE]; }
        }

        protected IEnumerable<int> _eventStatuses;

        protected IEnumerable<int> EventStatuses
        {
            get
            {
                if (_eventStatuses == null)
                    _eventStatuses = ParseQueryStringIntegers(Constants.QUERY_STRING_REPORT_SELECTED_EVENT_STATUSES);

                return _eventStatuses;
            }
        }

        protected IEnumerable<int> _eventResourceStatuses;

        protected IEnumerable<int> EventResourceStatuses
        {
            get
            {
                if (_eventResourceStatuses == null)
                    _eventResourceStatuses = ParseQueryStringIntegers(Constants.QUERY_STRING_REPORT_SELECTED_EVENT_RESOURCE_STATUSES);

                return _eventResourceStatuses;
            }
        }

        protected string SelectedInstructors
        {
            get { return Request.QueryString[Constants.QUERY_STRING_REPORT_SELECTED_INSTRUCTORS]; }
        }

        protected string SelectedSection
        {
            get { return Request.QueryString[Constants.QUERY_STRING_REPORT_SELECTED_SECTION]; }
        }

        protected ReportDaysCounted ReportDaysToCount
        {
            get
            {
                int daysID = 1;
                int.TryParse(Request.QueryString[Constants.QUERY_STRING_REPORT_DAYS_TO_COUNT], out daysID);
                ReportDaysCounted rdc = (ReportDaysCounted)daysID;
                return rdc;
            }
        }

        protected int CurrentTrainingCentreID
        {
            get 
            { 
                int id = 1; //default training centre id
                int.TryParse(Request.QueryString[Constants.QUERY_STRING_REPORT_TRAINING_CENTRE_ID], out id);
                return id;
            }
        }

        protected IEnumerable<int> _selectedSections;

        protected IEnumerable<int> SelectedSections
        {
            get 
            {
                if (_selectedSections == null)
                    _selectedSections = ParseQueryStringIntegers(Constants.QUERY_STRING_REPORT_SELECTED_SECTIONS);

                return _selectedSections;
            }
        }

        protected ReportInstructorAvailabilityGroups SelectedAvailabilityGroup
        {
            get
            {
                int group = 1;
                int.TryParse(Request.QueryString[Constants.QUERY_STRING_REPORT_SELECTED_AVAILABILITY_REASON], out group);
                ReportInstructorAvailabilityGroups riag = (ReportInstructorAvailabilityGroups)group;
                return riag;
            }
        }
        
        protected TimePeriods SelectedTimePeriod
        {
            get
            {
                int timePeriod = 1;
                int.TryParse(Request.QueryString[Constants.QUERY_STRING_REPORT_SELECTED_TIME_PERIOD], out timePeriod);
                TimePeriods tp = (TimePeriods)timePeriod;
                return tp;
            }
        }

        #endregion

        protected void InitialiseReportViewer()
        {
            System.Security.PermissionSet permissions = new System.Security.PermissionSet(System.Security.Permissions.PermissionState.None);
            permissions.AddPermission(new System.Security.Permissions.SecurityPermission(System.Security.Permissions.PermissionState.Unrestricted));
            permissions.AddPermission(new System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityPermissionFlag.AllFlags));
            ReportViewer1.ProcessingMode = ProcessingMode.Local;
            ReportViewer1.LocalReport.SetBasePermissionsForSandboxAppDomain(permissions);
            ReportViewer1.ShowRefreshButton = false;
            ReportViewer1.LocalReport.ReportPath = Server.MapPath(
                String.Format("{0}/{1}.{2}",
                              Constants.REPORT_FILE_PATH,
                              ReportName,
                              Constants.REPORT_FILENAME_EXTENSION));
        }

        protected void Page_Error(object sender, EventArgs e)
        {
            Exception ex = Server.GetLastError();            
            Response.Write(String.Format("The following error has occurred while generating the report. Please contact the IT ServiceDesk if this persists.<br><br>{0}", ex.GetFullMessage()));
            Server.ClearError();
        }
        
        protected void Page_Load(object sender, EventArgs e)
        {
            var unitOfWork = System.Web.Mvc.DependencyResolver.Current.GetService(typeof(ITORUnitOfWork)) as ITORUnitOfWork;

            if (unitOfWork == null)
                throw new NullReferenceException("Could not load the unit of work to prepare the report");

            var session = unitOfWork.Session;
            TORUser user = session.User;

            if (user == null || user.TORRole < TORRole.User)
            {
                this.unauthorisedPanel.Visible = true;
                return;
            }

            if (IsPostBack)
                return;

            InitialiseReportViewer();

            DateTime parsedFromDate, parsedToDate;
            try
            {
                parsedFromDate = DateTime.Parse(FromDate);
                parsedToDate = DateTime.Parse(ToDate);
            }
            catch (Exception ex) {
                errorPanel.Visible = true;
                ReportViewer1.Visible = !errorPanel.Visible;
                return;
            }

            DateTime minimumDate = new DateTime(2000, 01, 01);

            if ((parsedFromDate < minimumDate) ||
                (parsedToDate < minimumDate) ||
                (parsedFromDate > parsedToDate))
            {
                errorPanel.Visible = true;
                ReportViewer1.Visible = !errorPanel.Visible;
                return;
            }

            List<IEnumerable> reportData = GetReportData(unitOfWork, ReportName, parsedFromDate, parsedToDate);

            if (reportData == null)
            {
                errorPanel.Visible = true; //something went wrong fetching the data
                return;
            }
            int index = 1;
            foreach (IEnumerable dataset in reportData)
            {
                ReportViewer1.LocalReport.DataSources.Add(new ReportDataSource(Constants.REPORT_DATASET_NAME + index, dataset));
                index++;
            }

            List<ReportParameter> parameters = new List<ReportParameter>();

            parameters.Add(new ReportParameter(Constants.REPORT_PARAM_FROM_DATE, FromDate));
            parameters.Add(new ReportParameter(Constants.REPORT_PARAM_TO_DATE, ToDate));
                        
            //Any additional parameters which are not common to all reports can be added here

            var trainingCentre = unitOfWork.TrainingCentres.SelectBy(tc => tc.ID == CurrentTrainingCentreID);
            
            switch (ReportName)
            {
                case Constants.REPORT_NAME_RESOURCE_UTILISATION:
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_TOTAL_DAYS, GetTotalDaysBetweenDates(parsedFromDate, parsedToDate, (int)SFR.TOR.Utility.EventPartTypeEnum.FullDay, parsedFromDate, parsedToDate, ReportDaysToCount).ToString()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_SELECTED_AVAILABILITY_TYPE, SelectedAvailabilityGroup.GetDescription()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_TRAINING_CENTRE_NAME, trainingCentre.Name));
                    parameters.Add(new ReportParameter(Constants.QUERY_STRING_REPORT_DAYS_TO_COUNT, ReportDaysToCount.GetDescription()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_TRAINING_CENTRE_ID, trainingCentre.ID.ToString()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_SELECTED_AVAILABILITY_ID, ((int)SelectedAvailabilityGroup).ToString()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_COUNT_WEEKDAYS, (ReportDaysToCount != ReportDaysCounted.Weekends).ToString()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_COUNT_WEEKENDS, (ReportDaysToCount != ReportDaysCounted.Weekdays).ToString()));
                    break;
                case Constants.REPORT_NAME_INSTRUCTOR_ASSIGNMENTS:
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_INSTRUCTOR_ID, SelectedInstructors));
                    parameters.Add(new ReportParameter(Constants.QUERY_STRING_REPORT_DAYS_TO_COUNT, ReportDaysToCount.GetDescription()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_COUNT_WEEKDAYS, (ReportDaysToCount != ReportDaysCounted.Weekends).ToString()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_COUNT_WEEKENDS, (ReportDaysToCount != ReportDaysCounted.Weekdays).ToString()));
                    break;
                case Constants.REPORT_NAME_TOR_SECTION:
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_SECTION_NAME, GetSectionNamesBySectionIDs(unitOfWork, SelectedSections)));
                    parameters.Add(new ReportParameter(Constants.QUERY_STRING_REPORT_DAYS_TO_COUNT, ReportDaysToCount.GetDescription()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_SECTION_IDS, String.Join(",", SelectedSections)));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_TRAINING_CENTRE_ID, trainingCentre.ID.ToString()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_COUNT_WEEKDAYS, (ReportDaysToCount != ReportDaysCounted.Weekends).ToString()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_COUNT_WEEKENDS, (ReportDaysToCount != ReportDaysCounted.Weekdays).ToString()));
                    break;
                case Constants.REPORT_NAME_EVENTS:
                    parameters.Add(new ReportParameter(Constants.QUERY_STRING_REPORT_DAYS_TO_COUNT, ReportDaysToCount.GetDescription()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_TRAINING_CENTRE_ID, trainingCentre.ID.ToString()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_EVENT_STATUS_IDS, String.Join(",", EventStatuses)));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_RESOURCE_STATUS_IDS, String.Join(",", EventResourceStatuses)));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_SECTION_IDS, String.Join(",", SelectedSections)));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_COUNT_WEEKDAYS, (ReportDaysToCount != ReportDaysCounted.Weekends).ToString()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_COUNT_WEEKENDS, (ReportDaysToCount != ReportDaysCounted.Weekdays).ToString()));
                    break;
                case Constants.REPORT_NAME_TOR_SECTION_SIGN_OFF:
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_SECTION_NAME, GetSectionNamesBySectionIDs(unitOfWork, SelectedSections)));
                    parameters.Add(new ReportParameter(Constants.QUERY_STRING_REPORT_DAYS_TO_COUNT, ReportDaysToCount.GetDescription()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_SECTION_IDS, String.Join(",", SelectedSections)));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_TRAINING_CENTRE_ID, trainingCentre.ID.ToString()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_COUNT_WEEKDAYS, (ReportDaysToCount != ReportDaysCounted.Weekends).ToString()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_COUNT_WEEKENDS, (ReportDaysToCount != ReportDaysCounted.Weekdays).ToString()));
                    break;
                case Constants.REPORT_NAME_INSTRUCTOR_UTILISATION:
                    parameters.Add(new ReportParameter(Constants.QUERY_STRING_REPORT_DAYS_TO_COUNT, ReportDaysToCount.GetDescription()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_SELECTED_AVAILABILITY_TYPE, SelectedAvailabilityGroup.GetDescription()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_TRAINING_CENTRE_ID, trainingCentre.ID.ToString()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_SELECTED_AVAILABILITY_ID, ((int)SelectedAvailabilityGroup).ToString()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_SELECTED_TIME_PERIOD, ((int)SelectedTimePeriod).ToString()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_COUNT_WEEKDAYS, (ReportDaysToCount != ReportDaysCounted.Weekends).ToString()));
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_COUNT_WEEKENDS, (ReportDaysToCount != ReportDaysCounted.Weekdays).ToString()));
                    switch (SelectedTimePeriod)
                    {
                        case TimePeriods.YEAR:
                            parameters.Add(new ReportParameter(Constants.REPORT_PARAM_NAME_DATE_FORMAT, Constants.REPORT_PARAM_VALUE_DATE_FORMAT_YEAR));
                            parameters.Add(new ReportParameter(Constants.REPORT_PARAM_NAME_WEELY_OR_MONTHLY, Constants.REPORT_PARAM_VALUE_MONTHLY_PERIOD));
                            break;
                        default:
                            parameters.Add(new ReportParameter(Constants.REPORT_PARAM_NAME_DATE_FORMAT, Constants.REPORT_PARAM_VALUE_DATE_FORMAT_MONTH));
                            parameters.Add(new ReportParameter(Constants.REPORT_PARAM_NAME_WEELY_OR_MONTHLY, Constants.REPORT_PARAM_VALUE_WEEKLY_PERIOD));
                            break;
                    }
                    break;
                case Constants.REPORT_NAME_EVENTS_BY_VENUE_GROUP:
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_TRAINING_CENTRE_ID, trainingCentre.ID.ToString()));
                    break;
                case Constants.REPORT_NAME_VENUE_CATEGORIES:
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_TRAINING_CENTRE_ID, trainingCentre.ID.ToString()));
                    break;
                case Constants.REPORT_NAME_CATERING:
                    parameters.Add(new ReportParameter(Constants.REPORT_PARAM_TRAINING_CENTRE_ID, trainingCentre.ID.ToString()));
                    break;
            }

            if (parameters.Count > 0)
                ReportViewer1.LocalReport.SetParameters(parameters);
        }

        #region Data

        protected List<IEnumerable> GetReportData(ITORUnitOfWork unitOfWork, string reportName, DateTime fromDate, DateTime toDate)
        {
            switch (reportName) {
                case Constants.REPORT_NAME_EVENTS:
                    return GetEventsData(unitOfWork, fromDate, toDate, CurrentTrainingCentreID, EventStatuses, EventResourceStatuses, SelectedSections, ReportDaysToCount);
                case Constants.REPORT_NAME_CATERING:
                    return GetCateringData(unitOfWork, fromDate, toDate, CurrentTrainingCentreID);
                case Constants.REPORT_NAME_RESOURCE_UTILISATION:
                    return GetResourceUtilisationData(unitOfWork, fromDate, toDate, CurrentTrainingCentreID, SelectedAvailabilityGroup, ReportDaysToCount);
                case Constants.REPORT_NAME_INSTRUCTOR_UTILISATION:
                    return GetInstructorUtilisationData(unitOfWork, fromDate, CurrentTrainingCentreID, SelectedAvailabilityGroup, SelectedTimePeriod, ReportDaysToCount);
                case Constants.REPORT_NAME_VENUE_CATEGORIES:
                    return GetVenueCategoriesData(unitOfWork, CurrentTrainingCentreID);
                case Constants.REPORT_NAME_INSTRUCTOR_ASSIGNMENTS:
                    return GetInstructorAssignmentsData(unitOfWork, fromDate, toDate, SelectedInstructors, ReportDaysToCount);
                case Constants.REPORT_NAME_TOR_SECTION:
                    return GetTORSectionData(unitOfWork, fromDate, toDate, CurrentTrainingCentreID, SelectedSections, ReportDaysToCount);
                case Constants.REPORT_NAME_TOR_SECTION_SIGN_OFF:
					return GetTORSectionSignOffData(unitOfWork, fromDate, toDate, CurrentTrainingCentreID, SelectedSections, ReportDaysToCount);
                case Constants.REPORT_NAME_EVENTS_BY_VENUE_GROUP:
                    return GetEventsByVenueGroup(unitOfWork, fromDate, toDate, CurrentTrainingCentreID);
                default:
                    return null;
            }
        }

        private List<IEnumerable> GetEventsByVenueGroup(ITORUnitOfWork unitOfWork, DateTime fromDate, DateTime toDate, int trainingCentreID)
        {
            var reportDataModel = unitOfWork.Reports.GetReportEventsByVenueGroup(fromDate, toDate, trainingCentreID);

            return reportDataModel.GetReportData();
        }

        private List<IEnumerable> GetTORSectionSignOffData(ITORUnitOfWork unitOfWork, DateTime fromDate, DateTime toDate, int trainingCentreID, IEnumerable<int> sectionIDList, ReportDaysCounted daysToCount)
        {
            var reportDataModel = unitOfWork.Reports.GetReportSectionSignOff(fromDate, toDate, trainingCentreID, sectionIDList, daysToCount);

            return reportDataModel.GetReportData();
        }

        private List<IEnumerable> GetTORSectionData(ITORUnitOfWork unitOfWork, DateTime fromDate, DateTime toDate, int trainingCentreID, IEnumerable<int> sectionIDList, ReportDaysCounted daysToCount)
        {
            var reportDataModel = unitOfWork.Reports.GetReportSectionEvents(fromDate, toDate, trainingCentreID, sectionIDList, daysToCount);

            return reportDataModel.GetReportData();
        }
       
        protected List<IEnumerable> GetInstructorAssignmentsData(ITORUnitOfWork unitOfWork, DateTime fromDate, DateTime toDate, string SelectedInstructors, ReportDaysCounted daysToCount)
        {
            int instructorID = 0;
            bool ok = Int32.TryParse(SelectedInstructors, out instructorID);

            if (!ok)
                return null;

            var reportDataModel = unitOfWork.Reports.GetReportInstructorAssignments(fromDate, toDate, instructorID, daysToCount);

            return reportDataModel.GetReportData();
        }

        protected List<IEnumerable> GetVenueCategoriesData(ITORUnitOfWork unitOfWork, int trainingCentreID)
        {
            var reportDataModel = unitOfWork.Reports.GetReportVenueCategories(trainingCentreID);

            return reportDataModel.GetReportData();
        }

        protected List<IEnumerable> GetResourceUtilisationData(ITORUnitOfWork unitOfWork, DateTime fromDate, DateTime toDate, int trainingCentreID, ReportInstructorAvailabilityGroups availabilityGroup, ReportDaysCounted ReportDaysToCount)
        {
            var reportDataModel = unitOfWork.Reports.GetReportResourceUtilisation(fromDate, toDate, trainingCentreID, availabilityGroup, ReportDaysToCount);

            return reportDataModel.GetReportData();
        }

        protected List<IEnumerable> GetInstructorUtilisationData(ITORUnitOfWork unitOfWork, DateTime fromDate, int trainingCentreID, ReportInstructorAvailabilityGroups availabilityGroup, TimePeriods timePeriod, ReportDaysCounted ReportDaysToCount)
        {
            var reportDataModel = unitOfWork.Reports.GetReportInstructorUtilisation(fromDate, trainingCentreID, availabilityGroup, timePeriod, ReportDaysToCount);

            return reportDataModel.GetReportData();
        }

        protected List<IEnumerable> GetEventsData(ITORUnitOfWork unitOfWork, DateTime fromDate, DateTime toDate, int trainingCentreID, IEnumerable<int> eventStatusIDList, IEnumerable<int> eventResourceStatusIDList, IEnumerable<int> sectionIDList, ReportDaysCounted daysToCount)
        {
            var reportDataModel = unitOfWork.Reports.GetReportEventsByStatus(fromDate, toDate, trainingCentreID, eventStatusIDList, eventResourceStatusIDList, sectionIDList, daysToCount);

            return reportDataModel.GetReportData();
        }

        protected List<IEnumerable> GetCateringData(ITORUnitOfWork unitOfWork, DateTime fromDate, DateTime toDate, int trainingCentreID)
        {
            var reportDataModel = unitOfWork.Reports.GetReportCatering(fromDate, toDate, trainingCentreID);

            return reportDataModel.GetReportData();
        }
      
        #endregion

        #region Helper Methods

        /// <summary>
        /// Returns a list of selected section titles in a single string; separated by ", ".
        /// </summary>
        /// <param name="unitOfWork"></param>
        /// <param name="selectedSections">string array of section IDs</param>
        /// <returns></returns>
        private string GetSectionNamesBySectionIDs(ITORUnitOfWork unitOfWork, IEnumerable<int> selectedSections)
        {
            var sectionNameList = 
                unitOfWork.Sections.SelectFilteredList(s => selectedSections.Contains(s.ID)).Select(s => s.Title).ToList();

            return String.Join(", ", sectionNameList);
        }

        /// <summary>
        /// Returns a double value with total number of days between 2 dates, inclusive
        /// </summary>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        private double GetTotalDaysBetweenDates(DateTime fromDate, DateTime? toDate, int dayPartType = (int)EventPartTypeEnum.FullDay, DateTime? countFrom = null, DateTime? countTo = null, ReportDaysCounted daysToCount = ReportDaysCounted.Weekdays)
        {
            double result;

            // strip the time portion from the date
            fromDate = fromDate.Date;

            // if no toDate supplied, use today's date. Strip the time portion.
            if (toDate.HasValue)
                toDate = toDate.Value.Date;
            else
                toDate = DateTime.Now.Date;

            if (countFrom.HasValue && countFrom > fromDate)
                fromDate = countFrom.Value;

            if (countTo.HasValue && countTo < toDate)
                toDate = countTo.Value;

            // We're comparing dates with no time portions so TotalDays should have no decimal portion
            int totalDays = (int)(toDate.Value - fromDate).TotalDays + 1;

            double workDays =
                1 + ((toDate.Value - fromDate).TotalDays * 5 -
                (fromDate.DayOfWeek - toDate.Value.DayOfWeek) * 2) / 7;

            if ((int)toDate.Value.DayOfWeek == 6) workDays--;
            if ((int)fromDate.DayOfWeek == 0) workDays--;

            if (daysToCount == ReportDaysCounted.Weekdays)
                result = workDays;
            else if (daysToCount == ReportDaysCounted.Weekends)
                result = totalDays - workDays;
            else
                result = totalDays;

            // If the result is 1 and the caller has indicated that this isn't a full day, return 0.5
            if (result == 1 && dayPartType != (int)SFR.TOR.Utility.EventPartTypeEnum.FullDay)
                result = 0.5;

            return result;
        }

        #endregion

    }
}