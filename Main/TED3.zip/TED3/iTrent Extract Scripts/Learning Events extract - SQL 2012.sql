/* Script to extract event data between supplied dates for iTrent upload. 
   The code does not use the actual start and end times stored against the events, instead it assumes
   that morning events run from 0900 to 1300 and afternoon events from 1301 to 1700.
   This script is only compatible with SQL Server 2012, therefore it is necessary to take a backup
   of the production database from SQL Server 2008, restore it on a local SQL 2012 instance and
   run this script against the SQL 2012 instance. */

USE TOR

set nocount on

DECLARE @Start DATE
DECLARE @End DATE
DECLARE @Root DATE

SET @Start = '01 Apr 2013'
SET @End = '31 Mar 2014'
SET @Root = '01 Jan 2010'

DECLARE @Results TABLE (
	ACTIVITY_CODE VARCHAR(20),
	ACTIVITY NVARCHAR(100),
	EVENT_CODE VARCHAR(30),
	[START_DATE] VARCHAR(8),
	START_TIME VARCHAR(4),
	END_DATE VARCHAR(8),
	END_TIME VARCHAR(4),
	VENUE_NAME NVARCHAR(100),
	VENUE_START_DATE VARCHAR(8),
	VENUE_START_TIME VARCHAR(4),
	VENUE_END_DATE VARCHAR(8),
	VENUE_END_TIME VARCHAR(4),
	PR_PER_REF_NO VARCHAR(10),
	EXTERNAL_PR_FORENAME1 NVARCHAR(50),
	EXTERNAL_PR_SURNAME NVARCHAR(50),
	PR_START_DATE VARCHAR(8),
	PR_START_TIME VARCHAR(4),
	PR_END_DATE VARCHAR(8),
	PR_END_TIME VARCHAR(4)
)

-- LEARNING EVENTS
;with Parts as (
	select distinct p.EventID
	-- get the earliest and latest EventPartIDs for each event
	, first_value(p.ID) over (
		partition by p.EventID 
		-- for all rows with the same EventID as the current row, order them by the number of half days since @root
		order by datediff(d, @root, p.[Date]) * 2 + case p.DayType when 1 then 0 when 2 then 1 else 2 end 
		rows between unbounded preceding and unbounded following
	) as FirstPartID
	, last_value(p.ID) over (
		partition by p.EventID 
		order by datediff(d, @root, p.[Date]) * 2 + case p.DayType when 1 then 0 when 2 then 1 else 2 end 
		rows between unbounded preceding and unbounded following
	) as LastPartID
	from EventPart p
	where p.[Date] between @Start and @End
)
insert @Results (ACTIVITY_CODE, ACTIVITY, EVENT_CODE, [START_DATE], START_TIME, END_DATE, END_TIME)
select
	a.Code as ACTIVITY_CODE, 
	a.Title as ACTIVITY, 
	a.Code + ' ' + cast(e.EventNumber as varchar) + '/' + right(cast(e.FinanciaYear as varchar),2) as EVENT_CODE,
	convert(varchar, ep1.[Date], 112) as [START_DATE],
	case when ep1.DayType = 2 then '1301' else '0900' end as START_TIME,
	convert(varchar, ep2.[Date], 112) as END_DATE,
	case when ep2.DayType = 1 then '1300' else '1700' end as END_TIME
from Parts p
inner join EventPart ep1 on p.FirstPartID = ep1.ID
inner join EventPart ep2 on p.LastPartID = ep2.ID
inner join [Event] e on p.EventID = e.ID
inner join Activity a on e.ActivityID = a.ID
where e.[Status] = 2 -- Ready 

-- LEARNING EVENTS (VENUES)
;with q1 as (
	select vep.ID as VenueEventPartID, vep.VenueID, ep.EventID, ep.[Date], ep.DayType, 
		-- get the number of half days since @root, gives us a single numeric value to use instead of Date & DayType
		datediff(d, @root, ep.[Date]) * 2 + case ep.DayType when 1 then 0 when 2 then 1 else 2 end as HalfDays
	from VenueEventPart vep
	inner join EventPart ep on vep.DayPartID = ep.ID
	inner join [Event] e on ep.EventID = e.ID
	/**** TEMPORARY UNTIL UST-1694 IS IN PRODUCTION ****/
	inner join VenueTagActivityPart vtap on vtap.ActivityPartID = ep.ActivityPartID and vtap.VenueTagID = vep.VenueTagID
	/**** TEMPORARY UNTIL UST-1694 IS IN PRODUCTION ****/
	where e.[Status] = 2 -- Ready
	and ep.[Date] between @Start and @End
)
, q2 as (
	-- Assign each venue's rows a number based on its order within the event
	select *, row_number() over (partition by EventID, VenueID order by HalfDays) as RowNum
	-- Calculate the gap between the current row and the previous row
	, HalfDays - lag(HalfDays, 1, null) over (partition by EventID, VenueID order by HalfDays) as PrevDiff
	-- Calculate the gap between the current row and the next row
	, lead(HalfDays, 1, null) over (partition by EventID, VenueID order by HalfDays) - HalfDays as NextDiff
	from q1
)
, starts as (
	select *, lead(RowNum, 1, null) over (partition by EventID, VenueID order by RowNum) as NextStartRowNum
	from q2
	-- Get the rows that denote the start of a venue allocation (there is a gap between the current and previous row)
	-- Also, NextStartRowNum denotes the number of the next row, after the current one, to denote the start of a venue allocation
	where isnull(PrevDiff, 999) > 1
)
, ends as (
	select *
	from q2
	-- Get the rows that denote the end of a venue allocation (there is a gap between the current and next row)
	where isnull(NextDiff, 999) > 1
)
insert @Results (EVENT_CODE, VENUE_NAME, VENUE_START_DATE, VENUE_START_TIME, VENUE_END_DATE, VENUE_END_TIME)
select
	a.Code + ' ' + cast(t.EventNumber as varchar) + '/' + right(cast(t.FinanciaYear as varchar),2) as EVENT_CODE, 
	v.Name as VENUE_NAME,
	convert(varchar, s.[Date], 112) as VENUE_START_DATE,
	case when s.DayType = 2 then '1301' else '0900' end as VENUE_START_TIME,
	convert(varchar, e.[Date], 112) as VENUE_END_DATE,
	case when e.DayType = 1 then '1300' else '1700' end as VENUE_END_TIME
from starts s
-- Link the matching start and end of venue allocations together based on their row numbers
inner join ends e on s.EventID = e.EventID and s.VenueID = e.VenueID and e.RowNum between s.RowNum and isnull(s.NextStartRowNum - 1, 999)
inner join Venue v on s.VenueID = v.ID
inner join [Event] t on s.EventID = t.ID
inner join Activity a on t.ActivityID = a.ID

-- LEARNING EVENTS (PEOPLE)
;with q1 as (
	select iep.ID as InstructorEventPartID, iep.InstructorID, ep.EventID, ep.[Date], ep.DayType, 
		datediff(d, @root, ep.[Date]) * 2 + case ep.DayType when 1 then 0 when 2 then 1 else 2 end as HalfDays
	from InstructorEventPart iep
	inner join EventPart ep on iep.DayPartID = ep.ID
	inner join [Event] e on ep.EventID = e.ID
	where e.[Status] = 2 -- Ready
	and ep.[Date] between @Start and @End
)
, q2 as (
	select *, row_number() over (partition by EventID, InstructorID order by HalfDays) as RowNum
	, HalfDays - lag(HalfDays, 1, null) over (partition by EventID, InstructorID order by HalfDays) as PrevDiff
	, lead(HalfDays, 1, null) over (partition by EventID, InstructorID order by HalfDays) - HalfDays as NextDiff
	from q1
)
, starts as (
	select *, lead(RowNum, 1, null) over (partition by EventID, InstructorID order by RowNum) as NextStartRowNum
	from q2
	where isnull(PrevDiff, 999) > 1
)
, ends as (
	select *
	from q2
	where isnull(NextDiff, 999) > 1
)
insert @Results (EVENT_CODE, EXTERNAL_PR_FORENAME1, EXTERNAL_PR_SURNAME, PR_START_DATE, PR_START_TIME, PR_END_DATE, PR_END_TIME)
select
	a.Code + ' ' + cast(t.EventNumber as varchar) + '/' + right(cast(t.FinanciaYear as varchar),2) as EVENT_CODE, 
	i.FirstName as EXTERNAL_PR_FORENAME1,
	i.LastName as EXTERNAL_PR_SURNAME,
	convert(varchar, s.[Date], 112) as PR_START_DATE,
	case when s.DayType = 2 then '1301' else '0900' end as PR_START_TIME,
	convert(varchar, e.[Date], 112) as PR_END_DATE,
	case when e.DayType = 1 then '1300' else '1700' end as PR_END_TIME
from starts s
inner join ends e on s.EventID = e.EventID and s.InstructorID = e.InstructorID and e.RowNum between s.RowNum and isnull(s.NextStartRowNum - 1, 999)
inner join Instructor i on s.InstructorID = i.ID
inner join [Event] t on s.EventID = t.ID
inner join Activity a on t.ActivityID = a.ID

select 
	ISNULL(ACTIVITY_CODE, '') as ACTIVITY_CODE,
	ISNULL(ACTIVITY, '') as ACTIVITY,
	ISNULL(EVENT_CODE, '') as EVENT_CODE,
	ISNULL([START_DATE], '') as [START_DATE],
	ISNULL(START_TIME, '') as START_TIME,
	ISNULL(END_DATE, '') as END_DATE,
	ISNULL(END_TIME, '') as END_TIME,
	ISNULL(VENUE_NAME, '') as VENUE_NAME,
	ISNULL(VENUE_START_DATE, '') as VENUE_START_DATE,
	ISNULL(VENUE_START_TIME, '') as VENUE_START_TIME,
	ISNULL(VENUE_END_DATE, '') as VENUE_END_DATE,
	ISNULL(VENUE_END_TIME, '') as VENUE_END_TIME,
	ISNULL(PR_PER_REF_NO, '') as PR_PER_REF_NO,
	ISNULL(EXTERNAL_PR_FORENAME1, '') as EXTERNAL_PR_FORENAME1,
	ISNULL(EXTERNAL_PR_SURNAME, '') as EXTERNAL_PR_SURNAME,
	ISNULL(PR_START_DATE, '') as PR_START_DATE,
	ISNULL(PR_START_TIME, '') as PR_START_TIME,
	ISNULL(PR_END_DATE, '') as PR_END_DATE,
	ISNULL(PR_END_TIME, '') as PR_END_TIME
from @Results r
order by 
	r.EVENT_CODE, 
	isnull(r.ACTIVITY_CODE, 'zzz'), 
	isnull(r.VENUE_NAME, 'zzz'), 
	r.VENUE_START_DATE, 
	r.VENUE_START_TIME, 
	isnull(r.EXTERNAL_PR_SURNAME, 'zzz'), 
	isnull(r.EXTERNAL_PR_FORENAME1, 'zzz'), 
	r.PR_START_DATE, 
	r.PR_START_TIME

set nocount off
