/* Script to extract event data between supplied dates for iTrent upload. */

USE TOR

set nocount on

DECLARE @Start date
DECLARE @End date

SET @Start = '01 Apr 2013'
SET @End = '31 Mar 2014'

DECLARE @Results TABLE (
	ACTIVITY_CODE VARCHAR(20),
	ACTIVITY NVARCHAR(100),
	EVENT_CODE VARCHAR(30),
	[START_DATE] VARCHAR(8),
	START_TIME VARCHAR(4),
	END_DATE VARCHAR(8),
	END_TIME VARCHAR(4),
	VENUE_NAME NVARCHAR(100),
	VENUE_START_DATE VARCHAR(8),
	VENUE_START_TIME VARCHAR(4),
	VENUE_END_DATE VARCHAR(8),
	VENUE_END_TIME VARCHAR(4),
	PR_PER_REF_NO VARCHAR(10),
	EXTERNAL_PR_FORENAME1 NVARCHAR(50),
	EXTERNAL_PR_SURNAME NVARCHAR(50),
	PR_START_DATE VARCHAR(8),
	PR_START_TIME VARCHAR(4),
	PR_END_DATE VARCHAR(8),
	PR_END_TIME VARCHAR(4)
)

-- LEARNING EVENTS
;with Parts as (
	select p.EventID, MIN(p.Date + p.StartTime) as EventStart, MAX(p.Date + p.EndTime) as EventEnd
	from EventPart p
	where p.Date between @Start and @End
	group by p.EventID
)
insert @Results
select 
	a.Code as ACTIVITY_CODE, 
	a.Title as ACTIVITY, 
	a.Code + ' ' + cast(e.EventNumber as varchar) + '/' + right(cast(e.FinanciaYear as varchar),2) as EVENT_CODE,
	CONVERT(varchar, p.EventStart, 112) as START_DATE,
	RIGHT('0' + CAST(DATEPART(hh, p.EventStart) as varchar), 2) + RIGHT('0' + CAST(DATEPART(mi, p.EventStart) as varchar), 2) as START_TIME,
	CONVERT(varchar, p.EventEnd, 112) as END_DATE,
	RIGHT('0' + CAST(DATEPART(hh, p.EventEnd) as varchar), 2) + RIGHT('0' + CAST(DATEPART(mi, p.EventEnd) as varchar), 2) as END_TIME,
	NULL as VENUE_NAME,
	NULL as VENUE_START_DATE,
	NULL as VENUE_START_TIME,
	NULL as VENUE_END_DATE,
	NULL as VENUE_END_TIME,
	NULL as PR_PER_REF_NO,
	NULL as EXTERNAL_PR_FORENAME1,
	NULL as EXTERNAL_PR_SURNAME,
	NULL as PR_START_DATE,
	NULL as PR_START_TIME,
	NULL as PR_END_DATE,
	NULL as PR_END_TIME
from Parts p
inner join Event e on p.EventID = e.ID
inner join Activity a on e.ActivityID = a.ID
where e.Status = 2 -- Ready
union all
-- LEARNING EVENTS (VENUES)
select 
	NULL as ACTIVITY_CODE,
	NULL as ACTIVITY,
	a.Code + ' ' + cast(e.EventNumber as varchar) + '/' + right(cast(e.FinanciaYear as varchar),2) as EVENT_CODE,
	NULL as [START_DATE],
	NULL as START_TIME,
	NULL as END_DATE,
	NULL as END_TIME,
	v.Name as VENUE_NAME,
	CONVERT(varchar, ep.Date, 112) as VENUE_START_DATE,
	RIGHT('0' + CAST(DATEPART(hh, ep.StartTime) as varchar), 2) + RIGHT('0' + CAST(DATEPART(mi, ep.StartTime) as varchar), 2) as VENUE_START_TIME,
	CONVERT(varchar, ep.Date, 112) as VENUE_END_DATE,
	RIGHT('0' + CAST(DATEPART(hh, ep.EndTime) as varchar), 2) + RIGHT('0' + CAST(DATEPART(mi, ep.EndTime) as varchar), 2) as VENUE_END_TIME,
	NULL as PR_PER_REF_NO,
	NULL as EXTERNAL_PR_FORENAME1,
	NULL as EXTERNAL_PR_SURNAME,
	NULL as PR_START_DATE,
	NULL as PR_START_TIME,
	NULL as PR_END_DATE,
	NULL as PR_END_TIME
from VenueEventPart vep
inner join Venue v on vep.VenueID = v.ID
inner join EventPart ep on vep.DayPartID = ep.ID
inner join Event e on ep.EventID = e.ID
inner join Activity a on e.ActivityID = a.ID
where e.Status = 2 -- Ready
and ep.Date between @Start and @End
union all
-- LEARNING EVENTS (PEOPLE)
select 
	NULL as ACTIVITY_CODE,
	NULL as ACTIVITY,
	a.Code + ' ' + cast(e.EventNumber as varchar) + '/' + right(cast(e.FinanciaYear as varchar),2) as EVENT_CODE,
	NULL as [START_DATE],
	NULL as START_TIME,
	NULL as END_DATE,
	NULL as END_TIME,
	NULL as VENUE_NAME,
	NULL as VENUE_START_DATE,
	NULL as VENUE_START_TIME,
	NULL as VENUE_END_DATE,
	NULL as VENUE_END_TIME,
	NULL as PR_PER_REF_NO,
	i.FirstName as EXTERNAL_PR_FORENAME1,
	i.LastName as EXTERNAL_PR_SURNAME,
	CONVERT(varchar, ep.Date, 112) as PR_START_DATE,
	RIGHT('0' + CAST(DATEPART(hh, ep.StartTime) as varchar), 2) + RIGHT('0' + CAST(DATEPART(mi, ep.StartTime) as varchar), 2) as PR_START_TIME,
	CONVERT(varchar, ep.Date, 112) as PR_END_DATE,
	RIGHT('0' + CAST(DATEPART(hh, ep.EndTime) as varchar), 2) + RIGHT('0' + CAST(DATEPART(mi, ep.EndTime) as varchar), 2) as PR_END_TIME
from InstructorEventPart iep
inner join Instructor i on iep.InstructorID = i.ID
inner join EventPart ep on iep.DayPartID = ep.ID
inner join Event e on ep.EventID = e.ID
inner join Activity a on e.ActivityID = a.ID
where e.Status = 2 -- Ready
and ep.Date between @Start and @End

select 
	ISNULL(ACTIVITY_CODE, '') as ACTIVITY_CODE,
	ISNULL(ACTIVITY, '') as ACTIVITY,
	ISNULL(EVENT_CODE, '') as EVENT_CODE,
	ISNULL([START_DATE], '') as [START_DATE],
	ISNULL(START_TIME, '') as START_TIME,
	ISNULL(END_DATE, '') as END_DATE,
	ISNULL(END_TIME, '') as END_TIME,
	ISNULL(VENUE_NAME, '') as VENUE_NAME,
	ISNULL(VENUE_START_DATE, '') as VENUE_START_DATE,
	ISNULL(VENUE_START_TIME, '') as VENUE_START_TIME,
	ISNULL(VENUE_END_DATE, '') as VENUE_END_DATE,
	ISNULL(VENUE_END_TIME, '') as VENUE_END_TIME,
	ISNULL(PR_PER_REF_NO, '') as PR_PER_REF_NO,
	ISNULL(EXTERNAL_PR_FORENAME1, '') as EXTERNAL_PR_FORENAME1,
	ISNULL(EXTERNAL_PR_SURNAME, '') as EXTERNAL_PR_SURNAME,
	ISNULL(PR_START_DATE, '') as PR_START_DATE,
	ISNULL(PR_START_TIME, '') as PR_START_TIME,
	ISNULL(PR_END_DATE, '') as PR_END_DATE,
	ISNULL(PR_END_TIME, '') as PR_END_TIME
from @Results
order by EVENT_CODE, isnull(ACTIVITY_CODE, 'zzz'), isnull(VENUE_NAME, 'zzz'), VENUE_START_DATE, VENUE_START_TIME, isnull(EXTERNAL_PR_SURNAME, 'zzz'), isnull(EXTERNAL_PR_FORENAME1, 'zzz'), PR_START_DATE, PR_START_TIME

set nocount off

