﻿using System;
using System.Data;
using System.Data.Objects;
using System.Web;
using SFR.TOR.Utility;
using SFR.TOR.Utility.Security;

namespace SFR.TOR.Data
{
    public partial class TORContainer
    {
        public ITORSession Session { get; set; }

        partial void OnContextCreated()
        {
            SavingChanges += new EventHandler(OnSavingChanges);
        }

        void OnSavingChanges(object sender, EventArgs e)
        {
            String username = Session != null ? Session.User.FullName : null;

            foreach (ObjectStateEntry entry in ObjectStateManager.GetObjectStateEntries(EntityState.Added | EntityState.Modified))
            {
                Event ev = entry.Entity as Event;

                // If this entry's entity is not an Event, skip to the next entry
                if (ev == null) 
                    continue;

                // Store the username and timestamp on the event for this update
                ev.LastEditedBy = username;
                ev.LastEditedOn = DateTime.UtcNow.TrimMilliseconds(); // Use universal time to avoid timezone ambiguity
            }
        }
    }
}