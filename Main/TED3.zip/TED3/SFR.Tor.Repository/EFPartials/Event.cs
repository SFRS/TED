﻿using System;
using SFR.TOR.Utility;
using Stateless;

namespace SFR.TOR.Data
{
    partial class Event
    {
        public StateMachine<EventStatusEnum, Trigger> Machine { get; set; }

        public Event()
        {
            //configures the state machine rules for managing event status through triggers
            Machine = new StateMachine<EventStatusEnum, Trigger>(
                () => (EventStatusEnum)Status, newState => Status = (int)newState
            );

            Machine.Configure(EventStatusEnum.NotReady)
                .Permit(Trigger.AllDatesAdded, EventStatusEnum.Ready) //if all dates have been added, then the event is Ready
                .Permit(Trigger.EventUploadedToITrent, EventStatusEnum.Blocked) // the event must previously have been Ready and included in an export
                
                .Ignore(Trigger.TotalActivityDaysIncreased) 
                .Ignore(Trigger.EventPartDateTypeChanged)  
                .Ignore(Trigger.EventPartAdded)
                .Ignore(Trigger.VenueMinNumberIncreased)
                .Ignore(Trigger.EquipmentMinNumberIncreased)
                .Ignore(Trigger.InstructorRequirementIncreased)
                
                //.Permit(Trigger.AllResourcesAdded, EventStatusEnum.Ready) //note: this indicates an event with no resources
                .Ignore(Trigger.AllResourcesAdded)    
                .Ignore(Trigger.PartResourced)    
                .Ignore(Trigger.DateRemoved)    
                .Ignore(Trigger.EventPartRemoved)               
                .Ignore(Trigger.TotalActivityDaysDecreased)     
                .Ignore(Trigger.InstructorRequirementDecreased)
                .Ignore(Trigger.VenueMinNumberDecreased)
                .Ignore(Trigger.EquipmentMinNumberDecreased)
                .Ignore(Trigger.NotResourced)
                .Ignore(Trigger.EventFailedToUploadToITrent)
                .Ignore(Trigger.ITrentExportCreated)
                .Ignore(Trigger.ITrentExportDeleted)
                .Ignore(Trigger.EventIdentificationChanged)
                .Ignore(Trigger.EventCancelled);

            Machine.Configure(EventStatusEnum.Ready)
                .Permit(Trigger.TotalActivityDaysDecreased, EventStatusEnum.NotReady)
                .Permit(Trigger.TotalActivityDaysIncreased, EventStatusEnum.NotReady)
                .Permit(Trigger.DateRemoved, EventStatusEnum.NotReady)
                .Permit(Trigger.EventUploadedToITrent, EventStatusEnum.Scheduled)
              
                .Ignore(Trigger.AllResourcesAdded)                
                .Ignore(Trigger.EventPartDateTypeChanged)  
                .Ignore(Trigger.EventPartAdded)  
                .Ignore(Trigger.EventPartRemoved)  
                .Ignore(Trigger.InstructorRequirementIncreased)  
                .Ignore(Trigger.VenueMinNumberIncreased)  
                .Ignore(Trigger.EquipmentMinNumberIncreased)                  
                .Ignore(Trigger.PartResourced)  
                .Ignore(Trigger.AllDatesAdded)                
                .Ignore(Trigger.InstructorRequirementDecreased)
                .Ignore(Trigger.VenueMinNumberDecreased)
                .Ignore(Trigger.EquipmentMinNumberDecreased)
                .Ignore(Trigger.NotResourced)
                .Ignore(Trigger.EventFailedToUploadToITrent)
                .Ignore(Trigger.ITrentExportCreated)
                .Ignore(Trigger.ITrentExportDeleted)
                .Ignore(Trigger.EventIdentificationChanged)
                .Ignore(Trigger.EventCancelled);

            Machine.Configure(EventStatusEnum.Cancelled)
                .Ignore(Trigger.PartResourced)
                .Ignore(Trigger.AllResourcesAdded)
                .Ignore(Trigger.NotResourced)
                .Ignore(Trigger.AllDatesAdded)
                .Ignore(Trigger.TotalActivityDaysIncreased)
                .Ignore(Trigger.TotalActivityDaysDecreased)
                .Ignore(Trigger.EventPartDateTypeChanged)
                .Ignore(Trigger.EventPartAdded)
                .Ignore(Trigger.EventPartRemoved)
                .Ignore(Trigger.InstructorRequirementIncreased)
                .Ignore(Trigger.VenueMinNumberIncreased)
                .Ignore(Trigger.EquipmentMinNumberIncreased)
                .Ignore(Trigger.DateRemoved)
                .Ignore(Trigger.InstructorRequirementDecreased)
                .Ignore(Trigger.VenueMinNumberDecreased)
                .Ignore(Trigger.EquipmentMinNumberDecreased)
                .Ignore(Trigger.EventUploadedToITrent)
                .Ignore(Trigger.EventFailedToUploadToITrent)
                .Ignore(Trigger.ITrentExportCreated)
                .Ignore(Trigger.ITrentExportDeleted)
                .Ignore(Trigger.EventIdentificationChanged)
                .Ignore(Trigger.EventCancelled);

            Machine.Configure(EventStatusEnum.Scheduled) //blocking only happens when an event is Scheduled (ie. when it has been uploaded to iTrent)
                .Permit(Trigger.DateRemoved, EventStatusEnum.Blocked)
                .Permit(Trigger.PartResourced, EventStatusEnum.Blocked)
                .Permit(Trigger.EventPartDateTypeChanged, EventStatusEnum.Blocked)
                .Permit(Trigger.TotalActivityDaysIncreased, EventStatusEnum.Blocked)
                .Permit(Trigger.TotalActivityDaysDecreased, EventStatusEnum.Blocked)
                .Permit(Trigger.EventPartAdded, EventStatusEnum.Blocked)
                .Permit(Trigger.EventPartRemoved, EventStatusEnum.Blocked)
                .Permit(Trigger.InstructorRequirementIncreased, EventStatusEnum.Blocked)
                .Permit(Trigger.VenueMinNumberIncreased, EventStatusEnum.Blocked)
                .Permit(Trigger.EquipmentMinNumberIncreased, EventStatusEnum.Blocked)
                .Permit(Trigger.InstructorRequirementDecreased, EventStatusEnum.Blocked)
                .Permit(Trigger.VenueMinNumberDecreased, EventStatusEnum.Blocked)
                .Permit(Trigger.EquipmentMinNumberDecreased, EventStatusEnum.Blocked)
                .Permit(Trigger.NotResourced, EventStatusEnum.Blocked)
                .Permit(Trigger.EventCancelled, EventStatusEnum.Cancelled)
                .Ignore(Trigger.AllDatesAdded)
                .Ignore(Trigger.AllResourcesAdded)
                .Ignore(Trigger.EventUploadedToITrent)
                .Ignore(Trigger.EventFailedToUploadToITrent)
                .Ignore(Trigger.ITrentExportCreated)
                .Ignore(Trigger.ITrentExportDeleted)
                .Ignore(Trigger.EventIdentificationChanged);

            Machine.Configure(EventStatusEnum.Blocked)
                .Permit(Trigger.AllResourcesAdded, EventStatusEnum.Scheduled)
                .Permit(Trigger.EventCancelled, EventStatusEnum.Cancelled)
                .Ignore(Trigger.TotalActivityDaysIncreased)
                .Ignore(Trigger.TotalActivityDaysDecreased)
                .Ignore(Trigger.EventPartDateTypeChanged)
                .Ignore(Trigger.EventPartAdded)
                .Ignore(Trigger.EventPartRemoved)
                .Ignore(Trigger.AllDatesAdded)
                .Ignore(Trigger.PartResourced)
                .Ignore(Trigger.InstructorRequirementIncreased)
                .Ignore(Trigger.VenueMinNumberIncreased)
                .Ignore(Trigger.EquipmentMinNumberIncreased)
                .Ignore(Trigger.DateRemoved)
                .Ignore(Trigger.InstructorRequirementDecreased)
                .Ignore(Trigger.VenueMinNumberDecreased)
                .Ignore(Trigger.EquipmentMinNumberDecreased)
                .Ignore(Trigger.NotResourced)
                .Ignore(Trigger.EventUploadedToITrent)
                .Ignore(Trigger.EventFailedToUploadToITrent)
                .Ignore(Trigger.ITrentExportCreated)
                .Ignore(Trigger.ITrentExportDeleted)
                .Ignore(Trigger.EventIdentificationChanged);

             Machine.Configure(EventStatusEnum.Complete)
                .Permit(Trigger.EventCancelled, EventStatusEnum.Cancelled)
                .Ignore(Trigger.PartResourced)
                .Ignore(Trigger.AllResourcesAdded)
                .Ignore(Trigger.NotResourced)
                .Ignore(Trigger.EventPartRemoved)
                .Ignore(Trigger.EventPartAdded)
                .Ignore(Trigger.EventPartDateTypeChanged)
                .Ignore(Trigger.TotalActivityDaysIncreased)
                .Ignore(Trigger.TotalActivityDaysDecreased)
                .Ignore(Trigger.AllDatesAdded)
                .Ignore(Trigger.InstructorRequirementIncreased)
                .Ignore(Trigger.VenueMinNumberIncreased)
                .Ignore(Trigger.EquipmentMinNumberIncreased)
                .Ignore(Trigger.DateRemoved)
                .Ignore(Trigger.InstructorRequirementDecreased)
                .Ignore(Trigger.VenueMinNumberDecreased)
                .Ignore(Trigger.EquipmentMinNumberDecreased)
                .Ignore(Trigger.EventUploadedToITrent)
                .Ignore(Trigger.EventFailedToUploadToITrent)
                .Ignore(Trigger.ITrentExportCreated)
                .Ignore(Trigger.ITrentExportDeleted)
                .Ignore(Trigger.EventIdentificationChanged);
                
        }

        public string GetEventCode()
        {
            return String.Format("{0} {1}/{2}", this.Activity.Code, this.EventNumber, this.FinanciaYear.ToString().Substring(2, 2));
        }
    }
}
