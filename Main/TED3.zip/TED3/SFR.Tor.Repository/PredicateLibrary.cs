﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using SFR.TOR.Utility;
using LinqKit;

namespace SFR.TOR.Data
{
    public static class PredicateLibrary
    {
        public static Expression<Func<Event, bool>> GetEventsToExportPredicate(int financialYear, iTrentExportTypeEnum? iTrentExportType)
        {
            Expression<Func<Event, bool>> predicate = PredicateBuilder.True<Event>().And(e =>
               e.FinanciaYear == financialYear && e.iTrentDataStale);

            switch (iTrentExportType)
            {
                case iTrentExportTypeEnum.ReadyAndCancelledEvents:
                    predicate = predicate.And(e =>
                        e.Status == (int)EventStatusEnum.Cancelled ||
                        e.Status == (int)EventStatusEnum.Ready);
                    break;
                case iTrentExportTypeEnum.UpdatesToScheduledEvents:
                    predicate = predicate.And(e => e.Status == (int)EventStatusEnum.Scheduled);
                    break;
                default:
                    throw new ArgumentException("Unknown iTrent Export Type supplied.", "iTrentExportType");
            }

            return predicate;
        }

        public static Expression<Func<Activity, bool>> GetActivityTemplateIDPredicate(int id)
        {
            Expression<Func<Activity, bool>> predicate = PredicateBuilder.False<Activity>();
            predicate = predicate.Or(p => p.ID == id);
            return predicate;
        }

        public static Expression<Func<InstructorUnavailablePeriod, bool>> GetInstructorUnavailablePeriodsPredicate(List<int> ids, DateTime startDate, DateTime endDate)
        {
            Expression<Func<InstructorUnavailablePeriod, bool>> mainPredicate = PredicateBuilder.True<InstructorUnavailablePeriod>();

            mainPredicate = mainPredicate.And(p => ids.Contains(p.InstructorID));
            
            DateTime infinity = new DateTime(2999, 12, 31);
            var datePredicate = PredicateBuilder.False<InstructorUnavailablePeriod>();
            datePredicate = datePredicate.Or(p => startDate >= p.StartDate && startDate <= (p.EndDate ?? infinity)); // start date we're looking for falls within the unavailable period
            datePredicate = datePredicate.Or(p => endDate >= p.StartDate && endDate <= (p.EndDate ?? infinity)); // end date we're looking for falls within the unavailable period
            datePredicate = datePredicate.Or(p => p.StartDate >= startDate && p.StartDate <= endDate); // unavailable period starts in between the start and end dates we're looking for

            //combine with the date period check
            mainPredicate = mainPredicate.And(datePredicate.Expand());


            return mainPredicate;
        }

        public static Expression<Func<VenueUnavailablePeriod, bool>> GetVenueUnavailablePeriodsPredicate(List<int> ids, DateTime startDate, DateTime endDate)
        {
            Expression<Func<VenueUnavailablePeriod, bool>> mainPredicate = PredicateBuilder.True<VenueUnavailablePeriod>();

            mainPredicate = mainPredicate.And(p => ids.Contains(p.VenueID));

            DateTime infinity = new DateTime(2999, 12, 31);
            var datePredicate = PredicateBuilder.False<VenueUnavailablePeriod>();
            datePredicate = datePredicate.Or(p => startDate >= p.StartDate && startDate <= (p.EndDate ?? infinity)); // start date we're looking for falls within the unavailable period
            datePredicate = datePredicate.Or(p => endDate >= p.StartDate && endDate <= (p.EndDate ?? infinity)); // end date we're looking for falls within the unavailable period
            datePredicate = datePredicate.Or(p => p.StartDate >= startDate && p.StartDate <= endDate); // unavailable period starts in between the start and end dates we're looking for

            //combine with the date period check
            mainPredicate = mainPredicate.And(datePredicate.Expand());

            return mainPredicate;
        }

        public static Expression<Func<EquipmentUnavailablePeriod, bool>> GetEquipmentUnavailablePeriodsPredicate(List<int> ids, DateTime startDate, DateTime endDate)
        {
            Expression<Func<EquipmentUnavailablePeriod, bool>> mainPredicate = PredicateBuilder.True<EquipmentUnavailablePeriod>();

            mainPredicate = mainPredicate.And(p => ids.Contains(p.EquipmentID));

            DateTime infinity = new DateTime(2999, 12, 31);
            var datePredicate = PredicateBuilder.False<EquipmentUnavailablePeriod>();
            datePredicate = datePredicate.Or(p => startDate >= p.StartDate && startDate <= (p.EndDate ?? infinity)); // start date we're looking for falls within the unavailable period
            datePredicate = datePredicate.Or(p => endDate >= p.StartDate && endDate <= (p.EndDate ?? infinity)); // end date we're looking for falls within the unavailable period
            datePredicate = datePredicate.Or(p => p.StartDate >= startDate && p.StartDate <= endDate); // unavailable period starts in between the start and end dates we're looking for

            //combine with the date period check
            mainPredicate = mainPredicate.And(datePredicate.Expand());


            return mainPredicate;
        }

        /// <summary>
        /// Builds a predicate query for all future events that are based on an activity
        /// </summary>
        /// <param name="activityID"></param>
        /// <returns></returns>
        public static Expression<Func<Event, bool>> FutureEventsBasedOnActivityTemplatePredicate(int activityID)
        {
            Expression<Func<Event, bool>> realDates = PredicateBuilder.True<Event>();
            realDates = realDates.And(p => p.EventParts.Count(dp => dp.Date > DateTime.Now) > 0);   //has parts after today
            realDates = realDates.And(p => p.EventParts.Count(dp => dp.Date <= DateTime.Now) == 0); //and no parts today or earlier

            var datesOrNull = PredicateBuilder.False<Event>();
            datesOrNull = datesOrNull.Or(realDates.Expand());                                        //either in the future, 
            datesOrNull = datesOrNull.Or(p => p.EventParts.Count() 
                                            == p.EventParts.Count(dp => dp.Date == null));  //or all the events parts have no date assigned

            Expression<Func<Event, bool>> main = PredicateBuilder.True<Event>();
            main = main.And(p => p.ActivityID == activityID);
            main = main.And(datesOrNull.Expand());


            return main;
        }

        public static Expression<Func<EventPart, bool>> FutureEventPartsBasedOnActivityTemplatePredicate(int activityPartID)
        {
            var inner = PredicateBuilder.False<EventPart>();
            inner = inner.Or(p => p.Date > DateTime.Now); //either in the future, 
            inner = inner.Or(p => p.Date == null);        //or no date set yet

            Expression<Func<EventPart, bool>> predicate = PredicateBuilder.True<EventPart>();
            predicate = predicate.And(p => p.ActivityPartID == activityPartID);
            predicate = predicate.And(inner.Expand());  
            
            return predicate;
        }

        public static Expression<Func<InstructorEventPart, bool>> GetInstructorEventPartInADateRange(int instructorID, DateTime startDate, DateTime? endDate, int dayType)
        {
            var predicate = PredicateBuilder.True<InstructorEventPart>();
            predicate = predicate.And(p => p.EventPart.Date >= startDate);

            if (endDate.HasValue)
            {
                predicate = predicate.And(p => p.EventPart.Date <= endDate);    
            }            
            
            predicate = predicate.And(p => p.InstructorID == instructorID);

            predicate = dayType == 3
                ? predicate.And(p => p.EventPart.DayType == 1 || p.EventPart.DayType == 2)
                : predicate.And(p => p.EventPart.DayType == dayType);

            return predicate;
        }

        public static Expression<Func<EquipmentEventPart, bool>> GetEquipmentEventPartInADateRange(int equipmentID, DateTime startDate, DateTime? endDate, int dayType)
        {
            var predicate = PredicateBuilder.True<EquipmentEventPart>();
            predicate = predicate.And(p => p.EventPart.Date >= startDate);

            if (endDate.HasValue)
            {
                predicate = predicate.And(p => p.EventPart.Date <= endDate);    
            }
            
            predicate = predicate.And(p => p.EquipmentID == equipmentID);

            predicate = dayType == 3 
                ? predicate.And(p => p.EventPart.DayType == 1 || p.EventPart.DayType == 2) 
                : predicate.And(p => p.EventPart.DayType == dayType);
            

            return predicate;
        }

        public static Expression<Func<VenueEventPart, bool>> GetVenueEventPartInADateRange(int venueID, DateTime startDate, DateTime? endDate, int dayType)
        {
            var predicate = PredicateBuilder.True<VenueEventPart>();
            predicate = predicate.And(p => p.EventPart.Date >= startDate);

            if (endDate.HasValue)
            {
                predicate = predicate.And(p => p.EventPart.Date <= endDate);
            }

            predicate = predicate.And(p => p.VenueID == venueID);

            predicate = dayType == 3
                ? predicate.And(p => p.EventPart.DayType == 1 || p.EventPart.DayType == 2)
                : predicate.And(p => p.EventPart.DayType == dayType);

            return predicate;
        }



    }
}
