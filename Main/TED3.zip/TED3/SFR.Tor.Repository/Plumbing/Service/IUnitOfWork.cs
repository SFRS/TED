﻿using System;

namespace SFR.TOR.Data.Plumbing.Service
{
    public interface IUnitOfWork : IDisposable
    {
        /// <summary>
        /// Save changes to the database
        /// </summary>
        /// <returns></returns>
        int Commit();        
    }

}
