﻿using System;
using SFR.TOR.Data.Plumbing.Repository;
using System.Data.Objects;
using System.Data;

namespace SFR.TOR.Data.Plumbing.Service
{
    public abstract class UnitOfWork <TContext> : IUnitOfWork where TContext : ObjectContext, new()
    {
        public TContext Context { get; set; }        

        protected UnitOfWork()
        {
            Context = new TContext();
        }

        public int Commit()
        {
            return Context.SaveChanges();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (Context != null)
                {
                    Context.Dispose();
                    Context = null;
                }
            }
        }

        public IRepository<TEntity> EntityRepositoryFor<TEntity>() where TEntity : class
        {
            return new EntityRepository<TEntity>(Context);
        }
    }

}
