﻿using System.Data.Objects;

namespace SFR.TOR.Data.Plumbing.Service
{
    public abstract class BaseEFService
    {
        public TORContainer Container { get; set; }

        public BaseEFService(ObjectContext context)
        {
            Container = ((TORContainer)context);  
        }
    }
}
