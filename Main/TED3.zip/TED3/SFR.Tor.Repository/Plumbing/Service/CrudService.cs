﻿using System;
using System.Linq;
using System.Linq.Expressions;
using LinqKit;
using SFR.TOR.Data.Plumbing.Repository;

namespace SFR.TOR.Data.Plumbing.Service
{
    public abstract class CrudService<TEntity>: BaseEFService where TEntity : class 
    {
        protected IRepository<TEntity> Repository { get; set; }

        public void Delete(TEntity existingEntity)
        {
            Repository.Delete(existingEntity);
        }

        public void DeleteAll()
        {
            Repository.DeleteAll();
        }

        public virtual TEntity Insert(TEntity newEntity)
        {
            return Repository.Insert(newEntity);
        }

        public virtual IQueryable<TEntity> SelectAll()
        {
            return Repository.SelectAll();
        }

        public virtual TEntity SelectBy(Expression<Func<TEntity, bool>> predicate)
        {
            return SelectAll().AsExpandable().Where(predicate).SingleOrDefault();
        }

        public virtual void DeleteAll(Expression<Func<TEntity, bool>> predicate)
        {
            var toDelete = SelectAll().AsExpandable().Where(predicate).ToList();

            foreach (var entity in toDelete)
            {
                Repository.Delete(entity);
            }            
        }


        public virtual IQueryable<TEntity> SelectFilteredList(Expression<Func<TEntity, bool>> predicate)
        {
            //build query starting with "all"
            var all = SelectAll();

            //now add optional filters 
            if (predicate != null)
            {
                all = all.AsExpandable().Where(predicate);    
            }
            
            return all;
        }

        public TEntity Update(TEntity existingEntity)
        {
            return Repository.Update(existingEntity);
        }

        public TEntity Update(TEntity existingEntity, TEntity original)
        {
            return Repository.Update(existingEntity, original);
        }

        public int Count()
        {
            return Repository.Count();
        }

        protected CrudService(IRepository<TEntity> repository): base(repository.Context)
        {
            this.Repository = repository;            
        }
    }

}
