﻿using System.Configuration;
using System.Web.Configuration;

namespace SFR.TOR.Data.Plumbing.Service
{
    public abstract class BaseADOService
    {
        public string ConnectionString { get; set; }
        public BaseADOService()
        {            
            Configuration rootWebConfig = WebConfigurationManager.OpenWebConfiguration("/TOR");
            ConnectionStringSettings connString;

            if (rootWebConfig.ConnectionStrings.ConnectionStrings.Count > 0)
            {
                ConnectionString = rootWebConfig.ConnectionStrings.ConnectionStrings["TORConnection"].ConnectionString;             
            }
        }
    }
}
