﻿using System.Data;
using System.Data.Objects;
using System.Data.Objects.DataClasses;
using System.Linq;
using System;

namespace SFR.TOR.Data.Plumbing.Repository
{
    public class EntityRepository<TEntity> : IRepository<TEntity> where TEntity : class
    {
        private EntityKey CreateEntityKey(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }
            return Context.CreateEntityKey(Context.GetEntitySetName(entity.GetType()), entity);
        }

        public void Delete(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }
            Entities.DeleteObject(GetAttachedEntity(entity));
            
        }

        public void DeleteAll()
        {
            foreach (TEntity entity in Entities.ToList())
            {
                Entities.DeleteObject(entity);
            }
        }

        private TEntity GetAttachedEntity(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }
            if (!Context.EntityIsDetached(entity))
            {
                return entity;
            }
            var ek = CreateEntityKey(entity);
            return (TEntity)Context.GetObjectByKey(ek);
        }

        public TEntity Insert(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }
            Entities.AddObject(entity);
            return entity;
        }

        public IQueryable<TEntity> SelectAll()
        {
            return Entities;
        }

        public TEntity Update(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }
            if (Context.EntityIsDetached(entity))
            {
                object dbEntity = GetAttachedEntity(entity);
                Entities.ApplyCurrentValues(entity);
                return (TEntity)dbEntity;
            }
            // otherwise, it's already attached, and modifications are already tracked
            return entity;
        }

        public TEntity Update(TEntity entity, TEntity original)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }
            if (original == null)
            {
                throw new ArgumentNullException("original");
            }

            TEntity entityToReturn = entity;

            if (Context.EntityIsDetached(entity))
            {
                object dbEntity = GetAttachedEntity(entity);
                Entities.ApplyCurrentValues(entity);
                entityToReturn = (TEntity)dbEntity;
            }
            // otherwise, it's already attached, and modifications are already tracked
            
            // Use the entity with the original values to be applied to the context
            Entities.ApplyOriginalValues(original);

            return entityToReturn;
        }

        public int Count()
        {
            return Entities.Count();
        }

        public ObjectContext Context { get; set; }

        private ObjectSet<TEntity> Entities { get; set; }

        public EntityRepository(ObjectContext context)
        {
            if (context == null)
            {
                throw new ArgumentNullException("context");
            }
            Context = context;
            
            Entities = context.CreateObjectSet<TEntity>();
        }

    }

}
