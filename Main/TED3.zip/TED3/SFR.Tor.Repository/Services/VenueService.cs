﻿using System;
using System.Linq;
using System.Linq.Expressions;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.Utility;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for Venue data access
    /// </summary>
    public class VenueService : CrudService<Venue>, IVenueService
    {
        public VenueService(IRepository<Venue> repository) : base(repository) { }
        public IQueryable<VenueModel> GetVenues(Expression<Func<Venue, bool>> predicate)
        {
            var today = DateTime.Now.Date;

            //can't use Automapper here as it interferes with paging in JQGrid, so revert to manual mapping to viewmodel
            var data =
                from v in SelectFilteredList(predicate)
                let p = v.VenueUnavailablePeriods.FirstOrDefault(p => p.StartDate <= today && (p.EndDate ?? today) >= today)
                select new VenueModel
                {
                    ID = v.ID,
                    Name = v.Name,
                    VenueGroup = v.VenueGroup != null ? v.VenueGroup.Title : string.Empty,
                    VenueGroupID = v.VenueGroupID,
                    TrainingCentre = v.TrainingCentre.Name,
                    TrainingCentreID = v.TrainingCentreID,
                    Availability = p == null ? Constants.RESOURCE_AVAILABILITY_AVAILABLE : (
                        p.EndDate == null ?
                        Constants.RESOURCE_AVAILABILITY_STATUS_UNAVAILABLE :
                        Constants.RESOURCE_AVAILABILITY_STATUS_LIMITED)
                };

            return data;
        }

        public VenueModel GetVenue(int id)
        {
            var v = SelectBy(x => x.ID == id);

            return new VenueModel
                    {
                        Name = v.Name,
                        ID = v.ID,
                        TrainingCentre = v.TrainingCentre.Name,
                        // Added D Scott for Venues Edit select list
                        TrainingCentreID = v.TrainingCentreID,
                        //
                        VenueGroup = v.VenueGroup != null ? v.VenueGroup.Title : string.Empty,
                        VenueGroupID = v.VenueGroupID
                    };
        }
    }
}
