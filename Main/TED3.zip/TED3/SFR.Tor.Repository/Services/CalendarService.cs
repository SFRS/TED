﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for Calendar data access
    /// </summary>
    public class CalendarService : BaseADOService, ICalendarService 
    {
        /// <summary>
        /// Returns a paged, filtered, ordered list of instructor calendar data 
        /// </summary>
        /// <param name="startDate">The date to start on</param>
        /// <param name="page">The page number of the resultset</param>
        /// <param name="size">The number of rows in the page</param>
        /// <param name="sortDir">The sort direction</param>
        /// <param name="sortBy">The sort column</param>
        /// <param name="section">Filter by Event Section ID</param>
        /// <param name="status">Filter by Event Status ID</param>
        /// <param name="totalCount">Output parameter to return total rows matching BEFORE paging</param>
        /// <param name="ShowWeekends">Show weekend data</param>
        /// <returns>a paged, filtered, ordered list of instructor calendar data</returns>
        public List<InstructorCalendarData> GetInstructorCalendarView(DateTime? startDate, int page, int size, string sortDir, string sortBy, string section, string status, out int totalCount, string trainingCentreIDs, string SelectedGroup, string SelectedInstructorID, bool ShowWeekends)
        {           
            var instructorCalendarData = new List<InstructorCalendarData>();

            using (var connection = new SqlConnection(ConnectionString))
            {
                var command = SetUpCommandObject(startDate, page, size, sortDir, sortBy, section, status, "GetInstructorCalendarView", connection, trainingCentreIDs, ShowWeekends);

                if (SelectedGroup != null)
                {
                    command.Parameters.Add(new SqlParameter
                    {
                        ParameterName = "@group",
                        Value = SelectedGroup,
                        SqlDbType = SqlDbType.VarChar
                    });
                }

                if (SelectedInstructorID != null)
                {
                    command.Parameters.Add(new SqlParameter
                    {
                        ParameterName = "@instructor",
                        Value = SelectedInstructorID,
                        SqlDbType = SqlDbType.VarChar
                    });
                }

                connection.Open();

                using (IDataReader reader = command.ExecuteReader())
                {
                    //get the main paged result set into a list
                    while (reader.Read())
                    {
                        instructorCalendarData.Add(
                            new InstructorCalendarData
                            {
                                ID = Convert.ToInt32(reader[0]),
                                SectionName = reader[1] as string,
                                GroupName = reader[2] as string,
                                Name = reader[5] as string,                                
                                Day1AM = reader[6] as string,
                                Day1PM = reader[7] as string,
                                Day2AM = reader[8] as string,
                                Day2PM = reader[9] as string,
                                Day3AM = reader[10] as string,
                                Day3PM = reader[11] as string,
                                Day4AM = reader[12] as string,
                                Day4PM = reader[13] as string,
                                Day5AM = reader[14] as string,
                                Day5PM = reader[15] as string,
                                Day6AM = reader[16] as string,
                                Day6PM = reader[17] as string,
                                Day7AM = reader[18] as string,
                                Day7PM = reader[19] as string,
                            });

                    }
                }

                //get the total count of matching rows, before paging
                totalCount = (int)command.Parameters["@totalCount"].Value;

                connection.Close();
            }

            return instructorCalendarData;
        }

        /// <summary>
        /// Returns a paged, filtered, ordered list of Equipment calendar data 
        /// </summary>
        /// <param name="startDate">The date to start on</param>
        /// <param name="page">The page number of the resultset</param>
        /// <param name="size">The number of rows in the page</param>
        /// <param name="sortDir">The sort direction</param>
        /// <param name="sortBy">The sort column</param>
        /// <param name="section">Filter by Event Section ID</param>
        /// <param name="status">Filter by Event Status ID</param>
        /// <param name="totalCount">Output parameter to return total rows matching BEFORE paging</param>
        /// <param name="trainingCentreID">Training centre to filter by</param>
        /// <param name="ShowWeekends"> </param>
        /// <returns>a paged, filtered, ordered list of Equipment calendar data</returns>
        public List<EquipmentCalendarData> GetEquipmentCalendarView(DateTime? startDate, int page, int size, string sortDir, string sortBy, string section, string status, out int totalCount, string trainingCentreIDs, string SelectedGroup, string SelectedEquipmentID, bool ShowWeekends)
        {            
            var equipmentCalendarData = new List<EquipmentCalendarData>();

            using (var connection = new SqlConnection(ConnectionString))
            {
                var command = SetUpCommandObject(startDate, page, size, sortDir, sortBy, section, status, "GetEquipmentCalendarView", connection, trainingCentreIDs, ShowWeekends);

                if (SelectedGroup != null)
                {
                    command.Parameters.Add(new SqlParameter
                    {
                        ParameterName = "@group",
                        Value = SelectedGroup,
                        SqlDbType = SqlDbType.VarChar
                    });
                }

                if (SelectedEquipmentID != null)
                {
                    command.Parameters.Add(new SqlParameter
                    {
                        ParameterName = "@equipment",
                        Value = SelectedEquipmentID,
                        SqlDbType = SqlDbType.VarChar
                    });
                }

                connection.Open();

                using (IDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read()) ; //used to fill the totalCount

                    reader.NextResult();

                    //now get the main paged result set into a list
                    while (reader.Read())
                    {
                        equipmentCalendarData.Add(
                            new EquipmentCalendarData
                                {
                                    ID = Convert.ToInt32(reader[0]),
                                    Name = reader[1] as string,
                                    GroupName = reader[2] as string,
                                    Day1AM = reader[3] as string,
                                    Day1PM = reader[4] as string,
                                    Day2AM = reader[5] as string,
                                    Day2PM = reader[6] as string,
                                    Day3AM = reader[7] as string,
                                    Day3PM = reader[8] as string,
                                    Day4AM = reader[9] as string,
                                    Day4PM = reader[10] as string,
                                    Day5AM = reader[11] as string,
                                    Day5PM = reader[12] as string,
                                    Day6AM = reader[13] as string,
                                    Day6PM = reader[14] as string,
                                    Day7AM = reader[15] as string,
                                    Day7PM = reader[16] as string,
                                });
                    }    
                }

                //get the total count of matching rows, before paging
                totalCount = (int)command.Parameters["@totalCount"].Value;
                
                connection.Close();
            }

            return equipmentCalendarData;
        }

        /// <summary>
        /// Returns a paged, filtered, ordered list of Venue calendar data 
        /// </summary>
        /// <param name="startDate">The date to start on</param>
        /// <param name="page">The page number of the resultset</param>
        /// <param name="size">The number of rows in the page</param>
        /// <param name="sortDir">The sort direction</param>
        /// <param name="sortBy">The sort column</param>
        /// <param name="section">Filter by Event Section ID</param>
        /// <param name="status">Filter by Event Status ID</param>
        /// <param name="totalCount">Output parameter to return total rows matching BEFORE paging</param>
        /// <returns>a paged, filtered, ordered list of venue calendar data</returns>
        public List<VenueCalendarData> GetVenueCalendarView(DateTime? startDate, int page, int size, string sortDir, string sortBy, string section, string status, out int totalCount, string trainingCentreIDs, string SelectedGroup, string SelectedVenueID, bool ShowWeekends)
        {
            var venueCalendarData = new List<VenueCalendarData>();

            using (var connection = new SqlConnection(ConnectionString))
            {
                var command = SetUpCommandObject(startDate, page, size, sortDir, sortBy, section, status, "GetVenueCalendarView", connection, trainingCentreIDs, ShowWeekends);

                if (SelectedGroup != null)
                {
                    command.Parameters.Add(new SqlParameter
                    {
                        ParameterName = "@group",
                        Value = SelectedGroup,
                        SqlDbType = SqlDbType.VarChar
                    });
                }

                if (SelectedVenueID != null)
                {
                    command.Parameters.Add(new SqlParameter
                    {
                        ParameterName = "@venue",
                        Value = SelectedVenueID,
                        SqlDbType = SqlDbType.VarChar
                    });
                }

                connection.Open();
                using (IDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read()) ; //used to fill the totalCount

                    //now get the main paged result set into a list
                    reader.NextResult();
                    while (reader.Read())
                    {
                        venueCalendarData.Add(
                            new VenueCalendarData
                                {
                                    ID = Convert.ToInt32(reader[0]),
                                    Name = reader[1] as string,
                                    GroupName = reader[2] as string,
                                    Day1AM = reader[3] as string,
                                    Day1PM = reader[4] as string,
                                    Day2AM = reader[5] as string,
                                    Day2PM = reader[6] as string,
                                    Day3AM = reader[7] as string,
                                    Day3PM = reader[8] as string,
                                    Day4AM = reader[9] as string,
                                    Day4PM = reader[10] as string,
                                    Day5AM = reader[11] as string,
                                    Day5PM = reader[12] as string,
                                    Day6AM = reader[13] as string,
                                    Day6PM = reader[14] as string,
                                    Day7AM = reader[15] as string,
                                    Day7PM = reader[16] as string
                                });

                    }
                }

                //get the total count of matching rows, before paging
                totalCount = (int)command.Parameters["@totalCount"].Value;

                connection.Close();
            }

            return venueCalendarData;
        }

        /// <summary>
        /// Returns a paged, filtered, ordered list of Event calendar data 
        /// </summary>
        /// <param name="startDate">The date to start on</param>
        /// <param name="page">The page number of the resultset</param>
        /// <param name="size">The number of rows in the page</param>
        /// <param name="section">Filter by Event Section ID</param>
        /// <param name="status">Filter by Event Status ID</param>
        /// <param name="totalCount">Output parameter to return total rows matching BEFORE paging</param>
        /// <param name="trainingCentreID"> </param>
        /// <param name="ShowWeekends"> </param>
        /// <returns>a paged, filtered, ordered list of event  calendar data</returns>
        public List<EventsCalendarData> GetEventsCalendarView(DateTime? startDate, int page, int size, string section, string status, out int totalCount, string trainingCentreIDs, bool ShowWeekends)
        {
            var eventsCalendarData = new List<EventsCalendarData>();

            using (var connection = new SqlConnection(ConnectionString))
            {
                //note: we don't sort the event data 
                var command = SetUpCommandObject(startDate, page, size, null, null, section, status, "GetEventCalendarView", connection, trainingCentreIDs, ShowWeekends); //todo: how do we figure out which events are at which training centre?? How do we stop a user creating an event with different parts at different training centres??

                connection.Open();
                using (IDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read()); //used to fill the totalCount

                    reader.NextResult();
                    while (reader.Read())
                    {
                        eventsCalendarData.Add(
                            new EventsCalendarData
                                {
                                    //Name = reader[1] as string,
                                    Day1AM = reader[1] as string,
                                    Day1PM = reader[2] as string,
                                    Day2AM = reader[3] as string,
                                    Day2PM = reader[4] as string,
                                    Day3AM = reader[5] as string,
                                    Day3PM = reader[6] as string,
                                    Day4AM = reader[7] as string,
                                    Day4PM = reader[8] as string,
                                    Day5AM = reader[9] as string,
                                    Day5PM = reader[10] as string,
                                    Day6AM = reader[11] as string,
                                    Day6PM = reader[12] as string,
                                    Day7AM = reader[13] as string,
                                    Day7PM = reader[14] as string,
                                });

                    }
                }
                totalCount = (int)command.Parameters["@totalCount"].Value;

                connection.Close();
            }

            return eventsCalendarData;
        }

        /// <summary>
        /// Helper method for setting up the SqlCommand for each of the main calendar methods
        /// </summary>
        /// <param name="startDate">The date to start on</param>
        /// <param name="page">The page number of the resultset</param>
        /// <param name="size">The number of rows in the page</param>
        /// <param name="sortDir">The sort direction</param>
        /// <param name="sortBy">The sort column</param>
        /// <param name="section">Filter by Event Section ID</param>
        /// <param name="status">Filter by Event Status ID</param>
        /// <param name="sprocName">The stored procedure to be called</param>
        /// <param name="connection">The connecton to use</param>
        /// <param name="trainingCentreID"> </param>
        /// <param name="ShowWeekends"> </param>
        /// <returns></returns>
        private static SqlCommand SetUpCommandObject(DateTime? startDate, int page, int size, string sortDir, string sortBy, string section, string status, string sprocName, SqlConnection connection, string trainingCentreIDs, bool ShowWeekends)
        {
            var command = new SqlCommand
            {
                CommandType = CommandType.StoredProcedure,
                Connection = connection,
                CommandText = sprocName
            };

            command.Parameters.Add(new SqlParameter()
            {
                ParameterName = "@startDate",
                Value = startDate.Value.ToString("yyyyMMdd"),
                SqlDbType = SqlDbType.VarChar
            });
            command.Parameters.Add(new SqlParameter()
            {
                ParameterName = "@endDate",
                //Value = startDate.Value.AddDays(ShowWeekends ? 7 : 5).ToString("yyyyMMdd"),
                Value = startDate.Value.AddDays(6).ToString("yyyyMMdd"),
                SqlDbType = SqlDbType.VarChar
            });

            command.Parameters.Add(new SqlParameter() { ParameterName = "@page", Value = page, SqlDbType = SqlDbType.Int });
            command.Parameters.Add(new SqlParameter() { ParameterName = "@size", Value = size, SqlDbType = SqlDbType.Int });

            if (!string.IsNullOrEmpty(sortDir))
            {
                command.Parameters.Add(new SqlParameter() { ParameterName = "@sortDir", Value = sortDir, SqlDbType = SqlDbType.VarChar });
            }

            if (!string.IsNullOrEmpty(sortBy))
            {
                command.Parameters.Add(new SqlParameter() { ParameterName = "@sortBy", Value = sortBy, SqlDbType = SqlDbType.VarChar });
            }

            var totalCountParam = new SqlParameter()
            {
                ParameterName = "@totalCount",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };
            command.Parameters.Add(totalCountParam);

            if (status != null)
            {
                command.Parameters.Add(new SqlParameter { ParameterName = "@status", Value = status, SqlDbType = SqlDbType.VarChar });
            }

            if (section != null)
            {
                command.Parameters.Add(new SqlParameter { ParameterName = "@section", Value = section, SqlDbType = SqlDbType.VarChar });
            }

            if (trainingCentreIDs != null)
            {
                command.Parameters.Add(new SqlParameter { ParameterName = "@trainingCentreIDs", Value = trainingCentreIDs, SqlDbType = SqlDbType.VarChar });
            }


            return command;
        }
    }
}
