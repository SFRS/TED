﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    public class InstructorUnavailableReasonGroupsService : CrudService<InstructorUnavailableReasonGroup>, IInstructorUnavailableReasonGroupsService
    {
        public InstructorUnavailableReasonGroupsService(IRepository<InstructorUnavailableReasonGroup> repository)
            : base(repository)
        {
        }
    }

}
