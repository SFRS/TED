using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;

namespace SFR.TOR.Data.Services
{
    public class ActivityPartTypeService : CrudService<ActivityPartType>, IActivityPartTypeService
    {
        public ActivityPartTypeService(IRepository<ActivityPartType> repository) : base(repository) { }
    }
}