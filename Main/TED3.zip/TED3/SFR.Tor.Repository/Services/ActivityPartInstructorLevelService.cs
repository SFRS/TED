using System.Linq;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    public class ActivityPartInstructorLevelService : CrudService<ActivityPartInstructorLevel>, IActivityPartInstructorLevelService
    {
        public ActivityPartInstructorLevelService(IRepository<ActivityPartInstructorLevel> repository) : base(repository) { }

        public IQueryable<ActivityPartInstructorLevelModel> GetActivityPartInstructorLevelList(int ActivityID)
        {
            IQueryable<ActivityPartInstructorLevelModel> apLevels =
                SelectFilteredList(x => x.ActivityPart.Activity.ID == ActivityID)
                .Select(x => new ActivityPartInstructorLevelModel()
                    {
                        ID = x.ID,
                        Name = x.ActivityPart.Name,
                        LeadsCount = x.LeadsCount,
                        AssessorCount = x.AssessorCount,
                        InstructorCount = x.InstructorCount,
                        SpecialistCount = x.SpecialistCount,
                        ShadowCount = x.ShadowCount
                    });

            return apLevels;
        }
    }
}