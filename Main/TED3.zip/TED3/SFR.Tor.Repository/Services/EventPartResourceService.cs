using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Objects.SqlClient;
using System.Linq;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.Utility;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    public class EventPartResourceService : CrudService<EventPart>, IEventPartResourceService
    {
        public EventPartResourceService(IRepository<EventPart> repository) : base(repository) { }

        public IQueryable<InstructorActivityDayPartModel> GetAllInstructorActivityDayParts(int ActivityID, int? TrainingCentreID)
        {
            // note: this is a quite complex EF query that is quite difficult to read. May need to look at simplifying it. 
            // The alternative would be to write a stored proc for this. Doing it with EF however gives us automatic paging 
            // out the box with AsQueryable and JQGrid. Should the SQL query generated cause performance issues we can look 
            // at creating a stored proc with custom paging instead

            var instructors = Container.Instructors.AsQueryable();
            if (TrainingCentreID != -1)
            {
                instructors = instructors.Where(x => x.TrainingCentreID == TrainingCentreID);
            }

            //first get all instructors for which there is data on them being eligible to run an activity
            var iaInstructorActivityDayPartModels = (from i in instructors
                                                     join eia in Container.EligibleInstructorsForActivities
                                                         on i.ID equals eia.InstructorID into lj2
                                                     from x2 in lj2.DefaultIfEmpty()
                                                     join s in Container.Sections
                                                         on i.SectionID equals s.ID
                                                     where x2.ActivityTemplateID == ActivityID
                                                     select new InstructorActivityDayPartModel
                                                     {
                                                         ID = i.ID,
                                                         Name = i.FirstName + " " + i.LastName,
                                                         SectionTitle = s.Title,
                                                         IsLead = x2.IsLead,
                                                         IsAssessor = x2.IsAssessor,
                                                         IsInstructor = x2.IsInstructor,
                                                         IsShadow = x2.IsShadow,
                                                         IsSpecialist = x2.IsSpecialist
                                                     }
                                                    ).Union
                (   //then add all the other instructors with defaults for the eligibility checkboxes
                (from i in instructors 
                 join s in Container.Sections
                     on i.SectionID equals s.ID
                 select new InstructorActivityDayPartModel
                 {
                     ID = i.ID,
                     Name = i.FirstName + " " + i.LastName,
                     SectionTitle = s.Title,
                     IsLead = false,
                     IsAssessor = false,
                     IsInstructor = false,
                     IsShadow = false,
                     IsSpecialist = false
                 }).Except( //miss out the ones selected in the first part of the query
                    from i in instructors 
                    join eia in Container.EligibleInstructorsForActivities
                        on i.ID equals eia.InstructorID into lj2
                    from x2 in lj2.DefaultIfEmpty()
                    join s in Container.Sections
                        on i.SectionID equals s.ID
                    where x2.ActivityTemplateID == ActivityID
                    select new InstructorActivityDayPartModel 
                    {
                        ID = i.ID,
                        Name = i.FirstName + " " + i.LastName,
                        SectionTitle = s.Title,
                        IsLead = false,
                        IsAssessor = false,
                        IsInstructor = false,
                        IsShadow = false,
                        IsSpecialist = false
                    }
                    )
                );

            return iaInstructorActivityDayPartModels;
        }

        public IQueryable<InstructorAvailabilityModel> 
            GetInstructorsAvailabilityByDate(DateTime? date, int dayType, int activityID, int dayPartID, int[] trainingCentreIDs)
        {
            var instructors = Container.Instructors.AsQueryable();
            // filter on instructors who have a Section on the supplied date i.e. they are active on that date
            instructors = instructors.Where(i => i.InstructorSectionHistories.Any(h => date >= h.StartDate && date <= (h.EndDate ?? date)));

            //all instructors who are working on the given date/dayType
            IQueryable<intermediaryModel> eps;
            
            eps = from iep in Container.InstructorEventParts
                    join ep in Container.EventParts                      
                    on iep.DayPartID equals ep.ID into lj2                      
                    from x2 in lj2.DefaultIfEmpty()
                    join e in Container.Events
                        on x2.EventID equals e.ID into lj3
                    from x3 in lj3.DefaultIfEmpty()
                    join i in instructors 
                        on iep.InstructorID equals i.ID into lj4
                    from x4 in lj4.DefaultIfEmpty()
                    where x2.Date == date
                        && x2.DayType == dayType
                    select new intermediaryModel
                    {
                        Name = x4.LastName + ", " + x4.FirstName,
                        InstructorID = iep.InstructorID,
                        Date = x2.Date.Value,
                        DayType = (int)x2.DayType,
                        Title = x3.Activity.Title + " " + x3.Activity.Code + " " 
                            + SqlFunctions.StringConvert((decimal)x3.EventNumber).TrimStart() + "/" 
                            + SqlFunctions.StringConvert((decimal)x3.FinanciaYear).TrimStart().Substring(2, 2),
                        Free = x2 == null
                    };            

            //include all other instructors
            var instructorsAvailability = from i in instructors 
                                          join e in eps
                                              on i.ID equals e.InstructorID into lj1
                                          from x1 in lj1.DefaultIfEmpty()
                                          select new
                                          {
                                              Name = i.LastName + ", " + i.FirstName,
                                              InstructorID = i.ID,
                                              Free = x1.Title == null,
                                              EventName = x1.Title,
                                              DayType = x1.DayType
                                          };

            // now filter by whether they can take the course
            var instAvailActivityInfo = from ia in instructorsAvailability
                                        join e in Container.EligibleInstructorsForActivities
                                            on ia.InstructorID equals e.InstructorID into lj1
                                        from x1 in lj1.DefaultIfEmpty()
                                        where x1.ActivityTemplateID == activityID
                                              && (
                                                     x1.IsAssessor ||
                                                     x1.IsInstructor ||
                                                     x1.IsLead ||
                                                     x1.IsShadow ||
                                                     x1.IsSpecialist
                                                 )
                                        select new 
                                        {
                                            ID = ia.InstructorID,
                                            Name = ia.Name,
                                            Free = ia.Free,
                                            EventName = ia.EventName,
                                            DayType = ia.DayType,
                                            IsLead = x1.IsLead,
                                            IsAssessor = x1.IsAssessor,
                                            IsInstructor = x1.IsInstructor,
                                            IsShadow = x1.IsShadow,
                                            IsSpecialist = x1.IsSpecialist,
                                            ActivityTemplateID = x1.ActivityTemplateID,
                                            DayPartID = dayPartID
                                        };

            var includeSelectedInstructors = from iaai in instAvailActivityInfo
                                             join iep in Container.InstructorEventParts
                                                 on
                                                 new { iaai.DayPartID, iaai.ID }
                                                 equals
                                                 new { iep.DayPartID, ID = iep.InstructorID }
                                                 into lj2
                                             from x1 in lj2.DefaultIfEmpty()
                                             select new 
                                             {
                                                 ID = iaai.ID, 
                                                 Name = iaai.Name,
                                                 Free = iaai.Free,
                                                 EventName = iaai.EventName + (x1.IsLead || x1.IsInstructor || x1.IsShadow || x1.IsAssessor || x1.IsSpecialist ? "(this event)" : ""),
                                                 DayType = iaai.DayType, 
                                                 IsLead = iaai.IsLead,
                                                 IsAssessor = iaai.IsAssessor,
                                                 IsInstructor = iaai.IsInstructor,
                                                 IsShadow = iaai.IsShadow,
                                                 IsSpecialist = iaai.IsSpecialist,
                                                 ActivityTemplateID = iaai.ActivityTemplateID, 
                                                 SelectedLead = x1.IsLead,
                                                 SelectedAssessor = x1.IsAssessor,
                                                 SelectedShadow = x1.IsShadow,
                                                 SelectedInstructor = x1.IsInstructor,
                                                 SelectedSpecialist = x1.IsSpecialist
                                             };

            var filteredUnavailability =
                Container.InstructorUnavailablePeriods.Where(
                    iup => date >= iup.StartDate && (date <= iup.EndDate || iup.EndDate == null)).Select(iup => new
                        {
                            iup.InstructorID,
                            iup.UnavailableReasonID,
                            iup.UnavailableReason.Reason,
                            DayTypeID = iup.DayTypeID == (int)EventPartTypeEnum.FullDay ? dayType : iup.DayTypeID
                            //we only care about daytype passed in, so can replace 3 (full day) with the dayType to search for
                        });

            filteredUnavailability = filteredUnavailability.Distinct(); //strip out any instances of unavailability on the same day

            var includePeriodsOfUnavailability = from isi in includeSelectedInstructors
                                                 join iup in filteredUnavailability 
                                                    on
                                                     new { dayType, isi.ID }
                                                     equals
                                                     new { dayType = iup.DayTypeID, ID = iup.InstructorID }
                                                     into lj1
                                                 from x1 in lj1.DefaultIfEmpty()     
                                                 //where isi.DayType == dayType
                                                 select new InstructorAvailabilityModel
                                                     {
                                                         ID = isi.ID,
                                                         Name = isi.Name,
                                                         Free = x1.UnavailableReasonID > 0 ? false : isi.Free,
                                                         EventName = x1.UnavailableReasonID > 0 ? "UNAVAILABLE: " + x1.Reason : isi.EventName,
                                                         DayType = isi.DayType,
                                                         IsLead = isi.IsLead,
                                                         IsAssessor = isi.IsAssessor,
                                                         IsInstructor = isi.IsInstructor,
                                                         IsShadow = isi.IsShadow,
                                                         IsSpecialist = isi.IsSpecialist,
                                                         ActivityTemplateID = isi.ActivityTemplateID,
                                                         SelectedLead = isi.SelectedLead,
                                                         SelectedInstructor = isi.SelectedInstructor,
                                                         SelectedAssessor = isi.SelectedAssessor,
                                                         SelectedShadow = isi.SelectedShadow,   
                                                         SelectedSpecialist = isi.SelectedSpecialist,
                                                         UnavailableReasonID = x1.UnavailableReasonID != null ? x1.UnavailableReasonID : 0
                                                     };


            var includePeriodsOfUnavailabilityList = includePeriodsOfUnavailability.ToList();
            PopulateTrainingCentreDetails(includePeriodsOfUnavailabilityList, trainingCentreIDs);

            return includePeriodsOfUnavailabilityList.AsQueryable();            
        }

        public IQueryable<VenueAvailabilityModel> GetVenuesAvailabilityByDate(EventPart eventPart, List<int> tagIDs, int[] trainingCentreIDs, bool includeAdditionalVenues = true)
        {

            var venues = Container.Venues.AsQueryable();
          
            //get all venues matching the tags we are searching for
            var matchingVenues = (from v in venues
                                  join vtv in Container.VenueTagVenues
                                  on v.ID equals vtv.VenueID
                                  join vep in Container.VenueEventParts
                                  on v.ID equals vep.VenueID 
                                  where
          //any additional venues that are not part of the activity template (added from within the event); 
          //If we are copying event venues, then we don't want to include any of the additional venues added that are not part of the activity template.
          includeAdditionalVenues ? (tagIDs.Contains(vtv.VenueTagID) || (vep.EventPart.ID == eventPart.ID && !vep.VenueTagID.HasValue))
                                  : (tagIDs.Contains(vtv.VenueTagID))
                                  select new
                                  {
                                      v.ID,
                                      v.Name,
                                  }).Distinct();

            //all venues who are used on the given date/dayType	
            var inUseVenues = from vep in Container.VenueEventParts
                              join ep in Container.EventParts
                                on vep.DayPartID equals ep.ID into lj2
                              from x2 in lj2.DefaultIfEmpty()
                              join e in Container.Events
                                  on x2.EventID equals e.ID into lj3
                              from x3 in lj3.DefaultIfEmpty()
                              join v in venues
                                  on vep.VenueID equals v.ID into lj4
                              from x4 in lj4.DefaultIfEmpty()
                              where x2.Date == eventPart.Date 
                                      && x2.DayType == eventPart.DayType
                              select new
                              {
                                  x4.ID,
                                  Name = x4.Name,
                                  VenueID = vep.VenueID,
                                  Date = x2.Date.Value,
                                  EventName = x3.Activity.Title + " " + x3.Activity.Code + " "
                                                + SqlFunctions.StringConvert((decimal)x3.EventNumber).TrimStart() + "/"
                                                + SqlFunctions.StringConvert((decimal)x3.FinanciaYear).TrimStart().Substring(2, 2),
                                  DayType = x2.DayType,
                                  Free = x2 == null
                              };

            //all matching venues with any details of courses they are already involved in
            var summaryWithDetailsOfOtherCourses = from m in matchingVenues
                                                   join u in inUseVenues
                                                   on m.ID equals u.ID into lj1
                                                   from x1 in lj1.DefaultIfEmpty()
                                                   select new
                                                   {
                                                       m.ID,
                                                       m.Name,
                                                       x1.EventName,
                                                       Free = ((bool?)x1.Free) ?? true,
                                                       DayPartID = eventPart.ID,
                                                       
                                                   };
           
            //now get details if the venues are already booked by the event part we are searching against
            var final = from s in summaryWithDetailsOfOtherCourses
                        join vep in Container.VenueEventParts
                        on
                        new { s.DayPartID, s.ID }
                    equals
                        new { vep.DayPartID, ID = vep.VenueID }
                    into lj1
                        from x1 in lj1.DefaultIfEmpty()
                        select new 
                        {
                            ID = s.ID,
                            Venue = s.Name,
                            EventName = s.EventName  + (x1 != null ? "(this event)" : ""),
                            Free = s.Free,
                            Booked = x1 != null,
                            VenueTag = x1.VenueTag.Name,
                            NeedsCatering = x1.NeedsCatering,
                            VenueTagID = x1.VenueTag.ID
                            
                        };

            var filteredUnavailability = from vup in Container.VenueUnavailablePeriods
                                         where eventPart.Date >= vup.StartDate && (eventPart.Date <= vup.EndDate || vup.EndDate == null)
                                         select new
                                         {
                                             vup.VenueID,
                                             vup.VenueUnavailableReasonID,
                                             vup.VenuesUnavailableReason.Reason,
                                             DayTypeID = vup.DayTypeID == 3 ? eventPart.DayType : vup.DayTypeID
                                         };

            filteredUnavailability = filteredUnavailability.Distinct(); //strip out any instances of unavailability on the same day

            var includePeriodsOfUnavailability = from f in final
                                                 join iup in filteredUnavailability                                                 
                                                 on
                                                 new { DayTypeID = eventPart.DayType, f.ID }
                                                 equals
                                                 new { iup.DayTypeID, ID = iup.VenueID }
                                                 into lj1
                                                 from x1 in lj1.DefaultIfEmpty()
                                                 select new VenueAvailabilityModel
                                                 {
                                                     ID = f.ID,
                                                     Venue = f.Venue,
                                                     Free = x1.VenueUnavailableReasonID > 0 ? false : f.Free,
                                                     EventName = x1.VenueUnavailableReasonID > 0 ? "UNAVAILABLE: " + x1.Reason : f.EventName,
                                                     Booked = f.Booked,
                                                     VenueTag = f.VenueTag,
                                                     VenueTagID = f.VenueTagID,
                                                     VenueUnavailableReasonID = x1.VenueUnavailableReasonID != null ? x1.VenueUnavailableReasonID : 0,
                                                     NeedsCatering = f.NeedsCatering
                                                 };

            var includePeriodsOfUnavailabilityList = includePeriodsOfUnavailability.ToList();
            PopulateTrainingCentreDetails(includePeriodsOfUnavailabilityList, trainingCentreIDs);

            return includePeriodsOfUnavailabilityList.AsQueryable();
            
        }

        public InstructorNumbersModel GetInstructorNumbers(int eventPartID)
        {
            var activityPartID = Container.EventParts.First(ep => ep.ID == eventPartID).ActivityPartID;

            var inm = new InstructorNumbersModel
                        {
                            RequiredAssessorCount = Container.ActivityPartInstructorLevels
                                                    .First(x => x.ActivityPartID == activityPartID).AssessorCount,
                            RequiredInstructorCount = Container.ActivityPartInstructorLevels
                                                    .First(x => x.ActivityPartID == activityPartID).InstructorCount,
                            RequiredLeadCount = Container.ActivityPartInstructorLevels
                                                    .First(x => x.ActivityPartID == activityPartID).LeadsCount,
                            RequiredShadowCount = Container.ActivityPartInstructorLevels
                                                    .First(x => x.ActivityPartID == activityPartID).ShadowCount,
                            RequiredSpecialistCount = Container.ActivityPartInstructorLevels
                                                    .First(x => x.ActivityPartID == activityPartID).SpecialistCount,
                            SelectedAssessorCount = Container.InstructorEventParts
                                                    .Count(x => x.DayPartID == eventPartID && x.IsAssessor),
                            SelectedInstructorCount = Container.InstructorEventParts
                                                    .Count(x => x.DayPartID == eventPartID && x.IsInstructor),
                            SelectedLeadCount = Container.InstructorEventParts
                                                    .Count(x => x.DayPartID == eventPartID && x.IsLead),
                            SelectedShadowCount = Container.InstructorEventParts
                                                    .Count(x => x.DayPartID == eventPartID && x.IsShadow),
                            SelectedSpecialistCount = Container.InstructorEventParts
                                                    .Count(x => x.DayPartID == eventPartID && x.IsSpecialist)
                        };
            
            return inm;
        }

        public IQueryable<EquipmentAvailabilityModel> GetEquipmentAvailabilityByDate(EventPart eventPart, List<int> tagIDs, int[] trainingCentreIDs, bool includeAdditionalEquipment = true)
        {
            //first, filter by training centre ID
            var equipment = Container.Equipments.AsQueryable();

            if (trainingCentreIDs.Any())
            {
                equipment = equipment.Where(x => trainingCentreIDs.Contains(x.TrainingCentreID));
            }

            //get all equipment matching the tags we are searching for
            var matchingEquipment = (from e in equipment 
                                  join ete in Container.EquipmentTagEquipments
                                    on e.ID equals ete.EquipmentID
                                  join eep in Container.EquipmentEventParts
                                    on e.ID equals eep.EquipmentID
                                  where 
       //any additional venues that are not part of the activity template (added from within the event); 
       //If we are copying event venues, then we don't want to include any of the additional venues added that are not part of the activity template.
       includeAdditionalEquipment ? (tagIDs.Contains(ete.EquipmentTagID) || (eep.EventPart.ID == eventPart.ID && !eep.EquipmentTagID.HasValue))
                                  : (tagIDs.Contains(ete.EquipmentTagID))
                                  select new
                                  {
                                      e.ID,
                                      e.Name,
                                  }).Distinct();

            //all equipment that is used on the given date/dayType	
            var inUseEquipment = from e in equipment 
                                 join eep in Container.EquipmentEventParts
                                  on e.ID equals eep.EquipmentID into lj1
                                 from x1 in lj1.DefaultIfEmpty()
                              join ep in Container.EventParts
                                on x1.DayPartID equals ep.ID into lj2
                              from x2 in lj2.DefaultIfEmpty()
                              join e in Container.Events
                                  on x2.EventID equals e.ID into lj3
                              from x3 in lj3.DefaultIfEmpty()
                              join e in Container.Equipments
                                  on x1.EquipmentID equals e.ID into lj4
                              from x4 in lj4.DefaultIfEmpty()
                              where x2.Date == eventPart.Date
                                      && x2.DayType == eventPart.DayType
                              select new
                              {
                                  x4.ID,
                                  Name = x4.Name,
                                  EquipmentID = x1.EquipmentID,
                                  Date = x2.Date.Value,
                                  EventName = x3.Activity.Title + " " + x3.Activity.Code + " "
                                                + SqlFunctions.StringConvert((decimal)x3.EventNumber).TrimStart() + "/"
                                                + SqlFunctions.StringConvert((decimal)x3.FinanciaYear).TrimStart().Substring(2, 2),
                                  DayType = x2.DayType,
                                  Free = x2 == null
                              };

            //all matching equipment with any details of courses they are already involved in
            var summaryWithDetailsOfOtherCourses = from m in matchingEquipment
                                                   join u in inUseEquipment
                                                   on m.ID equals u.ID into lj1
                                                   from x1 in lj1.DefaultIfEmpty()
                                                   select new
                                                   {
                                                       m.ID,
                                                       m.Name,
                                                       x1.EventName,
                                                       Free = ((bool?)x1.Free) ?? true,
                                                       DayPartID = eventPart.ID,
                                                   };

            //now get details if the equipment is already booked by the event part we are searching against
            var final = from s in summaryWithDetailsOfOtherCourses
                        join eep in Container.EquipmentEventParts
                        on
                        new { s.DayPartID, s.ID }
                    equals
                        new { eep.DayPartID, ID = eep.EquipmentID }
                    into lj1
                        from x1 in lj1.DefaultIfEmpty()
                        select new 
                        {
                            ID = s.ID,
                            Equipment = s.Name,
                            EventName = s.EventName + (x1 != null ? "(this event)" : ""),
                            Free = s.Free,
                            Booked = x1 != null,
                            EquipmentTag = x1.EquipmentTag.Name,
                            ActivityTemplateID = s.DayPartID,
                            EquipmentTagID = x1.EquipmentTag.ID
                        };

            var filteredUnavailability = from eup in Container.EquipmentUnavailablePeriods
                                         where eventPart.Date >= eup.StartDate && (eventPart.Date <= eup.EndDate || eup.EndDate == null)
                                         select new
                                         {
                                             eup.EquipmentID,
                                             eup.EquipmentUnavailableReasonID,
                                             eup.EquipmentUnavailableReason.Reason,
                                             DayTypeID = eup.DayTypeID == 3 ? eventPart.DayType : eup.DayTypeID
                                         };

            filteredUnavailability = filteredUnavailability.Distinct(); //strip out any instances of unavailability on the same day

            var includePeriodsOfUnavailability = from f in final
                                                 join iup in filteredUnavailability
                                                 //on f.ID equals iup.EquipmentID into lj1
                                                 on
                                                 new { DayTypeID = eventPart.DayType, f.ID }
                                                 equals
                                                 new { iup.DayTypeID, ID = iup.EquipmentID }
                                                 into lj1
                                                 from x1 in lj1.DefaultIfEmpty()
                                                 select new EquipmentAvailabilityModel
                                                 {
                                                     ID = f.ID,
                                                     Equipment = f.Equipment,
                                                     Free = x1.EquipmentUnavailableReasonID > 0 ? false : f.Free,
                                                     EventName = x1.EquipmentUnavailableReasonID > 0 ? "UNAVAILABLE: " + x1.Reason : f.EventName,
                                                     Booked = f.Booked,                                                
                                                     EquipmentTag = f.EquipmentTag,
                                                     EquipmentTagID = f.EquipmentTagID,
                                                     EquipmentUnavailableReasonID = x1.EquipmentUnavailableReasonID != null ? x1.EquipmentUnavailableReasonID : 0
                                                 };

            var includePeriodsOfUnavailabilityList = includePeriodsOfUnavailability.ToList();
            PopulateTrainingCentreDetails(includePeriodsOfUnavailabilityList, trainingCentreIDs);

            return includePeriodsOfUnavailabilityList.AsQueryable();
        }

        private void PopulateTrainingCentreDetails(IList<InstructorAvailabilityModel> instructorAvailabilityModels, int[] trainingCentreIds)
        {
            if (instructorAvailabilityModels == null)
                return;

            var instructorIds = instructorAvailabilityModels.ToList().Select(iam => iam.ID);
            
            var instructors = from instructor in Container.Instructors
                                    join trainingCentre in Container.TrainingCentres
                                  on instructor.TrainingCentreID equals trainingCentre.ID
                              where instructorIds.Contains(instructor.ID)
                              select new
                              {
                                 Id = instructor.ID,
                                 TrainingCentreId = trainingCentre.ID,
                                 TrainingCentreName = trainingCentre.Name
                              };

            var toDelete = new List<InstructorAvailabilityModel>();

            foreach (var instructorAvailabilityModel in instructorAvailabilityModels)
            {
                var ins = instructors.FirstOrDefault(i => i.Id == instructorAvailabilityModel.ID);
                if (ins == null)
                    continue;

                if (trainingCentreIds == null || trainingCentreIds.Length == 0 ||
                    trainingCentreIds.Contains(ins.TrainingCentreId) || 
                    instructorAvailabilityModel.SelectedAssessor.GetValueOrDefault(false) ||
                    instructorAvailabilityModel.SelectedInstructor.GetValueOrDefault(false) ||
                    instructorAvailabilityModel.SelectedLead.GetValueOrDefault(false) ||
                    instructorAvailabilityModel.SelectedShadow.GetValueOrDefault(false) ||
                    instructorAvailabilityModel.SelectedSpecialist.GetValueOrDefault(false))
                {
                     instructorAvailabilityModel.TrainingCentreId = ins.TrainingCentreId;
                    instructorAvailabilityModel.TrainingCentreName = ins.TrainingCentreName;
                } 
                else
                {
                    toDelete.Add(instructorAvailabilityModel);
                }

                
            }

            foreach (var availabilityModel in toDelete)
            {
                instructorAvailabilityModels.Remove(availabilityModel);
            }
               
        }

        private void PopulateTrainingCentreDetails(IList<VenueAvailabilityModel> venueAvailabilityModels, int[] trainingCentreIds)
        {
            if (venueAvailabilityModels == null)
                return;
            var venueIds = venueAvailabilityModels.ToList().Select(iam => iam.ID);
            
            var venues = from venue in Container.Venues
                              join trainingCentre in Container.TrainingCentres
                            on venue.TrainingCentreID equals trainingCentre.ID
                         where venueIds.Contains(venue.ID)
                              select new
                              {
                                  Id = venue.ID,
                                  TrainingCentreId = trainingCentre.ID,
                                  TrainingCentreName = trainingCentre.Name
                              };

            var toDelete = new List<VenueAvailabilityModel>();

            foreach (var venueAvailabilityModel in venueAvailabilityModels)
            {
                var ins = venues.FirstOrDefault(i => i.Id == venueAvailabilityModel.ID);
                if (ins == null)
                    continue;

                if (trainingCentreIds == null || trainingCentreIds.Length == 0 ||
                   trainingCentreIds.Contains(ins.TrainingCentreId) ||
                   venueAvailabilityModel.Booked.GetValueOrDefault(false))
                {
                    venueAvailabilityModel.TrainingCentreId = ins.TrainingCentreId;
                    venueAvailabilityModel.TrainingCentreName = ins.TrainingCentreName;
                }
                else
                {
                    toDelete.Add(venueAvailabilityModel);
                }
                venueAvailabilityModel.TrainingCentreId = ins.TrainingCentreId;
                venueAvailabilityModel.TrainingCentreName = ins.TrainingCentreName;
            }

            foreach (var availabilityModel in toDelete)
            {
                venueAvailabilityModels.Remove(availabilityModel);
            }
        }

        private void PopulateTrainingCentreDetails(IList<EquipmentAvailabilityModel> equipmentAvailabilityModels, int[] trainingCentreIds)        
        {
            if (equipmentAvailabilityModels == null)
                return;
            var venueIds = equipmentAvailabilityModels.ToList().Select(iam => iam.ID);
          
            var equips = from equip in Container.Equipments
                         join trainingCentre in Container.TrainingCentres
                       on equip.TrainingCentreID equals trainingCentre.ID
                         where venueIds.Contains(equip.ID)
                         select new
                         {
                             Id = equip.ID,
                             TrainingCentreId = trainingCentre.ID,
                             TrainingCentreName = trainingCentre.Name
                         };

            var toDelete = new List<EquipmentAvailabilityModel>();

            foreach (var equipAvailabilityModel in equipmentAvailabilityModels)
            {
                var ins = equips.FirstOrDefault(i => i.Id == equipAvailabilityModel.ID);
                if (ins == null)
                    continue;

                if (trainingCentreIds == null || trainingCentreIds.Length == 0 ||
                   trainingCentreIds.Contains(ins.TrainingCentreId) ||
                   equipAvailabilityModel.Booked.GetValueOrDefault(false))
                {
                    equipAvailabilityModel.TrainingCentreId = ins.TrainingCentreId;
                    equipAvailabilityModel.TrainingCentreName = ins.TrainingCentreName;
                }
                else
                {
                    toDelete.Add(equipAvailabilityModel);
                }

               
            }

            foreach (var availabilityModel in toDelete)
            {
                equipmentAvailabilityModels.Remove(availabilityModel);
            }
        }
    }

    public class intermediaryModel
    {
        public string Name { get; set; }

        public int InstructorID { get; set; }

        public DateTime Date { get; set; }

        public string EventName { get; set; }

        public int DayType { get; set; }

        public string Title { get; set; }

        public bool Free { get; set; }
    }
}