﻿using System.Linq;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for EquipmentUnavailablePeriod data access
    /// </summary>
    public class EquipmentUnavailablePeriodService : CrudService<EquipmentUnavailablePeriod>, IEquipmentUnavailablePeriodService
    {
        public EquipmentUnavailablePeriodService(IRepository<EquipmentUnavailablePeriod> repository) : base(repository)
        {
        }

        public IQueryable<EquipmentEditAvailabilityModel> GetUnavailabilityReasons(int id)
        {
            var periods = from y in SelectFilteredList(x => x.EquipmentID == id)
                          select new EquipmentEditAvailabilityModel
                          {
                              ID = y.ID,
                              EquipmentID = y.EquipmentID,
                              StartDate = y.StartDate,
                              //StartTime = y.StartTime.Value,
                              EndDate = y.EndDate,
                              //EndTime = y.EndTime,
                              EquipmentUnavailableReasonID = y.EquipmentUnavailableReasonID,
                              DayTypeID = y.DayTypeID,
                              Comments = y.Comments
                          };

            return periods;

        }
    }
}