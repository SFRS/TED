﻿using System;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.Utility.Security;

namespace SFR.TOR.Data.Services
{
    public class TORUnitOfWork : UnitOfWork<TORContainer>, ITORUnitOfWork
    {
        public ISectionService SectionService { get; set; }
        private Lazy<ISectionService> _sections;
        private Lazy<IEventStatusService> _eventStatus;
        private Lazy<ICalendarService> _calendars;
        private Lazy<IReportService> _reports;
        private Lazy<IInstructorService> _instructors;
        private Lazy<IVenueService> _venues;
        private Lazy<IEventService> _events;
        private Lazy<IEquipmentService> _equipment;
        private Lazy<IActivityService> _activities;
        private Lazy<IActivityPartTypeService> _activityPartType;
        private Lazy<IEventPartResourceService> _instructorDayPart;
        private Lazy<IEligibleInstructorsForActivityService> _eligibleInstructorsForActivity;
        private Lazy<IActivityPartService> _activityPart;
        private Lazy<IActivityPartInstructorLevelService> _activityPartInstructorLevel;
        private Lazy<IVenueTagService> _venueTags;
        private Lazy<IVenueTagActivityPartService> _venueTagActivityPart;
        private Lazy<IEquipmentTagService> _equipmentTags;
        private Lazy<IEquipmentTagActivityPartService> _equipmentTagActivityPart;
        private Lazy<IActivityStatusService> _activityStatus;
        private Lazy<IEventPartService> _eventParts;
        private Lazy<ICancelEventReasonService> _cancelReasons;
        private Lazy<IPostponeEventReasonService> _postponeReasons;
        private Lazy<IEventPostponedHistoryService> _eventPostponedHistory;
        private Lazy<IEventCancelledHistoryService> _eventCancelledHistory;
        private Lazy<IInstructorEventPartService> _instructorEventParts;
        private Lazy<IVenueEventPartService> _venueEventParts;
        private Lazy<IEventPriorityService> _eventPriorities;
        private Lazy<IEquipmentEventPartService> _equipmentEventParts;
        private Lazy<IEventPartTypeService> _eventPartTypes;
        private Lazy<IInstructorUnavailablePeriodService> _instructorUnavailablePeriods;
        private Lazy<IUnavailableReasonService> _unavailableReasons;
        private Lazy<IEventStatusHistoryService> _eventStatusHistory;
        private Lazy<IVenueUnavailablePeriodService> _venueUnavailablePeriod;
        private Lazy<IVenueUnavailableReasonService> _venueUnavailableReason;
        private Lazy<IUserService> _users;
        private Lazy<ITrainingCentreService> _trainingCentres;
        private Lazy<IEquipmentUnavailablePeriodService> _equipmentUnavailablePeriods;
        private Lazy<IEquipmentTagEquipmentService> _equipmentTagEquipments;
        private Lazy<IEquipmentUnavailableReasonService> _equipmentUnavailableReasons;
        private Lazy<IVenueTagVenueService> _venueTagVenues;
        private Lazy<IGroupService> _groups;
        private Lazy<IPinchpointService> _pinchpoints;
        private Lazy<IPinchpointReasonService> _pinchpointReasons;
        private Lazy<IPinchpointTypeService> _pinchpointTypes;
        private Lazy<IGroupCalendarService> _groupCalendars;
        private Lazy<IResourceStatusService> _resourceStatus;
        private Lazy<IVenueGroupService> _venueGroups;
        private Lazy<IEquipmentGroupService> _equipmentGroups;
        private Lazy<IInstructorUnavailableReasonGroupsService> _instructorUnavailableReasonGroups;
        private Lazy<IInstructorSectionHistoryService> _instructorSectionHistory;
        private Lazy<IITrentExportService> _iTrentExport;
        private Lazy<IITrentExportDataService> _iTrentExportDatas;
        private Lazy<IITrentExportTypeService> _iTrentExportTypes;
        private Lazy<IITrentExportErrorsService> _iTrentExportErrors;
        private Lazy<IITrentImportFailuresService> _iTrentImportFailures;

        public IITrentImportFailuresService iTrentImportFailures
        {
            get
            {
                return _iTrentImportFailures.Value;
            }
        }

        public IITrentExportErrorsService iTrentExportErrors
        {
            get
            {
                return _iTrentExportErrors.Value;
            }
        }

        public IITrentExportDataService iTrentExportDatas
        {
            get
            {
                return _iTrentExportDatas.Value;
            }
        }

        public IITrentExportTypeService iTrentExportTypes
        {
            get
            {
                return _iTrentExportTypes.Value;
            }
        }

        public IITrentExportService iTrentExports
        {
            get
            {
                return _iTrentExport.Value;
            }
        }

        public IInstructorSectionHistoryService InstructorSectionHistories
        {
            get
            {
                return _instructorSectionHistory.Value;
            }
        }

        public IInstructorUnavailableReasonGroupsService InstructorUnavailableReasonGroups
        {
            get
            {
                return _instructorUnavailableReasonGroups.Value;
            }
        }

        public IEquipmentGroupService EquipmentGroups
        {
            get
            {
                return _equipmentGroups.Value;
            }
        }

        public IResourceStatusService ResourceStatus
        {
            get
            {
                return _resourceStatus.Value;
            }
        }


        public IGroupCalendarService GroupCalendars
        {
            get
            {
                return _groupCalendars.Value;
            }
        }


        public IPinchpointTypeService PinchpointTypes
        {
            get
            {
                return _pinchpointTypes.Value;
            }
        }

        public IPinchpointReasonService PinchpointReasons
        {
            get
            {
                return _pinchpointReasons.Value;
            }
        }

        public IPinchpointService Pinchpoints
        {
            get
            {
                return _pinchpoints.Value;
            }
        }

        public IGroupService Groups
        {
            get
            {
                return _groups.Value;
            }
        }

        public IVenueTagVenueService VenueTagVenues
        {
            get
            {
                return _venueTagVenues.Value;
            }
        }

        public IEquipmentUnavailableReasonService EquipmentUnavailableReasons
        {
            get
            {
                return _equipmentUnavailableReasons.Value;
            }
        }

        public IEquipmentTagEquipmentService EquipmentTagEquipment
        {
            get
            {
                return _equipmentTagEquipments.Value;
            }
        }

        public IEquipmentUnavailablePeriodService EquipmentUnavailablePeriods
        {
            get
            {
                return _equipmentUnavailablePeriods.Value;
            }
        }

        public IVenueUnavailablePeriodService VenueUnavailablePeriod
        {
            get
            {
                return _venueUnavailablePeriod.Value;
            }
        }

        public IVenueUnavailableReasonService VenueUnavailableReason
        {
            get
            {
                return _venueUnavailableReason.Value;
            }
        }

        public ITrainingCentreService TrainingCentres
        {
            get
            {
                return _trainingCentres.Value;
            }
        }
        public IUserService Users
        {
            get
            {
                return _users.Value;
            }
        }


        public IEventStatusHistoryService EventStatusHistory
        {
            get
            {
                return _eventStatusHistory.Value;
            }
        }
        public IUnavailableReasonService UnavailableReasons
        {
            get
            {
                return _unavailableReasons.Value;
            }
        }
        public IInstructorUnavailablePeriodService InstructorUnavailablePeriods
        {
            get
            {
                return _instructorUnavailablePeriods.Value;
            }
        }
        
        public IEventPartTypeService EventPartTypes
        {
            get
            {
                return _eventPartTypes.Value;
            }
        }
        public IEquipmentEventPartService EquipmentEventParts
        {
            get
            {
                return _equipmentEventParts.Value;
            }
        }
        public IVenueEventPartService VenueEventParts
        {
            get
            {
                return _venueEventParts.Value;
            }
        }
        public IEventPriorityService EventPriorities
        {
            get
            {
                return _eventPriorities.Value;
            }
        }
        public IEventCancelledHistoryService EventCancelledHistory
        {
            get
            {
                return _eventCancelledHistory.Value;
            }
        }
        public IInstructorEventPartService InstructorEventPart {

            get
            {
                return _instructorEventParts.Value;
            }
        }

        public IEventPostponedHistoryService EventPostponedHistory
        {
            get{return _eventPostponedHistory.Value;}
        }

        public IEquipmentTagService EquipmentTags
        {
            get { return _equipmentTags.Value; }
        }

        public IEquipmentTagActivityPartService EquipmentTagActivityPart
        {
            get { return _equipmentTagActivityPart.Value; }
        }

        public IActivityStatusService ActivityStatus
        {
            get { return _activityStatus.Value; }
        }

        public IEventPartService EventParts
        {
            get { return _eventParts.Value; }
        }

        public ICancelEventReasonService CancelEventReasons
        {
            get { return _cancelReasons.Value; }
        }

        public IPostponeEventReasonService PostponeEventReasons
        {
            get { return _postponeReasons.Value; }
        }

        public IActivityPartInstructorLevelService ActivityPartInstructorLevel
        {
            get { return _activityPartInstructorLevel.Value; }
        }

        public IVenueTagService VenueTags
        {
            get { return _venueTags.Value; }
        }

        public IVenueTagActivityPartService VenueTagActivityPart
        {
            get { return _venueTagActivityPart.Value; }
        }

        public IActivityPartService ActivityDayPart
        {
            get { return _activityPart.Value; }
        }

        public IEligibleInstructorsForActivityService EligibleInstructorsForActivity
        {
            get { return _eligibleInstructorsForActivity.Value; }
        }

        public IActivityService Activities
        {
            get { return _activities.Value; }
        }

        public IEventService Events
        {
            get { return _events.Value; }
        }

        public IEquipmentService Equipment
        {
            get { return _equipment.Value; }
        }

        public IVenueService Venues
        {
            get { return _venues.Value; }
        }

        public ISectionService Sections
        {
           get { return _sections.Value; }
        }

        public IInstructorService Instructors
        {
            get { return _instructors.Value; }

        }

        public IEventStatusService EventStatus
        {
            get { return _eventStatus.Value; }
        }

        public IActivityPartTypeService ActivityPartTypes
        {
            get { return _activityPartType.Value; }
        }

        public IEventPartResourceService EventPartResources
        {
            get { return _instructorDayPart.Value; }
        }

        public ICalendarService Calendars
        {
            get { return _calendars.Value; }
        }

        public IReportService Reports
        {
            get { return _reports.Value; }
        }

        public IVenueGroupService VenueGroups
        {
            get { return _venueGroups.Value; }
        }

        public ITORSession Session
        {
            get { return Context.Session; }
            set { Context.Session = value; }
        }

        public TORUnitOfWork(ITORSession session) 
        {
            Session = session;

            _groups = new Lazy<IGroupService>(() => new GroupService(EntityRepositoryFor<Group>()), false);
            _equipmentTagEquipments = new Lazy<IEquipmentTagEquipmentService>(() => new EquipmentTagEquipmentService(EntityRepositoryFor<EquipmentTagEquipment>()), false);
            _equipmentUnavailablePeriods = new Lazy<IEquipmentUnavailablePeriodService>(() => new EquipmentUnavailablePeriodService(EntityRepositoryFor<EquipmentUnavailablePeriod>()), false);
            _trainingCentres = new Lazy<ITrainingCentreService>(() => new TrainingCentreService(EntityRepositoryFor<TrainingCentre>()), false);
            _users = new Lazy<IUserService>(() => new UserService(EntityRepositoryFor<User>()), false);
            _eventStatusHistory = new Lazy<IEventStatusHistoryService>(() => new EventStatusHistoryService(EntityRepositoryFor<EventStatusHistory>()), false);
            _unavailableReasons = new Lazy<IUnavailableReasonService>(() => new UnavailableReasonService(EntityRepositoryFor<UnavailableReason>()), false);
            _instructorUnavailablePeriods = new Lazy<IInstructorUnavailablePeriodService>(() => new InstructorUnavailablePeriodService(EntityRepositoryFor<InstructorUnavailablePeriod>()), false);
            _sections = new Lazy<ISectionService>(() => new SectionService(EntityRepositoryFor<Section>()), false);
            _eventStatus = new Lazy<IEventStatusService>(() => new EventStatusService(EntityRepositoryFor<EventStatus>()), false);
            _calendars = new Lazy<ICalendarService>(() => new CalendarService(), false);
            _reports = new Lazy<IReportService>(() => new ReportService(), false);
            _instructors = new Lazy<IInstructorService>(() => new InstructorService(EntityRepositoryFor<Instructor>()), false);
            _venues = new Lazy<IVenueService>(() => new VenueService(EntityRepositoryFor<Venue>()), false);
            _equipment = new Lazy<IEquipmentService>(() => new EquipmentService(EntityRepositoryFor<Equipment>()), false);
            _events = new Lazy<IEventService>(() => new EventService(EntityRepositoryFor<Event>()), false);
            _activities = new Lazy<IActivityService>(() => new ActivityService(EntityRepositoryFor<Activity>()), false);
            _activityPartType = new Lazy<IActivityPartTypeService>(() => new ActivityPartTypeService(EntityRepositoryFor<ActivityPartType>()), false);
            _instructorDayPart = new Lazy<IEventPartResourceService>(() => new EventPartResourceService(EntityRepositoryFor<EventPart>()), false);
            _eligibleInstructorsForActivity = new Lazy<IEligibleInstructorsForActivityService>(() => new EligibleInstructorsForActivityService(EntityRepositoryFor<EligibleInstructorsForActivity>()), false);
            _activityPart = new Lazy<IActivityPartService>(() => new ActivityPartService(EntityRepositoryFor<ActivityPart>()), false);
            _activityPartInstructorLevel = new Lazy<IActivityPartInstructorLevelService>(() => new ActivityPartInstructorLevelService(EntityRepositoryFor<ActivityPartInstructorLevel>()), false);
            _venueTags = new Lazy<IVenueTagService>(() => new VenueTagService(EntityRepositoryFor<VenueTag>()), false);
            _venueTagActivityPart = new Lazy<IVenueTagActivityPartService>(() => new VenueTagActivityPartService(EntityRepositoryFor<VenueTagActivityPart>()), false);
            _equipmentTags = new Lazy<IEquipmentTagService>(() => new EquipmentTagService(EntityRepositoryFor<EquipmentTag>()), false);
            _equipmentTagActivityPart = new Lazy<IEquipmentTagActivityPartService>(() => new EquipmentTagActivityPartService(EntityRepositoryFor<EquipmentTagActivityPart>()), false);
            _activityStatus = new Lazy<IActivityStatusService>(() => new ActivityStatusService(EntityRepositoryFor<ActivityStatus>()), false);            
            _cancelReasons = new Lazy<ICancelEventReasonService>(() => new CancelEventReasonService(EntityRepositoryFor<CancelEventReason>()), false);
            _postponeReasons = new Lazy<IPostponeEventReasonService>(() => new PostponeEventReasonService(EntityRepositoryFor<PostponeEventReason>()), false);
            _eventPostponedHistory = new Lazy<IEventPostponedHistoryService>(() => new EventPostponedHistoryService(EntityRepositoryFor<EventPostponedHistory>()), false);
            _eventCancelledHistory = new Lazy<IEventCancelledHistoryService>(() => new EventCancelledHistoryService(EntityRepositoryFor<EventCancelledHistory>()), false);
            _eventParts = new Lazy<IEventPartService>(() => new EventPartService(EntityRepositoryFor<EventPart>()), false);
            _instructorEventParts = new Lazy<IInstructorEventPartService>(() => new InstructorEventPartService(EntityRepositoryFor<InstructorEventPart>()), false);
            _venueEventParts = new Lazy<IVenueEventPartService>(() => new VenueEventPartService(EntityRepositoryFor<VenueEventPart>()), false);
            _eventPriorities = new Lazy<IEventPriorityService>(() => new EventPriorityService(EntityRepositoryFor<EventPriority>()), false);
            _equipmentEventParts = new Lazy<IEquipmentEventPartService>(() => new EquipmentEventPartService(EntityRepositoryFor<EquipmentEventPart>()), false);
            _eventPartTypes = new Lazy<IEventPartTypeService>(() => new EventPartTypeService(EntityRepositoryFor<EventPartType>()), false);            
            _venueUnavailablePeriod = new Lazy<IVenueUnavailablePeriodService>(() => new VenueUnavailablePeriodService(EntityRepositoryFor<VenueUnavailablePeriod>()), false);
            _venueUnavailableReason = new Lazy<IVenueUnavailableReasonService>(() => new VenueUnavailableReasonService(EntityRepositoryFor<VenuesUnavailableReason>()), false);
            _equipmentUnavailableReasons = new Lazy<IEquipmentUnavailableReasonService>(() => new EquipmentUnavailableReasonService(EntityRepositoryFor<EquipmentUnavailableReason>()), false);
            _venueTagVenues = new Lazy<IVenueTagVenueService>(() => new VenueTagVenueService(EntityRepositoryFor<VenueTagVenue>()), false);
            _pinchpoints = new Lazy<IPinchpointService>(() => new PinchpointService(EntityRepositoryFor<Pinchpoint>()), false);
            _pinchpointReasons = new Lazy<IPinchpointReasonService>(() => new PinchpointReasonService(EntityRepositoryFor<PinchpointReason>()), false);
            _pinchpointTypes = new Lazy<IPinchpointTypeService>(() => new PinchpointTypeService(EntityRepositoryFor<PinchpointType>()), false);
            _groupCalendars = new Lazy<IGroupCalendarService>(() => new GroupCalendarService(EntityRepositoryFor<GroupCalendar>()), false);
            _resourceStatus = new Lazy<IResourceStatusService>(() => new ResourceStatusService(EntityRepositoryFor<ResourceStatus>()), false);
            _venueGroups = new Lazy<IVenueGroupService>(() => new VenueGroupService(EntityRepositoryFor<VenueGroup>()), false);
            _equipmentGroups = new Lazy<IEquipmentGroupService>(() => new EquipmentGroupService(EntityRepositoryFor<EquipmentGroup>()), false);
            _instructorUnavailableReasonGroups = new Lazy<IInstructorUnavailableReasonGroupsService>(() => new InstructorUnavailableReasonGroupsService(EntityRepositoryFor<InstructorUnavailableReasonGroup>()), false);
            _instructorSectionHistory = new Lazy<IInstructorSectionHistoryService>(() => new InstructorSectionHistoryService(EntityRepositoryFor<InstructorSectionHistory>()), false);
            _iTrentExport = new Lazy<IITrentExportService>(() => new iTrentExportService(EntityRepositoryFor<iTrentExport>()), false);
            _iTrentExportDatas = new Lazy<IITrentExportDataService>(() => new iTrentExportDataService(EntityRepositoryFor<iTrentExportData>()), false);
            _iTrentExportTypes = new Lazy<IITrentExportTypeService>(() => new iTrentExportTypeService(EntityRepositoryFor<iTrentExportType>()), false);
            _iTrentExportErrors = new Lazy<IITrentExportErrorsService>(() => new iTrentExportErrorsService(EntityRepositoryFor<iTrentExportError>()), false);
            _iTrentImportFailures = new Lazy<IITrentImportFailuresService>(() => new iTrentImportFailureService(EntityRepositoryFor<iTrentImportFailure>()), false);
        }
    }
}
