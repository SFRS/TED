﻿using System.Linq;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for Pinchpoint data access
    /// </summary>
    public class PinchpointService : CrudService<Pinchpoint>, IPinchpointService
    {
        public PinchpointService(IRepository<Pinchpoint> repository) : base(repository)
        {
        }

        public IQueryable<PinchpointModel> GetPinchpoints(int trainingCentreID)
        {
            var pps = from y in SelectFilteredList(x => x.TrainingCentreID == trainingCentreID)
                      select new PinchpointModel
                          {
                              ID = y .ID,
                              ReasonID = y.ReasonID,
                              StartDate = y.StartDate,
                              EndDate = y.EndDate,                              
                          };

            return pps;
        }
    }
}