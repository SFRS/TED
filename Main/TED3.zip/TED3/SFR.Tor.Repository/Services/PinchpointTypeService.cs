﻿using System.Linq;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for PinchpointType data access
    /// </summary>
    public class PinchpointTypeService : CrudService<PinchpointType>, IPinchpointTypeService
    {
        public PinchpointTypeService(IRepository<PinchpointType> repository) : base(repository)
        {
        }

        public IQueryable<PinchpointTypeModel> GetPinchpointTypes()
        {
            var pps = from y in SelectAll()
                      select new PinchpointTypeModel
                      {
                          ID = y.ID,
                          Name = y.TypeName                          
                      };

            return pps;
        }
    }
}