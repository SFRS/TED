using System;
using System.Collections.Generic;
using System.Data.Objects.SqlClient;
using System.Linq.Expressions;
using AutoMapper;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using System.Linq;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.Utility;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for Event data access
    /// </summary>
    public class EventService : CrudService<Event>, IEventService
    {
        public EventService(IRepository<Event> repository) : base(repository) { }

        public int NumberOfEventsInTimePeriod(DateTime? startDate, DateTime? endDate)
        {
            return SelectAll().Count(x => x.EventParts.Any(dp => dp.Date >= startDate.Value && dp.Date <= endDate.Value));           
        }

        public IQueryable<EventModel> GetEvents(Expression<Func<Event, bool>> predicate)
        {
            //can't use Automapper here as it interferes with paging in JQGrid, so revert to manual mapping to viewmodel
            IQueryable<EventModel> events = SelectFilteredList(predicate)
                .Select(x => new EventModel
                {
                    EventCode = x.Activity.Code + " "
                                + SqlFunctions.StringConvert((decimal)x.EventNumber).TrimStart() 
                                + "/" + SqlFunctions.StringConvert((decimal)x.FinanciaYear).TrimStart().Substring(2, 2),
                    Section = x.Activity.Section.Title,
                    TotalDays = x.TotalDays,
                    Title = x.Activity.Title,
                    ID = x.ID,
                    DaysReady =
                        x.EventParts.Count(ep => ep.Status == 3 && ep.DayType == 2) / 2.0 
                        + x.EventParts.Count(ep => ep.Status == 3 && ep.DayType == 1) / 2.0,
                    Priority = x.EventPriority.ID,
                    PriorityTitle = x.EventPriority.Title,
                    Resourced = x.ResourceStatus.Title,
                    Status = x.EventStatus.Title,
                    StatusID = x.Status,
                    StartDate = x.EventParts.Min(y => y.Date),
                    CancelReason = x.EventCancelledHistories
                        .OrderByDescending(h => h.CancelledOn)
                        .Select(h => (h.CancelEventReason != null ? h.CancelEventReason.Reason : null) + " - " + h.Reason)
                        .FirstOrDefault(),
                    FinancialYear = SqlFunctions.StringConvert((decimal)x.FinanciaYear).TrimStart()
                                    + "/"
                                    + SqlFunctions.StringConvert((decimal)x.FinanciaYear + 1).TrimStart().Substring(2, 2)
                });
            
            return events;
        }

        public EventModel GetEvent(Expression<Func<Event, bool>> predicate)
        {
            var a = SelectBy(predicate);

            var am = Mapper.Map<Event, EventModel>(a);

            if (am == null)
            {
                throw new Exception();
            }

            am.CancelReason = a.EventCancelledHistories
                .OrderByDescending(h => h.CancelledOn)
                .Select(h => (h.CancelEventReason != null ? h.CancelEventReason.Reason : null) + " - " + h.Reason)
                .FirstOrDefault();
            
            return am;
        }


        public int HighestEventNumberInFinancialYear(int activityID, int financialYear)
        {
            List<int> list = (SelectAll()
                .Where(x => x.FinanciaYear == financialYear && x.ActivityID == activityID)
                .Select(x => x.EventNumber)).ToList();

            return list.Any() ? list.Max() : 0;
        }

        public bool HasResourceAssigned(int eventID)
        {
            var e = SelectBy(x => x.ID == eventID);

            return e.EventParts.Sum(x => x.VenueEventParts.Count() 
                                    + x.EquipmentEventParts.Count() 
                                    + x.InstructorEventParts.Count() ) 
                                    > 0;

        }

        public void ResetResourceStatus(int eventID, string UserName)
        {
            var eps = Container.EventParts.Where(x => x.EventID == eventID);

            var eventPartCount = eps.Count();
            var fullyResourcedCount = eps.Count(x => x.Status == (int)Utility.ResourceStatus.FullyResourced);
            var partResourcedCount = eps.Count(x => x.Status == (int)Utility.ResourceStatus.PartResourced);

            var e = SelectBy(x => x.ID == eventID);

            if (eventPartCount == fullyResourcedCount)
            {
                e.Resourced = (int)Utility.ResourceStatus.FullyResourced;
                UpdateStatus(eventID, Trigger.AllResourcesAdded, UserName); 
            }
            else if (partResourcedCount > 0 || fullyResourcedCount > 0)
            {
                e.Resourced = (int)Utility.ResourceStatus.PartResourced;
                UpdateStatus(eventID, Trigger.PartResourced, UserName);
            }
            else
            {
                e.Resourced = (int)Utility.ResourceStatus.NotResourced;
                UpdateStatus(eventID, Trigger.NotResourced, UserName);
            }

            // Any resource change means that the event data held in iTrent is now stale
            e.iTrentDataStale = true;
        }

        protected virtual bool IsBlockingChange(Trigger? trigger)
        {
            if (!trigger.HasValue)
                return false;
            
            Trigger triggerVal = trigger.Value;

            return
                triggerVal == Trigger.DateRemoved ||
                triggerVal == Trigger.PartResourced ||
                triggerVal == Trigger.EventPartDateTypeChanged ||
                triggerVal == Trigger.TotalActivityDaysIncreased ||
                triggerVal == Trigger.TotalActivityDaysDecreased ||
                triggerVal == Trigger.EventPartAdded ||
                triggerVal == Trigger.EventPartRemoved ||
                triggerVal == Trigger.InstructorRequirementIncreased ||
                triggerVal == Trigger.VenueMinNumberIncreased ||
                triggerVal == Trigger.EquipmentMinNumberIncreased ||
                triggerVal == Trigger.InstructorRequirementDecreased ||
                triggerVal == Trigger.VenueMinNumberDecreased ||
                triggerVal == Trigger.EquipmentMinNumberDecreased ||
                triggerVal == Trigger.NotResourced;
        }

        public void UpdateStatus(int eventID, Trigger? trigger, string UserName, int? manualStatus = null)
        {
            Event e = SelectBy(x => x.ID == eventID);

            int originalStatus = e.Status;

            if (trigger.HasValue)
            {
                e.Machine.Fire(trigger.Value);
            }
            else if (manualStatus.HasValue)
            {
                e.Status = manualStatus.Value;
            }

            if (trigger == Trigger.ITrentExportCreated)
            {
                // The event was included in an export
                e.iTrentDataStale = false;
            }
            else if (trigger == Trigger.EventUploadedToITrent && e.BlockAfterUpload)
            {
                // The event was uploaded, and the state machine will have changed the status to Scheduled.
                // However if the event has BlockAfterUpload set, we want the status to be Blocked.
                e.Status = (int)EventStatusEnum.Blocked;
                e.BlockAfterUpload = false;
            }
            else if (trigger == Trigger.EventFailedToUploadToITrent || trigger == Trigger.ITrentExportDeleted)
            {
                // Either the event failed to upload, or the export was deleted without being uploaded,
                // so set iTrentDataStale = true to ensure it is included in the next export
                e.iTrentDataStale = true;
                e.BlockAfterUpload = false;
            }
            else if (trigger == Trigger.EventIdentificationChanged)
            {
                // An identifying detail of the event changed, such as its code or title.
                // Set iTrentDataStale = true to ensure it is included in the next export.
                e.iTrentDataStale = true;
            }
            else if (e.Status != originalStatus && e.Status != (int)EventStatusEnum.Complete)
            {
                // The event's status has changed to something other than Complete, so iTrent's data may be stale.
                // If the new status is not Scheduled, then the data is definitely stale.
                // If the new status is Scheduled then we do not change the stale flag.
                if (e.Status != (int)EventStatusEnum.Scheduled)
                {
                    e.iTrentDataStale = true;
                }

                // If the event's status changes to Scheduled or Blocked, set BlockAfterUpload to false.
                if (e.Status == (int)EventStatusEnum.Scheduled || e.Status == (int)EventStatusEnum.Blocked)
                {
                    e.BlockAfterUpload = false;
                }
            }

            // if event is in a pending upload and a blocking change happened, set BlockAfterUpload = true
            if (IsBlockingChange(trigger))
            {
                bool eventInPendingUpload = e.iTrentExportDatas.Any(d =>
                    d.iTrentExport.iTrentExportStatusID == (int)iTrentExportStatusEnum.Pending);

                if (eventInPendingUpload)
                    e.BlockAfterUpload = true;
            }

            //save audit of event status
            Container.AddToEventStatusHistories(new EventStatusHistory()
            {
                EventID = eventID,
                UserName = UserName,
                NewStatusID = e.Status,
                OldStatusID = originalStatus,
                OccurredOn = DateTime.Now
            });
        }

        public void ProcessDayCountIncreasedActivityTemplate(int activityID, string UserName, double totalDays)
        {
            var events = SelectFilteredList(PredicateLibrary.FutureEventsBasedOnActivityTemplatePredicate(activityID));

            foreach (var e in events)
            {
                e.TotalDays = totalDays;
                UpdateStatus(e.ID, Trigger.TotalActivityDaysIncreased, UserName);
            }
        }

        public void ProcessDayCountReducedActivityTemplate(int activityID, string UserName, double totalDays)
        {
            var events = SelectFilteredList(PredicateLibrary.FutureEventsBasedOnActivityTemplatePredicate(activityID));

            foreach (var e in events) 
            {
                e.TotalDays = totalDays;
                UpdateStatus(e.ID, Trigger.TotalActivityDaysDecreased, UserName);
            }
        }

        /// <summary>
        /// Applies a trigger to all events that match a query
        /// </summary>
        /// <param name="predicate"></param>
        /// <param name="trigger"></param>
        public void ApplyTriggerToMatchingEvents(Expression<Func<Event, bool>> predicate, Trigger trigger, string UserName)
        {
            var events = SelectFilteredList(predicate);

            foreach (var e in events)
            {
                UpdateStatus(e.ID, trigger, UserName);
            }
        }

        public IQueryable<ITrentEventModel> GetCancelledEventsForITrent(Expression<Func<Event, bool>> predicate)
        {
            var events = SelectFilteredList(predicate);

            //filter event parts for those events
            var eventParts = from e in events
                             join ep in Container.EventParts
                             on e.ID equals ep.EventID
                             select ep;

            var cancelledHistory = from e in events
                                   join ech in Container.EventCancelledHistories
                                   on e.ID equals ech.EventID
                                   select ech;

            var eventStatuses = from cr in events
                                join es in Container.EventStatuses
                                on cr.Status equals es.ID
                                select es;

            var finalListOfEvents =
                            from e in events
                            join ech in cancelledHistory
                            on e.ID equals ech.EventID
                            join es in eventStatuses
                            on e.Status equals es.ID
                            select new ITrentEventModel()
                            {
                                ID = e.ID,
                                ActivityCode = e.Activity.Code,
                                Title = e.Activity.Title,
                                EventCode = e.Activity.Code + " "
                                            + SqlFunctions.StringConvert((decimal)e.EventNumber).TrimStart() + "/"
                                            +
                                            SqlFunctions.StringConvert((decimal)e.FinanciaYear).TrimStart().Substring(
                                                2, 2),
                                StatusText = es.Title,
                                Status = e.Status,
                                CancelledOn = ech.CancelledOn,
                                CancelReason = ech.CancelEventReason.Reason
                            };

            return finalListOfEvents;
        }

        public IQueryable<ITrentEventModel> GetReadyEventsForITrent()
        {
            //filter events
            var events = SelectFilteredList(x => 
                x.Status == (int)Status.Ready &&
                !x.iTrentDataStale);

            //filter event parts for those events
            var eventParts = from e in events
                             join ep in Container.EventParts 
                             on e.ID equals ep.EventID
                             select ep;

            //get earliest event part date for each event
            var startDates =
                from ep in eventParts
                group ep by ep.EventID into grp
                    let startDate = grp.Min(g => g.Date) 
                from epList in grp
                    where epList.Date == startDate 
                select epList;

            //from the start dates for each events, get the earliest dayType
            var startDateAndDayType =
                from sds in startDates
                group sds by sds.EventID
                into grp
                let dayType = grp.Min(g => g.DayType)
                from sdList in grp
                where sdList.DayType == dayType
                select sdList;

            //get last event parts for each event
            var endDates =
                from ep in eventParts
                group ep by ep.EventID into grp
                    let startDate = grp.Max(g => g.Date)
                from epList in grp
                    where epList.Date == startDate //&& epList.DayType == 2 //we want the afternoon
                select epList;

            //from the end dates for each events, get the latest dayType
            var endDateAndDayType =
                from eds in endDates
                group eds by eds.EventID
                    into grp
                    let dayType = grp.Max(g => g.DayType)
                    from sdList in grp
                    where sdList.DayType == dayType
                    select sdList;

            //now join to get final list
            var finalListOfEvents = 
                        from e in events
                        join sd in startDateAndDayType
                             on e.ID equals sd.EventID
                        join ed in endDateAndDayType
                             on e.ID equals ed.EventID
                         select new ITrentEventModel()
                             {
                                 ID = e.ID,
                                 ActivityCode = e.Activity.Code,
                                 Title = e.Activity.Title,
                                 EventCode = e.Activity.Code + " "
                                             + SqlFunctions.StringConvert((decimal) e.EventNumber).TrimStart() + "/"
                                             +
                                             SqlFunctions.StringConvert((decimal) e.FinanciaYear).TrimStart().Substring(
                                                 2, 2),
                                 StartDate = sd.Date,
                                 StartTime = sd.StartTime,
                                 EndDate = ed.Date,
                                 EndTime = ed.EndTime
                             };


            return finalListOfEvents;
        }
    }
}