﻿using System.Collections.Generic;
using System.Linq;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for EventPart data access
    /// </summary>
    public class EventPartService : CrudService<EventPart>, IEventPartService
    {
        public EventPartService(IRepository<EventPart> repository) : base(repository)
        {
        }

        /// <summary>
        /// Returns the earliest event part for an Event. Takes into account day type, so for
        /// event parts with same date, will return 1 (Morning) ahead of 2 (afternoon)
        /// </summary>
        /// <param name="eventID">The event to search against</param>
        /// <returns>the earliest event part for the event</returns>
        public EventPart GetEarliestEventPart(int eventID)
        {
            return SelectFilteredList(x => x.EventID == eventID)
                .Where(d => d.Date != null)
                .OrderBy(d => d.Date)
                .ThenBy(t => t.DayType).FirstOrDefault();
        }

        public void ResetResourceStatus(int dayPartID)
        {
            var e = SelectBy(x => x.ID == dayPartID);

            if (e.Date == null)
            {
                e.Status = (int)Utility.ResourceStatus.NotResourced;
            }
            else
            {
                //get required instructor count
                var instructorLevels = Container.ActivityPartInstructorLevels.First(x => x.ActivityPartID == e.ActivityPartID);

                //check instructor count against base
                int instructorCount = Container.InstructorEventParts.Count(x => x.DayPartID == dayPartID && x.IsInstructor);
                int leadCount = Container.InstructorEventParts.Count(x => x.DayPartID == dayPartID && x.IsLead);
                int assessorCount = Container.InstructorEventParts.Count(x => x.DayPartID == dayPartID && x.IsAssessor);
                int shadowCount = Container.InstructorEventParts.Count(x => x.DayPartID == dayPartID && x.IsShadow);
                int specialistCount = Container.InstructorEventParts.Count(x => x.DayPartID == dayPartID && x.IsSpecialist);

                //do instructors have all their resources assigned?
                bool areInstructorsFullyResourced = instructorCount >= instructorLevels.InstructorCount;
                bool areLeadsFullyResourced = leadCount >= instructorLevels.LeadsCount;
                bool areAssessorsFullyResourced = assessorCount >= instructorLevels.AssessorCount;
                bool areShadowsFullyResourced = shadowCount >= instructorLevels.ShadowCount;
                bool areSpecialistsFullyResourced = specialistCount >= instructorLevels.SpecialistCount;

                //do instructors have 1 more of their resources assigned?
                bool areInstructorsPartResourced = instructorLevels.InstructorCount > 0 && instructorCount > 0;
                bool areLeadsPartResourced = instructorLevels.LeadsCount > 0 && leadCount > 0;
                bool areAssessorsPartResourced = instructorLevels.AssessorCount > 0 && assessorCount > 0;
                bool areShadowsPartResourced = instructorLevels.ShadowCount > 0 && shadowCount > 0;
                bool areSpecialistsPartResourced = instructorLevels.SpecialistCount > 0 && specialistCount > 0;

                //get all venue tags for this Event Parts activity part
                var tags = Container.VenueTagActivityParts.Where(x => x.ActivityPartID == e.ActivityPartID).ToList();
                //get all VenueEventParts for the event part
                var venues = Container.VenueEventParts.Where(x => x.DayPartID == dayPartID).ToList();
                //now check all tags to see if we have more than the minimum required for each
                var venueFullyResourcedChecks = tags.Select(t => venues.Count(x => x.VenueTagID == t.VenueTagID) >= t.MinRequired).ToList();
                //now get any tags that have at least 1 of their min amount selected
                var venuePartResourcedChecks =
                    tags.Select(tag => venues.Count(x => x.VenueTagID == tag.VenueTagID) > 0 &&
                                                venues.Count(x => x.VenueTagID == tag.VenueTagID) <= tag.MinRequired)
                                                .ToList();

                //get all equipment tags for this Event Parts activity part
                var equipmentTags = Container.EquipmentTagActivityParts.Where(x => x.ActivityPartID == e.ActivityPartID).ToList();
                //get all EquipmentEventParts for this event part
                var equipment = Container.EquipmentEventParts.Where(x => x.DayPartID == dayPartID).ToList();
                //now check all tags to see if we have more than the minimum required for each
                var equipmentFullyResourcedChecks = equipmentTags.Select(tag => equipment.Count(x => x.EquipmentTagID == tag.EquipmentTagID) >= tag.MinRequired).ToList();
                //now get any tags that have at least 1 of their min amount selected
                var equipmentPartResourcedChecks =
                    equipmentTags.Select(tag => equipment.Count(x => x.EquipmentTagID == tag.EquipmentTagID) > 0 &&
                                                equipment.Count(x => x.EquipmentTagID == tag.EquipmentTagID) <= tag.MinRequired)
                                                .ToList();

                var fullyResourcedFlags = new List<bool> { areInstructorsFullyResourced, areLeadsFullyResourced, areAssessorsFullyResourced, areShadowsFullyResourced, areSpecialistsFullyResourced };

                fullyResourcedFlags.AddRange(venueFullyResourcedChecks);
                fullyResourcedFlags.AddRange(equipmentFullyResourcedChecks);

                var partResourcedFlags = new List<bool> { areInstructorsPartResourced, areLeadsPartResourced, areAssessorsPartResourced, areShadowsPartResourced, areSpecialistsPartResourced };
                partResourcedFlags.AddRange(venuePartResourcedChecks);
                partResourcedFlags.AddRange(equipmentPartResourcedChecks);

                bool isFullyResourced = fullyResourcedFlags.Count() == fullyResourcedFlags.Count(x => x);

                bool isPartResourced = partResourcedFlags.Count(x => x) > 0;

                if (isFullyResourced)
                {
                    e.Status = (int)Utility.ResourceStatus.FullyResourced;
                }
                else if (isPartResourced)
                {
                    e.Status = (int)Utility.ResourceStatus.PartResourced;
                }
                else
                {
                    e.Status = (int)Utility.ResourceStatus.NotResourced;
                }
            }

            

        }
    }
}