using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;

namespace SFR.TOR.Data.Services
{
    public class ActivityStatusService : CrudService<ActivityStatus>, IActivityStatusService
    {
        public ActivityStatusService(IRepository<ActivityStatus> repository) : base(repository) { }
    }
}