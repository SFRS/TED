﻿using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;
using System.Linq;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for EquipmentGroupService data access
    /// </summary>
    public class EquipmentGroupService : CrudService<EquipmentGroup>, IEquipmentGroupService
    {
        public EquipmentGroupService(IRepository<EquipmentGroup> repository)
            : base(repository)
        {
        }

        public IQueryable<EquipmentGroupModel> GetEquipmentGroups()
        {
            var egm = from y in SelectAll()
                      select new EquipmentGroupModel
                      {
                          ID = y.ID,
                          Title = y.Title,
                      };

            return egm.AsQueryable();
        }
    }
}