﻿using System;
using System.Linq;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for GroupCalendar data access
    /// </summary>
    public class GroupCalendarService : CrudService<GroupCalendar>, IGroupCalendarService
    {
        public GroupCalendarService(IRepository<GroupCalendar> repository) : base(repository)
        {
        }

        public IQueryable<GroupCalendarItemModel> GetGroupCalendar(DateTime startDate, DateTime endDate, int trainingCentreID)
        {
            var gcd = from y in SelectAll()
                      where y.GroupDate >= startDate && y.GroupDate <= endDate
                      && y.TrainingCentreID == trainingCentreID
                      select new GroupCalendarItemModel
                      {
                          ID = y.ID,
                          Title = y.Title,
                          GroupDate = y.GroupDate
                      };

            return gcd;
        }
    }
}