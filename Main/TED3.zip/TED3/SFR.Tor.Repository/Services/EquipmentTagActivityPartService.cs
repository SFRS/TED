using System.Linq;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    public class EquipmentTagActivityPartService : CrudService<EquipmentTagActivityPart>, IEquipmentTagActivityPartService
    {
        public EquipmentTagActivityPartService(IRepository<EquipmentTagActivityPart> repository) : base(repository) { }

        public IQueryable<EquipmentDayPartModel> GetEquipmentActivityPartView(int activityPartID)
        {
            return SelectFilteredList(x => x.ActivityPartID == activityPartID)
                 .Select(x => new EquipmentDayPartModel
                 {
                     Name = x.EquipmentTag.Name,
                     MinRequired = x.MinRequired,
                     ID = x.ID
                 });
        }
    }
}