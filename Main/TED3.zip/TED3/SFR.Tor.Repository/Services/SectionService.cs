﻿using System;
using System.Linq;
using System.Linq.Expressions;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for Section data access
    /// </summary>
    public class SectionService : CrudService<Section>, ISectionService
    {
        public SectionService(IRepository<Section> repository) : base(repository) { }

        
    }
}
