﻿using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using System.Linq;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for iTrentExportService data access
    /// </summary>
    public class iTrentExportErrorsService : CrudService<iTrentExportError>, IITrentExportErrorsService
    {
        public iTrentExportErrorsService(IRepository<iTrentExportError> repository)
            : base(repository)
        {
        }

    }
}