﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;
using SFR.TOR.Utility;
using System.Linq;
using AutoMapper;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for Report data access
    /// </summary>
    public class ReportService : BaseADOService, IReportService 
    {
        private static SqlDbType GetSqlType(string clrType)
        {
            SqlDbType sqlType;

            switch (clrType)
            {
                case "Int32":
                    sqlType = SqlDbType.Int;
                    break;
                case "Double":
                    sqlType = SqlDbType.Float;
                    break;
                case "String":
                    sqlType = SqlDbType.VarChar;
                    break;
                case "DateTime":
                    sqlType = SqlDbType.DateTime;
                    break;
                case "Boolean":
                    sqlType = SqlDbType.Bit;
                    break;
                default:
                    sqlType = SqlDbType.VarChar;
                    break;
            }

            return sqlType;
        }

        private static void AddSqlParameters(SqlCommand command, Dictionary<string, dynamic> parameters, ParameterDirection direction)
        {
            if (parameters == null || parameters.Count == 0)
                return;

            foreach (var entry in parameters)
            {
                string typeName = entry.Value.GetType().Name;
                SqlDbType sqlType = GetSqlType(typeName);

                command.Parameters.Add(new SqlParameter()
                {
                    ParameterName = String.Format("@{0}", entry.Key),
                    Value = entry.Value,
                    SqlDbType = sqlType,
                    Direction = direction,
                });
            }
        }

        /// <summary>
        /// Helper method for setting up the SqlCommand
        /// </summary>
        private static SqlCommand SetUpCommand(SqlConnection connection, string sprocName, Dictionary<string, dynamic> inParams = null, Dictionary<string, dynamic> outParams = null)
        {
            int reportTimeout = Convert.ToInt32(ConfigurationManager.AppSettings[Constants.APP_SETTINGS_KEY_REPORT_TIMEOUT_SECS]);
            
            var command = new SqlCommand
            {
                CommandType = CommandType.StoredProcedure,
                Connection = connection,
                CommandText = sprocName,
                CommandTimeout = reportTimeout
            };

            AddSqlParameters(command, inParams, ParameterDirection.Input);
            AddSqlParameters(command, outParams, ParameterDirection.Output);

            return command;
        }

        public ReportResourceUtilisationModel GetReportResourceUtilisation(DateTime startDate, DateTime endDate, int trainingCentreID, ReportInstructorAvailabilityGroups availabilityGroup, ReportDaysCounted daysToCount)
        {
            var results = new ReportResourceUtilisationModel();

            using (var connection = new SqlConnection(ConnectionString))
            {
                var inParams = new Dictionary<string, dynamic>()
                    .AddFluent(Constants.SPROC_PARAM_TRAINING_CENTRE_ID, trainingCentreID)
                    .AddFluent(Constants.SPROC_PARAM_FROM, startDate)
                    .AddFluent(Constants.SPROC_PARAM_TO, endDate)
                    .AddFluent(Constants.SPROC_PARAM_AVAILABILITY_GROUP_ID, (int)availabilityGroup)
                    .AddFluent(Constants.SPROC_PARAM_COUNT_WEEKDAYS, daysToCount != ReportDaysCounted.Weekends)
                    .AddFluent(Constants.SPROC_PARAM_COUNT_WEEKENDS, daysToCount != ReportDaysCounted.Weekdays);

                var command = SetUpCommand(connection, Constants.SPROC_REPORT_RESOURCE_UTILISATION, inParams);

                connection.Open();

                using (var reader = command.ExecuteReader())
                {
                    // The recordset columns must match the property names in the model classes
                    Mapper.CreateMap(reader.GetType(), results.Table3.GetType().GetGenericArguments()[0]);
                    results.Table3 = Mapper.Map(reader, results.Table3);
                    reader.NextResult();

                    Mapper.CreateMap(reader.GetType(), results.Table3Totals.GetType().GetGenericArguments()[0]);
                    results.Table3Totals = Mapper.Map(reader, results.Table3Totals);
                    reader.NextResult();

                    Mapper.CreateMap(reader.GetType(), results.Table2.GetType().GetGenericArguments()[0]);
                    results.Table2 = Mapper.Map(reader, results.Table2);
                    reader.NextResult();

                    Mapper.CreateMap(reader.GetType(), results.Table2Totals.GetType().GetGenericArguments()[0]);
                    results.Table2Totals = Mapper.Map(reader, results.Table2Totals);
                    reader.NextResult();

                    Mapper.CreateMap(reader.GetType(), results.Table1.GetType().GetGenericArguments()[0]);
                    results.Table1 = Mapper.Map(reader, results.Table1);
                    reader.NextResult();

                    Mapper.CreateMap(reader.GetType(), results.Table1Events.GetType().GetGenericArguments()[0]);
                    results.Table1Events = Mapper.Map(reader, results.Table1Events);
                    reader.NextResult();

                    Mapper.CreateMap(reader.GetType(), results.Table1Totals.GetType().GetGenericArguments()[0]);
                    results.Table1Totals = Mapper.Map(reader, results.Table1Totals);                    
                }

                connection.Close();
            }

            return results;
        }

        public ReportInstructorUtilisationModel GetReportInstructorUtilisation(DateTime startDate, int trainingCentreID, ReportInstructorAvailabilityGroups availabilityGroup, TimePeriods timePeriod, ReportDaysCounted daysToCount)
        {
            var results = new ReportInstructorUtilisationModel();

            using (var connection = new SqlConnection(ConnectionString))
            {
                var inParams = new Dictionary<string, dynamic>()
                    .AddFluent(Constants.SPROC_PARAM_TRAINING_CENTRE_ID, trainingCentreID)
                    .AddFluent(Constants.SPROC_PARAM_FROM, startDate)
                    .AddFluent(Constants.SPROC_PARAM_AVAILABILITY_GROUP_ID, (int)availabilityGroup)
                    .AddFluent(Constants.SPROC_PARAM_TIME_PERIOD, (int)timePeriod)
                    .AddFluent(Constants.SPROC_PARAM_COUNT_WEEKDAYS, daysToCount != ReportDaysCounted.Weekends)
                    .AddFluent(Constants.SPROC_PARAM_COUNT_WEEKENDS, daysToCount != ReportDaysCounted.Weekdays);

                var command = SetUpCommand(connection, Constants.SPROC_REPORT_INSTRUCTOR_UTILISATION, inParams);

                connection.Open();

                using (var reader = command.ExecuteReader())
                {
                    // The recordset columns must match the property names in the model classes
                    Mapper.CreateMap(reader.GetType(), results.InstructorUtilisations.GetType().GetGenericArguments()[0]);
                    results.InstructorUtilisations = Mapper.Map(reader, results.InstructorUtilisations);
                    reader.NextResult();

                    Mapper.CreateMap(reader.GetType(), results.InstructorUtilisationTotals.GetType().GetGenericArguments()[0]);
                    results.InstructorUtilisationTotals = Mapper.Map(reader, results.InstructorUtilisationTotals);
                    reader.NextResult();
                }

                connection.Close();
            }

            return results;
        }

        public ReportSectionEventsModel GetReportSectionEvents(DateTime startDate, DateTime endDate, int trainingCentreID, IEnumerable<int> sectionIDList, ReportDaysCounted daysToCount)
        {
            var results = new ReportSectionEventsModel();

            using (var connection = new SqlConnection(ConnectionString))
            {
                var inParams = new Dictionary<string, dynamic>()
                    .AddFluent(Constants.SPROC_PARAM_TRAINING_CENTRE_ID, trainingCentreID)
                    .AddFluent(Constants.SPROC_PARAM_FROM, startDate)
                    .AddFluent(Constants.SPROC_PARAM_TO, endDate)
                    .AddFluent(Constants.SPROC_PARAM_SECTION_IDS, String.Join(",", sectionIDList))
                    .AddFluent(Constants.SPROC_PARAM_COUNT_WEEKDAYS, daysToCount != ReportDaysCounted.Weekends)
                    .AddFluent(Constants.SPROC_PARAM_COUNT_WEEKENDS, daysToCount != ReportDaysCounted.Weekdays);

                var command = SetUpCommand(connection, Constants.SPROC_REPORT_SECTION_EVENTS, inParams);

                connection.Open();

                using (var reader = command.ExecuteReader())
                {
                    // The recordset columns must match the property names in the model classes
                    Mapper.CreateMap(reader.GetType(), results.SectionEvents.GetType().GetGenericArguments()[0]);
                    results.SectionEvents = Mapper.Map(reader, results.SectionEvents);
                    reader.NextResult();

                    Mapper.CreateMap(reader.GetType(), results.UtilisationTotals.GetType().GetGenericArguments()[0]);
                    results.UtilisationTotals = Mapper.Map(reader, results.UtilisationTotals);
                    reader.NextResult();
                }

                connection.Close();
            }

            return results;
        }

        public ReportSectionSignOffModel GetReportSectionSignOff(DateTime startDate, DateTime endDate, int trainingCentreID, IEnumerable<int> sectionIDList, ReportDaysCounted daysToCount)
        {
            var results = new ReportSectionSignOffModel();

            using (var connection = new SqlConnection(ConnectionString))
            {
                var inParams = new Dictionary<string, dynamic>()
                    .AddFluent(Constants.SPROC_PARAM_TRAINING_CENTRE_ID, trainingCentreID)
                    .AddFluent(Constants.SPROC_PARAM_FROM, startDate)
					.AddFluent(Constants.SPROC_PARAM_TO, endDate)
                    .AddFluent(Constants.SPROC_PARAM_SECTION_IDS, String.Join(",", sectionIDList))
                    .AddFluent(Constants.SPROC_PARAM_COUNT_WEEKDAYS, daysToCount != ReportDaysCounted.Weekends)
                    .AddFluent(Constants.SPROC_PARAM_COUNT_WEEKENDS, daysToCount != ReportDaysCounted.Weekdays);

                var command = SetUpCommand(connection, Constants.SPROC_REPORT_SECTION_SIGNOFF, inParams);

                connection.Open();

                using (var reader = command.ExecuteReader())
                {
                    // The recordset columns must match the property names in the model classes
                    Mapper.CreateMap(reader.GetType(), results.SignOffEventsAndTotals.GetType().GetGenericArguments()[0]);
                    results.SignOffEventsAndTotals = Mapper.Map(reader, results.SignOffEventsAndTotals);
                    reader.NextResult();
                }

                connection.Close();
            }

            return results;
        }

        public ReportEventsByStatusModel GetReportEventsByStatus(DateTime startDate, DateTime toDate, int trainingCentreID, IEnumerable<int> eventStatusIDList, IEnumerable<int> eventResourceStatusIDList, IEnumerable<int> sectionIDList, ReportDaysCounted daysToCount)
        {
            var results = new ReportEventsByStatusModel();

            using (var connection = new SqlConnection(ConnectionString))
            {
                var inParams = new Dictionary<string, dynamic>()
                    .AddFluent(Constants.SPROC_PARAM_TRAINING_CENTRE_ID, trainingCentreID)
                    .AddFluent(Constants.SPROC_PARAM_FROM, startDate)
                    .AddFluent(Constants.SPROC_PARAM_TO, toDate)
                    .AddFluent(Constants.SPROC_PARAM_EVENT_STATUS_IDS, String.Join(",", eventStatusIDList))
                    .AddFluent(Constants.SPROC_PARAM_RESOURCE_STATUS_IDS, String.Join(",", eventResourceStatusIDList))
                    .AddFluent(Constants.SPROC_PARAM_SECTION_IDS, String.Join(",", sectionIDList))
                    .AddFluent(Constants.SPROC_PARAM_COUNT_WEEKDAYS, daysToCount != ReportDaysCounted.Weekends)
                    .AddFluent(Constants.SPROC_PARAM_COUNT_WEEKENDS, daysToCount != ReportDaysCounted.Weekdays);

                var command = SetUpCommand(connection, Constants.SPROC_REPORT_EVENTS_BY_STATUS, inParams);

                connection.Open();

                using (var reader = command.ExecuteReader())
                {
                    // The recordset columns must match the property names in the model classes
                    Mapper.CreateMap(reader.GetType(), results.EventsByStatus.GetType().GetGenericArguments()[0]);
                    results.EventsByStatus = Mapper.Map(reader, results.EventsByStatus);
                    reader.NextResult();
                }

                connection.Close();
            }

            return results;
        }

        public ReportEventsByVenueCategoriesModel GetReportEventsByVenueGroup(DateTime startDate, DateTime endDate, int trainingCentreID)
        {
            var results = new ReportEventsByVenueCategoriesModel();

            using (var connection = new SqlConnection(ConnectionString))
            {
                var inParams = new Dictionary<string, dynamic>()
                    .AddFluent(Constants.SPROC_PARAM_TRAINING_CENTRE_ID, trainingCentreID)
                    .AddFluent(Constants.SPROC_PARAM_FROM, startDate)
                    .AddFluent(Constants.SPROC_PARAM_TO, endDate);

                var command = SetUpCommand(connection, Constants.SPROC_REPORT_EVENTS_BY_VENUE_CATEGORIES, inParams);

                connection.Open();

                using (var reader = command.ExecuteReader())
                {
                    // The recordset columns must match the property names in the model classes
                    Mapper.CreateMap(reader.GetType(), results.EventsByVenueCategories.GetType().GetGenericArguments()[0]);
                    results.EventsByVenueCategories = Mapper.Map(reader, results.EventsByVenueCategories);
                    reader.NextResult();
                }

                connection.Close();
            }

            return results;
        }

        public ReportVenueCategoriesModel GetReportVenueCategories(int trainingCentreID)
        {
            var results = new ReportVenueCategoriesModel();

            using (var connection = new SqlConnection(ConnectionString))
            {
                var inParams = new Dictionary<string, dynamic>()
                    .AddFluent(Constants.SPROC_PARAM_TRAINING_CENTRE_ID, trainingCentreID);

                var command = SetUpCommand(connection, Constants.SPROC_REPORT_VENUE_CATEGORIES, inParams);

                connection.Open();

                using (var reader = command.ExecuteReader())
                {
                    // The recordset columns must match the property names in the model classes
                    Mapper.CreateMap(reader.GetType(), results.VenueCategories.GetType().GetGenericArguments()[0]);
                    results.VenueCategories = Mapper.Map(reader, results.VenueCategories);
                    reader.NextResult();
                }

                connection.Close();
            }

            return results;
        }

        public ReportCateringModel GetReportCatering(DateTime startDate, DateTime endDate, int trainingCentreID)
        {
            var results = new ReportCateringModel();

            using (var connection = new SqlConnection(ConnectionString))
            {
                var inParams = new Dictionary<string, dynamic>()
                    .AddFluent(Constants.SPROC_PARAM_TRAINING_CENTRE_ID, trainingCentreID)
                    .AddFluent(Constants.SPROC_PARAM_FROM, startDate)
                    .AddFluent(Constants.SPROC_PARAM_TO, endDate);

                var command = SetUpCommand(connection, Constants.SPROC_REPORT_CATERING, inParams);

                connection.Open();

                using (var reader = command.ExecuteReader())
                {
                    // The recordset columns must match the property names in the model classes
                    Mapper.CreateMap(reader.GetType(), results.Catering.GetType().GetGenericArguments()[0]);
                    results.Catering = Mapper.Map(reader, results.Catering);
                    reader.NextResult();

                    Mapper.CreateMap(reader.GetType(), results.CateringTrainingCentre.GetType().GetGenericArguments()[0]);
                    results.CateringTrainingCentre = Mapper.Map(reader, results.CateringTrainingCentre);
                    reader.NextResult();
                }

                connection.Close();
            }

            return results;
        }

        public ReportInstructorAssignmentsModel GetReportInstructorAssignments(DateTime startDate, DateTime endDate, int instructorID, ReportDaysCounted daysToCount)
        {
            var results = new ReportInstructorAssignmentsModel();

            using (var connection = new SqlConnection(ConnectionString))
            {
                var inParams = new Dictionary<string, dynamic>()
                    .AddFluent(Constants.SPROC_PARAM_FROM, startDate)
                    .AddFluent(Constants.SPROC_PARAM_TO, endDate)
                    .AddFluent(Constants.SPROC_PARAM_INSTRUCTOR_ID, instructorID)
                    .AddFluent(Constants.SPROC_PARAM_COUNT_WEEKDAYS, daysToCount != ReportDaysCounted.Weekends)
                    .AddFluent(Constants.SPROC_PARAM_COUNT_WEEKENDS, daysToCount != ReportDaysCounted.Weekdays);

                var command = SetUpCommand(connection, Constants.SPROC_REPORT_INSTRUCTOR_ASSIGNMENTS, inParams);

                connection.Open();

                using (var reader = command.ExecuteReader())
                {
                    // The recordset columns must match the property names in the model classes
                    Mapper.CreateMap(reader.GetType(), results.InstructorAssignments.GetType().GetGenericArguments()[0]);
                    results.InstructorAssignments = Mapper.Map(reader, results.InstructorAssignments);
                    reader.NextResult();

                    Mapper.CreateMap(reader.GetType(), results.Instructors.GetType().GetGenericArguments()[0]);
                    results.Instructors = Mapper.Map(reader, results.Instructors);
                    reader.NextResult();

                    Mapper.CreateMap(reader.GetType(), results.InstructorAssignmentTotals.GetType().GetGenericArguments()[0]);
                    results.InstructorAssignmentTotals = Mapper.Map(reader, results.InstructorAssignmentTotals);
                    reader.NextResult();

                    Mapper.CreateMap(reader.GetType(), results.TotalDays.GetType().GetGenericArguments()[0]);
                    results.TotalDays = Mapper.Map(reader, results.TotalDays);
                    reader.NextResult();
                }

                connection.Close();
            }

            return results;
        }
    }
}
