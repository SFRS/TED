﻿using System.Linq;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for InstructorUnavailablePeriod data access
    /// </summary>
    public class InstructorUnavailablePeriodService : CrudService<InstructorUnavailablePeriod>, IInstructorUnavailablePeriodService
    {
        public InstructorUnavailablePeriodService(IRepository<InstructorUnavailablePeriod> repository) : base(repository)
        {
        }

        public IQueryable<InstructorEditAvailabilityModel> GetUnavailabilityReasons(int id)
        {
            var periods = from y in SelectFilteredList(x => x.InstructorID == id)
                    select new InstructorEditAvailabilityModel
                        {
                            ID = y.ID,
                            InstructorID = y.InstructorID,
                            StartDate = y.StartDate,
                            StartTime = y.StartTime,
                            EndDate = y.EndDate,
                            EndTime = y.EndTime,   
                            UnavailableReasonGroup = y.UnavailableReason.InstructorUnavailableReasonGroup.Title,
                            UnavailableReasonID = y.UnavailableReasonID,
                            UnavailableReason = y.UnavailableReason.Reason,

                            DayTypeID = y.DayTypeID,
                            DayType = y.EventPartType.Title,
                            Comments = y.Comments
                        };

            return periods;

        }
    }
}