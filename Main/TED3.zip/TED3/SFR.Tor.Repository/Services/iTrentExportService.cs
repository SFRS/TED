﻿using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using System.Linq;
using SFR.TOR.ViewModels;
using SFR.TOR.Utility;
using System;
using System.Data.Objects.SqlClient;
using AutoMapper;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for iTrentExportService data access
    /// </summary>
    public class iTrentExportService : CrudService<iTrentExport>, IITrentExportService
    {
        public iTrentExportService(IRepository<iTrentExport> repository) : base(repository)
        {
        }

        public IQueryable<iTrentExportModel> GetITrentExports()
        {
            var itexp = SelectAll().Select(ie => new iTrentExportModel
            {
                ID = ie.ID,
                iTrentExportDate = ie.ExportDate,
                EventsExported = ie.EventsExported,
                ExportErrors = ie.ExportErrors,
                EventsUploaded = ie.EventsUploaded,
                UploadErrors = ie.UploadErrors,
                Title = ie.Title,
                Status = ie.iTrentExportStatus.Title,
                StatusID = ie.iTrentExportStatusID,
                Type = ie.iTrentExportType.Title,
                TypeID = ie.iTrentExportTypeID,
                FinancialYear = SqlFunctions.StringConvert((decimal)ie.FinancialYear).TrimStart()
                        + "/"
                        + SqlFunctions.StringConvert((decimal)ie.FinancialYear + 1).TrimStart().Substring(2, 2)
            });

            return itexp.AsQueryable();
        }

        public iTrentExportModel GetITrentExportDetails(int id)
        {
            var ie = SelectBy(x => x.ID == id);

            var model = Mapper.Map<iTrentExport, iTrentExportModel>(ie);

            return model;
        }
    }
}