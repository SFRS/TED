﻿using System;
using System.Linq;
using System.Linq.Expressions;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.Utility;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for Equipment data access
    /// </summary>
    public class EquipmentService : CrudService<Equipment>, IEquipmentService
    {
        public EquipmentService(IRepository<Equipment> repository) : base(repository) { }
        public IQueryable<EquipmentModel> GetEquipment(Expression<Func<Equipment, bool>> predicate)
        {
            var today = DateTime.Now.Date;

            //can't use Automapper here as it interferes with paging in JQGrid, so revert to manual mapping to viewmodel
            var data =
                from e in SelectFilteredList(predicate)
                let p = e.EquipmentUnavailablePeriods.FirstOrDefault(p => p.StartDate <= today && (p.EndDate ?? today) >= today)
                select new EquipmentModel
                {
                    ID = e.ID,
                    Name = e.Name,
                    TrainingCentre = e.TrainingCentre.Name,
                    EquipmentGroup = e.EquipmentGroup != null ? e.EquipmentGroup.Title : string.Empty,
                    EquipmentGroupID = e.EquipmentGroupID,
                    Availability = p == null ? Constants.RESOURCE_AVAILABILITY_AVAILABLE : (
                        p.EndDate == null ?
                        Constants.RESOURCE_AVAILABILITY_STATUS_UNAVAILABLE :
                        Constants.RESOURCE_AVAILABILITY_STATUS_LIMITED)
                };

            return data;
        }

        public EquipmentModel GetEquipment(int id)
        {
            var e = SelectBy(x => x.ID == id);

            return new EquipmentModel
            {
                Name = e.Name,
                ID = e.ID,
                TrainingCentre = e.TrainingCentre.Name,
                TrainingCentreID = e.TrainingCentreID,
                EquipmentGroup = e.EquipmentGroup != null ? e.EquipmentGroup.Title : string.Empty,
                EquipmentGroupID = e.EquipmentGroupID
            };
        }
    }
}
