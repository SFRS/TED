﻿using System;
using System.Linq;
using System.Linq.Expressions;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;
using SFR.TOR.Utility;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for Instructor data access
    /// </summary>
    public class InstructorService : CrudService<Instructor>, IInstructorService
    {
        public InstructorService(IRepository<Instructor> repository) : base(repository){}

        public IQueryable<InstructorModel> GetInstructors(Expression<Func<Instructor, bool>> predicate)
        {
            var today = DateTime.Now.Date;

            //can't use Automapper here as it interferes with paging in JQGrid, so revert to manual mapping to viewmodel
            var data = 
                from i in SelectFilteredList(predicate)
                let p = i.InstructorUnavailablePeriods.FirstOrDefault(p => p.StartDate <= today && (p.EndDate ?? today) >= today)
                select new InstructorModel
                {
                    ID = i.ID,
                    Name = i.LastName + ", " + i.FirstName,
                    Section = i.Section != null ? i.Section.Title : Constants.INSTRUCTOR_INACTIVE_SECTION_NAME,
                    Group = i.Group.Name,
                    TrainingCentre = i.TrainingCentre.Name,
                    Availability = p == null ? Constants.RESOURCE_AVAILABILITY_AVAILABLE : (
                        p.EndDate == null ?
                        Constants.RESOURCE_AVAILABILITY_STATUS_UNAVAILABLE :
                        Constants.RESOURCE_AVAILABILITY_STATUS_LIMITED)
                };

            return data;
        }

    }
}

