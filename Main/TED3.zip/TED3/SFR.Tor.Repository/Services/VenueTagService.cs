using System.Linq;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    public class VenueTagService : CrudService<VenueTag>, IVenueTagService
    {
        public VenueTagService(IRepository<VenueTag> repository) : base(repository)
        {
        }

        public IQueryable<VenueTagModel> GetVenueTagsForActivityPart(int activityPartID)
        {
            IQueryable<VenueTagModel> list = from vt in SelectAll()
                    join vtap in Container.VenueTagActivityParts
                        on vt.ID equals vtap.VenueTagID
                    where vtap.ActivityPartID == activityPartID
                    select new VenueTagModel
                        {
                            ID = vt.ID,
                            Name = vt.Name,
                            MinRequired = vtap.MinRequired
                        };

            return list;
        }
    }
}