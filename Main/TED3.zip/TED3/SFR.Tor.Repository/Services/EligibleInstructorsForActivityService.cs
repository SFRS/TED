using System.Linq;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    public class EligibleInstructorsForActivityService : CrudService<EligibleInstructorsForActivity>, IEligibleInstructorsForActivityService
    {
        public EligibleInstructorsForActivityService(IRepository<EligibleInstructorsForActivity> repository) : base(repository) { }

        public IQueryable<InstructorEligibilityModel> GetEligibilityForInstructor(int instructorID)
        {
            var savedData = from a in Container.Activities
                            join s in SelectFilteredList(x => x.InstructorID == instructorID)
                                on a.ID equals s.ActivityTemplateID into lj1
                            from x1 in lj1.DefaultIfEmpty()
                            where a.ActivityStatusID != 3 //don't show obsolete activities in this list                            
                            select new InstructorEligibilityModel
                                {
                                    ID = a.ID,                                    
                                    IsLead = x1.IsLead,
                                    IsInstructor = x1.IsInstructor,
                                    IsAssessor = x1.IsAssessor,
                                    IsShadow = x1.IsShadow,
                                    IsSpecialist = x1.IsSpecialist,
                                    Title = a.Title,
                                    Code = a.Code
                                };

            return savedData;
        }
    }
}