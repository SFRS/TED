using System.Linq;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    public class EquipmentTagService : CrudService<EquipmentTag>, IEquipmentTagService
    {
        public EquipmentTagService(IRepository<EquipmentTag> repository) : base(repository) { }
        public IQueryable<EquipmentTagModel> GetEquipmentTagsForActivityPart(int activityPartID)
        {
            IQueryable<EquipmentTagModel> list = from et in SelectAll()
                                             join etap in Container.EquipmentTagActivityParts
                                                 on et.ID equals etap.EquipmentTagID
                                             where etap.ActivityPartID == activityPartID
                                                 select new EquipmentTagModel
                                             {
                                                 ID = et.ID,
                                                 Name = et.Name,
                                                 MinRequired = etap.MinRequired
                                             };

            return list;
        }
    }
}