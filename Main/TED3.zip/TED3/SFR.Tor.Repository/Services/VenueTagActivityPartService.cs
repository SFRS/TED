using System.Linq;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    public class VenueTagActivityPartService : CrudService<VenueTagActivityPart>, IVenueTagActivityPartService
    {
        public VenueTagActivityPartService(IRepository<VenueTagActivityPart> repository) : base(repository) { }

        public IQueryable<VenueDayPartModel> GetVenueActivityPartView(int activityPartID)
        {
            return SelectFilteredList(x => x.ActivityPartID == activityPartID)
                .Select(x => new VenueDayPartModel
                    {
                        Name = x.VenueTag.Name,
                        MinRequired = x.MinRequired,
                        ID = x.ID
                    });
        }
    }
}