﻿using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for UnavailableReason data access
    /// </summary>
    public class UnavailableReasonService : CrudService<UnavailableReason>, IUnavailableReasonService
    {
        public UnavailableReasonService(IRepository<UnavailableReason> repository) : base(repository)
        {
        }
    }
}