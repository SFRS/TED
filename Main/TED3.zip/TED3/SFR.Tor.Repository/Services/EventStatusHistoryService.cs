﻿using System.Linq;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for EventStatusHistory data access
    /// </summary>
    public class EventStatusHistoryService : CrudService<EventStatusHistory>, IEventStatusHistoryService
    {
        public EventStatusHistoryService(IRepository<EventStatusHistory> repository) : base(repository)
        {
        }

        public IQueryable<EventStatusHistoryModel> GetEventHistory(int eventID)
        {
            return SelectFilteredList(x => x.EventID == eventID)
                .Select(x => new EventStatusHistoryModel()
                    {   
                        UserName = x.UserName,
                        OccurredOn = x.OccurredOn,
                        NewStatus = x.EventStatusNew.Title,
                        OldStatus = x.EventStatusOld.Title
                    }
                );
        }
    }
}