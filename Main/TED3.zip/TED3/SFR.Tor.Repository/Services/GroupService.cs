﻿using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for Group data access
    /// </summary>
    public class GroupService : CrudService<Group>, IGroupService
    {
        public GroupService(IRepository<Group> repository) : base(repository)
        {
        }
    }
}