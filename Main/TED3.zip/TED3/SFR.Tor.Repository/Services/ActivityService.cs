using System;
using System.Linq;
using System.Linq.Expressions;
using AutoMapper;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services 
{
    public class ActivityService : CrudService<Activity>, IActivityService
    {
        public ActivityService(IRepository<Activity> repository) : base(repository) { }

        public IQueryable<ActivityModel> GetActivities(Expression<Func<Activity, bool>> predicate)
        {
            //can't use Automapper here as it interferes with paging in JQGrid, so revert to manual mapping to viewmodel
            return SelectFilteredList(predicate)
                .Select(x => new ActivityModel
                {
                    Code = x.Code,
                    Description = x.Description,
                    Section = x.Section.Title,
                    TotalDays = x.TotalDays,
                    Title = x.Title,
                    ID = x.ID,
                    ExistingEvents = x.Events.Count(y => y.EventParts.Any(ep => ep.Date > DateTime.Now)),
                    Status = x.ActivityStatus.Title
                });    
        }

        public ActivityModel GetActivity(Expression<Func<Activity, bool>> predicate)
        {            
            var a = SelectBy(predicate);

            var am = Mapper.Map<Activity, ActivityModel>(a);

            if (am == null)
            {
                throw new Exception();
            }
            //todo: do these date checks need the time removed??
            am.HasFutureEvents =
                a.Events.Any(x => x.EventParts.Count(dp => dp.Date > DateTime.Now) > 0) &&  //has parts after today
                a.Events.Any(x => x.EventParts.Count(dp => dp.Date <= DateTime.Now) == 0);  //and no parts today or earlier

            am.HasHistoricalEvents = 
                a.Events.Any(x => x.EventParts.Count(dp => dp.Date < DateTime.Now) > 0) &&  //has parts before today
                a.Events.Any(x => x.EventParts.Count(dp => dp.Date > DateTime.Now) == 0);   //and no parts after today

            am.HasEventSpanningToday = 
                a.Events.Any(x => x.EventParts.Count(dp => dp.Date > DateTime.Now) > 0) &&  //has parts after today
                a.Events.Any(x => x.EventParts.Count(dp => dp.Date <= DateTime.Now) > 0);   //and has parts before or on today

            am.ExistingEvents = a.Events.Count(y => y.EventParts.Any(ep => ep.Date > DateTime.Now));

            return am;
        }
    }
}