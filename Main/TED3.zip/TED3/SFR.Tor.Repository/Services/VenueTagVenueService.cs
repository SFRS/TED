﻿using System.Linq;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for VenueTagVenue data access
    /// </summary>
    public class VenueTagVenueService : CrudService<VenueTagVenue>, IVenueTagVenueService
    {
        public VenueTagVenueService(IRepository<VenueTagVenue> repository) : base(repository)
        {
        }

        public IQueryable<VenueTagVenueModel> GetVenueTags(int id)
        {
            var tags = SelectFilteredList(x => x.VenueID == id);

            var data = from t in tags
                       select new VenueTagVenueModel
                       {
                           ID = t.ID,
                           VenueID = t.VenueID,
                           VenueTagID = t.VenueTagID,
                           Name = t.VenueTag.Name
                       };
            return data;
        }
    }
}