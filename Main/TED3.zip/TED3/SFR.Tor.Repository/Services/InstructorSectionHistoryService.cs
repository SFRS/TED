﻿using System;
using System.Linq;
using System.Linq.Expressions;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for instructor history access
    /// </summary>
    public class InstructorSectionHistoryService : CrudService<InstructorSectionHistory>, IInstructorSectionHistoryService
    {
        public InstructorSectionHistoryService(IRepository<InstructorSectionHistory> repository) : base(repository) { }

        public IQueryable<InstructorSectionHistoryEditModel> GetInstructorSectionHistory(int id)
        {
            var history = from y in SelectFilteredList(x => x.InstructorID == id)
                          select new InstructorSectionHistoryEditModel
                          {
                              ID = y.ID,
                              InstructorID = y.InstructorID,
                              StartDate = y.StartDate,
                              EndDate = y.EndDate,
                              SectionID = y.SectionID                          
                          };

            return history;

        }
    }
}
