﻿using System;
using System.Linq;
using System.Linq.Expressions;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services.Interfaces
{
    /// <summary>
    /// Public interface for the InstructorService
    /// </summary>
    public interface IInstructorService : IEntityService<Instructor>
    {
        IQueryable<InstructorModel> GetInstructors(Expression<Func<Instructor, bool>> predicate);
    }
}