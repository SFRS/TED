﻿using SFR.TOR.Data.Plumbing.Service;

namespace SFR.TOR.Data.Services.Interfaces
{
    /// <summary>
    /// Public interface for the EventPartService
    /// </summary>
    public interface IEventPartService : IEntityService<EventPart>
    {
        EventPart GetEarliestEventPart(int id);
        void ResetResourceStatus(int dayPartID);
    }
}