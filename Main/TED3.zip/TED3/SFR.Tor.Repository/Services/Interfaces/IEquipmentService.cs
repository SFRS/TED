﻿using System;
using System.Linq;
using System.Linq.Expressions;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services.Interfaces
{
    /// <summary>
    /// Public interface for the EquipmentService
    /// </summary>
    public interface IEquipmentService : IEntityService<Equipment>
    {
        IQueryable<EquipmentModel> GetEquipment(Expression<Func<Equipment, bool>> predicate);
        EquipmentModel GetEquipment(int id);
    }

    
}
