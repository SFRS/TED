﻿using System;
using System.Collections.Generic;
using SFR.TOR.ViewModels;
using SFR.TOR.Utility;

namespace SFR.TOR.Data.Services.Interfaces
{
    /// <summary>
    /// Public interface for the ReportService
    /// </summary>
    public interface IReportService
    {
        ReportResourceUtilisationModel GetReportResourceUtilisation(DateTime startDate, DateTime endDate, int trainingCentreID, ReportInstructorAvailabilityGroups availabilityGroup, ReportDaysCounted daysToCount);
        ReportInstructorUtilisationModel GetReportInstructorUtilisation(DateTime startDate, int trainingCentreID, ReportInstructorAvailabilityGroups availabilityGroup, TimePeriods timePeriod, ReportDaysCounted daysToCount);
        ReportSectionEventsModel GetReportSectionEvents(DateTime startDate, DateTime endDate, int trainingCentreID, IEnumerable<int> sectionIDList, ReportDaysCounted daysToCount);
        ReportSectionSignOffModel GetReportSectionSignOff(DateTime startDate, DateTime endDate, int trainingCentreID, IEnumerable<int> sectionIDList, ReportDaysCounted daysToCount);
        ReportEventsByStatusModel GetReportEventsByStatus(DateTime startDate, DateTime toDate, int trainingCentreID, IEnumerable<int> eventStatusIDList, IEnumerable<int> eventResourceStatusIDList, IEnumerable<int> sectionIDList, ReportDaysCounted daysToCount);
        ReportEventsByVenueCategoriesModel GetReportEventsByVenueGroup(DateTime startDate, DateTime endDate, int trainingCentreID);
        ReportVenueCategoriesModel GetReportVenueCategories(int trainingCentreID);
        ReportCateringModel GetReportCatering(DateTime startDate, DateTime endDate, int trainingCentreID);
        ReportInstructorAssignmentsModel GetReportInstructorAssignments(DateTime startDate, DateTime endDate, int instructorID, ReportDaysCounted daysToCount);
    }
}