﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SFR.TOR.Data.Plumbing.Service;

namespace SFR.TOR.Data.Services.Interfaces
{
    public interface IInstructorUnavailableReasonGroupsService : IEntityService<InstructorUnavailableReasonGroup>
    {
    }
}
