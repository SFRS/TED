﻿using SFR.TOR.Data.Plumbing.Service;

namespace SFR.TOR.Data.Services.Interfaces
{
    /// <summary>
    /// Public interface for the VenueUnavailableReasonService
    /// </summary>
    public interface IVenueUnavailableReasonService : IEntityService<VenuesUnavailableReason>
    {

    }
}
