﻿using SFR.TOR.Data.Plumbing.Service;

namespace SFR.TOR.Data.Services.Interfaces
{
    /// <summary>
    /// Public interface for the EventPartTypeService
    /// </summary>
    public interface IEventPartTypeService : IEntityService<EventPartType>
    {

    }
}