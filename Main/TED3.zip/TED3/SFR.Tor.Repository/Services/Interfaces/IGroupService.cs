﻿using SFR.TOR.Data.Plumbing.Service;

namespace SFR.TOR.Data.Services.Interfaces
{
    /// <summary>
    /// Public interface for the GroupService
    /// </summary>
    public interface IGroupService : IEntityService<Group>
    {

    }
}