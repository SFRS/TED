﻿using SFR.TOR.Data.Plumbing.Service;

namespace SFR.TOR.Data.Services.Interfaces
{
    public interface IActivityStatusService : IEntityService<ActivityStatus>
    {
        
    }
}
