﻿using System;
using System.Linq;
using System.Linq.Expressions;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services.Interfaces
{
    /// <summary>
    /// Public interface for the InstructorEventPartService
    /// </summary>
    public interface IInstructorEventPartService : IEntityService<InstructorEventPart> 
    {
        IQueryable<InstructorEventPartModel> GetInstructorEventParts(Expression<Func<InstructorEventPart, bool>> predicate);
    }
}