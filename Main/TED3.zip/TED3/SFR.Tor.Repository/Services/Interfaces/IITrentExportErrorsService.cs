﻿using SFR.TOR.Data.Plumbing.Service;
using System.Linq;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services.Interfaces
{
    /// <summary>
    /// Public interface for the iTrentExportService
    /// </summary>
    public interface IITrentExportErrorsService : IEntityService<iTrentExportError>
    {
        
    }
}