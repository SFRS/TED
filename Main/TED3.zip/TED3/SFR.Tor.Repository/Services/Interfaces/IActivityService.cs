using System;
using System.Linq;
using System.Linq.Expressions;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services.Interfaces
{
    public interface IActivityService : IEntityService<Activity>
    {
        IQueryable<ActivityModel> GetActivities(Expression<Func<Activity, bool>> predicate);

        ActivityModel GetActivity(Expression<Func<Activity, bool>> predicate);
    }
}