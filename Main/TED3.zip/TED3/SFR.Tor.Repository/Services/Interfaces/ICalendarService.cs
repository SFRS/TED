﻿using System;
using System.Collections.Generic;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services.Interfaces
{
    /// <summary>
    /// Public interface for the CalendarService
    /// </summary>
    public interface ICalendarService
    {
        /// <summary>
        /// Returns a paged, filtered, ordered list of instructor calendar data 
        /// </summary>
        /// <param name="startDate">The date to start on</param>
        /// <param name="page">The page number of the resultset</param>
        /// <param name="size">The number of rows in the page</param>
        /// <param name="sortDir">The sort direction</param>
        /// <param name="sortBy">The sort column</param>
        /// <param name="section">Filter by Event Section ID</param>
        /// <param name="status">Filter by Event Status ID</param>
        /// <param name="totalCount">Output parameter to return total rows matching BEFORE paging</param>
        /// <returns>a paged, filtered, ordered list of instructor calendar data</returns>
        List<InstructorCalendarData> GetInstructorCalendarView(DateTime? startDate, int page, int size, string sortDir, string sortBy, string section, string status, out int totalCount,string  trainingCentreIDs, string SelectedGroup, string SelectedInstructorID, bool ShowWeekends);

        /// <summary>
        /// Returns a paged, filtered, ordered list of Equipment calendar data 
        /// </summary>
        /// <param name="startDate">The date to start on</param>
        /// <param name="page">The page number of the resultset</param>
        /// <param name="size">The number of rows in the page</param>
        /// <param name="sortDir">The sort direction</param>
        /// <param name="sortBy">The sort column</param>
        /// <param name="section">Filter by Event Section ID</param>
        /// <param name="status">Filter by Event Status ID</param>
        /// <param name="totalCount">Output parameter to return total rows matching BEFORE paging</param>
        /// <returns>a paged, filtered, ordered list of Equipment calendar data</returns>
        List<EquipmentCalendarData> GetEquipmentCalendarView(DateTime? startDate, int page, int size, string sortDir, string sortBy, string section, string status, out int totalCount,string  trainingCentreIDs, string SelectedGroup, string SelectedEquipmentID, bool ShowWeekends);

        /// <summary>
        /// Returns a paged, filtered, ordered list of Venue calendar data 
        /// </summary>
        /// <param name="startDate">The date to start on</param>
        /// <param name="page">The page number of the resultset</param>
        /// <param name="size">The number of rows in the page</param>
        /// <param name="sortDir">The sort direction</param>
        /// <param name="sortBy">The sort column</param>
        /// <param name="section">Filter by Event Section ID</param>
        /// <param name="status">Filter by Event Status ID</param>
        /// <param name="totalCount">Output parameter to return total rows matching BEFORE paging</param>
        /// <returns>a paged, filtered, ordered list of venue calendar data</returns>
        List<VenueCalendarData> GetVenueCalendarView(DateTime? startDate, int page, int size, string sortDir, string sortBy, string section, string status, out int totalCount,string  trainingCentreIDs, string SelectedGroup, string SelectedVenueID, bool ShowWeekends);

        /// <summary>
        /// Returns a paged, filtered, ordered list of Event calendar data 
        /// </summary>
        /// <param name="startDate">The date to start on</param>
        /// <param name="page">The page number of the resultset</param>
        /// <param name="size">The number of rows in the page</param>
        /// <param name="section">Filter by Event Section ID</param>
        /// <param name="status">Filter by Event Status ID</param>
        /// <param name="totalCount">Output parameter to return total rows matching BEFORE paging</param>
        /// <returns>a paged, filtered, ordered list of event  calendar data</returns>
        List<EventsCalendarData> GetEventsCalendarView(DateTime? startDate, int page, int size, string section, string status, out int totalCount,string  trainingCentreIDs, bool ShowWeekends);
    }
}