﻿using SFR.TOR.Data.Plumbing.Service;

namespace SFR.TOR.Data.Services.Interfaces
{
    /// <summary>
    /// Public interface for the TrainingCentreService
    /// </summary>
    public interface ITrainingCentreService : IEntityService<TrainingCentre>
    {

    }
}