﻿using System;
using System.Linq;
using System.Linq.Expressions;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services.Interfaces
{
    /// <summary>
    /// Public interface for the VenueService
    /// </summary>
    public interface IVenueService : IEntityService<Venue>
    {
        IQueryable<VenueModel> GetVenues(Expression<Func<Venue, bool>> predicate);
        VenueModel GetVenue(int id);
    }
}

