﻿using System.Linq;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services.Interfaces
{
    /// <summary>
    /// Public interface for the EquipmentTagEquipmentService
    /// </summary>
    public interface IEquipmentTagEquipmentService : IEntityService<EquipmentTagEquipment>
    {
        IQueryable<EquipmentTagEquipmentModel> GetEquipmentTags(int id);
    }
}