using System;
using System.Collections.Generic;
using System.Linq;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services.Interfaces
{
    public interface IEventPartResourceService
    {
        IQueryable<InstructorActivityDayPartModel> GetAllInstructorActivityDayParts(int ActivityID, int? TrainingCentreID);

        IQueryable<InstructorAvailabilityModel> GetInstructorsAvailabilityByDate(DateTime? date, int dayType, int activityID, int dayPartID, int[] trainingCentreIDs);

        IQueryable<VenueAvailabilityModel> GetVenuesAvailabilityByDate(EventPart eventPart, List<int> tagIDs, int[] trainingCentreIDs, bool includeAdditionalVenues = true);

        InstructorNumbersModel GetInstructorNumbers(int eventPartID);

        IQueryable<EquipmentAvailabilityModel> GetEquipmentAvailabilityByDate(EventPart ep, List<int> tagIDs, int[] trainingCentreIDs, bool includeAdditionalVenues = true);
    }
}