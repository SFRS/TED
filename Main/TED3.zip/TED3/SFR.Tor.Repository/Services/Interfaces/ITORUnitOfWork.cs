﻿using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Utility.Security;

namespace SFR.TOR.Data.Services.Interfaces
{
    public interface ITORUnitOfWork : IUnitOfWork
    {
        ITORSession Session { get; }
        ISectionService Sections { get; }
        IEventStatusService EventStatus { get; }
        ICalendarService Calendars { get; }
        IReportService Reports { get; }
        IInstructorService Instructors { get; }
        IEquipmentService Equipment { get; }
        IVenueService Venues { get; }
        IEventService Events { get; }
        IActivityService Activities { get; }
        IActivityPartTypeService ActivityPartTypes { get; }
        IEventPartResourceService EventPartResources { get; }
        IEligibleInstructorsForActivityService EligibleInstructorsForActivity { get; }
        IActivityPartService ActivityDayPart { get; }
        IActivityPartInstructorLevelService ActivityPartInstructorLevel { get; }
        IVenueTagService VenueTags { get; }
        IVenueTagActivityPartService VenueTagActivityPart { get; }
        IEquipmentTagService EquipmentTags { get; }
        IEquipmentTagActivityPartService EquipmentTagActivityPart { get; }
        IActivityStatusService ActivityStatus { get; }
        IEventPartService EventParts { get; }
        ICancelEventReasonService CancelEventReasons { get; }
        IPostponeEventReasonService PostponeEventReasons { get; }
        IEventPostponedHistoryService EventPostponedHistory { get; }
        IEventCancelledHistoryService EventCancelledHistory { get; }
        IInstructorEventPartService InstructorEventPart { get; }
        IVenueEventPartService VenueEventParts { get; }
        IEventPriorityService EventPriorities { get; }
        IEquipmentEventPartService EquipmentEventParts { get; }
        IEventPartTypeService EventPartTypes { get; }
        IInstructorUnavailablePeriodService InstructorUnavailablePeriods { get; }
        IUnavailableReasonService UnavailableReasons { get; }
        IEventStatusHistoryService EventStatusHistory { get; }
        IUserService Users { get; }
        ITrainingCentreService TrainingCentres { get; }
        IVenueUnavailablePeriodService VenueUnavailablePeriod { get; }
        IVenueUnavailableReasonService VenueUnavailableReason { get; }
        IEquipmentUnavailablePeriodService EquipmentUnavailablePeriods { get; }
        IEquipmentTagEquipmentService EquipmentTagEquipment { get; }
        IEquipmentUnavailableReasonService EquipmentUnavailableReasons { get; }
        IEquipmentGroupService EquipmentGroups { get; }
        IVenueTagVenueService VenueTagVenues { get; }
        IGroupService Groups { get; }
        IPinchpointService Pinchpoints { get; }
        IPinchpointReasonService PinchpointReasons { get; }
        IPinchpointTypeService PinchpointTypes { get; }
        IGroupCalendarService GroupCalendars { get; }
        IResourceStatusService ResourceStatus { get; }
        IVenueGroupService VenueGroups { get; }
        IInstructorUnavailableReasonGroupsService InstructorUnavailableReasonGroups { get; }
        IInstructorSectionHistoryService InstructorSectionHistories { get; }
        IITrentExportService iTrentExports { get; }
        IITrentExportDataService iTrentExportDatas { get; }
        IITrentExportTypeService iTrentExportTypes { get; }
        IITrentExportErrorsService iTrentExportErrors { get; }
        IITrentImportFailuresService iTrentImportFailures { get; }
    }
}