﻿using System;
using System.Linq;
using System.Linq.Expressions;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Utility;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services.Interfaces
{
    /// <summary>
    /// Public interface for the EventService
    /// </summary>
    public interface IEventService : IEntityService<Event>
    {
        int NumberOfEventsInTimePeriod(DateTime? startDate, DateTime? endDate);

        IQueryable<EventModel> GetEvents(Expression<Func<Event, bool>> predicate);

        EventModel GetEvent(Expression<Func<Event, bool>> predicate);

        int HighestEventNumberInFinancialYear(int activityID, int financialYear);
        
        bool HasResourceAssigned(int eventID);

        void ResetResourceStatus(int eventID, string UserName);

        void UpdateStatus(int eventID, Trigger? trigger, string UserName, int? newStatus = null);

        void ProcessDayCountIncreasedActivityTemplate(int activityID, string UserName, double totalDays);
        void ProcessDayCountReducedActivityTemplate(int activityID, string UserName, double totalDays);

        void ApplyTriggerToMatchingEvents(Expression<Func<Event, bool>> predicate, Trigger trigger, string UserName);

        IQueryable<ITrentEventModel> GetReadyEventsForITrent();
    }
}
