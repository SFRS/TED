﻿using System.Linq;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services.Interfaces
{
    /// <summary>
    /// Public interface for the EventStatusHistoryService
    /// </summary>
    public interface IEventStatusHistoryService : IEntityService<EventStatusHistory>
    {
        IQueryable<EventStatusHistoryModel> GetEventHistory(int id);
    }
}