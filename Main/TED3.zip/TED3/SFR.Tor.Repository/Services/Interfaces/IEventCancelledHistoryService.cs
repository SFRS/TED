﻿using SFR.TOR.Data.Plumbing.Service;

namespace SFR.TOR.Data.Services.Interfaces
{
    /// <summary>
    /// Public interface for the EventCancelledHistoryService
    /// </summary>
    public interface IEventCancelledHistoryService : IEntityService<EventCancelledHistory>
    {

    }
}