using System;
using System.Linq;
using System.Linq.Expressions;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    public class InstructorEventPartService : CrudService<InstructorEventPart>, IInstructorEventPartService
    {
        public InstructorEventPartService(IRepository<InstructorEventPart> repository) : base(repository) { }

        public IQueryable<InstructorEventPartModel> GetInstructorEventParts(Expression<Func<InstructorEventPart, bool>> predicate)
        {
            return SelectFilteredList(predicate)
                .Select(x => new InstructorEventPartModel
                {
                    ID = x.ID,
                    IsLead= x.IsLead, 
                    IsInstructor = x.IsInstructor,
                    IsAssessor = x.IsAssessor,
                    IsShadow = x.IsShadow,
                    IsSpecialist = x.IsSpecialist,
                    EventPartID = x.EventPart.ID,
                    EventID = x.EventPart.EventID
                });  

        }
    }
}