﻿using System.Linq;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for PinchpointReason data access
    /// </summary>
    public class PinchpointReasonService : CrudService<PinchpointReason>, IPinchpointReasonService
    {
        public PinchpointReasonService(IRepository<PinchpointReason> repository) : base(repository)
        {
            
        }

        public IQueryable<PinchPointReasonModel> GetPinchpointReasons()
        {
            var pps = from y in SelectAll()
                      select new PinchPointReasonModel
                      {
                          ID = y.ID,
                          Reason = y.Reason,
                          TypeID = y.TypeID                          
                      };

            return pps;
        }
    }
}