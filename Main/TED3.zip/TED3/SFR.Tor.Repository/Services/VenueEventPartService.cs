﻿using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for VenueEventPart data access
    /// </summary>
    public class VenueEventPartService : CrudService<VenueEventPart>, IVenueEventPartService
    {
        public VenueEventPartService(IRepository<VenueEventPart> repository) : base(repository)
        {
        }
    }
}