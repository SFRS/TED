using System.Linq;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;

namespace SFR.TOR.Data.Services
{
    public class EventPartStatusService : CrudService<EventPart>, IEventPartStatusService
    {
        public EventPartStatusService(IRepository<EventPart> repository) : base(repository) { }
        
        
    }
}