﻿using System.Linq;
using SFR.TOR.Data.Plumbing.Repository;
using SFR.TOR.Data.Plumbing.Service;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.ViewModels;

namespace SFR.TOR.Data.Services
{
    /// <summary>
    /// Service wrapper for UnavailableReason data access
    /// </summary>
    public class VenueUnavailableReasonService : CrudService<VenuesUnavailableReason>, IVenueUnavailableReasonService
    {
        public VenueUnavailableReasonService(IRepository<VenuesUnavailableReason> repository)
            : base(repository)
        {
        }
    }
}
