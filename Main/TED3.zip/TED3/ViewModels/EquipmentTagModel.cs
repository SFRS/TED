namespace SFR.TOR.ViewModels
{
    public class EquipmentTagModel
    {
        public string Name { get; set; }
        public int ID { get; set; }
        public int MinRequired { get; set; }
    }
}