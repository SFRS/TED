﻿namespace SFR.TOR.ViewModels
{
    public class EquipmentCalendarData : CalendarData
    {        
    }

}