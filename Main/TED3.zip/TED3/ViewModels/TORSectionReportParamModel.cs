﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using SFR.TOR.ViewModels.Validators;
using System.Collections.Generic;
using System.Web.Mvc;
namespace SFR.TOR.ViewModels
{
    public class TORSectionReportParamModel : BaseReportParamModel
    {
        [IsValidDateFormat(ErrorMessage = " * From Date is invalid")]
        [Required(ErrorMessage = " * From date is required")]
        [DisplayFormat(ApplyFormatInEditMode=true, DataFormatString="{0:dd/MM/yyyy}")]
        [DisplayName("From Date")]
        [DataType(DataType.Date)]
        public DateTime FromDate { get; set; }

        [IsValidDateFormat(ErrorMessage = " * To Date is invalid")]
        [Required(ErrorMessage = " * To date is required")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        [DisplayName("To Date")]
        [DataType(DataType.Date)]
        [DateGreaterThan(ToDatePropertyName = "ToDate", FromDatePropertyName = "FromDate", ErrorMessage = " * To Date must be after From Date")]
        public DateTime ToDate { get; set; }

        public IEnumerable<SelectListItem> AllSections { get; set; }

        [Required(ErrorMessage = " * You must select 1 section")]
        [DisplayName("Section")]
        public IEnumerable<int> SelectedSection { get; set; }

        [ScaffoldColumn(false)]
        public string SelectedSectionString { get; set; }

        [ScaffoldColumn(false)]
        [DisplayName("Display stats for")]
        public string SelectedReportType { get; set; }
    }
}