﻿using System;
using System.Web.Mvc;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
namespace SFR.TOR.ViewModels
{
    public class ReportIndexModel : BaseModel
    {
        public List<SelectListItem> Reports { get; set; }
    }
}