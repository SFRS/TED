using System;
using System.ComponentModel.DataAnnotations;

namespace SFR.TOR.ViewModels
{
    public class PinchpointModel: BaseModel
    {
        [Required]
        public DateTime StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public int? ReasonID { get; set; }
    }
}