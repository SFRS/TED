﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using SFR.TOR.ViewModels.Validators;
using System.Collections.Generic;
using System.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class InstructorUtilisationParamModel : BaseReportParamModel
    {
        [DisplayName("Week Commencing")]
        public List<SelectListItem> FromDateList { get; set; }

        [DisplayName("Availability Group")]
        public IEnumerable<SelectListItem> AvailabilityReasons { get; set; }

        [ScaffoldColumn(false)]
        public string SelectedAvailabilityReason { get; set; }

        [Required(ErrorMessage = " * You must select a date")]
        [DisplayName("Month Commencing")]
        public IEnumerable<string> SelectedDate { get; set; }

        [ScaffoldColumn(false)]
        public string SelectedDateString { get; set; }

        [DisplayName("Evening events only?")]
        public bool EveningOnlyEvents { get; set; }
     
        public IEnumerable<SelectListItem> MonthYearTimePeriodList { get; set; }
        
        [DisplayName("Display the report for a monthly or yearly time period")]   
        public string SelectedTimePeriod { get; set; }

        [DisplayName("Total Column Stats")]
        public string SelectedReportType { get; set; }
    }
}