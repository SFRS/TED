﻿namespace SFR.TOR.ViewModels
{
    /// <summary>
    /// data class to represent a row in JSon
    /// </summary>
    public class JsonRow
    {
        public string[] cell { get; set; }
        public string id { get; set; }

        public JsonRow(CalendarData calendarData)
        {
            //id = calendarData.Name;
            id = calendarData.ID.ToString();
            cell = new string[17];
            cell[0] = calendarData.Name ?? "";
            cell[1] = calendarData.SectionName != null ? calendarData.SectionName.ToString() : "";
            cell[2] = calendarData.GroupName != null ? calendarData.GroupName.ToString() : "";
            cell[3] = calendarData.Day1AM ?? "";
            cell[4] = calendarData.Day1PM ?? "";
            cell[5] = calendarData.Day2AM ?? "";
            cell[6] = calendarData.Day2PM ?? "";
            cell[7] = calendarData.Day3AM ?? "";
            cell[8] = calendarData.Day3PM ?? "";
            cell[9] = calendarData.Day4AM ?? "";
            cell[10] = calendarData.Day4PM ?? "";
            cell[11] = calendarData.Day5AM ?? "";
            cell[12] = calendarData.Day5PM ?? "";
            cell[13] = calendarData.Day6AM ?? "";
            cell[14] = calendarData.Day6PM ?? "";
            cell[15] = calendarData.Day7AM ?? "";
            cell[16] = calendarData.Day7PM ?? "";
            

        }
    }
}
