﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using SFR.TOR.Utility;
using Trirand.Web.Mvc;
using TextAlign = Trirand.Web.Mvc.TextAlign;

namespace SFR.TOR.ViewModels
{
    public class ResourcesInstructorsModel : ActivityModel
    {

        public JQGrid EligibleInstructors { get; set; }
        public JQGrid DayPartInstructorNumbers { get; set; }

        public ResourcesInstructorsModel(string instructorsURL, string dayPartURL, string instructorEditURL,
            string activityPartEditURL, SelectList sectionData)
        {
            EligibleInstructors = new JQGrid
            {
                Columns = new List<JQGridColumn>()
                {
                    new JQGridColumn
                    {
                        DataField = "Name",
                        HeaderText = "Name",
                        Editable = false,
                        Width = 50,
                        Searchable = false
                    },
                    new JQGridColumn
                    {
                        DataField = "SectionTitle",
                        HeaderText = "Section",
                        Editable = false,
                        Width = 60,
                        Searchable = true
                    }
                    ,
                    new JQGridColumn
                    {
                        DataField = "IsLead",
                        HeaderText = "Lead",
                        Editable = true,
                        TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                        Width = 50,
                        EditType = EditType.CheckBox,
                        EditorControlID = "cbLead",
                        Formatter = new CheckBoxFormatter(),
                        Searchable = false
                    },
                    new JQGridColumn
                    {
                        DataField = "IsInstructor",
                        HeaderText = "Instructor",
                        Editable = true,
                        TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                        Width = 50,
                        EditType = EditType.CheckBox,
                        EditorControlID = "cbInstructor",
                        Formatter = new CheckBoxFormatter(),
                        Searchable = false
                    },
                    new JQGridColumn
                    {
                        DataField = "IsAssessor",
                        HeaderText = "Assessor",
                        Editable = true,
                        TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                        Width = 50,
                        EditType = EditType.CheckBox,
                        EditorControlID = "cbAssessor",
                        Formatter = new CheckBoxFormatter(),
                        Searchable = false
                    },
                    new JQGridColumn
                    {
                        DataField = "IsShadow",
                        HeaderText = "Shadow",
                        Editable = true,
                        TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                        Width = 50,
                        EditType = EditType.CheckBox,
                        EditorControlID = "cbShadow",
                        Formatter = new CheckBoxFormatter(),
                        Searchable = false
                    },
                    new JQGridColumn
                    {
                        DataField = "IsSpecialist",
                        HeaderText = "Specialist",
                        Editable = true,
                        TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                        Width = 50,
                        EditType = EditType.CheckBox,
                        EditorControlID = "cbSpecialist",
                        Formatter = new CheckBoxFormatter(),
                        Searchable = false
                    },
                    new JQGridColumn
                    {
                        PrimaryKey = true,
                        DataField = "ID",
                        Visible = false,
                    },
                    new JQGridColumn
                    {
                        EditActionIconsColumn = true,
                        EditActionIconsSettings = new EditActionIconsSettings
                        {
                            SaveOnEnterKeyPress = true,
                            ShowDeleteIcon = false
                        },
                        HeaderText = " ",
                        Width = 20,
                        Sortable = false,
                        TextAlign = TextAlign.Center,
                        Searchable = false
                    },
                },

                Width = Unit.Pixel(900),
                Height = Unit.Percentage(100),
                PagerSettings =
                {
                    PageSize = 10
                },
                ID = "EligibleInstructorsGrid",
                DataUrl = instructorsURL,
                EditUrl = instructorEditURL,
                ToolBarSettings = new ToolBarSettings()
                {
                    ShowSearchToolBar = true

                },
                SortSettings = new SortSettings()
                {
                    InitialSortColumn = "SectionTitle"
                }
            };

            EligibleInstructors.SetupDropDownFilterColumn("SectionTitle", SearchOperation.IsEqualTo, SearchType.DropDown,
                sectionData, true);


            DayPartInstructorNumbers = new JQGrid
            {
                Columns = new List<JQGridColumn>()
                {
                    new JQGridColumn
                    {
                        DataField = "Name",
                        HeaderText = "Day",
                        Editable = false,
                        Width = 40
                    },
                    new JQGridColumn
                    {
                        DataField = "LeadsCount",
                        HeaderText = "Leads",
                        Editable = true,
                        Width = 20,
                        TextAlign = Trirand.Web.Mvc.TextAlign.Center
                    }
                    ,
                    new JQGridColumn
                    {
                        DataField = "InstructorCount",
                        HeaderText = "Instructors",
                        Editable = true,
                        Width = 20,
                        TextAlign = Trirand.Web.Mvc.TextAlign.Center
                    },
                    new JQGridColumn
                    {
                        DataField = "AssessorCount",
                        HeaderText = "Assessors",
                        Editable = true,
                        Width = 20,
                        TextAlign = Trirand.Web.Mvc.TextAlign.Center
                    },
                    new JQGridColumn
                    {
                        DataField = "ShadowCount",
                        HeaderText = "Shadows",
                        Editable = true,
                        Width = 20,
                        TextAlign = Trirand.Web.Mvc.TextAlign.Center
                    },
                    new JQGridColumn
                    {
                        DataField = "SpecialistCount",
                        HeaderText = "Specialists",
                        Editable = true,
                        Width = 20,
                        TextAlign = Trirand.Web.Mvc.TextAlign.Center
                    },
                    new JQGridColumn
                    {
                        PrimaryKey = true,
                        DataField = "ID",
                        Visible = false
                    },
                    new JQGridColumn
                    {
                        EditActionIconsColumn = true,
                        EditActionIconsSettings = new EditActionIconsSettings
                        {
                            SaveOnEnterKeyPress = true,
                            ShowDeleteIcon = false
                        },
                        HeaderText = " ",
                        Width = 10,
                        Sortable = false,
                        TextAlign = TextAlign.Center
                    }
                },
                Width = Unit.Pixel(900),
                Height = Unit.Percentage(100),
                PagerSettings =
                {
                    PageSize = 10
                },
                ID = "requiredInstructorsNumbersGrid",
                DataUrl = dayPartURL,
                EditUrl = activityPartEditURL,
                SortSettings = new SortSettings()
                {
                    InitialSortColumn = "Name"
                }
            };
        }
    }
}