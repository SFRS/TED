﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using SFR.TOR.ViewModels.Validators;
using System.Web.Mvc;
using System.Collections.Generic;
namespace SFR.TOR.ViewModels
{
    public class InstructorAssignmentsReportParamModel : BaseReportParamModel
    {
        [Required(ErrorMessage = " * From date is required")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        [DisplayName("From Date")]
        [IsValidDateFormat(ErrorMessage = " * To Date is invalid")]
        [DataType(DataType.Date)]
        public DateTime FromDate { get; set; }

        [Required(ErrorMessage = " * To date is required")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        [DisplayName("To Date")]
        [DataType(DataType.Date)]
        [IsValidDateFormat(ErrorMessage = " * To Date is invalid")]
        [DateGreaterThan(ToDatePropertyName = "ToDate", FromDatePropertyName = "FromDate", ErrorMessage = " * To Date must be after From Date")]
        public DateTime ToDate { get; set; }
        
        [Required(ErrorMessage = " * You must provide an instructor name")]
        [ScaffoldColumn(false)]
        [Range(1, Int32.MaxValue, ErrorMessage = " * You must select the instructor from the list")]
        public int SelectedInstructor { get; set; }

        [ScaffoldColumn(false)]
        public string SelectedInstructorString { get; set; }

        [ScaffoldColumn(false)]
        [Required(ErrorMessage = " * You must provide an instructor name")]
        public string InstructorSearchString { get; set; }

        [ScaffoldColumn(false)]
        [DisplayName("Display stats for")]
        public string SelectedReportType { get; set; }
    }
}