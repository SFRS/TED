namespace SFR.TOR.ViewModels
{
    public class InstructorUnavailableReasonModel : BaseModel
    {
        public string Reason { get; set; }
        public int UnavailableReasonGroupID { get; set; }
    }
}