﻿using System;

namespace SFR.TOR.ViewModels 
{
    public class VenueEditAvailabilityModel : BaseModel
    {
        public int VenueID { get; set; }
        public DateTime StartDate { get; set; }
        public TimeSpan StartTime { get; set; }


        public DateTime? EndDate { get; set; }
        public TimeSpan EndTime { get; set; }
        public int VenueUnavailableReasonID { get; set; }

        public int DayTypeID { get; set; }

        public string Comments { get; set; }
    }
 }
