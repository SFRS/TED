﻿using System;
using System.Collections.Generic;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using System.Reflection;
using System.Text.RegularExpressions;

namespace SFR.TOR.ViewModels.Validators
{
    public class IsValidDateFormatAttribute : ValidationAttribute, IClientValidatable
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            string pattern = SFR.TOR.Utility.Constants.REGEX_UK_DATE_FORMAT;
            string date = value.ToString().Split(' ')[0]; //value = 'dd/MM/yyyy hh:mm:ss'
            Match match = Regex.Match(date, pattern);

            if (!match.Success)
            {
                var message = FormatErrorMessage(validationContext.DisplayName);
                return new ValidationResult(message);
            }

            return ValidationResult.Success;
        }

        public IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            yield return new ModelClientValidationRule
            {
                ErrorMessage = this.ErrorMessage,
                ValidationType = "isvaliddateformat"
            };
        }
    }
}