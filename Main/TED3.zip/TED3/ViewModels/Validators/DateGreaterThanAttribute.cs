﻿using System;
using System.Collections.Generic;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using System.Reflection;

namespace SFR.TOR.ViewModels.Validators
{
    public class DateGreaterThanAttribute : ValidationAttribute, IClientValidatable
    {
        public string ToDatePropertyName { get; set; }
        public string FromDatePropertyName { get; set; }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            PropertyInfo fromDateProperty = validationContext.ObjectType.GetProperty(FromDatePropertyName);

            var toDate = (DateTime)value;
            var fromDate = (DateTime)fromDateProperty.GetValue(validationContext.ObjectInstance, null);

            bool isValid = fromDate < toDate || fromDate == toDate;

            if (!isValid)
            {
                var message = FormatErrorMessage(validationContext.DisplayName);
                return new ValidationResult(message);
            }

            return ValidationResult.Success;
        }

        public IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            yield return new ModelClientValidationRule
            {
                ErrorMessage = this.ErrorMessage,
                ValidationType = "dategreaterthan"
            };
        }
    }
}