﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace SFR.TOR.ViewModels.Validators
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public class AssertValueAttribute : ValidationAttribute, IClientValidatable
    {
        public object AssertedValue { get; protected set; }

        public AssertValueAttribute(object value)
        {
            AssertedValue = value;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            bool match = false;

            try
            {
                match = AssertedValue.Equals(value);
            }
            catch (Exception e) { }

            if (match)
                return ValidationResult.Success;
            else
                return new ValidationResult(FormatErrorMessage(validationContext.DisplayName));
        }

        public IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            var rule = new ModelClientValidationRule
            {
                ErrorMessage = this.ErrorMessage,
                ValidationType = "assertvalue"
            };

            rule.ValidationParameters.Add("asserted", AssertedValue);
            yield return rule;
        }
    }
}