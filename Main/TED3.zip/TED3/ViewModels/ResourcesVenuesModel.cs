﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class ResourcesVenuesModel: ActivityModel
    {
        public List<DayVenuesModel> DayVenueData { get; set; }

        public List<SelectListItem> VenueTags { get; set; }

        public int ActivityPartID { get; set; }

        public double MinRequired { get; set; }
        

        public ResourcesVenuesModel()
        {
            
        }

    }
}