using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    /// <summary>
    /// base class for Calendar model objects
    /// </summary>
    public abstract class CalendarModel
    {
        public string ViewTitle { get; set; }
        public List<DateTime> Dates { get; set; }
        public bool ShowWeekend { get; set; }
        public SelectList TrainingCentres { get; set; }
        public SelectList Sections { get; set; }
        public string[] SelectedSection { get; set; }
        public string[] SelectedTrainingCentres { get; set; }

        public SelectList StatusData { get; set; }
        public string[] SelectedStatus { get; set; }
        public DateTime? StartDate { get; set; }
        public string Datepicker { get; set; }

        public bool ShowFilterBar { get; set; }

        public string[] SelectedGroup { get; set; }

        public SelectList GroupData { get; set; }

        public string[] SelectedItemID { get; set; }
        public MultiSelectList ItemData { get; set; }
    }
}