namespace SFR.TOR.ViewModels
{
    public class CreateEquipmentCategoryModel
    {
        public int ID { get; set; }
        public int EquipmentTagID { get; set; }
        public int ActivityPartID { get; set; }
        public int MinRequired { get; set; }
    }
}