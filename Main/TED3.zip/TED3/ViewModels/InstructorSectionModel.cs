namespace SFR.TOR.ViewModels
{
    public class InstructorSectionModel : BaseModel
    {
        public string Title { get; set; }
    }
}