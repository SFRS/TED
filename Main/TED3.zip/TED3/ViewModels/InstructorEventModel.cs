namespace SFR.TOR.ViewModels
{
    public class InstructorEventModel
    {
        public int ID { get; set; }
        public bool SelectedLead { get; set; }
        public bool SelectedAssessor { get; set; }
        public bool SelectedShadow { get; set; }
        public bool SelectedInstructor { get; set; }
        public bool SelectedSpecialist { get; set; }
    }
}