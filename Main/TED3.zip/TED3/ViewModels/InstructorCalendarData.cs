﻿namespace SFR.TOR.ViewModels
{
    public class InstructorCalendarData : CalendarData
    {
        
    }
}