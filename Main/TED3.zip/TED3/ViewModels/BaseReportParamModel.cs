﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class BaseReportParamModel
    {
        public List<SelectListItem> Reports { get; set; }

        [ScaffoldColumn(false)]
        public bool RunReport { get; set; }

        [ScaffoldColumn(false)]
        public string SelectedReport { get; set; }
    }
}
