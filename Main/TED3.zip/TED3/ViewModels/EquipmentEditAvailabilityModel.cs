﻿using System;

namespace SFR.TOR.ViewModels
{
    public class EquipmentEditAvailabilityModel : BaseModel
    {
        public int EquipmentID { get; set; }
        public DateTime StartDate { get; set; }
        public TimeSpan StartTime { get; set; }
        public DateTime? EndDate { get; set; }
        public TimeSpan EndTime { get; set; }
        public int EquipmentUnavailableReasonID { get; set; }

        public int DayTypeID { get; set; }
        public string Comments { get; set; }
    }
}
