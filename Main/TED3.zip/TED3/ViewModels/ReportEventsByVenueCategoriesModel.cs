﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SFR.TOR.ViewModels
{
    public class ReportEventsByVenueCategoriesModel
    {
        public ReportEventsByVenueCategoriesModel()
        {
            EventsByVenueCategories = new List<EventsByVenueCategoriesData>();
        }

        public List<IEnumerable> GetReportData()
        {
            // Must return datasets in the order expected by the report
            return new List<IEnumerable> { EventsByVenueCategories };
        }

        // DataSet1
        public List<EventsByVenueCategoriesData> EventsByVenueCategories { get; set; }

        public class EventsByVenueCategoriesData
        {
            public string VenueName { get; set; }
            public DateTime BookingDate { get; set; }
            public TimeSpan StartTime { get; set; }
            public TimeSpan EndTime { get; set; }
            public string EventTitle { get; set; }
            public string EventSection { get; set; }
            public string TrainingCentre { get; set; }
            public string VenueGroupTitle { get; set; }
        }
    }
}
