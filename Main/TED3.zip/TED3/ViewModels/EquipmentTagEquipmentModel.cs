﻿
namespace SFR.TOR.ViewModels
{
    public class EquipmentTagEquipmentModel: BaseModel
    {
        public int EquipmentID { get; set; }
        public int EquipmentTagID { get; set; }
        public string Name { get; set; }
    }
}
