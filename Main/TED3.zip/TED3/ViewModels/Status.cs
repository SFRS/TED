﻿namespace SFR.TOR.ViewModels
{
    public enum Status
    {
        Empty = 0,
        NotReady,
        Ready,
        Scheduled,
        Blocked
    }
}