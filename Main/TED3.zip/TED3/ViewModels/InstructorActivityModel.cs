﻿namespace SFR.TOR.ViewModels
{
    public class InstructorActivityModel: BaseModel
    {        
        public int ActivityID { get; set; }        
        public bool IsLead { get; set; }
        public bool IsInstructor { get; set; }
        public bool IsAssessor { get; set; }
        public bool IsShadow { get; set; }
        public bool IsSpecialist { get; set; }
    }
}