using System;
using System.ComponentModel.DataAnnotations;

namespace SFR.TOR.ViewModels
{
    public class InstructorEditAvailabilityModel : BaseModel
    {
        public int InstructorID { get; set; }

        [Required]
        public DateTime StartDate { get; set; }
        public TimeSpan StartTime { get; set; }
        public DateTime? EndDate { get; set; }
        public TimeSpan EndTime { get; set; }

        [Required]
        public int UnavailableReasonID { get; set; }
        public string UnavailableReasonGroup { get; set; }
        public string UnavailableReason { get; set; }

        [Required]
        public int DayTypeID { get; set; }
        public string DayType { get; set; }

        public string Comments { get; set; }
    }
}