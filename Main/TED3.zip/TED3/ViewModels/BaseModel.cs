﻿namespace SFR.TOR.ViewModels
{
    public abstract class BaseModel
    {
        public int ID { get; set; }
    }
}