namespace SFR.TOR.ViewModels
{
    public class VenueAvailabilityModel
    {
        public int ID { get; set; }

        public string Venue { get; set; }

        public bool? Free { get; set; }
        public bool? Booked { get; set; }

        public string EventName { get; set; }

        public int? DayType { get; set; }
        
        public int? ActivityTemplateID { get; set; }

        public int DayPartID { get; set; }

        public bool? NeedsCatering { get; set; }

        public string VenueTag { get; set; }

        public int VenueUnavailableReasonID { get; set; }

        public int? VenueTagID { get; set; }

        public int TrainingCentreId { get; set; }

        public string TrainingCentreName { get; set; }
    }
}