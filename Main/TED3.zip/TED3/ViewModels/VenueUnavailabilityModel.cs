﻿using System.Collections.Generic;
using System.Web.UI.WebControls;
using Trirand.Web.Mvc;
using SortDirection = Trirand.Web.Mvc.SortDirection;

namespace SFR.TOR.ViewModels
{
    public class VenueUnavailabilityModel : BaseModel
    {
        public JQGrid Unavailability { get; set; }
        public string Name { get; set; }
        public VenueUnavailabilityModel(string dataURL, string editURL)
        {
            Unavailability = new JQGrid
                {
                    Columns = new List<JQGridColumn>()
                        {
                            new JQGridColumn
                                {
                                    DataField = "ID",
                                    PrimaryKey = true,
                                    Visible = false                                    
                                },                                 
                            new JQGridColumn
                                {
                                    DataField = "VenueUnavailableReasonID",
                                    HeaderText = "Reason",
                                    Editable = true,
                                    EditType = EditType.Custom,
                                    EditTypeCustomCreateElement = "createDropDown",
                                    EditTypeCustomGetValue = "getSelectedReason",                                                         
                                    Formatter = new CustomFormatter
                                    {
                                        FormatFunction = "formatReason",                                                             
                                    },
                                    Width = 50
                                },     
                            new JQGridColumn
                                {
                                    DataField = "Comments",
                                    HeaderText = "Comments",
                                    Editable = true,                                    
                                    Width = 50,
                                    EditClientSideValidators = new List<JQGridEditClientSideValidator>
                                                             {
                                                               new Trirand.Web.Mvc.CustomValidator()
                                                                   {
                                                                       ValidationFunction = "CheckCommentLength"
                                                                   }
                                                              }
                                },   
                            new JQGridColumn
                                {
                                    DataField = "DayTypeID",
                                    HeaderText = "Period",
                                    Editable = true,
                                    EditType = EditType.Custom,
                                    EditTypeCustomCreateElement = "createDayTypeDropDown",
                                    EditTypeCustomGetValue = "getSelectedDayType",                                                         
                                    Formatter = new CustomFormatter
                                    {
                                        FormatFunction = "formatDayType",                                                             
                                    },
                                    Width = 50
                                }, 
                            new JQGridColumn
                                {
                                    DataField = "StartDate",
                                    HeaderText = "Start Date",
                                    Editable = true,
                                    Width = 20,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                    EditType = EditType.DatePicker,
                                    EditorControlID = "DatePicker",  
                                    DataFormatString = "{0:dd/MM/yyyy}",
                                    EditClientSideValidators = new List<JQGridEditClientSideValidator>()
                                        {
                                            new RequiredValidator()
                                        }
                                },
                            
                            new JQGridColumn
                                {
                                    DataField = "EndDate",
                                    HeaderText = "End Date",
                                    Editable = true,
                                    DataFormatString = "{0:dd/MM/yyyy}",
                                    Width = 20,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                    EditType = EditType.DatePicker,
                                    EditorControlID = "DatePicker"
                                },
                                                 
                            new JQGridColumn 
                                {
                                    EditActionIconsColumn = true, 
                                    EditActionIconsSettings = new EditActionIconsSettings
                                                                {
                                                                    SaveOnEnterKeyPress = true,
                                                                    ShowDeleteIcon = true,
                                                                    ShowEditIcon = true
                                                                }, 
                                    HeaderText = " ", 
                                    Width = 30,
                                    Sortable = false,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                                                      
                                }
                        },
                    Width = Unit.Pixel(900),
                    Height = Unit.Percentage(100),
                    PagerSettings =
                        {
                            PageSize = 20
                        },
                    ID = "UnavailabilityGrid",
                    DataUrl = dataURL,
                    EditUrl = editURL,
                    ToolBarSettings = new ToolBarSettings()
                    {
                        ShowAddButton = true,
                        ToolBarPosition = ToolBarPosition.Bottom
                    },
                    ClientSideEvents = new ClientSideEvents()
                    {
                        AfterAddDialogShown = "addDialogEvents"
                    },
                    SortSettings = new SortSettings()
                        {
                            InitialSortColumn = "StartDate",
                            InitialSortDirection = SortDirection.Desc
                        },          
          
                   AddDialogSettings = new AddDialogSettings(){
                       CloseAfterAdding = true
                   }
                };
        }
    }
}