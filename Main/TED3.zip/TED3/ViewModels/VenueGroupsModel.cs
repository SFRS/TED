﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Trirand.Web.Mvc;
using System.Web.UI.WebControls;

namespace SFR.TOR.ViewModels
{
    public class VenueGroupsModel : BaseModel
    {
        public string Title { get; set; }
        public string Name { get; set; }

        public JQGrid VenueGroups { get; set; }

        public VenueGroupsModel(string dataURL, string editURL)
        {
            VenueGroups = new JQGrid
            {
                Columns = new List<JQGridColumn>()
                        {
                            new JQGridColumn
                                {
                                    DataField = "ID",
                                    PrimaryKey = true,
                                    Visible = false                                    
                                },                                   
                            new JQGridColumn
                                {
                                    DataField = "Title",
                                    PrimaryKey = true,
                                    Visible = true,     
                                    HeaderText = "Title",
                                    Editable = true
                                },
                            new JQGridColumn 
                                {
                                    EditActionIconsColumn = true, 
                                    EditActionIconsSettings = new EditActionIconsSettings
                                        {
                                            ShowEditIcon = true,
                                            ShowDeleteIcon = false
                                        }, 
                                    HeaderText = " ", 
                                    Width = 20,
                                    Sortable = false,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,                                                                      
                                }
                        },
                Width = Unit.Pixel(500),
                Height = Unit.Percentage(100),
                ToolBarSettings = new ToolBarSettings()
                {
                    ShowAddButton = true,
                    ShowDeleteButton = true
                },
                PagerSettings =
                {
                    PageSize = 20
                },
                ID = "VenuesGroupGrid",
                DataUrl = dataURL,
                EditUrl = editURL,
                SortSettings = new SortSettings()
                {
                    InitialSortColumn = "Title"
                },
                AddDialogSettings = new AddDialogSettings()
                {
                    CloseAfterAdding = true
                }
            };
        }
    }
}
