﻿using System.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class EventEditModel: EventModel
    {
        public SelectList Priorities { get; set; }

        public SelectList StatusData { get; set; }
    }
}