using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace SFR.TOR.ViewModels
{
    [DateChoice]
    public class GenerateEventsModel
    {
        public int NumberofEvents { get; set; }
        public int ActivityID { get; set; }
        public int FinancialYear { get; set; }
        public int Priority { get; set; }
        
        public int DateChoice { get; set; }

        public string SpecificDate { get; set; }        
        public string StartDate { get; set; }        
        public string EndDate { get; set; }
        
    }

    public class DateChoiceAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(value);
            string SpecificDate = (string)properties.Find("SpecificDate", true).GetValue(value);
            string StartDate = (string)properties.Find("StartDate", true).GetValue(value);
            string EndDate = (string)properties.Find("EndDate", true).GetValue(value);

            int DateChoice = (int)properties.Find("DateChoice", true).GetValue(value);

            switch (DateChoice)
            {
                case 1:
                    return true;                    
                case 2:
                    if (string.IsNullOrEmpty(SpecificDate))
                    {
                        ErrorMessage = "Please enter a value for the Specific Date.";
                        return false;
                    }
                    break;
                case 3:
                    if (string.IsNullOrEmpty(StartDate) || string.IsNullOrEmpty(EndDate))
                    {
                        ErrorMessage = "Please enter both start date and end date.";
                        return false;
                    }
                    else
                    {
                        DateTime s = DateTime.Parse(StartDate);
                        DateTime e = DateTime.Parse(EndDate);

                        if (e < s)
                        {
                            ErrorMessage = "End date must be later than start date.";
                            return false;
                        }                        

                    }
                    break;
            }
            return true;
        }
    }
}