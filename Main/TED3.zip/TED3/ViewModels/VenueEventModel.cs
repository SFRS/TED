namespace SFR.TOR.ViewModels
{
    public class VenueEventModel
    {
        public int ID { get; set; }
        public bool Booked { get; set; }
        public bool NeedsCatering { get; set; }
        public string VenueTag { get; set; }

        public int? VenueTagID { get; set; }
    }
}