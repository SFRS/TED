using System;

namespace SFR.TOR.ViewModels
{
    public class GroupCalendarItemModel: BaseModel
    {
        public DateTime GroupDate { get; set; }
        public string Title { get; set; }
    }
}