using System.Collections.Generic;

namespace SFR.TOR.ViewModels
{
    public class EventVenueSummaryModel
    {
        public string VenueCategory { get; set; }

        public List<string> Venues { get; set; }

        public string SummaryOfNumbers { get; set; }

        public bool Fulfilled { get; set; }
    }
}