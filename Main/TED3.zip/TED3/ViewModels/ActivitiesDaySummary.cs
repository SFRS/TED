﻿using System.Collections.Generic;

namespace SFR.TOR.ViewModels
{
    public class ActivityPartSummary
    {
        public string Name { get; set; }        
        public string Description { get; set; }

        public List<ActivityPartInstructorLevelModel> PeopleLevels { get; set; }

        public List<VenueDayPartModel> VenueTags { get; set; }

        public List<EquipmentDayPartModel> EquipmentTags { get; set; }
    }
}