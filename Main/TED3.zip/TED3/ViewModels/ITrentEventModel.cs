
using System;

namespace SFR.TOR.ViewModels
{
    public class ITrentEventModel
    {
        public int ID { get; set; }
        public string ActivityCode { get; set; }
        public string EventCode { get; set; }
        public string Title { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public TimeSpan? StartTime { get; set; }
        public TimeSpan? EndTime { get; set; }

        public int Status { get; set; }
        public string StatusText { get; set; }
        public string CancelReason { get; set; }
        public DateTime? CancelledOn { get; set; }
    }
}