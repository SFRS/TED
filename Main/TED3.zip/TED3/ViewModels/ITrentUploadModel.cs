﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using SFR.TOR.Utility;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using SFR.TOR.ViewModels.Validators;
using DataAnnotationsExtensions;

namespace SFR.TOR.ViewModels
{
    public class ITrentUploadModel
    {
        public IEnumerable<SelectListItem> ITrentUploadTypes { get; set; }

        [DisplayName("iTrent Export Type"), Required]
        public iTrentExportTypeEnum? SelectedITrentExportType { get; set; }

        public IEnumerable<SelectListItem> FinancialYearsSelectList { get; set; }

        [DisplayName("Financial Year"), Required]
        public int SelectedFinancialYear { get; set; }
        
        [DisplayName("Export Title"), Required, StringLength(250)]
        public string Title { get; set; }

        [AssertValue(true, ErrorMessage = "No events are selected for export")]
        public bool EventsFound { get; set; }

        [AssertValue(false, ErrorMessage = "A pending export already exists")]
        public bool PendingExportFound { get; set; }
    }
}
