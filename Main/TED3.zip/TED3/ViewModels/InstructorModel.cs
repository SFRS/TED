﻿namespace SFR.TOR.ViewModels
{
    public class InstructorModel : BaseModel
    {
        public string Name { get; set; }

        public string Section { get; set; }

        public string TrainingCentre { get; set; }

        public string Availability { get; set; }

        public string Group { get; set; }
    }
}