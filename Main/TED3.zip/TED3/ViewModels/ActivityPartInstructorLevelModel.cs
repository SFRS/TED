using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
namespace SFR.TOR.ViewModels
{
    public class ActivityPartInstructorLevelModel : BaseModel
    {
        public string Name { get; set; }
		
        [DisplayName("Leads")]
        [Required(ErrorMessage = "A Number is required for {0}")]
        [Range(0, int.MaxValue, ErrorMessage = "{0} number must be in range")]
        public int LeadsCount { get; set; }

        [DisplayName("Assessors")]
        [Required(ErrorMessage = "A Number is required for {0}")]
        [Range(0, int.MaxValue, ErrorMessage = "{0} number must be in range")]
        public int AssessorCount { get; set; }

        [DisplayName("Instructors")]
        [Required(ErrorMessage = "A Number is required for {0}")]
        [Range(0, int.MaxValue, ErrorMessage = "{0} number must be in range")]
        public int InstructorCount { get; set; }

        [DisplayName("Shadows")]
        [Required(ErrorMessage = "A Number is required for {0}")]
        [Range(0, int.MaxValue, ErrorMessage = "{0} number must be in range")]
        public int ShadowCount { get; set; }

        [DisplayName("Specialists")]
        [Required(ErrorMessage = "A Number is required for {0}")]
        [Range(0, int.MaxValue, ErrorMessage = "{0} number must be in range")]
        public int SpecialistCount { get; set; }
    }
}