﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using SFR.TOR.Utility;
using Trirand.Web.Mvc;
using SortDirection = Trirand.Web.Mvc.SortDirection;

namespace SFR.TOR.ViewModels
{
    public class InstructorSectionHistoryModel : BaseModel
    {
        public JQGrid SectionHistory { get; set; }

        public string Name { get; set; }
        public InstructorSectionHistoryModel(string dataURL, string editURL)
        {
            SectionHistory = new JQGrid
                {
                    Columns = new List<JQGridColumn>()
                        {
                            new JQGridColumn
                                {
                                    DataField = "ID",
                                    PrimaryKey = true,
                                    Visible = false                                    
                                }, 
                            new JQGridColumn
                                {
                                    DataField = "SectionID",
                                    HeaderText = "Section Title",
                                    Width = 40,
                                    Editable = true,
                                    EditType = EditType.Custom,
                                    EditTypeCustomCreateElement = "createSectionDropDown",
                                    EditTypeCustomGetValue = "getSelectedSection",                                                         
                                    Formatter = new CustomFormatter
                                        {
                                            FormatFunction = "formatSection",                                                             
                                        },
                                },
                            new JQGridColumn
                                {
                                    DataField = "StartDate",
                                    HeaderText = "Start Date",
                                    Editable = true,
                                    Width = 20,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                    EditType = EditType.DatePicker,
                                    EditorControlID = "DatePicker",  
                                    DataFormatString = "{0:dd/MM/yyyy}", 
                                    EditClientSideValidators = new List<JQGridEditClientSideValidator>()
                                        {
                                            new RequiredValidator()
                                        }
                                },
                           new JQGridColumn
                                {
                                    DataField = "EndDate",
                                    HeaderText = "End Date",
                                    Editable = true,
                                    DataFormatString = "{0:dd/MM/yyyy}",
                                    Width = 20,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                    EditType = EditType.DatePicker,
                                    EditorControlID = "DatePicker",
                                    EditClientSideValidators = new List<JQGridEditClientSideValidator>
                                        {
                                        new Trirand.Web.Mvc.CustomValidator()
                                            {
                                                ValidationFunction = "ValidateDates"                                                                       
                                            }
                                        }
                                },
                            new JQGridColumn 
                                {
                                    EditActionIconsColumn = true, 
                                    EditActionIconsSettings = new EditActionIconsSettings
                                        {
                                            SaveOnEnterKeyPress = true,
                                            ShowDeleteIcon = true,
                                            ShowEditIcon = true
                                        }, 
                                    HeaderText = " ", 
                                    Width = 10,
                                    Sortable = false,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                                                      
                                }
                        },
                    Width = Unit.Pixel(800),
                    Height = Unit.Percentage(100),
                    PagerSettings =
                        {
                            PageSize = 30
                        },
                    ID = "SectionHistoryGrid",
                    DataUrl = dataURL,
                    EditUrl = editURL,
                    ClientSideEvents = new ClientSideEvents()
                        {
                            AfterAddDialogShown = "addDialogEvents"
                        },
                    ToolBarSettings = new ToolBarSettings()
                        {
                            ShowAddButton = true,
                            ToolBarPosition = ToolBarPosition.Bottom
                        },
                    SortSettings = new SortSettings()
                        {
                            InitialSortColumn = "StartDate",
                            InitialSortDirection = SortDirection.Desc
                        },
                    AddDialogSettings = new AddDialogSettings(){
                        CloseAfterAdding = true
                   }
                };   
        }
    }
}