﻿using System.ComponentModel.DataAnnotations;
using System;
using System.ComponentModel;
namespace SFR.TOR.ViewModels
{   
    public class EditVenueCategoryModel
    {
        public int ID { get; set; }

        [DisplayName("minimum number of venues")]
        [Required(ErrorMessage = " * Number of venues must be at least 1")]
        [Range(1, Int32.MaxValue, ErrorMessage = " * Number of venues must be at least 1")]
        public int MinRequired { get; set; }
    }
}
