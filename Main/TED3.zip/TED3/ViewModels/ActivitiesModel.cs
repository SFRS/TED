﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using SFR.TOR.Utility;
using Trirand.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class ActivitiesModel
    {
        public List<SelectListItem> FinancialYears { get; set; }

        public JQGrid Activities { get; set; }

        public ActivitiesModel(string dataURL, SelectList sectionData, SelectList statusData)
        {
            Activities = new JQGrid
                {
                    Columns = new List<JQGridColumn>()
                        {
                            new JQGridColumn
                                {
                                    DataField = "Code",
                                    HeaderText = "Code",
                                    Editable = true,
                                    Width = 40,
                                    Searchable = false
                                },
                            new JQGridColumn
                                {
                                    DataField = "Title",
                                    HeaderText = "Title",
                                    Editable = true,
                                    Width = 100,
                                    Searchable = false
                                }
                            ,
                            new JQGridColumn
                                {
                                    DataField = "Section",
                                    HeaderText = "Section",
                                    Editable = true,
                                    Searchable = true,
                                    Width = 100
                                },
                            new JQGridColumn
                                {
                                    DataField = "TotalDays",
                                    HeaderText = "Total Days",
                                    Editable = true,
                                    Width = 40,
                                    Searchable = false
                                },
                            new JQGridColumn
                                {
                                    DataField = "Status",
                                    HeaderText = "Status",
                                    Editable = true,
                                    Width = 40,
                                },
                            new JQGridColumn
                                {
                                    DataField = "ExistingEvents",
                                    Editable = false,
                                    Visible = false,
                                    Width = 50
                                },
                            new JQGridColumn
                                {
                                    DataField = "ID",
                                    HeaderText = " ",
                                    Width = 50,
                                    Sortable = false,
                                    Searchable = false,
                                    Formatter = new CustomFormatter
                                        {
                                            FormatFunction = "formatLinks",
                                            UnFormatFunction = "unformatLinks"
                                        }
                                },
                        },
                    Width = Unit.Pixel(900),
                    Height = Unit.Percentage(100),
                    PagerSettings =
                        {
                            PageSize = 20
                        },
                    ID = "ActivitiesGrid",
                    DataUrl = dataURL,
                    SortSettings = new SortSettings()
                        {
                            InitialSortColumn = ""
                        },
                    ToolBarSettings = new ToolBarSettings()
                        {
                            ShowSearchToolBar = true

                        }
                };

            Activities.SetupDropDownFilterColumn("Section", SearchOperation.IsEqualTo, SearchType.DropDown, sectionData, true);
            Activities.SetupDropDownFilterColumn("Status", SearchOperation.IsEqualTo, SearchType.DropDown, statusData, true);
        }

    }

}