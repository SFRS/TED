﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SFR.TOR.ViewModels
{
    public class ReportInstructorAssignmentsModel
    {
        public ReportInstructorAssignmentsModel()
        {
            InstructorAssignments = new List<InstructorAssignmentsData>();
            Instructors = new List<InstructorData>();
            InstructorAssignmentTotals = new List<InstructorAssignmentTotalsData>();
            TotalDays = new List<TotalDaysData>();
        }

        public List<IEnumerable> GetReportData()
        {
            // Must return datasets in the order expected by the report
            return new List<IEnumerable> { InstructorAssignments, Instructors, InstructorAssignmentTotals, TotalDays };
        }

        // DataSet1
        public List<InstructorAssignmentsData> InstructorAssignments { get; set; }

        // DataSet2
        public List<InstructorData> Instructors { get; set; }

        // DataSet3
        public List<InstructorAssignmentTotalsData> InstructorAssignmentTotals { get; set; }

        // DataSet4
        public List<TotalDaysData> TotalDays { get; set; }

        public class InstructorAssignmentsData
        {
            public string Activity { get; set; }
            public string EventTitle { get; set; }
            public string EventStatus { get; set; }
            public string AvailabilityReasons { get; set; }
            public DateTime StartDate { get; set; }
            public TimeSpan StartAMPM { get; set; }
            public DateTime? EndDate { get; set; }
            public TimeSpan? EndAMPM { get; set; }
            /* The following string field ought to be a double, but for unknown reasons AutoMapper 
             * isn't setting the value correctly based on what was found in the SqlDataReader */
            public string DaysCounted { get; set; }
        }

        public class InstructorData
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string SectionName { get; set; }
        }

        public class InstructorAssignmentTotalsData
        {
            public double TotalDaysBusy { get; set; }
            public double TotalFreeDays { get; set; }
            public double TotalDaysTraining { get; set; }
            public double TotalDaysOtherTraining { get; set; }
            public double TotalDaysNonTraining { get; set; }
            public double TotalDaysNonWork { get; set; }
            public double TotalEveningTraining { get; set; }
            public double TotalWorkingDaysInReport { get; set; }
            public double TotalDaysBusyRelativePercent { get; set; }
            public double TotalFreeDaysRelativePercent { get; set; }
            public double TotalDaysTrainingRelativePercent { get; set; }
            public double TotalDaysOtherTrainingRelativePercent { get; set; }
            public double TotalDaysNonTrainingRelativePercent { get; set; }
            public double TotalDaysBusyAbsolutePercent { get; set; }
            public double TotalFreeDaysAbsolutePercent { get; set; }
            public double TotalDaysTrainingAbsolutePercent { get; set; }
            public double TotalDaysOtherTrainingAbsolutePercent { get; set; }
            public double TotalDaysNonTrainingAbsolutePercent { get; set; }
            public double TotalDaysNonWorkAbsolutePercent { get; set; }
            public double TotalEveningTrainingAbsolutePercent { get; set; }
            public double TotalWorkingDaysInReportAbsolutePercent { get; set; }
        }

        public class TotalDaysData
        {
            /* The following string fields ought to be doubles, but for unknown reasons AutoMapper 
             * isn't setting their values correctly based on what was found in the SqlDataReader */
            public string TotalDays { get; set; }
            public string DaysCounted { get; set; }
        }
    }
}
