using System;

namespace SFR.TOR.ViewModels
{
    public class ErrorDetailsModel
    {        
        public string Message { get; set; }
        public string TechnicalDetail { get; set; }
    }

    
}