﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using SFR.TOR.Utility;
using SFR.TOR.Utility.Security;
using Trirand.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class EventsModel
    {
        public  string[] SelectedTrainingCentres { get; set; }
        public  SelectList TrainingCentres { get; set; }
        public JQGrid Events { get; set; }
        
        public EventsModel(string dataURL, SelectList sectionData, SelectList priorityData, SelectList resourceData,
            SelectList statusData, SelectList fyData, SelectList trainingCentres)
        {
            TrainingCentres = trainingCentres;

            #region Grid

            Events = new JQGrid
                             {
                                 Columns = new List<JQGridColumn>()
                                               {
                                                   new JQGridColumn
                                                       {
                                                           DataField = "EventCode",
                                                           HeaderText = "Event Code",
                                                           Editable = true,
                                                           Width = 60,
                                                           Searchable = false
                                                       },
                                                   new JQGridColumn
                                                       {
                                                           DataField = "Title",
                                                           HeaderText = "Title",
                                                           Editable = true,
                                                           Width = 100,
                                                           Searchable = false
                                                       }
                                                   ,
                                                   new JQGridColumn
                                                       {
                                                           DataField = "Section",
                                                           HeaderText = "Section",
                                                           Editable = true,
                                                           Width = 80,
                                                           Searchable = true
                                                       },
                                                   new JQGridColumn
                                                       {
                                                           DataField = "TotalDays",
                                                           HeaderText = "Total Days",
                                                           Editable = true,
                                                           Width = 55,
                                                           Searchable = false
                                                       },
                                                   new JQGridColumn
                                                       {
                                                           DataField = "PriorityTitle",
                                                           HeaderText = "Priority",
                                                           Editable = true,
                                                           Width = 50,
                                                           Searchable = true
                                                       },
                                                    new JQGridColumn
                                                       {
                                                           DataField = "DaysReady",
                                                           HeaderText = "Days Ready",
                                                           Editable = true,
                                                           Width = 60,
                                                           Searchable = false
                                                       },
                                                     new JQGridColumn
                                                       {
                                                           DataField = "Resourced",
                                                           HeaderText = "Resourced",
                                                           Editable = true,
                                                           Width = 55,
                                                           Searchable = true
                                                       },
                                                    new JQGridColumn
                                                       {
                                                           DataField = "Status",
                                                           HeaderText = "Status",
                                                           Editable = true,
                                                           Width = 50,
                                                           Searchable = true,
                                                           Formatter = new CustomFormatter
                                                               {
                                                                   FormatFunction = "formatStatus"
                                                               }
                                                       }, 
                                                   new JQGridColumn
                                                       {
                                                           DataField = "StartDate",
                                                           HeaderText = "Start Date",
                                                           Editable = false,
                                                           Width = 50,
                                                           Searchable = false,
                                                           DataFormatString = "{0:dd/MM/yyyy}"
                                                       },
                                                    new JQGridColumn
                                                       {
                                                           DataField = "FinancialYear",
                                                           HeaderText = "FY",
                                                           Editable = true,
                                                           Width = 50,
                                                           Searchable = true,
                                                       },
                                                    new JQGridColumn
                                                       {
                                                           DataField = "ID",
                                                           HeaderText = " ",
                                                           Width = 50,
                                                           Sortable = false,
                                                           Formatter = new CustomFormatter
                                                               {
                                                                   FormatFunction = "formatLinks",
                                                                   UnFormatFunction = "unformatLinks"
                                                               },
                                                           Searchable = false
                                                       },
                                                    new JQGridColumn
                                                       {
                                                           DataField = "CancelReason",
                                                           Visible = false,
                                                           Searchable = false,
                                                           Editable = false
                                                       }
                                               },
                                 Width = Unit.Pixel(1000),
                                 Height = Unit.Percentage(100),
                                 PagerSettings =
                                     {
                                         PageSize = 20
                                     },
                                 ToolBarSettings = new ToolBarSettings()
                                     {
                                         ShowSearchToolBar = true
                                     },
                                 ID = "EventsGrid",
                                 DataUrl = dataURL
                             };
            #endregion

            Events.SetupDropDownFilterColumn("Section", SearchOperation.IsEqualTo, SearchType.DropDown, sectionData, true);
            Events.SetupDropDownFilterColumn("PriorityTitle", SearchOperation.IsEqualTo, SearchType.DropDown, priorityData, true);
            Events.SetupDropDownFilterColumn("Resourced", SearchOperation.IsEqualTo, SearchType.DropDown, resourceData, true);
            Events.SetupDropDownFilterColumn("Status", SearchOperation.IsEqualTo, SearchType.DropDown, statusData, true);
            Events.SetupDropDownFilterColumn("FinancialYear", SearchOperation.BeginsWith, SearchType.DropDown, fyData, true);

        }
    }
}