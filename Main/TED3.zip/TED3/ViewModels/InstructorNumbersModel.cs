namespace SFR.TOR.ViewModels
{
    public class InstructorNumbersModel
    {
        public int RequiredLeadCount { get; set; }
        public int RequiredInstructorCount { get; set; }
        public int RequiredAssessorCount { get; set; }
        public int RequiredShadowCount { get; set; }
        public int RequiredSpecialistCount { get; set; }

        public int SelectedLeadCount { get; set; }
        public int SelectedInstructorCount { get; set; }
        public int SelectedAssessorCount { get; set; }
        public int SelectedShadowCount { get; set; }
        public int SelectedSpecialistCount { get; set; }
    }
}