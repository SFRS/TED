﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SFR.TOR.ViewModels
{
    public class ReportInstructorUtilisationModel
    {
        public ReportInstructorUtilisationModel()
        {
            InstructorUtilisations = new List<InstructorUtilisationData>();
            InstructorUtilisationTotals = new List<InstructorUtilisationTotalData>();
        }

        public List<IEnumerable> GetReportData()
        {
            // Must return datasets in the order expected by the report
            return new List<IEnumerable> { InstructorUtilisations, InstructorUtilisationTotals };
        }

        // DataSet1
        public List<InstructorUtilisationData> InstructorUtilisations { get; set; }

        // DataSet2
        public List<InstructorUtilisationTotalData> InstructorUtilisationTotals { get; set; }

        public class InstructorUtilisationData
        {
            public DateTime? InstructorEngagedDate { get; set; }
            public string InstructorFirstName { get; set; }
            public string InstructorSecondName { get; set; }
            public string SectionName { get; set; }
            public double InstructorTimeSpentInEvents { get; set; }
            public double InstructorTimeSpentInEventsPercent { get; set; }
            public int InstructorID { get; set; }
            public string TrainingCentreName { get; set; }
            public int SectionID { get; set; }
            public string SectionSummaryRecord { get; set; }
        }

        public class InstructorUtilisationTotalData
        {
            public double InstructorTimeSpentInEvents { get; set; }
            public double InstructorTimeSpentInEventsPercent { get; set; }
            public DateTime? InstructorEngagedDate { get; set; }
            public string TrainingCentreName { get; set; }
        }
    }
}
