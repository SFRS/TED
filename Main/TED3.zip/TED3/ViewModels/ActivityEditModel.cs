﻿using System.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class ActivityEditModel: ActivityModel
    {
        public SelectList SectionData { get; set; }
        public SelectList ActivityStatusData { get; set; }
        
    }
}