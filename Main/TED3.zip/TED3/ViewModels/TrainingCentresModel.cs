using System.Collections.Generic;
using System.Web.UI.WebControls;
using Trirand.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class TrainingCentresModel : BaseModel
    {
        public JQGrid TrainingCentresGrid { get; set; }

        public string Name { get; set; }

        public TrainingCentresModel(string dataURL, string editURL)
        {
            TrainingCentresGrid = new JQGrid
                {
                    Columns = new List<JQGridColumn>()
                        {
                            new JQGridColumn
                                {
                                    DataField = "ID",
                                    PrimaryKey = true,
                                    Visible = false                                    
                                },                                   
                            new JQGridColumn
                                {
                                    DataField = "Name",
                                    Visible = true,     
                                    Editable = true,
                                    HeaderText = "Name",
                                    //EditClientSideValidators = new List<JQGridEditClientSideValidator>
                                    //                         {
                                    //                           new Trirand.Web.Mvc.CustomValidator() { ValidationFunction = "CheckReasonLength"}
                                    //                          }
                                }, 
                            new JQGridColumn
                                {
                                    EditActionIconsColumn = true,
                                    EditActionIconsSettings = new EditActionIconsSettings
                                        {
                                            SaveOnEnterKeyPress = true,
                                            ShowEditIcon = true,
                                            ShowDeleteIcon = false
                                        },
                                    HeaderText = " ",
                                    Width = 30,
                                    Sortable = false,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                    Searchable = false
                                }
                        },
                    Width = Unit.Pixel(500),
                    Height = Unit.Percentage(100),
                    ToolBarSettings = new ToolBarSettings()
                        {
                            ShowAddButton = true,
                            ShowDeleteButton = true
                        },
                    PagerSettings =
                        {
                            PageSize = 20
                        },
                    ID = "TrainingCentresGrid",
                    DataUrl = dataURL,
                    EditUrl = editURL,
                    SortSettings = new SortSettings()
                        {
                            InitialSortColumn = "Name"
                        },
                    AddDialogSettings = new AddDialogSettings()
                        {
                            CloseAfterAdding = true
                        }
                };
        }
    }
}