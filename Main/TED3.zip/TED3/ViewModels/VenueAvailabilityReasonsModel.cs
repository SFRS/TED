using System.Collections.Generic;
using System.Web.UI.WebControls;
using Trirand.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class VenueAvailabilityReasonsModel : BaseModel
    {
        public JQGrid VenueAvailabilityReasonsGrid { get; set; }

        public string Name { get; set; }

        public VenueAvailabilityReasonsModel(string dataURL, string editURL)
        {
            VenueAvailabilityReasonsGrid = new JQGrid
                {
                    Columns = new List<JQGridColumn>()
                        {
                            new JQGridColumn
                                {
                                    DataField = "ID",
                                    PrimaryKey = true,
                                    Visible = false                                    
                                },                                   
                            new JQGridColumn
                                {
                                    DataField = "Reason",
                                    Visible = true,     
                                    Editable = true,
                                    HeaderText = "Reason",
                                    EditClientSideValidators = new List<JQGridEditClientSideValidator>
                                                             {
                                                               new Trirand.Web.Mvc.CustomValidator() { ValidationFunction = "CheckReasonLength"}
                                                              }
                                },
                            new JQGridColumn 
                                {
                                    EditActionIconsColumn = true, 
                                    EditActionIconsSettings = new EditActionIconsSettings
                                        {
                                            ShowEditIcon = true,
                                            ShowDeleteIcon = false
                                        }, 
                                    HeaderText = " ", 
                                    Width = 20,
                                    Sortable = false,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,                                                                      
                                }                            
                        },
                    Width = Unit.Pixel(500),
                    Height = Unit.Percentage(100),
                    ToolBarSettings = new ToolBarSettings()
                        {
                            ShowAddButton = true,
                            ShowDeleteButton = true
                        },
                    PagerSettings =
                        {
                            PageSize = 20
                        },
                    ID = "VenueAvailabilityReasonsGrid",
                    DataUrl = dataURL,
                    EditUrl = editURL,
                    SortSettings = new SortSettings()
                        {
                            InitialSortColumn = "Reason"
                        },
                    AddDialogSettings = new AddDialogSettings()
                        {
                            CloseAfterAdding = true
                        }
                };
        }
    }
}