using System.Collections.Generic;
using System.Web.UI.WebControls;
using Trirand.Web.Mvc;
using TextAlign = Trirand.Web.Mvc.TextAlign;

namespace SFR.TOR.ViewModels
{
    public class EventAuditModel : EventModel
    {
        public JQGrid StatusHistoryGrid { get; set; }

        public EventAuditModel(string dataURL)
        {
            this.ID = ID;
            StatusHistoryGrid = new JQGrid
                {
                    Columns = new List<JQGridColumn>()
                        {
                            //new JQGridColumn
                            //    {
                            //        PrimaryKey = true,
                            //        DataField = "ID",
                            //        Visible = false,
                            //    },
                            new JQGridColumn
                            {
                                DataField = "OccurredOn",
                                HeaderText = "Occurred On",
                                Width = 50,
                                TextAlign = TextAlign.Center,
                                //DataFormatString = "{0:dd/MM/yyyy}",
                            },
                            new JQGridColumn
                                {
                                    DataField = "UserName",
                                    HeaderText = "User",
                                    Width = 60,
                                },
                            new JQGridColumn
                                {
                                    DataField = "OldStatus",
                                    HeaderText = "Previous Status",
                                    Width = 50,
                                    TextAlign = TextAlign.Center
                                },
                            new JQGridColumn
                                {
                                    DataField = "NewStatus",
                                    HeaderText = "New Status",
                                    Width = 50,
                                    TextAlign = TextAlign.Center
                                },
                            


                            
                        },
                    Width = Unit.Pixel(500),
                    Height = Unit.Percentage(100),
                    PagerSettings =
                        {
                            PageSize = 10
                        },
                    ID = "StatusHistoryGrid",
                    DataUrl = dataURL,                 
                };
        }
    }
}