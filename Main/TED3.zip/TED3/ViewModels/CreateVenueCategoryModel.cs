﻿
namespace SFR.TOR.ViewModels
{
    public class CreateVenueCategoryModel: BaseModel
    {
        public int VenueTagID { get; set; }
        public int ActivityPartID { get; set; }
        public int MinRequired { get; set; }
    }
}
