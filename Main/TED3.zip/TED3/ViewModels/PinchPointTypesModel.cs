using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using SFR.TOR.Utility;
using Trirand.Web.Mvc;
using SortDirection = Trirand.Web.Mvc.SortDirection;

namespace SFR.TOR.ViewModels
{
    public class PinchPointReasonsModel
    {        
        public JQGrid PinchpointReasons { get; set; }

        public PinchPointReasonsModel(string dataURL, string editURL, SelectList reasonTypeData)
        {
            PinchpointReasons = new JQGrid
                {
                    Columns = new List<JQGridColumn>()
                        {
                            new JQGridColumn
                                {
                                    DataField = "ID",
                                    PrimaryKey = true,
                                    Visible = false
                                },
                            new JQGridColumn
                                {
                                    DataField = "Reason",
                                    HeaderText = "Reason",
                                    Editable = true,
                                    Width = 100,
                                    Searchable = false
                                },
                            
                            new JQGridColumn
                                {
                                    DataField = "TypeID",
                                    HeaderText = "Type",
                                    Editable = true,
                                    EditType = EditType.Custom,
                                    EditTypeCustomCreateElement = "createTypeDropDown",
                                    EditTypeCustomGetValue = "getSelectedType",
                                    Formatter = new CustomFormatter
                                        {
                                            FormatFunction = "formatType",
                                        },
                                    Width = 80,
                                    Searchable = false
                                    
                                },
                            new JQGridColumn
                                {
                                    EditActionIconsColumn = true,
                                    EditActionIconsSettings = new EditActionIconsSettings
                                        {
                                            SaveOnEnterKeyPress = true,
                                            ShowEditIcon = true,
                                            ShowDeleteIcon = false
                                        },
                                    HeaderText = " ",
                                    Width = 10,
                                    Sortable = false,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                    Searchable = false
                                }
                        },
                    Width = Unit.Pixel(900),
                    Height = Unit.Percentage(100),
                    PagerSettings =
                        {
                            PageSize = 20
                        },
                    ID = "PinchpointTypesGrid",
                    DataUrl = dataURL,
                    EditUrl = editURL,
                    ToolBarSettings = new ToolBarSettings()
                        {
                            ShowAddButton = true,
                            ToolBarPosition = ToolBarPosition.Bottom,
                            ShowDeleteButton = true
                        },
                    SortSettings = new SortSettings()
                        {
                            InitialSortColumn = "Reason",
                            InitialSortDirection = SortDirection.Desc
                        },

                    AddDialogSettings = new AddDialogSettings()
                        {
                            CloseAfterAdding = true
                        }
                };

            PinchpointReasons.SetupDropDownFilterColumn("TypeID", SearchOperation.IsEqualTo, SearchType.DropDown, reasonTypeData, false);
        }
    }
}