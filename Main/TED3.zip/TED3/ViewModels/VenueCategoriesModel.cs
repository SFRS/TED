using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using Trirand.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class VenueCategoriesModel : BaseModel
    {
        public JQGrid VenueCategories { get; set; }

        public string Name { get; set; }

        public VenueCategoriesModel(string dataURL, string editURL, List<SelectListItem> categories)
        {
            VenueCategories = new JQGrid
                {
                    Columns = new List<JQGridColumn>()
                        {
                            new JQGridColumn
                                {
                                    DataField = "ID",
                                    PrimaryKey = true,
                                    Visible = false                                    
                                },                                   
                            new JQGridColumn
                                {
                                    DataField = "VenueTagID",
                                    HeaderText = "Category",
                                    Editable = true,
                                    EditType = EditType.Custom,
                                    EditTypeCustomCreateElement = "createDropDown",
                                    EditTypeCustomGetValue = "getSelected",                                                         
                                    Formatter = new CustomFormatter
                                        {
                                            FormatFunction = "formatDayType",                                                             
                                        },
                                    EditList = categories,
                                    Width = 50
                                },         
                            new JQGridColumn 
                                {
                                    EditActionIconsColumn = true, 
                                    EditActionIconsSettings = new EditActionIconsSettings
                                        {
                                            ShowEditIcon = false,
                                            ShowDeleteIcon = true
                                        }, 
                                    HeaderText = " ", 
                                    Width = 10,
                                    Sortable = false,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                                                      
                                }
                        },
                    Width = Unit.Pixel(400),
                    Height = Unit.Percentage(100),
                    ToolBarSettings = new ToolBarSettings()
                        {
                            ShowAddButton = true
                        },
                    PagerSettings =
                        {
                            PageSize = 20
                        },
                    ID = "VenueCategoryGrid",
                    DataUrl = dataURL,
                    EditUrl = editURL,
                    SortSettings = new SortSettings()
                        {
                            InitialSortColumn = ""
                        },
                    AddDialogSettings = new AddDialogSettings()
                        {
                            CloseAfterAdding = true
                        }
                };
        }
    }
}