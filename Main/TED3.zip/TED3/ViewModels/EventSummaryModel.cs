﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SFR.TOR.ViewModels
{
    public class EventSummaryModel: EventModel
    {
        public List<EventPartSummaryModel> EventPartModels { get; set; }

        public EventSummaryModel()
        {
            EventPartModels = new List<EventPartSummaryModel>();
        }
    }
}
