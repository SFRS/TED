using System.Collections.Generic;
using System.Web.UI.WebControls;
using Trirand.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class VenueCategoryAdminModel : BaseModel
    {
        public JQGrid VenueCategories { get; set; }

        public string Name { get; set; }

        public VenueCategoryAdminModel(string dataURL, string editURL)
        {
            VenueCategories = new JQGrid
                {
                    Columns = new List<JQGridColumn>()
                        {
                            new JQGridColumn
                                {
                                    DataField = "ID",
                                    PrimaryKey = true,
                                    Visible = false                                    
                                },                                   
                            new JQGridColumn
                                {
                                    DataField = "Name",
                                    PrimaryKey = true,
                                    Visible = true,     
                                    HeaderText = "Name",
                                    Editable = true
                                },
                            new JQGridColumn 
                                {
                                    EditActionIconsColumn = true, 
                                    EditActionIconsSettings = new EditActionIconsSettings
                                        {
                                            ShowEditIcon = true,
                                            ShowDeleteIcon = false
                                        }, 
                                    HeaderText = " ", 
                                    Width = 20,
                                    Sortable = false,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,                                                                      
                                }
                        },
                    Width = Unit.Pixel(700),
                    Height = Unit.Percentage(100),
                    ToolBarSettings = new ToolBarSettings()
                        {
                            ShowAddButton = true,
                            ShowDeleteButton = true
                        },
                    PagerSettings =
                        {
                            PageSize = 20
                        },
                    ID = "VenueCategoryGrid",
                    DataUrl = dataURL,
                    EditUrl = editURL,
                    SortSettings = new SortSettings()
                        {
                            InitialSortColumn = "Name"
                        },
                    AddDialogSettings = new AddDialogSettings()
                        {
                            CloseAfterAdding = true
                        }
                };
        }
    }
}