﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SFR.TOR.ViewModels
{
    public class iTrentExportModel : BaseModel
    {
        public string Title { get; set; }
        public string Type { get; set; }
        public int TypeID { get; set; }
        public string Status { get; set; }
        public int StatusID { get; set; }
        public string FinancialYear { get; set; }
        public DateTime iTrentExportDate { get; set; }
        public int EventsExported { get; set; }
        public int ExportErrors { get; set; }
        public int EventsUploaded { get; set; }
        public int UploadErrors { get; set; }
        public string FileDownloadURL { get; set; }
    }
}