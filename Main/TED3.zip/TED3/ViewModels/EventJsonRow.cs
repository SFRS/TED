namespace SFR.TOR.ViewModels
{
    public class EventJsonRow
    {
        public string[] cell { get; set; }
        public string id { get; set; }

        public EventJsonRow(CalendarData calendarData)
        {
            id = calendarData.Name;
            cell = new string[16];            
            cell[0] = calendarData.Day1AM ?? "";
            cell[1] = calendarData.Day1PM ?? "";
            cell[2] = calendarData.Day2AM ?? "";
            cell[3] = calendarData.Day2PM ?? "";
            cell[4] = calendarData.Day3AM ?? "";
            cell[5] = calendarData.Day3PM ?? "";
            cell[6] = calendarData.Day4AM ?? "";
            cell[7] = calendarData.Day4PM ?? "";
            cell[8] = calendarData.Day5AM ?? "";
            cell[9] = calendarData.Day5PM ?? "";
            cell[10] = calendarData.Day6AM ?? "";
            cell[11] = calendarData.Day6PM ?? "";
            cell[12] = calendarData.Day7AM ?? "";
            cell[13] = calendarData.Day7PM ?? "";
        }
    }
}