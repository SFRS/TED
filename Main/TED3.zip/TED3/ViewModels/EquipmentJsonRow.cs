namespace SFR.TOR.ViewModels
{
    public class EquipmentJsonRow
    {
        public string[] cell { get; set; }
        public string id { get; set; }

        public EquipmentJsonRow(CalendarData calendarData)
        {
            id = calendarData.ID.ToString();
            cell = new string[16];
            cell[0] = calendarData.Name ?? "";
            cell[1] = calendarData.GroupName ?? "";
            cell[2] = calendarData.Day1AM ?? "";
            cell[3] = calendarData.Day1PM ?? "";
            cell[4] = calendarData.Day2AM ?? "";
            cell[5] = calendarData.Day2PM ?? "";
            cell[6] = calendarData.Day3AM ?? "";
            cell[7] = calendarData.Day3PM ?? "";
            cell[8] = calendarData.Day4AM ?? "";
            cell[9] = calendarData.Day4PM ?? "";
            cell[10] = calendarData.Day5AM ?? "";
            cell[11] = calendarData.Day5PM ?? "";
            cell[12] = calendarData.Day6AM ?? "";
            cell[13] = calendarData.Day6PM ?? "";
            cell[14] = calendarData.Day7AM ?? "";
            cell[15] = calendarData.Day7PM ?? "";
        }
    }
}