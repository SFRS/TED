using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SFR.TOR.ViewModels
{
    public class ReportVenueCategoriesModel
    {
        public ReportVenueCategoriesModel()
        {
            VenueCategories = new List<VenueCategoriesData>();
        }

        public List<IEnumerable> GetReportData()
        {
            // Must return datasets in the order expected by the report
            return new List<IEnumerable> { VenueCategories };
        }

        // DataSet1
        public List<VenueCategoriesData> VenueCategories { get; set; }

        public class VenueCategoriesData
        {
            public string VenueName { get; set; }
            public string TrainingCentre { get; set; }
            public string VenueGroupTitle { get; set; }
            public string VenueCategory { get; set; }
        }
    }
}
