﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class EquipmentEditModel: BaseModel
    {
        [Required(ErrorMessage = "Required")]
        [DisplayName("Name:")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Required")]
        [DisplayName("Training Centre:")]
        public int TrainingCentreID { get; set; }

        public SelectList TrainingCentreData { get; set; }

        [Required(ErrorMessage = "Required")]
        [DisplayName("Equipment Group:")]
        public int EquipmentGroupID { get; set; }

        public SelectList EquipmentGroupData { get; set; }

    }
}
