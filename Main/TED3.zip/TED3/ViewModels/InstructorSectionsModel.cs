using System.Collections.Generic;
using System.Web.UI.WebControls;
using Trirand.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class InstructorSectionsModel : BaseModel
    {
        public JQGrid InstructorSectionsGrid { get; set; }

        public string Title { get; set; }

        public InstructorSectionsModel(string dataURL, string editURL)
        {
            InstructorSectionsGrid = new JQGrid
                {
                    Columns = new List<JQGridColumn>()
                        {
                            new JQGridColumn
                                {
                                    DataField = "ID",
                                    PrimaryKey = true,
                                    Visible = false                                    
                                },                                   
                            new JQGridColumn
                                {
                                    DataField = "Title",
                                    Visible = true,     
                                    Editable = true,
                                    HeaderText = "Title",
                                    //EditClientSideValidators = new List<JQGridEditClientSideValidator>
                                    //                         {
                                    //                           new Trirand.Web.Mvc.CustomValidator() { ValidationFunction = "CheckReasonLength"}
                                    //                          }
                                }, 
                            new JQGridColumn
                                {
                                    EditActionIconsColumn = true,
                                    EditActionIconsSettings = new EditActionIconsSettings
                                        {
                                            SaveOnEnterKeyPress = true,
                                            ShowEditIcon = true,
                                            ShowDeleteIcon = false
                                        },
                                    HeaderText = " ",
                                    Width = 30,
                                    Sortable = false,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                    Searchable = false
                                }
                        },
                    Width = Unit.Pixel(500),
                    Height = Unit.Percentage(100),
                    ToolBarSettings = new ToolBarSettings()
                        {
                            ShowAddButton = true,
                            ShowDeleteButton = true
                        },
                    PagerSettings =
                        {
                            PageSize = 20
                        },
                    ID = "InstructorSectionsGrid",
                    DataUrl = dataURL,
                    EditUrl = editURL,
                    SortSettings = new SortSettings()
                        {
                            InitialSortColumn = "Title"
                        },
                    AddDialogSettings = new AddDialogSettings()
                        {
                            CloseAfterAdding = true
                        }
                };
        }
    }
}