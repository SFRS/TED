﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace SFR.TOR.ViewModels
{
    public class InstructorSectionHistoryEditModel : BaseModel
    {
        public int InstructorID     { get; set; }

        public int SectionID        { get; set; }

        [Required]
        public DateTime StartDate   { get; set; }

        public DateTime? EndDate    { get; set; }
    }
}
