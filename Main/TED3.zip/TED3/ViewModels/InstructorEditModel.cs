using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class InstructorEditModel: BaseModel
    {
        [Required(ErrorMessage = "Required")]
        [DisplayName("First Name:")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Required")]
        [DisplayName("Last Name:")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Required")]
        [DisplayName("Section:")]
        public int SectionID { get; set; }

        [Required(ErrorMessage = "Required")]
        [DisplayName("Status:")]
        public int StatusID { get; set; }

        public bool HasEvents { get; set; }

        public SelectList SectionData { get; set; }

        public string Name { get; set; }

        [Required(ErrorMessage = "Required")]
        [DisplayName("Base Training Centre:")]
        public int TrainingCentreID { get; set; }

        public SelectList TrainingCentreData { get; set; }

        [Required(ErrorMessage = "Required")]
        [DisplayName("Group:")]
        public int GroupID { get; set; }

        public SelectList GroupData { get; set; }
    }
}