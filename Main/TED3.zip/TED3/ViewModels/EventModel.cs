﻿using System;
using System.ComponentModel;

namespace SFR.TOR.ViewModels
{
    public class EventModel : BaseModel
    {
        [DisplayName("Event Code:")]
        public string EventCode { get; set; }

        [DisplayName("Status:")]
        public string Status { get; set; }

        //public EventStatus EventStatus { get; set; }

        [DisplayName("Title:")]
        public string Title { get; set; }
        
        [DisplayName("Section:")]
        public string Section { get; set; }
        
        [DisplayName("Priority:")]
        public int Priority { get; set; }

        [DisplayName("Total Days:")]
        public double TotalDays { get; set; }

        [DisplayName("Days Ready:")]
        public double DaysReady { get; set; }
       
        [DisplayName("Resourced:")]
        public string Resourced { get; set; }

        [DisplayName("Description:")]
        public string Description { get; set; }

        [DisplayName("Notes:")]
        public string Notes { get; set; }

        [DisplayName("Cancel Reason:")]
        public string CancelReason { get; set; }

        public string PriorityTitle { get; set; }

        [DisplayName("Status:")]
        public int StatusID { get; set; }

        public string FinancialYear { get; set; }

        public int DateChoice { get; set; }
        public string SpecificDate { get; set; }
        public DateTime? StartDate { get; set; }
        public string EndDate { get; set; }

        public DateTime? LastEditedOn { get; set; }

        public int TrainingCentreId { get; set; } 
        public string TrainingCentreName { get; set; }
    }
}