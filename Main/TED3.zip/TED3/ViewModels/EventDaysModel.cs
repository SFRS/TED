﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class EventDaysModel : EventModel
    {
        public bool ResourcesAssigned { get; set; }

        //[Required(ErrorMessage = "Required: Please select a date.")]
        //[DataType(DataType.Date)]
        //public DateTime? TestDate { get; set; }

        public IEnumerable<EventDayModel> EventDays { get; set; }

        public EventDaysModel()
        {
            EventDays = new List<EventDayModel>();
        }
    }
}
