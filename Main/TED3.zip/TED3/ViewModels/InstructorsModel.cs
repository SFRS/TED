﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using SFR.TOR.Utility;
using Trirand.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class InstructorsModel
    {
        public JQGrid InstructorGrid { get; set; }

        public InstructorsModel(string dataURL, SelectList sectionData, SelectList trainingCentreData, SelectList availabilityData, SelectList groupData)
        {
            InstructorGrid = new JQGrid
                {
                    Columns = new List<JQGridColumn>()
                        {
                            new JQGridColumn
                                {
                                    DataField = "Name",
                                    HeaderText = "Name",
                                    Editable = true,
                                    Width = 30,
                                    Searchable = false
                                },                            
                            new JQGridColumn
                                {
                                    DataField = "Section",
                                    HeaderText = "Section",
                                    Editable = true,
                                    Width = 30,
                                    Searchable = true
                                },  
                            new JQGridColumn
                                {
                                    DataField = "Group",
                                    HeaderText = "Group",
                                    Editable = true,
                                    Width = 20,
                                    Searchable = true
                                },
                            new JQGridColumn
                                {
                                    DataField = "Availability",
                                    HeaderText = "Availability",
                                    Width = 30,
                                    Searchable = true
                                },  
                            new JQGridColumn
                                {
                                    DataField = "TrainingCentre",
                                    HeaderText = "Training Centre",
                                    Editable = true,
                                    Width = 30,
                                    Searchable = true
                                },
                            new JQGridColumn
                                {
                                    DataField = "ID",
                                    HeaderText = " ",
                                    Width = 20,
                                    Sortable = false,
                                    Formatter = new CustomFormatter
                                        {
                                            FormatFunction = "formatLinks",
                                        },
                                    Searchable = false
                                },
                        },
                    Width = Unit.Pixel(700),
                    Height = Unit.Percentage(100),
                    PagerSettings =
                        {
                            PageSize = 20
                        },
                    ID = "InstructorsGrid",
                    DataUrl = dataURL,
                    SortSettings = new SortSettings()
                        {
                            InitialSortColumn = "Section"
                        },
                    ToolBarSettings = new ToolBarSettings()
                    {
                        ShowSearchToolBar = true

                    }
                };

            InstructorGrid.SetupDropDownFilterColumn("Section", SearchOperation.IsEqualTo, SearchType.DropDown, sectionData, true);
            InstructorGrid.SetupDropDownFilterColumn("Group", SearchOperation.IsEqualTo, SearchType.DropDown, groupData, true);
            InstructorGrid.SetupDropDownFilterColumn("TrainingCentre", SearchOperation.IsEqualTo, SearchType.DropDown, trainingCentreData, true);
            InstructorGrid.SetupDropDownFilterColumn("Availability", SearchOperation.IsEqualTo, SearchType.DropDown, availabilityData, true);
        }
    }
}