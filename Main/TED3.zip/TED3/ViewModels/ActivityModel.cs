﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace SFR.TOR.ViewModels
{
    public class ActivityModel : BaseModel
    {
        [DisplayName("Title:")]
        [StringLength(100, ErrorMessage = "Max 100 characters")]
        [Required(ErrorMessage = "Required: Please select a title.")]
        [RegularExpression("[^\"]*", ErrorMessage="Double quotes are not allowed.")]
        public string Title { get; set; }
        
        [DisplayName("Code:")]
        [StringLength(20, ErrorMessage = "Max 20 characters")]
        [Required(ErrorMessage = "Required: Please enter a code.")]
        [RegularExpression("[^\"]*", ErrorMessage = "Double quotes are not allowed.")]
        public string Code { get; set; }

        [DisplayName("Section:")]
        [Required(ErrorMessage = "Required: Please select a section.")]
        public int SectionID { get; set; }

        [DisplayName("Status:")]
        public int ActivityStatusID { get; set; }

        [DisplayName("Section:")]
        public string Section { get; set; }

        //[DisplayName("Status:")]
        //public string Status { get; set; }

        [DisplayName("Total Days:")]
        public double TotalDays { get; set; }

        [DisplayName("Description:")]
        public string Description { get; set; }

        public bool HasFutureEvents { get; set; }
        public bool HasHistoricalEvents { get; set; }
        public bool HasEventSpanningToday { get; set; }

        public int ExistingEvents { get; set; }

        public string Status { get; set; }
    }
}