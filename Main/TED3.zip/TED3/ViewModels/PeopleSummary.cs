using System.Collections.Generic;

namespace SFR.TOR.ViewModels
{
    public class EventPeopleSummaryModel
    {
        public string Title { get; set; }

        public List<string> People { get; set; }

        public string SummaryOfNumbers { get; set; }

        public bool Fulfilled { get; set; }

    }
}