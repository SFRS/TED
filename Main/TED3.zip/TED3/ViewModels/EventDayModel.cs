using System;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace SFR.TOR.ViewModels
{    
    public class EventDayModel
    {
        public string Name { get; set; }

        [DataType(DataType.Date)]
        public DateTime? Date { get; set; }
        
        //public string Date { get; set; }

        public int DayTypeID { get; set; }

        public string Notes { get; set; }

        public int ID { get; set; }

        public string ResourceStatus { get; set; }

        
        [RegularExpression(@"([1-9]|1[0-9]|2[0-3]|0):([0-5][0-9])", ErrorMessage = "Please enter time in correct format eg: 09:00")]        
        public string StartTime { get; set; }
        
        [RegularExpression(@"([1-9]|1[0-9]|2[0-3]|0):([0-5][0-9])", ErrorMessage = "Please enter time in correct format eg: 17:00")]
        public string EndTime { get; set; }

        public SelectList DayTypes { get; set; }


    }
}