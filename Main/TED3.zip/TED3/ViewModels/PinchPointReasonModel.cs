namespace SFR.TOR.ViewModels
{
    public class PinchPointReasonModel: BaseModel
    {
        public string Reason { get; set; }
        public int TypeID { get; set; }
    }
}