﻿namespace SFR.TOR.ViewModels
{
    public class Equipment: BaseModel
    {
        public string Category { get; set; }
        public int MinimumNumberRequired { get; set; }
    }
}