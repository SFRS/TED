using System.Collections.Generic;

namespace SFR.TOR.ViewModels
{
    public class EventPartSummaryModel: BaseModel
    {
        public string SummaryTitle { get; set; }

        public int Status { get; set; }
        public string StatusDescription { get; set; }

        public string Notes { get; set; }

        public EventPeopleSummaryModel Instructors { get; set; }
        public EventPeopleSummaryModel Leads { get; set; }
        public EventPeopleSummaryModel Assessors { get; set; }
        public EventPeopleSummaryModel Shadows { get; set; }
        public EventPeopleSummaryModel Specialists { get; set; }

        public List<EventVenueSummaryModel> Venues { get; set; }

        public List<EventEquipmentSummaryModel> Equipment { get; set; }

    }
}