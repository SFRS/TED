﻿namespace SFR.TOR.ViewModels
{
    public class EquipmentCategoryModel : BaseModel
    {
        public string Name { get; set; }
    }
}
