namespace SFR.TOR.ViewModels
{
    public class InstructorEligibilityModel
    {
        public int? ID { get; set; }

        public bool? IsLead { get; set; }

        public bool? IsInstructor { get; set; }

        public bool? IsAssessor { get; set; }

        public bool? IsShadow { get; set; }

        public bool? IsSpecialist { get; set; }

        public string Title { get; set; }

        public string Code { get; set; }
    }
}