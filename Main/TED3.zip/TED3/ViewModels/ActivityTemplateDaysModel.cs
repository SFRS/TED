﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using Trirand.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class ActivityTemplateDaysModel
    {
        public ActivityModel ActivityModel { get; set; }
        public SelectList DayItems { get; set; }
        public JQGrid ActivityParts { get; set; }

        public double DaysAssigned { get; set; }
        public double TotalDays { get; set; }

        public ActivityTemplateDaysModel(string dataURL, string editURL, List<SelectListItem> dayTypes)
        {
            ActivityParts = new JQGrid
                           {
                               Columns = new List<JQGridColumn>()
                                             {
                                                 new JQGridColumn
                                                     {
                                                         DataField = "ID",
                                                         PrimaryKey = true,
                                                         Visible = false                                                         
                                                     },

                                                 new JQGridColumn
                                                     {
                                                         DataField = "Name",
                                                         HeaderText = "Name",
                                                         Editable = false,
                                                         Width = 40
                                                     },
                                                 //new JQGridColumn
                                                 //    {
                                                 //        DataField = "DayTypeID",
                                                 //        HeaderText = "Type",
                                                 //        Editable = true,
                                                 //        Width = 50,
                                                 //        EditType = EditType.Custom,
                                                 //        EditTypeCustomCreateElement = "createDropDown",
                                                 //        EditTypeCustomGetValue = "getSelected",                                                         
                                                 //        Formatter = new CustomFormatter
                                                 //        {
                                                 //            FormatFunction = "formatDayType",                                                             
                                                 //        },
                                                 //    },
                                                new JQGridColumn
                                                     {
                                                         DataField = "Description",
                                                         HeaderText = "Description",
                                                         Editable = true,
                                                         Width = 100,
                                                         EditClientSideValidators = new List<JQGridEditClientSideValidator>
                                                             {
                                                               new Trirand.Web.Mvc.CustomValidator() { ValidationFunction = "CheckDescriptionLength"}
                                                              }
                                                     },                                                 
                                                new JQGridColumn 
                                                                  {
                                                                      EditActionIconsColumn = true, 
                                                                      EditActionIconsSettings = new EditActionIconsSettings
                                                                                                    {
                                                                                                        SaveOnEnterKeyPress = true,
                                                                                                        ShowDeleteIcon = true
                                                                                                    }, 
                                                                      HeaderText = " ", 
                                                                      Width = 30,
                                                                      Sortable = false,
                                                                      TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                                                      
                                                                  }
                                             },
                               Width = Unit.Pixel(600),
                               Height = Unit.Pixel(200),                               
                               PagerSettings =
                                   {
                                       PageSize = 20
                                   },
                               ToolBarSettings =
                                   {
                                       ShowRefreshButton = false,
                                       ShowAddButton = true
                                       
                                   },
                               
                               DataUrl = dataURL,
                               EditUrl = editURL,                               
                               SortSettings = new SortSettings()
                                                  {
                                                      InitialSortColumn = ""
                                                  }
                           };

            ActivityParts.AddDialogSettings.CloseAfterAdding = true;
        }
    }
}
