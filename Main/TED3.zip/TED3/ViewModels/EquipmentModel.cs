namespace SFR.TOR.ViewModels
{
    public class EquipmentModel : BaseModel
    {
        public string Name { get; set; }
        public string TrainingCentre { get; set; }
        public int TrainingCentreID { get; set; }
        public int? EquipmentGroupID { get; set; }
        public string EquipmentGroup { get; set; }
        public string Availability { get; set; }
    }
}