﻿using System.Collections.Generic;
using System.Web.UI.WebControls;
using Trirand.Web.Mvc;
using TextAlign = Trirand.Web.Mvc.TextAlign;

namespace SFR.TOR.ViewModels
{
    public class DayEquipmentModel
    {
        public int ID { get; set; }
        public string Title { get; set; }

        public JQGrid DayEquipmentGrid { get; set; }

        public DayEquipmentModel(string dataURL, string editURL, int ID)
        {
            this.ID = ID;
            DayEquipmentGrid = new JQGrid
                {
                    Columns = new List<JQGridColumn>()
                        {
                            new JQGridColumn
                                {
                                    DataField = "Name",
                                    HeaderText = "Equipment Category",
                                    Editable = false,
                                    Width = 100,
                                },
                            new JQGridColumn
                                {
                                    DataField = "MinRequired",
                                    HeaderText = "Min",
                                    Editable = true,
                                    Width = 20,
                                    TextAlign = TextAlign.Center
                                },
                            new JQGridColumn
                                {
                                    PrimaryKey = true,
                                    DataField = "ID",
                                    Visible = false,
                                },
                            new JQGridColumn
                                {
                                    EditActionIconsColumn = true,
                                    EditActionIconsSettings = new EditActionIconsSettings
                                        {
                                            SaveOnEnterKeyPress = true,
                                            ShowDeleteIcon = true
                                        },
                                    HeaderText = " ",
                                    Width = 20,
                                    Sortable = false,
                                    TextAlign = TextAlign.Center
                                }
                        },
                    Width = Unit.Pixel(500),
                    Height = Unit.Percentage(100),
                    PagerSettings =
                        {
                            PageSize = 10
                        },
                    ID = "equipmentGrid",
                    DataUrl = dataURL,
                    EditUrl = editURL,                    
                };
        }
    }
}
