using System.Collections.Generic;
using System.Web.UI.WebControls;
using Trirand.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class InstructorActivitiesModel: BaseModel
    {
        public JQGrid Activities { get; set; }

        public string Name { get; set; }

        public InstructorActivitiesModel(string dataURL, string editURL)
        {
            Activities = new JQGrid
                {
                    Columns = new List<JQGridColumn>()
                        {
                            new JQGridColumn
                                {
                                    DataField = "ID",
                                    PrimaryKey = true,
                                    Visible = false                                    
                                },                                 
                            new JQGridColumn
                                {
                                    DataField = "Code",
                                    HeaderText = "Code",
                                    Editable = false,
                                    Width = 40
                                },    
                            new JQGridColumn
                                {
                                    DataField = "Title",
                                    HeaderText = "Title",
                                    Editable = false,
                                    Width = 100
                                },  
                            new JQGridColumn
                                {
                                    DataField = "IsLead",
                                    HeaderText = "Lead",
                                    Editable = true,
                                    Width = 20,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                    EditType = EditType.CheckBox,
                                    EditorControlID = "cbLead",
                                    Formatter = new CheckBoxFormatter()
                                },
                            new JQGridColumn
                                {
                                    DataField = "IsInstructor",
                                    HeaderText = "Instructor",
                                    Editable = true,
                                    Width = 20,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                    EditType = EditType.CheckBox,
                                    EditorControlID = "cbInstructor",
                                    Formatter = new CheckBoxFormatter()
                                },
                            new JQGridColumn
                                {
                                    DataField = "IsAssessor",
                                    HeaderText = "Assessor",
                                    Editable = true,
                                    Width = 20,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                    EditType = EditType.CheckBox,
                                    EditorControlID = "cbAssessor",
                                    Formatter = new CheckBoxFormatter()

                                },
                            new JQGridColumn
                                {
                                    DataField = "IsShadow",                                                                    
                                    HeaderText = "Shadow",
                                    Editable = true,
                                    Width = 30,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                    EditType = EditType.CheckBox,
                                    EditorControlID = "cbShadow",
                                    Formatter = new CheckBoxFormatter()
                                },
                            new JQGridColumn
                                {
                                    DataField = "IsSpecialist",                                                                    
                                    HeaderText = "Specialist",
                                    Editable = true,
                                    Width = 30,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                    EditType = EditType.CheckBox,
                                    EditorControlID = "cbSpecialist",
                                    Formatter = new CheckBoxFormatter()
                                },
                            new JQGridColumn 
                                {
                                    EditActionIconsColumn = true, 
                                    EditActionIconsSettings = new EditActionIconsSettings
                                                                {
                                                                    SaveOnEnterKeyPress = true,
                                                                    ShowDeleteIcon = false
                                                                }, 
                                    HeaderText = " ", 
                                    Width = 30,
                                    Sortable = false,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                                                      
                                }
                        },
                    Width = Unit.Pixel(900),
                    Height = Unit.Percentage(100),
                    PagerSettings =
                        {
                            PageSize = 20
                        },
                    ID = "ActivitiesGrid",
                    DataUrl = dataURL,
                    EditUrl = editURL,
                    SortSettings = new SortSettings()
                        {
                            InitialSortColumn = "Title"
                        },                        
                };
        }
    }
}