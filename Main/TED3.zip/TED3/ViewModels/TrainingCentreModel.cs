namespace SFR.TOR.ViewModels
{
    public class TrainingCentreModel : BaseModel
    {
        public string Name { get; set; }
    }
}