﻿namespace SFR.TOR.ViewModels
{
    public class VenueDayPartModel : BaseModel
    {
        public string Name { get; set; }

        public int MinRequired { get; set; }

    }
}
