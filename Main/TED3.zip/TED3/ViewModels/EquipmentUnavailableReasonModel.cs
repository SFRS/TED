namespace SFR.TOR.ViewModels
{
    public class EquipmentUnavailableReasonModel : BaseModel
    {
        public string Reason { get; set; }
    }
}