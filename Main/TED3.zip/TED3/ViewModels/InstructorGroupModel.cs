namespace SFR.TOR.ViewModels
{
    public class InstructorGroupModel : BaseModel
    {
        public string Name { get; set; }
    }
}