
namespace SFR.TOR.ViewModels
{
    public class ActivityDayPartModel: BaseModel
    {
        public int DayTypeID { get; set; }
        
        public string Description { get; set; }
    }
}