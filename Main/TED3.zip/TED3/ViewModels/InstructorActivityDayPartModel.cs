﻿
namespace SFR.TOR.ViewModels
{
    public class InstructorActivityDayPartModel
    {
        public int ID { get; set; }

        public string SectionTitle { get; set; }

        public int EligibleInstructorID { get; set; }

        public bool IsLead { get; set; }

        public bool IsInstructor { get; set; }

        public bool IsAssessor { get; set; }

        public bool IsShadow { get; set; }

        public bool IsSpecialist { get; set; }

        public string Name { get; set; }

    }
}
