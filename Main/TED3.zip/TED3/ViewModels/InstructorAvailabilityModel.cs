namespace SFR.TOR.ViewModels
{
    public class InstructorAvailabilityModel {
        public int ID { get; set; }

        public string Name { get; set; }

        public bool? Free { get; set; }

        public string EventName { get; set; }

        public int? DayType { get; set; }

        public bool? IsLead { get; set; }

        public bool? IsAssessor { get; set; }

        public bool? IsInstructor { get; set; }

        public bool? IsShadow { get; set; }

        public bool? IsSpecialist { get; set; }

        public int? ActivityTemplateID { get; set; }

        public int DayPartID { get; set; }

        public bool? SelectedLead { get; set; }

        public bool? SelectedAssessor { get; set; }

        public bool? SelectedShadow { get; set; }

        public bool? SelectedInstructor { get; set; }

        public bool? SelectedSpecialist { get; set; }

        public int UnavailableReasonID { get; set; }

        public int TrainingCentreId { get; set; }

        public string TrainingCentreName { get; set; }
    }
}