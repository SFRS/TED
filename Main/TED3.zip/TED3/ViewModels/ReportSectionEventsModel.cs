﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SFR.TOR.ViewModels
{
    public class ReportSectionEventsModel
    {
        public ReportSectionEventsModel()
        {
            SectionEvents = new List<SectionEventsData>();
            UtilisationTotals = new List<UtilisationTotalsData>();
        }

        public List<IEnumerable> GetReportData()
        {
            // Must return datasets in the order expected by the report
            return new List<IEnumerable> { SectionEvents, UtilisationTotals };
        }

        // DataSet1
        public List<SectionEventsData> SectionEvents { get; set; }

        // DataSet2
        public List<UtilisationTotalsData> UtilisationTotals { get; set; }

        public class SectionEventsData
        {
            public string EventCode { get; set; }
            public string EventTitle { get; set; }
            public double NumberOfDays { get; set; }
            public double DaysFullyResourced { get; set; }
            public DateTime StartDate { get; set; }
            public DateTime EndDate { get; set; }
            public string OverallStatus { get; set; }
            public string DayEveningString { get; set; }
        }

        public class UtilisationTotalsData
        {
            public double TotalTrainingDelivery { get; set; }
            public double TotalTrainingDeliveryAbsolutePercent { get; set; }
            public double TotalTrainingDeliveryRelativePercent { get; set; }
            public double TotalNonTrainingRelated { get; set; }
            public double TotalNonTrainingRelatedAbsolutePercent { get; set; }
            public double TotalNonTrainingRelatedRelativePercent { get; set; }
            public double TotalNonWorkRelated { get; set; }
            public double TotalNonWorkRelatedAbsolutePercent { get; set; }
            public double TotalOtherTrainingRelated { get; set; }
            public double TotalOtherTrainingRelatedAbsolutePercent { get; set; }
            public double TotalOtherTrainingRelatedRelativePercent { get; set; }
            public double TotalEveningDelivery { get; set; }
            public double TotalEveningDeliveryAbsolutePercent { get; set; }
            public double TotalFreeDays { get; set; }
            public double TotalFreeDaysAbsolutePercent { get; set; }
            public double TotalFreeDaysRelativePercent { get; set; }
            public double TotalDaysBusy { get; set; }
            public double TotalDaysBusyAbsolutePercent { get; set; }
            public double TotalDaysBusyRelativePercent { get; set; }
            public double TotalWorkingDaysInReport { get; set; }
            public double TotalWorkingDaysInReportAbsolutePercent { get; set; }
        }
    }
}
