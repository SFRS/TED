namespace SFR.TOR.ViewModels
{
    public class VenueTagVenueModel : BaseModel
    {
        public int VenueID { get; set; }
        public int VenueTagID { get; set; }
        public string Name { get; set; }
    }
}