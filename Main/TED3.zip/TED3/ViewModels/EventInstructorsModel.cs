﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using Trirand.Web.Mvc;
using TextAlign = Trirand.Web.Mvc.TextAlign;

namespace SFR.TOR.ViewModels
{
    public class EventInstructorsModel: EventModel
    {
        public JQGrid InstructorGrid { get; set; }

        public int EventDayPartID { get; set; }

        public List<SelectListItem> EventParts { get; set; }
        public List<SelectListItem> CopyToEventPartList { get; set; }

        public string[] SelectedSection { get; set; }
        public string[] SelectedTrainingCentres { get; set; }
        public SelectList TrainingCentres { get; set; }
        
        public int SelectedEventPartID { get; set; }

        public int RequiredInstructorCount { get; set; }
        public int RequiredLeadCount { get; set; }
        public int RequiredAssessorCount { get; set; }
        public int RequiredShadowCount { get; set; }
        public int RequiredSpecialistCount { get; set; }

        public int SelectedInstructorCount { get; set; }
        public int SelectedLeadCount { get; set; }
        public int SelectedAssessorCount { get; set; }
        public int SelectedShadowCount { get; set; }
        public int SelectedSpecialistCount { get; set; }

        public EventInstructorsModel(string dataURL, string editURL)
        {
            InstructorGrid = new JQGrid
            {
                Columns = new List<JQGridColumn>()
                {
                    new JQGridColumn
                    {
                        PrimaryKey = true,
                        DataField = "ID",
                        Visible = false,
                    },
                    new JQGridColumn
                    {
                        DataField = "Name",
                        HeaderText = "Name",
                        Width = 40
                    },
                    new JQGridColumn
                    {
                        DataField = "Free",
                        HeaderText = "Free?",
                        Width = 40,   
                        Formatter = new CustomFormatter { FormatFunction = "formatFree" },
                    },
                    new JQGridColumn
                    {
                        DataField = "EventName",
                        HeaderText = "Event Name",
                        Width = 100
                    },
                    new JQGridColumn
                    {
                        DataField = "SelectedLead",
                        HeaderText = "Lead",
                        Editable = true,
                        Width = 20,
                        TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                        Formatter = new CustomFormatter { FormatFunction = "formatSelectedLead" },
                        EditType = EditType.Custom,
                        EditTypeCustomCreateElement = "createEditOptionLead",
                        EditTypeCustomGetValue = "getLeadSelected",
                        EditorControlID = "SelectedLead",
                        Sortable = false
                    },
                    new JQGridColumn
                    {
                        DataField = "IsLead",
                        Visible = false
                    },
                    new JQGridColumn
                    {
                        DataField = "SelectedInstructor",
                        HeaderText = "Instructor",
                        Editable = true,
                        Width = 30,
                        TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                        Formatter = new CustomFormatter { FormatFunction = "formatSelectedInstructor" },
                        EditType = EditType.Custom,
                        EditTypeCustomCreateElement = "createEditOptionInstructor",
                        EditTypeCustomGetValue = "getInstructorSelected",
                        EditorControlID = "SelectedInstructor", 
                        Sortable = false
                    },
                    new JQGridColumn
                    {
                        DataField = "IsInstructor",
                        Visible = false
                    },
                    new JQGridColumn
                    {
                        DataField = "SelectedAssessor",
                        HeaderText = "Assessor",
                        Editable = true,
                        Width = 30,
                        TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                        Formatter = new CustomFormatter { FormatFunction = "formatSelectedAssessor" },
                        EditType = EditType.Custom,
                        EditTypeCustomCreateElement = "createEditOptionAssessor",
                        EditTypeCustomGetValue = "getAssessorSelected",
                        EditorControlID = "SelectedAssessor", 
                        Sortable = false
                    },
                    new JQGridColumn
                    {
                        DataField = "IsAssessor",
                        Visible = false
                    },
                    new JQGridColumn
                    {
                        DataField = "SelectedShadow",
                        HeaderText = "Shadow",
                        Editable = true,
                        Width = 30,
                        TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                        Formatter = new CustomFormatter { FormatFunction = "formatSelectedShadow" },
                        EditType = EditType.Custom,
                        EditTypeCustomCreateElement = "createEditOptionShadow",
                        EditTypeCustomGetValue = "getShadowSelected",
                        EditorControlID = "SelectedShadow",
                        Sortable = false
                    },
                    new JQGridColumn
                    {
                        DataField = "IsShadow",
                        Visible = false
                    },
                  
                    new JQGridColumn
                    {
                        DataField = "SelectedSpecialist",
                        HeaderText = "Specialist",
                        Editable = true,
                        Width = 30,
                        TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                        Formatter = new CustomFormatter { FormatFunction = "formatSelectedSpecialist" },
                        EditType = EditType.Custom,
                        EditTypeCustomCreateElement = "createEditOptionSpecialist",
                        EditTypeCustomGetValue = "getSpecialistSelected",
                        EditorControlID = "SelectedSpecialist",
                        Sortable = false
                    },
                    new JQGridColumn
                    {
                        DataField = "IsSpecialist",
                        Visible = false
                    },
                    new JQGridColumn
                    {
                        DataField = "UnavailableReasonID",
                        Visible = false
                    },
                    new JQGridColumn
                    {
                        DataField = "TrainingCentreName",
                        HeaderText = "Training Centre",
                        Editable = false,
                        Width = 50,
                        TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                        Sortable = true
                    },
                    new JQGridColumn 
                    {
                        EditActionIconsColumn = true,
                        EditActionIconsSettings = new EditActionIconsSettings
                        {
                            SaveOnEnterKeyPress = true,
                            ShowDeleteIcon = false
                        },
                        HeaderText = " ",
                        Width = 20,
                        Sortable = false,
                        TextAlign = TextAlign.Center
                    },
                },
                Width = Unit.Pixel(900),
                Height = Unit.Percentage(100),
                PagerSettings = { PageSize = 20 },
                ID = "InstructorsGrid",
                DataUrl = dataURL,
                EditUrl = editURL,
                SortSettings = new SortSettings() { InitialSortColumn = "Name" },
            };
        }


    }
}