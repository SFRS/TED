﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class ActivitySummaryModel : ActivityModel
    {
        public List<ActivityPartSummary> ActivitiesPartSummaries { get; set; }

        public List<SelectListItem> FinancialYears { get; set; }
    }
}