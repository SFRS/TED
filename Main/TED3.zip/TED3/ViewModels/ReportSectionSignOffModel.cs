﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SFR.TOR.ViewModels
{
    public class ReportSectionSignOffModel
    {
        public ReportSectionSignOffModel()
        {
            SignOffEventsAndTotals = new List<SignOffEventsAndTotalsData>();
        }

        public List<IEnumerable> GetReportData()
        {
            // Must return datasets in the order expected by the report
            return new List<IEnumerable> { SignOffEventsAndTotals };
        }

        // DataSet1
        public List<SignOffEventsAndTotalsData> SignOffEventsAndTotals { get; set; }

        public class SignOffEventsAndTotalsData
        {
            public int WeekNum { get; set; }
            public DateTime? Date { get; set; }

            // Event data
            public string EventCode { get; set; }
            public string EventStatus { get; set; }
            public string EventTitle { get; set; }
            public string AMPM { get; set; }
            public string ResourcedStatusChar { get; set; }

            // Totals data
            public double TotalTrainingDelivery { get; set; }
            public double TotalAvailableNotAssigned { get; set; }
            public double TotalNonTrainingRelated { get; set; }
            public double TotalNonWorkRelated { get; set; }
            public double TotalOtherTrainingRelated { get; set; }
            public double TotalEveningEvents { get; set; }
            public double TotalTrainingDeliveryAbsolutePercent { get; set; }
            public double TotalAvailableNotAssignedAbsolutePercent { get; set; }
            public double TotalNonTrainingRelatedAbsolutePercent { get; set; }
            public double TotalNonWorkRelatedAbsolutePercent { get; set; }
            public double TotalOtherTrainingRelatedAbsolutePercent { get; set; }
            public double TotalEveningEventsAbsolutePercent { get; set; }
            public double TotalTrainingDeliveryRelativePercent { get; set; }
            public double TotalAvailableNotAssignedRelativePercent { get; set; }
            public double TotalNonTrainingRelatedRelativePercent { get; set; }
            public double TotalOtherTrainingRelatedRelativePercent { get; set; }
            public double TotalDaysBusy { get; set; }
            public double TotalDaysBusyAbsolutePercent { get; set; }
            public double TotalDaysBusyRelativePercent { get; set; }
            public double TotalWorkingDaysInReport { get; set; }
            public double TotalWorkingDaysInReportAbsolutePercent { get; set; }
        }
    }
}
