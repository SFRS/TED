﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Trirand.Web.Mvc;
using System.Web.UI.WebControls;

namespace SFR.TOR.ViewModels
{
    public class EquipmentGroupModel : BaseModel
    {
        public string Title { get; set; }        
    }
}
