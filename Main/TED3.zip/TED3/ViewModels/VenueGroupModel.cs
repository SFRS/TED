﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SFR.TOR.ViewModels
{
    public class VenueGroupModel : BaseModel
    {
        public string Title { get; set; }
    }
}
