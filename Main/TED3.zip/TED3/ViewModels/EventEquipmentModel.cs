﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using Trirand.Web.Mvc;
using TextAlign = Trirand.Web.Mvc.TextAlign;

namespace SFR.TOR.ViewModels
{
    public class EventEquipmentModel : EventModel
    {
        public JQGrid EquipmentGrid { get; set; }

        public int SelectedEventPartID { get; set; }

        public IEnumerable<SelectListItem> EventParts { get; set; }
        public List<SelectListItem> CopyToEventPartList { get; set; }


        public string[] SelectedTrainingCentres { get; set; }
        public SelectList TrainingCentres { get; set; }

        public List<EquipmentTagModel> EquipmentTags { get; set; }

        public EventEquipmentModel(string dataURL, string editURL, List<SelectListItem> equipmentTags)
        {
            EquipmentGrid = new JQGrid
            {
                Columns = new List<JQGridColumn>()
                {
                    new JQGridColumn
                    {
                        PrimaryKey = true,
                        DataField = "ID",
                        Visible = false,
                    },
                    new JQGridColumn
                    {
                        DataField = "Equipment",
                        HeaderText = "Equipment",
                        Width = 100
                    },
                    new JQGridColumn
                    {
                        DataField = "Free",
                        HeaderText = "Free",
                        Width = 20,
                        Formatter = new CustomFormatter { FormatFunction = "formatFree" }
                    },
                    new JQGridColumn
                    {
                        DataField = "EventName",
                        HeaderText = "Event",
                        Width = 100
                    },
                    new JQGridColumn
                    {
                        DataField = "Booked",
                        HeaderText = "Book",
                        Width = 20,
                        Editable = true,
                        TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                        Formatter = new CustomFormatter { FormatFunction = "formatBooked" },
                        EditType = EditType.Custom,
                        EditTypeCustomCreateElement = "createBookedCheckBox",
                        EditTypeCustomGetValue = "getBookedValue",
                        EditorControlID = "cbBooked",  
                    },
                    new JQGridColumn
                    {
                        DataField = "EquipmentTagID",
                        HeaderText = "Category",
                        Editable = true,
                        EditType = EditType.Custom,
                        EditTypeCustomCreateElement = "createDropDown",
                        EditTypeCustomGetValue = "getSelected",
                        Formatter = new CustomFormatter { FormatFunction = "formatCategorySelection" },
                        Width = 80
                    },
                    new JQGridColumn
                    {
                        DataField = "EquipmentUnavailableReasonID",
                        Visible = false,
                        Editable = false
                    },
                       new JQGridColumn{
                                    DataField = "TrainingCentreName",
                                    HeaderText = "Training Centre",
                                    Editable = false,
                                    Width = 50,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                    Sortable = true
                                },
                    new JQGridColumn
                    {
                        EditActionIconsColumn = true, 
                        EditActionIconsSettings = new EditActionIconsSettings
                        {
                            SaveOnEnterKeyPress = true,
                            ShowDeleteIcon = false
                        }, 
                        HeaderText = " ",
                        Width = 20,
                        Sortable = false,
                        TextAlign = TextAlign.Center
                    },
                },
                Width = Unit.Pixel(900),
                Height = Unit.Percentage(100),
                PagerSettings = { PageSize = 20 },
                ID = "EquipmentGrid",
                DataUrl = dataURL,
                EditUrl = editURL,
                ClientSideEvents = new ClientSideEvents { GridInitialized = "gridInitialized" },
                SortSettings = new SortSettings { InitialSortColumn = "Equipment" }
            };
        }
    }
}