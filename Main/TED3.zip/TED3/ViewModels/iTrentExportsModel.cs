using System.Collections.Generic;
using System.Web.UI.WebControls;
using Trirand.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class iTrentExportsModel : BaseModel
    {
        public JQGrid iTrentExportsGrid { get; set; }
        public ITrentUploadModel iTrentUploadModel = new ITrentUploadModel();
        public int? SelectedITrentExportID { get; set; }

        public iTrentExportsModel(string dataURL, string editURL)
        {
            iTrentExportsGrid = new JQGrid
                {
                    Columns = new List<JQGridColumn>()
                        {                       
                            new JQGridColumn
                                {
                                    DataField = "Title",
                                    HeaderText = "Title",
                                    Width = 300,
                                    Visible = true, 
                                }, 
                            new JQGridColumn
                                {
                                    DataField = "Status",
                                    HeaderText = "Status",
                                    Visible = true,
                                    Width = 150,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                    Formatter = new CustomFormatter
                                        {
                                            FormatFunction = "formatStatuses",
                                        },
                                },
                            new JQGridColumn
                                {
                                    DataField = "Type",
                                    HeaderText = "Type",
                                    Width = 250,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                    Visible = true, 
                                },
                            new JQGridColumn
                                {
                                    DataField = "FinancialYear",
                                    HeaderText = "Financial Year",
                                    Visible = true,
                                    Width = 160,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center
                                },  
                            new JQGridColumn
                                {
                                    DataField = "iTrentExportDate",
                                    HeaderText = "Export Date",
                                    DataFormatString = "{0:dd/MM/yyyy}",
                                    Visible = true,   
                                    Width = 150,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center
                                },
                            new JQGridColumn
                                {
                                    DataField = "EventsExported",
                                    HeaderText = "Exported",
                                    Visible = true,
                                    Width = 150,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center
                                },
                            new JQGridColumn
                                {
                                    DataField = "ExportErrors",
                                    HeaderText = "Export Errors",
                                    Visible = true,
                                    Width = 150,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center
                                },                                   
                            new JQGridColumn
                                {
                                    DataField = "EventsUploaded",
                                    HeaderText = "Uploaded",
                                    Visible = true, 
                                    Width = 150,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center
                                }, 
                            new JQGridColumn
                                {
                                    DataField = "UploadErrors",
                                    HeaderText = "Upload Errors",
                                    Visible = true, 
                                    Width = 150,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center
                                },    
                            new JQGridColumn
                                {
                                    DataField = "ID",
                                    HeaderText = " ",
                                    PrimaryKey = true,
                                    Width = 60,
                                    Sortable = false,
                                    Formatter = new CustomFormatter
                                        {
                                            FormatFunction = "formatLinks",
                                        },
                                    Searchable = false,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                    
                                },
                            new JQGridColumn
                                {
                                    EditActionIconsColumn = true,
                                    EditActionIconsSettings = new EditActionIconsSettings
                                        {
                                            SaveOnEnterKeyPress = false,
                                            ShowEditIcon = false,
                                            ShowDeleteIcon = true
                                        },
                                    Formatter = new CustomFormatter
                                        {
                                            FormatFunction = "formatLinks"
                                        },
                                    HeaderText = " ",
                                    Width = 40,
                                    Sortable = false,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                    Searchable = false
                                }
                        },
                    Width = Unit.Pixel(1075),
                    Height = Unit.Percentage(100),
                    PagerSettings =
                        {
                            PageSize = 20
                        },
                    ID = "iTrentExportGrid",
                    DataUrl = dataURL,
                    EditUrl = editURL,
                    SortSettings = new SortSettings()
                        {
                            InitialSortColumn = "Status",
                            InitialSortDirection = Trirand.Web.Mvc.SortDirection.Asc
                        }                    
                };
        }
    }
}