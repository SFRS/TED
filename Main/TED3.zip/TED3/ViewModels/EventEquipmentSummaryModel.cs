using System.Collections.Generic;

namespace SFR.TOR.ViewModels
{
    public class EventEquipmentSummaryModel
    {
        public string EquipmentCategory { get; set; }

        public List<string> Equipment { get; set; }

        public string SummaryOfNumbers { get; set; }

        public bool Fulfilled { get; set; }

    }
}