﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using SFR.TOR.Utility;
using Trirand.Web.Mvc;

namespace SFR.TOR.ViewModels
{
  public class EquipmentsModel
    {
        public JQGrid EquipmentGrid { get; set; }

        public EquipmentsModel(string dataURL, SelectList trainingCentreData, SelectList availabilityData, SelectList groupData)
        {
            EquipmentGrid = new JQGrid
            {
                Columns = new List<JQGridColumn>()
                        {
                            new JQGridColumn
                                {
                                    DataField = "Name",
                                    HeaderText = "Name",
                                    Editable = true,
                                    Width = 30,
                                    Searchable = false
                                },                            
                            new JQGridColumn
                                {
                                    DataField = "EquipmentGroup",
                                    HeaderText = "Equipment Group",
                                    Width = 20,
                                    Searchable = true
                                },
                            new JQGridColumn
                                {
                                    DataField = "Availability",
                                    HeaderText = "Availability",
                                    Width = 10
                                },
                             new JQGridColumn
                                {
                                    DataField = "TrainingCentre",
                                    HeaderText = "Training Centre",
                                    Width = 10
                                },
                            new JQGridColumn
                                {
                                    DataField = "ID",
                                    HeaderText = " ",
                                    Width = 10,
                                    Sortable = false,
                                    Formatter = new CustomFormatter
                                        {
                                            FormatFunction = "formatLinks",
                                        },
                                    Searchable = false
                                },
                        },
                Width = Unit.Pixel(700),
                Height = Unit.Percentage(100),
                PagerSettings =
                {
                    PageSize = 20
                },
                ID = "EquipmentGrid",
                DataUrl = dataURL,
                SortSettings = new SortSettings()
                {
                    InitialSortColumn = "EquipmentGroup"
                },
                ToolBarSettings = new ToolBarSettings()
                {
                    ShowSearchToolBar = true
                }
            };

            EquipmentGrid.SetupDropDownFilterColumn("TrainingCentre", SearchOperation.IsEqualTo, SearchType.DropDown, trainingCentreData, true);
            EquipmentGrid.SetupDropDownFilterColumn("Availability", SearchOperation.IsEqualTo, SearchType.DropDown, availabilityData, true);
            EquipmentGrid.SetupDropDownFilterColumn("EquipmentGroup", SearchOperation.IsEqualTo, SearchType.DropDown, groupData, true);
        }
    }
}