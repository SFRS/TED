﻿namespace SFR.TOR.ViewModels
{
    public class CalendarData: BaseModel
    {
        public string Name { get; set; }

        public string SectionName { get; set; }
        public string GroupName { get; set; }
     
        public string Day1AM { get; set; }
        public string Day1PM { get; set; }

        public string Day2AM { get; set; }
        public string Day2PM { get; set; }

        public string Day3AM { get; set; }
        public string Day3PM { get; set; }

        public string Day4AM { get; set; }
        public string Day4PM { get; set; }

        public string Day5AM { get; set; }
        public string Day5PM { get; set; }

        public string Day6AM { get; set; }
        public string Day6PM { get; set; }

        public string Day7AM { get; set; }
        public string Day7PM { get; set; }
    }
}