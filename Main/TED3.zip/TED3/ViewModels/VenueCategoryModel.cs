namespace SFR.TOR.ViewModels
{
    public class VenueCategoryModel: BaseModel
    {
        public string Name { get; set; }
    }
}