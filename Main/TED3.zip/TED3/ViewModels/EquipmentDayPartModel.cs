﻿
namespace SFR.TOR.ViewModels
{
    public class EquipmentDayPartModel: BaseModel
    {
        public string Name { get; set; }

        public int MinRequired { get; set; }
    }
}
