using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SFR.TOR.ViewModels
{
    public class ReportCateringModel
    {
        public ReportCateringModel()
        {
            Catering = new List<CateringData>();
            CateringTrainingCentre = new List<CateringTrainingCentreData>();
        }

        public List<IEnumerable> GetReportData()
        {
            // Must return datasets in the order expected by the report
            return new List<IEnumerable> { Catering, CateringTrainingCentre };
        }

        // DataSet1
        public List<CateringData> Catering { get; set; }

        // DataSet2
        public List<CateringTrainingCentreData> CateringTrainingCentre { get; set; }

        public class CateringData
        {
            public DateTime Date { get; set; }
            public TimeSpan StartTime { get; set; }
            public TimeSpan EndTime { get; set; }
            public string EventTitle { get; set; }
            public string VenueName { get; set; }
            public string SectionName { get; set; }
            public string EventCode { get; set; }
            public string Resourced { get; set; }
        }

        public class CateringTrainingCentreData
        {
            public string TrainingCentreName { get; set; }
        }
    }
}
