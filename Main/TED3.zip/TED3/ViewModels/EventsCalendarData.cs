namespace SFR.TOR.ViewModels
{
    public class EventsCalendarData : CalendarData
    {
    }
}