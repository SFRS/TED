﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SFR.TOR.ViewModels
{
    public class ReportEventsByStatusModel
    {
        public ReportEventsByStatusModel()
        {
            EventsByStatus = new List<EventsByStatusData>();
        }

        public List<IEnumerable> GetReportData()
        {
            // Must return datasets in the order expected by the report
            return new List<IEnumerable> { EventsByStatus };
        }

        // DataSet1
        public List<EventsByStatusData> EventsByStatus { get; set; }

        public class EventsByStatusData
        {
            public string EventCode { get; set; }
            public string EventTitle { get; set; }
            public string EventStatus { get; set; }
            public string SectionName { get; set; }
            public string Resourced { get; set; }
            /* The following string fields ought to be doubles, but for unknown reasons AutoMapper 
             * isn't setting their values correctly based on what was found in the SqlDataReader */
            public string TotalDays { get; set; }
            public string DaysCounted { get; set; }
            public string DaysResourced { get; set; }
            public string DaysCatered { get; set; }
            public DateTime StartDate { get; set; }
            public DateTime EndDate { get; set; }
        }
    }
}
