namespace SFR.TOR.ViewModels
{
    public class PinchpointTypeModel : BaseModel
    {
        public string Name { get; set; }

    }
}