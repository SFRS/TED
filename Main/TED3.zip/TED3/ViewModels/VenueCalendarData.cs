﻿namespace SFR.TOR.ViewModels
{
    public class VenueCalendarData: CalendarData
    {        
    }
}