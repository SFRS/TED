namespace SFR.TOR.ViewModels
{
    public class VenueModel : BaseModel
    {
        public string Name { get; set; }
        public string TrainingCentre { get; set; }
        // Added D Scott for Venues Edit select list
        public int TrainingCentreID { get; set; }
        //
        public string VenueGroup { get; set; }
        public int VenueGroupID { get; set; }
        public string Availability { get; set; }
    }
}