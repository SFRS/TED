namespace SFR.TOR.ViewModels
{
    public class InstructorEventPartModel: BaseModel
    {
        public bool? IsLead { get; set; }

        public bool? IsInstructor { get; set; }

        public bool? IsAssessor { get; set; }

        public bool? IsShadow { get; set; }

        public bool? IsSpecialist { get; set; }

        public int EventPartID { get; set; }

        public int EventID { get; set; }
    }
}