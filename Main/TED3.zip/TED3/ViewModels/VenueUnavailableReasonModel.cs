namespace SFR.TOR.ViewModels
{
    public class VenueUnavailableReasonModel : BaseModel
    {
        public string Reason { get; set; }
    }
}