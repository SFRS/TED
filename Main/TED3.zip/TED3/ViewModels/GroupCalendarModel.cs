using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using Trirand.Web.Mvc;
using SortDirection = Trirand.Web.Mvc.SortDirection;

namespace SFR.TOR.ViewModels
{
    public class GroupCalendarModel
    {
        public List<SelectListItem> Years { get; set; }

        public JQGrid GroupCalendarGrid { get; set; }

        public int SelectedYear { get; set; }

        public GroupCalendarModel(string dataURL, string editURL)
        {
            GroupCalendarGrid = new JQGrid
                {
                    Columns = new List<JQGridColumn>()
                        {
                            new JQGridColumn
                                {
                                    DataField = "ID",
                                    PrimaryKey = true,
                                    Visible = false                                    
                                },    
                            new JQGridColumn
                                {
                                    DataField = "GroupDate",
                                    HeaderText = "Date",
                                    Editable = false,
                                    Width = 100,
                                    DataFormatString = "{0:dd/MM/yyyy}",
                                },
                            new JQGridColumn
                                {
                                    DataField = "Title",
                                    HeaderText = "Group",
                                    Editable = true,
                                    Width = 100
                                },                                                                                                                                                                            
                            new JQGridColumn 
                                {
                                    EditActionIconsColumn = true, 
                                    EditActionIconsSettings = new EditActionIconsSettings
                                        {
                                            SaveOnEnterKeyPress = true,                                            
                                            ShowEditIcon = true,
                                            ShowDeleteIcon = false
                                        }, 
                                    HeaderText = " ", 
                                    Width = 30,
                                    Sortable = false,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,                                                                      
                                }
                        },
                    Width = Unit.Pixel(900),
                    Height = Unit.Percentage(100),
                    PagerSettings =
                        {
                            PageSize = 20 //max number of days in  year? or should we just page like every other grid?
                        },
                    ID = "GroupCalendarGrid",
                    DataUrl = dataURL,
                    EditUrl = editURL,
                    SortSettings = new SortSettings()
                        {
                            InitialSortColumn = "GroupDate",
                            InitialSortDirection = SortDirection.Asc
                        },                    
                };

        }
    }
}