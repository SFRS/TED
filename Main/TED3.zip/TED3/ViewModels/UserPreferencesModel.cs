﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class UserPreferencesEditModel: BaseModel
    {
        [DisplayName("Default Training Centre:")]
        [Required(ErrorMessage = "Required: Please select a Training Centre.")]
        public int DefaultTrainingCentreID { get; set; }

        [DisplayName("Show Resources from all Training Centres:")]
        public bool DefaultShowAllResources { get; set; }

        public SelectList TrainingCentreData { get; set; }
    }
}
