﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using Trirand.Web.Mvc;
using PagerSettings = Trirand.Web.Mvc.PagerSettings;
using TextAlign = Trirand.Web.Mvc.TextAlign;

namespace SFR.TOR.ViewModels
{
    public class InstructorsCalendarModel : CalendarModel
    {
        public JQGrid CalendarGrid { get; set; }
        
        public InstructorsCalendarModel(string dataURL, List<DateTime> dates, bool showWeekend)
        {
            ViewTitle = "Instructors";
            Dates = dates;
            ShowWeekend = showWeekend;
            StartDate = dates[0];
            Datepicker = dates[0].ToString("dd/MM/yyyy");
            CalendarGrid = new JQGrid
            {
                Columns = new List<JQGridColumn>()
                {
                    new JQGridColumn
                        {
                            DataField = "Name",
                            HeaderText = "Instructor",
                            Sortable = true,
                            Width = 90
                        },
                    new JQGridColumn
                        {
                            DataField = "SectionName",
                            HeaderText = "Section Name",
                            Visible = true,
                            Width = 100
                        },
                    new JQGridColumn
                        {
                            DataField = "GroupName",
                            HeaderText = "Group",
                            Visible = true,
                            Width = 50,
                            TextAlign = TextAlign.Center,
                        },
                    CreateDayPartColumn("Day1AM", "AM", "formatCourseData", dates[0]),
                    CreateDayPartColumn("Day1PM", "PM", "formatCourseData", dates[0]),
                    CreateDayPartColumn("Day2AM", "AM", "formatCourseData", dates[1]),
                    CreateDayPartColumn("Day2PM", "PM", "formatCourseData", dates[1]),
                    CreateDayPartColumn("Day3AM", "AM", "formatCourseData", dates[2]),
                    CreateDayPartColumn("Day3PM", "PM", "formatCourseData", dates[2]),
                    CreateDayPartColumn("Day4AM", "AM", "formatCourseData", dates[3]),
                    CreateDayPartColumn("Day4PM", "PM", "formatCourseData", dates[3]),
                    CreateDayPartColumn("Day5AM", "AM", "formatCourseData", dates[4]),
                    CreateDayPartColumn("Day5PM", "PM", "formatCourseData", dates[4]),
                    CreateDayPartColumn("Day6AM", "AM", "formatCourseData", dates[5]),
                    CreateDayPartColumn("Day6PM", "PM", "formatCourseData", dates[5]),
                    CreateDayPartColumn("Day7AM", "AM", "formatCourseData", dates[6]),
                    CreateDayPartColumn("Day7PM", "PM", "formatCourseData", dates[6]),
                },
                ID = "Grid",
                DataUrl = dataURL,
                Height = Unit.Pixel(500),    
                SortSettings = new SortSettings()
                {
                    InitialSortColumn = "SectionName"
                },
                PagerSettings = new PagerSettings
                {
                    ScrollBarPaging = true,
                    PageSize = 30
                }
            };

            CalendarGrid.HeaderGroups.Add(
                new JQGridHeaderGroup
                {
                    StartColumnName = "Day1AM",
                    NumberOfColumns = 2,
                    TitleText = dates[0].ToString("ddd d/M/yy")
                });
            CalendarGrid.HeaderGroups.Add(
                new JQGridHeaderGroup
                {
                    StartColumnName = "Day2AM",
                    NumberOfColumns = 2,
                    TitleText = dates[1].ToString("ddd d/M/yy")
                });
            CalendarGrid.HeaderGroups.Add(
                new JQGridHeaderGroup
                {
                    StartColumnName = "Day3AM",
                    NumberOfColumns = 2,
                    TitleText = dates[2].ToString("ddd d/M/yy")
                });
            CalendarGrid.HeaderGroups.Add(
                new JQGridHeaderGroup
                {
                    StartColumnName = "Day4AM",
                    NumberOfColumns = 2,
                    TitleText = dates[3].ToString("ddd d/M/yy")
                });
            CalendarGrid.HeaderGroups.Add(
                new JQGridHeaderGroup
                {
                    StartColumnName = "Day5AM",
                    NumberOfColumns = 2,
                    TitleText = dates[4].ToString("ddd d/M/yy")
                });

            CalendarGrid.HeaderGroups.Add(
                new JQGridHeaderGroup
                    {
                        StartColumnName = "Day6AM",
                        NumberOfColumns = 2,
                        TitleText = dates[5].ToString("ddd d/M/yy")
                    });
            CalendarGrid.HeaderGroups.Add(
                new JQGridHeaderGroup
                    {
                        StartColumnName = "Day7AM",
                        NumberOfColumns = 2,
                        TitleText = dates[6].ToString("ddd d/M/yy")                       
                    });
        }

        /// <summary>
        /// Creates a JQ Grid column for displaying day parts cells
        /// </summary>
        /// <param name="dataField"></param>
        /// <param name="headerText"></param>
        /// <param name="formatter"></param>
        /// <param name="theDate"></param>
        /// <returns></returns>
        private JQGridColumn CreateDayPartColumn(string dataField, string headerText, string formatter, DateTime theDate)
        {
            bool visible = 
                //is a weekend day and we must show weekend days
                (theDate.DayOfWeek == DayOfWeek.Saturday || theDate.DayOfWeek == DayOfWeek.Sunday) && ShowWeekend
                || //otherwise, if it's a weekday always display
                ((theDate.DayOfWeek == DayOfWeek.Monday || theDate.DayOfWeek == DayOfWeek.Tuesday ||
                  theDate.DayOfWeek == DayOfWeek.Wednesday || theDate.DayOfWeek == DayOfWeek.Thursday ||
                  theDate.DayOfWeek == DayOfWeek.Friday));

            return new JQGridColumn()
            {
                DataField = dataField,
                HeaderText = headerText,
                Width = ShowWeekend ? 65 : 90,
                //CssClass = "calendarPaddingOverride",
                Sortable = false,
                Visible = visible,                
                Formatter = new CustomFormatter
                {
                    FormatFunction = formatter,
                }
            };    
        }        
    }

}