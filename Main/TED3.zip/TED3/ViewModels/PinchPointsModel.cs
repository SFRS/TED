using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using Trirand.Web.Mvc;
using SortDirection = Trirand.Web.Mvc.SortDirection;

namespace SFR.TOR.ViewModels
{
    public class PinchPointsModel
    {       
        public SelectList DayItems { get; set; }
        public JQGrid Pinchpoints { get; set; }

        public double DaysAssigned { get; set; }
        public double TotalDays { get; set; }

        public PinchPointsModel(string dataURL, string editURL)
        {
            Pinchpoints = new JQGrid
                {
                    Columns = new List<JQGridColumn>()
                        {
                            new JQGridColumn
                                {
                                    DataField = "ID",
                                    PrimaryKey = true,
                                    Visible = false                                    
                                },        
                            new JQGridColumn
                                {
                                    DataField = "ReasonID",
                                    HeaderText = "Reason",
                                    Editable = true,
                                    EditType = EditType.Custom,
                                    EditTypeCustomCreateElement = "createPinchpointDropDown",
                                    EditTypeCustomGetValue = "getSelectedPinchpoint",                                                         
                                    Formatter = new CustomFormatter
                                    {
                                        FormatFunction = "formatPinchpoint",                                                             
                                    },
                                    Width = 50
                                },        
                                         
                            new JQGridColumn
                                {
                                    DataField = "StartDate",
                                    HeaderText = "Start Date",
                                    Editable = true,
                                    Width = 20,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                    EditType = EditType.DatePicker,
                                    EditorControlID = "DatePicker",  
                                    DataFormatString = "{0:dd/MM/yyyy}",
                                },                            
                            new JQGridColumn
                                {
                                    DataField = "EndDate",
                                    HeaderText = "End Date",
                                    Editable = true,
                                    DataFormatString = "{0:dd/MM/yyyy}",
                                    Width = 20,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,
                                    EditType = EditType.DatePicker,
                                    EditorControlID = "DatePicker"
                                },                                                                                   
                            new JQGridColumn 
                                {
                                    EditActionIconsColumn = true, 
                                    EditActionIconsSettings = new EditActionIconsSettings
                                                                {
                                                                    SaveOnEnterKeyPress = true,
                                                                    ShowDeleteIcon = true,
                                                                    ShowEditIcon = true
                                                                }, 
                                    HeaderText = " ", 
                                    Width = 30,
                                    Sortable = false,
                                    TextAlign = Trirand.Web.Mvc.TextAlign.Center,                                                                      
                                }
                        },
                    Width = Unit.Pixel(900),
                    Height = Unit.Percentage(100),
                    PagerSettings =
                        {
                            PageSize = 20
                        },
                    ID = "PinchpointsGrid",
                    DataUrl = dataURL,
                    EditUrl = editURL,
                    ToolBarSettings = new ToolBarSettings()
                    {
                        ShowAddButton = true,
                        ToolBarPosition = ToolBarPosition.Bottom
                    },
                    SortSettings = new SortSettings()
                        {
                            InitialSortColumn = "EndDate",
                            InitialSortDirection = SortDirection.Desc
                        },          
          
                   AddDialogSettings = new AddDialogSettings(){
                       CloseAfterAdding = true
                   }
                };
            
        }
    }

}