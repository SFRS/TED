﻿namespace SFR.TOR.ViewModels
{
    public class DayPartModel : BaseModel
    {
        public string DayTitle { get; set; }

        public int LeadsCount { get; set; }

        public int AssessorsCount { get; set; }

        public int InstructorsCount { get; set; }

        public int ShadowsCount { get; set; }

    }
}