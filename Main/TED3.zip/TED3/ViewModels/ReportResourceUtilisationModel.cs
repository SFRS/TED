﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SFR.TOR.ViewModels
{
    public class ReportResourceUtilisationModel
    {
        public ReportResourceUtilisationModel()
        {
            Table1 = new List<InstructorAvailabilityBySectionAndGroup>();
            Table1Totals = new List<InstructorTotalsBySectionAndGroup>();
            Table1Events = new List<TotalEventsBySection>();
            Table2 = new List<InstructorAvailabilityBySectionAndReason>();
            Table2Totals = new List<InstructorTotalsBySectionAndReason>();
            Table3 = new List<InstructorAvailabilityBySectionAndMonth>();
            Table3Totals = new List<InstructorTotalsBySectionAndMonth>();
        }

        public List<IEnumerable> GetReportData()
        {
            // Must return datasets in the order expected by the report
            return new List<IEnumerable> { Table3, Table3Totals, Table2, Table2Totals, Table1, Table1Events, Table1Totals };
        }

        // DataSet5
        public List<InstructorAvailabilityBySectionAndGroup> Table1 { get; set; }

        // DataSet7
        public List<InstructorTotalsBySectionAndGroup> Table1Totals { get; set; }

        // DataSet6
        public List<TotalEventsBySection> Table1Events { get; set; }

        // DataSet3
        public List<InstructorAvailabilityBySectionAndReason> Table2 { get; set; }

        // DataSet4
        public List<InstructorTotalsBySectionAndReason> Table2Totals { get; set; }

        // DataSet1
        public List<InstructorAvailabilityBySectionAndMonth> Table3 { get; set; }

        // DataSet2
        public List<InstructorTotalsBySectionAndMonth> Table3Totals { get; set; }

        public class InstructorAvailabilityBySectionAndGroup
        {
            public string GenericHeaderText { get; set; }
            public double InstructorsEngagedInEvents { get; set; }
            public string SectionName { get; set; }
            public double InstructorsEngagedInEventsPercent { get; set; }
            public bool IsAbsolutePercentage { get; set; }
            public int ColumnOrder { get; set; }
        }

        public class InstructorTotalsBySectionAndGroup
        {
            public double TotalInstructorsForSection { get; set; }
            public string GenericHeaderText { get; set; }
            public string SectionName { get; set; }
            public double InstructorsEngagedInEventsPercent { get; set; }
            public int ColumnOrder { get; set; }
        }

        public class TotalEventsBySection
        {
            public string SectionName { get; set; }
            public int TotalEventsForSection { get; set; }
        }

        public class InstructorAvailabilityBySectionAndReason
        {
            public string SectionName { get; set; }
            public string UnavailableReasonTitle { get; set; }
            public double InstructorsEngagedInEvents { get; set; }
            public double InstructorsEngagedInEventsPercent { get; set; }
        }

        public class InstructorTotalsBySectionAndReason
        {
            public string SectionName { get; set; }
            public double TotalInstructorsEngagedInNonWorkActivity { get; set; }
            public double InstructorsEngagedInNonWorkActivityPercent { get; set; }
            public string UnavailableReasonTitle { get; set; }
        }

        public class InstructorAvailabilityBySectionAndMonth
        {
            public DateTime InstructorEngagedDate { get; set; }
            public string SectionName { get; set; }
            public int SectionID { get; set; }
            public double InstructorTimeSpentInEvents { get; set; }
            public double InstructorTimeSpentInEventsPercent { get; set; }
        }

        public class InstructorTotalsBySectionAndMonth
        {
            public string SectionName { get; set; }
            public DateTime InstructorEngagedDate { get; set; }
            public double InstructorsEngagedInEvents { get; set; }
            public double InstructorsEngagedInEventsPercent { get; set; }
        }
    }
}
