﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace SFR.TOR.ViewModels
{
    public class ResourcesEquipmentModel: ActivityModel
    {
        public List<DayEquipmentModel> DayEquipmentData { get; set; }

        public List<SelectListItem> EquipmentTags { get; set; }

        public int ActivityPartID { get; set; }

        public double MinRequired { get; set; }

        public ResourcesEquipmentModel()
        {
            
        }

    }
}