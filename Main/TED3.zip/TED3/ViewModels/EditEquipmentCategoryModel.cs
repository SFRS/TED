﻿
using System.ComponentModel.DataAnnotations;
using System;
using System.ComponentModel;
namespace SFR.TOR.ViewModels
{
    public class EditEquipmentCategoryModel
    {
        public int ID { get; set; }

        [DisplayName("minimum number of equipment")]
        [Required(ErrorMessage = " * Number of required equipment must be at least 1")]
        [Range(1, Int32.MaxValue, ErrorMessage = " * Number of required equipment must be at least 1")]
        public int MinRequired { get; set; }
    }
}
