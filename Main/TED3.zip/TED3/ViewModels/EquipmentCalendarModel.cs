﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using Trirand.Web.Mvc;
using PagerSettings = Trirand.Web.Mvc.PagerSettings;

namespace SFR.TOR.ViewModels
{
    public class EquipmentCalendarModel: CalendarModel
    {
        public JQGrid CalendarGrid { get; set; }
        

        public EquipmentCalendarModel(string dataURL, List<DateTime> dates, bool showWeekend)
        {
            ViewTitle = "Equipment";
            Dates = dates;
            ShowWeekend = showWeekend;
            StartDate = dates[0];
            Datepicker = dates[0].ToString("dd/MM/yyyy");
            CalendarGrid = new JQGrid
            {
                Columns = new List<JQGridColumn>()
                {
                    new JQGridColumn
                    {
                        DataField = "Name",
                        HeaderText = "Equipment",
                        Sortable = true,
                    },
                new JQGridColumn
                    {
                        DataField = "GroupName",
                        HeaderText = "Equipment Group",
                        Sortable = true,
                    },
                    CreateDayPartColumn("Day1AM", "AM", "formatCourseData", dates[0]),
                    CreateDayPartColumn("Day1PM", "PM", "formatCourseData", dates[0]),
                    CreateDayPartColumn("Day2AM", "AM", "formatCourseData", dates[1]),
                    CreateDayPartColumn("Day2PM", "PM", "formatCourseData", dates[1]),
                    CreateDayPartColumn("Day3AM", "AM", "formatCourseData", dates[2]),
                    CreateDayPartColumn("Day3PM", "PM", "formatCourseData", dates[2]),
                    CreateDayPartColumn("Day4AM", "AM", "formatCourseData", dates[3]),
                    CreateDayPartColumn("Day4PM", "PM", "formatCourseData", dates[3]),
                    CreateDayPartColumn("Day5AM", "AM", "formatCourseData", dates[4]),
                    CreateDayPartColumn("Day5PM", "PM", "formatCourseData", dates[4]),
                    CreateDayPartColumn("Day6AM", "AM", "formatCourseData", dates[5]),
                    CreateDayPartColumn("Day6PM", "PM", "formatCourseData", dates[5]),
                    CreateDayPartColumn("Day7AM", "AM", "formatCourseData", dates[6]),
                    CreateDayPartColumn("Day7PM", "PM", "formatCourseData", dates[6]),
                },
                Width = Unit.Percentage(800),
                Height = Unit.Pixel(500),
                PagerSettings = new PagerSettings
                {
                    ScrollBarPaging = true,
                    PageSize = 30
                },
                DataUrl = dataURL,
                ID = "EquipmentGrid"
            };

            CalendarGrid.HeaderGroups.Add(
                new JQGridHeaderGroup
                {
                    StartColumnName = "Day1AM",
                    NumberOfColumns = 2,
                    TitleText = dates[0].ToString("ddd d/M/yy")
                });
            CalendarGrid.HeaderGroups.Add(
                new JQGridHeaderGroup
                {
                    StartColumnName = "Day2AM",
                    NumberOfColumns = 2,
                    TitleText = dates[1].ToString("ddd d/M/yy")
                });
            CalendarGrid.HeaderGroups.Add(
                new JQGridHeaderGroup
                {
                    StartColumnName = "Day3AM",
                    NumberOfColumns = 2,
                    TitleText = dates[2].ToString("ddd d/M/yy")
                });
            CalendarGrid.HeaderGroups.Add(
                new JQGridHeaderGroup
                {
                    StartColumnName = "Day4AM",
                    NumberOfColumns = 2,
                    TitleText = dates[3].ToString("ddd d/M/yy")
                });
            CalendarGrid.HeaderGroups.Add(
                new JQGridHeaderGroup
                {
                    StartColumnName = "Day5AM",
                    NumberOfColumns = 2,
                    TitleText = dates[4].ToString("ddd d/M/yy")
                });

            CalendarGrid.HeaderGroups.Add(
                new JQGridHeaderGroup
                {
                    StartColumnName = "Day6AM",
                    NumberOfColumns = 2,
                    TitleText = dates[5].ToString("ddd d/M/yy")
                });
            CalendarGrid.HeaderGroups.Add(
                new JQGridHeaderGroup
                {
                    StartColumnName = "Day7AM",
                    NumberOfColumns = 2,
                    TitleText = dates[6].ToString("ddd d/M/yy")
                });
        }

        /// <summary>
        /// Creates a JQ Grid column for displaying day parts cells
        /// </summary>
        /// <param name="dataField"></param>
        /// <param name="headerText"></param>
        /// <param name="formatter"></param>
        /// <param name="date"></param>
        /// <returns></returns>
        private JQGridColumn CreateDayPartColumn(string dataField, string headerText, string formatter, DateTime theDate)
        {
            //DateTime theDate;
            //DateTime.TryParse(date, out theDate);

            bool visible =
                //is a weekend day and we must show weekend days
                (theDate.DayOfWeek == DayOfWeek.Saturday || theDate.DayOfWeek == DayOfWeek.Sunday) && ShowWeekend
                || //otherwise, if it's a weekday always display
                ((theDate.DayOfWeek == DayOfWeek.Monday || theDate.DayOfWeek == DayOfWeek.Tuesday ||
                  theDate.DayOfWeek == DayOfWeek.Wednesday || theDate.DayOfWeek == DayOfWeek.Thursday ||
                  theDate.DayOfWeek == DayOfWeek.Friday));

            return new JQGridColumn()
            {
                DataField = dataField,
                HeaderText = headerText,
                Width = ShowWeekend ? 60 : 85,
                CssClass = "calendarPaddingOverride",
                Sortable = false,
                Visible = visible,
                Formatter = new CustomFormatter
                {
                    FormatFunction = formatter,
                }
            };
        }
    }
}