using System;

namespace SFR.TOR.ViewModels
{
    public class EventStatusHistoryModel
    {
        public string UserName { get; set; }
        public string OldStatus { get; set; }
        public string NewStatus { get; set; }
        public DateTime OccurredOn { get; set; }
    }
}