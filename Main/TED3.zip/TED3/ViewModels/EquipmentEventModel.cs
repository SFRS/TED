namespace SFR.TOR.ViewModels
{
    public class EquipmentEventModel
    {
        public int ID { get; set; }
        public bool Booked { get; set; }
        public string EquipmentTag { get; set; }
        public int EquipmentTagID { get; set; }
    }
}