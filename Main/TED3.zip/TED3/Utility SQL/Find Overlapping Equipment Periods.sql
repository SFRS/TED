use tor
select v.ID as EquipmentID, v.Name as EquipmentName, r1.Reason as Reason1, p1.StartDate as StartDate1, p1.EndDate as EndDate1, r2.Reason as Reason2, p2.StartDate as StartDate2, p2.EndDate as EndDate2, ept1.Title as DayType1, ept2.Title as DayType2
from EquipmentUnavailablePeriods p1
inner join EquipmentUnavailablePeriods p2 on p1.EquipmentID = p2.EquipmentID and p1.ID < p2.ID
	and (p1.StartDate between p2.StartDate and isnull(p2.EndDate, '31 Dec 2999') or 
		 p1.EndDate   between p2.StartDate and isnull(p2.EndDate, '31 Dec 2999') or 
		 p2.StartDate between p1.StartDate and isnull(p1.EndDate, '31 Dec 2999'))
	and not (p1.StartDate = isnull(p1.EndDate, '31 Dec 2999') and 
			 p2.StartDate = isnull(p2.EndDate, '31 Dec 2999') and 
			 p1.StartDate = p2.StartDate and 
			 p1.DayTypeID <> p2.DayTypeID and
			 p1.DayTypeID < 3 and 
			 p2.DayTypeID < 3)
inner join EquipmentUnavailableReasons r1 on p1.EquipmentUnavailableReasonID = r1.ID
inner join EquipmentUnavailableReasons r2 on p2.EquipmentUnavailableReasonID = r2.ID
inner join Equipment v on p1.EquipmentID = v.id
inner join EventPartType ept1 on p1.DayTypeID = ept1.ID
inner join EventPartType ept2 on p2.DayTypeID = ept2.ID
order by v.Name, p1.StartDate, p1.EndDate, p2.StartDate, p2.EndDate
