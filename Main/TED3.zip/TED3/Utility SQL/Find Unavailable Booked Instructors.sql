use tor

select i.FirstName, i.LastName, a.Code, e.EventNumber, e.FinanciaYear, ep.Date, ept2.Title as EventPartType, ep.Name, ur.Reason, iup.StartDate, iup.EndDate, ept.Title as UnavailabilityType
from instructoreventpart iep
inner join Instructor i on iep.InstructorID = i.id
inner join EventPart ep on iep.DayPartID = ep.ID
inner join Event e on ep.EventID = e.ID
inner join Activity a on a.ID = e.ActivityID
inner join InstructorUnavailablePeriods iup on iep.InstructorID = iup.InstructorID
inner join UnavailableReasons ur on iup.UnavailableReasonID = ur.ID
inner join EventPartType ept on ept.ID = iup.DayTypeID
inner join EventPartType ept2 on ept2.ID = ep.DayType
where ep.Date between iup.StartDate and ISNULL(iup.EndDate, '31 Dec 2999')
and (ept.ID = 3 or ept2.ID = 3 or ept.ID = ept2.ID)
order by ep.date

