﻿param($installPath, $toolsPath, $package, $project)
Remove-Item "$toolsPath\log.txt" -Force -ErrorAction SilentlyContinue

