﻿using System.Collections.Specialized;
using System.Security.Principal;
using Rhino.Mocks;
using SFR.TOR.Data.Services.Interfaces;
using SFR.TOR.UnitTests.MVCFakes;
using System.Web;
using System.Web.Mvc;
using System.Web.SessionState;

namespace SFR.TOR.UnitTests.Controllers
{
    public abstract class BaseControllerTest
    {
        public MockRepository Mocks;
        public ITORUnitOfWork StubUnitOfWork;

        protected BaseControllerTest()
        {
            Mocks = new MockRepository();
            StubUnitOfWork = Mocks.StrictMock<ITORUnitOfWork>();
        }

        public ControllerContext SetupControllerContext(Controller controller)
        {
            var sessionItems = new SessionStateItemCollection();

            return new FakeControllerContext(controller, "", null, new NameValueCollection() { }, new NameValueCollection() { }, null, null);
        }
    }

    public class MockHttpContext : HttpContextBase
    {
        private readonly IPrincipal _user = new GenericPrincipal(new GenericIdentity("someUser"), null /* roles */);

        public override IPrincipal User
        {
            get
            {
                return _user;
            }
            set
            {
                base.User = value;
            }
        }
    }
}
