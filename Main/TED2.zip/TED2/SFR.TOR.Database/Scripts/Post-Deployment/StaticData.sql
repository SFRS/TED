﻿DECLARE @DBVersionCount int

SET @DBVersionCount = (SELECT COUNT(*) FROM [dbo].[DatabaseVersion])

---- Only insert static data if no DB version record exists
IF @DBVersionCount = 0
BEGIN

	INSERT INTO [dbo].[DatabaseVersion] ([Version]) VALUES ('1.3')

	INSERT INTO [dbo].[TrainingCentre]([Name]) VALUES ('Uaill')

	INSERT INTO [dbo].[Section] ([ID],[Title]) VALUES (1, 'Default')

	INSERT INTO [dbo].[ActivityPartType] ([ID],[Title]) VALUES (1 ,'Half Day')
	INSERT INTO [dbo].[ActivityPartType] ([ID],[Title]) VALUES (2 ,'Full Day')

	INSERT INTO [dbo].[DayPartStatus] ([ID],[Title]) VALUES (1, 'Part Resourced')
	INSERT INTO [dbo].[DayPartStatus] ([ID],[Title]) VALUES (2, 'Fully Resourced')

	INSERT INTO [dbo].[EventStatus] ([ID],[Title]) VALUES (1,'Not Ready')
	INSERT INTO [dbo].[EventStatus] ([ID],[Title]) VALUES (2,'Ready')
	INSERT INTO [dbo].[EventStatus] ([ID],[Title]) VALUES (3,'Scheduled')
	INSERT INTO [dbo].[EventStatus] ([ID],[Title]) VALUES (4,'Blocked')
	INSERT INTO [dbo].[EventStatus] ([ID],[Title]) VALUES (5,'Complete')
	INSERT INTO [dbo].[EventStatus] ([ID],[Title]) VALUES (6,'Cancelled')

	INSERT INTO [dbo].[ResourceStatus]([ID],[Title],[Code]) VALUES (1, 'Not Resourced', 'N')
	INSERT INTO [dbo].[ResourceStatus]([ID],[Title],[Code]) VALUES (2, 'Part Resourced', 'P')
	INSERT INTO [dbo].[ResourceStatus]([ID],[Title],[Code]) VALUES (3, 'Fully Resourced', 'F')

	INSERT INTO [dbo].[ActivityStatus] ([ID],[Title]) VALUES (1, 'Incomplete')
	INSERT INTO [dbo].[ActivityStatus] ([ID],[Title]) VALUES (2, 'Complete')
	INSERT INTO [dbo].[ActivityStatus] ([ID],[Title]) VALUES (3, 'Obsolete')

	INSERT INTO [dbo].[EventPriority] ([ID], [Title]) VALUES (1, 'High')
	INSERT INTO [dbo].[EventPriority] ([ID], [Title]) VALUES (2, 'Medium')
	INSERT INTO [dbo].[EventPriority] ([ID], [Title]) VALUES (3, 'Low')

	INSERT INTO [dbo].[CancelEventReasons] ([ID],[Reason])
	VALUES (1, 'Administrative error')
	INSERT INTO [dbo].[CancelEventReasons] ([ID],[Reason])
	VALUES (2, 'Adverse weather conditions (not to be rescheduled)')
	INSERT INTO [dbo].[CancelEventReasons] ([ID],[Reason])
	VALUES (3, 'Adverse weather conditions (to be rescheduled)')
	INSERT INTO [dbo].[CancelEventReasons] ([ID],[Reason])
	VALUES (4, 'Directorate request (to be rescheduled)')
	INSERT INTO [dbo].[CancelEventReasons] ([ID],[Reason])
	VALUES (5, 'Directorate request (not to be rescheduled)')
	INSERT INTO [dbo].[CancelEventReasons] ([ID],[Reason])
	VALUES (6, 'Equipment Issues (not to be rescheduled)')
	INSERT INTO [dbo].[CancelEventReasons] ([ID],[Reason])
	VALUES (7, 'Equipment Issues (to be rescheduled)')
	INSERT INTO [dbo].[CancelEventReasons] ([ID],[Reason])
	VALUES (8, 'Instructor/Trainer availability(not to be rescheduled)')
	INSERT INTO [dbo].[CancelEventReasons] ([ID],[Reason])
	VALUES (9, 'Instructor/Trainer availability(to be rescheduled)')
	INSERT INTO [dbo].[CancelEventReasons] ([ID],[Reason])
	VALUES (10, 'Insufficient numbers (not to be rescheduled)')
	INSERT INTO [dbo].[CancelEventReasons] ([ID],[Reason])
	VALUES (11, 'Insufficient numbers (to be rescheduled)')
	INSERT INTO [dbo].[CancelEventReasons] ([ID],[Reason])
	VALUES (12, 'Venue Issues (not to be rescheduled)')
	INSERT INTO [dbo].[CancelEventReasons] ([ID],[Reason])
	VALUES (13, 'Venue Issues (to be rescheduled)')
	INSERT INTO [dbo].[CancelEventReasons] ([ID],[Reason])
	VALUES (14, 'Not Applicable')
	INSERT INTO [dbo].[CancelEventReasons] ([ID], [Reason]) 
	VALUES (15, 'Candidate(s) failed to attend (To be rescheduled)')
	INSERT INTO [dbo].[CancelEventReasons] ([ID], [Reason]) 
	VALUES (16, 'Candidate(s) failed to attend (Not to be rescheduled)')

	INSERT INTO [dbo].[PostponeEventReasons] ([ID],[Reason])
	VALUES (1, 'Not enough candidates to attend')
	INSERT INTO [dbo].[PostponeEventReasons] ([ID],[Reason])
	VALUES (2, 'No longer needed this year')
	INSERT INTO [dbo].[PostponeEventReasons] ([ID],[Reason])
	VALUES (3, 'Some other reason')

	INSERT INTO [dbo].[EventPartType] ([ID] ,[Title], [Code]) VALUES(1, 'Morning', 'AM')
	INSERT INTO [dbo].[EventPartType] ([ID] ,[Title], [Code]) VALUES(2, 'Afternoon', 'PM')
	INSERT INTO [dbo].[EventPartType] ([ID] ,[Title], [Code]) VALUES(3, 'Full Day', 'FULL')

	SET IDENTITY_INSERT [InstructorUnavailableReasonGroups] ON
	INSERT INTO [dbo].[InstructorUnavailableReasonGroups] ([ID], [Title]) VALUES (1, 'Default')
	INSERT INTO [dbo].[InstructorUnavailableReasonGroups] ([ID], [Title]) VALUES (2, 'Non-Work Related')
	INSERT INTO [dbo].[InstructorUnavailableReasonGroups] ([ID], [Title]) VALUES (3, 'Other Training Related')
	INSERT INTO [dbo].[InstructorUnavailableReasonGroups] ([ID], [Title]) VALUES (4, 'Non-Training Related')
	INSERT INTO [dbo].[InstructorUnavailableReasonGroups] ([ID], [Title]) VALUES (5, 'Evening Training')
	SET IDENTITY_INSERT [InstructorUnavailableReasonGroups] OFF
	
	SET IDENTITY_INSERT [dbo].[EquipmentGroup] ON
	INSERT INTO [dbo].[EquipmentGroup] ([ID], [Title]) VALUES (1, 'Default')
	SET IDENTITY_INSERT [dbo].[EquipmentGroup] OFF
	
	SET IDENTITY_INSERT [dbo].[VenueGroup] ON
	INSERT INTO [dbo].[VenueGroup] ([ID], [Title]) VALUES (1, 'Default')
	SET IDENTITY_INSERT [dbo].[VenueGroup] OFF
	
	SET IDENTITY_INSERT [dbo].[Group] ON
	INSERT INTO [dbo].[Group] ([ID], [Name]) VALUES (1, 'Default')
	SET IDENTITY_INSERT [dbo].[Group] OFF
	
	INSERT INTO [dbo].[PinchpointType] ([TypeName]) VALUES ('Training Centre Events')
	INSERT INTO [dbo].[PinchpointType] ([TypeName]) VALUES ('Public Holiday')
	INSERT INTO [dbo].[PinchpointType] ([TypeName]) VALUES ('Staffing')

	INSERT INTO [dbo].[PinchpointReason] ([Reason], [TypeID]) VALUES ('Training Centre Open Day', 1)
	INSERT INTO [dbo].[PinchpointReason] ([Reason], [TypeID]) VALUES ('Public holiday', 2)
	INSERT INTO [dbo].[PinchpointReason] ([Reason], [TypeID]) VALUES ('Bonfire Night', 3)

	SET IDENTITY_INSERT [iTrentExportStatus] ON
	INSERT INTO [dbo].[iTrentExportStatus] ([ID], [Title]) VALUES (1, 'Pending')
	INSERT INTO [dbo].[iTrentExportStatus] ([ID], [Title]) VALUES (2, 'Uploaded')
	SET IDENTITY_INSERT [iTrentExportStatus] OFF

	SET IDENTITY_INSERT [iTrentExportType] ON
	INSERT INTO [dbo].[iTrentExportType] ([ID], [Title]) VALUES (1, 'Ready & Cancelled Events')
	INSERT INTO [dbo].[iTrentExportType] ([ID], [Title]) VALUES (2, 'Updates to Scheduled Events')
	SET IDENTITY_INSERT [iTrentExportType] OFF

END