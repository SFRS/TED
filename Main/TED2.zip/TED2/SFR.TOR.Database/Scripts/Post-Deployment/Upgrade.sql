DECLARE @CurrentVersion VARCHAR(10)

SET @CurrentVersion = (SELECT [Version] FROM DatabaseVersion)

IF @CurrentVersion = '1.0'
BEGIN
	-- Upgrade database to version 1.1
	
	UPDATE [dbo].[DatabaseVersion] SET [Version] = '1.1'
	
	SET IDENTITY_INSERT [dbo].[Group] ON
	INSERT INTO [dbo].[Group] ([ID], [Name]) VALUES (6, 'Support')
	INSERT INTO [dbo].[Group] ([ID], [Name]) VALUES (7, 'External')
	INSERT INTO [dbo].[Group] ([ID], [Name]) VALUES (8, 'Area Trainer')
	SET IDENTITY_INSERT [dbo].[Group] OFF

	INSERT INTO [dbo].[Section] ([ID], [Title]) VALUES (15, 'Special Rescue - Boat')
	INSERT INTO [dbo].[Section] ([ID], [Title]) VALUES (16, 'Control')
	INSERT INTO [dbo].[Section] ([ID], [Title]) VALUES (17, 'Commercial')
	INSERT INTO [dbo].[Section] ([ID], [Title]) VALUES (18, 'National')
	INSERT INTO [dbo].[Section] ([ID], [Title]) VALUES (19, 'Staff Office')	
	INSERT INTO [dbo].[Section] ([ID], [Title]) VALUES (20, 'Operational Assurance')

	UPDATE [dbo].[Section] SET [Title] = 'Special Rescue - Resilience' WHERE ID = 4	
	UPDATE [dbo].[Section] SET [Title] = 'L&SD' WHERE [ID] = 7
	UPDATE [dbo].[Section] SET [Title] = 'CSE' WHERE [ID] = 8
	UPDATE [dbo].[Section] SET [Title] = 'Special Event' WHERE [ID] = 9
	UPDATE [dbo].[Section] SET [Title] = 'Special Rescue - Water' WHERE [ID] = 10
	UPDATE [dbo].[Section] SET [Title] = 'Special Rescue - SWAH' WHERE [ID] = 11
	UPDATE [dbo].[Section] SET [Title] = 'Special Rescue - Transport' WHERE [ID] = 12
	UPDATE [dbo].[Section] SET [Title] = 'Special Rescue - Trauma' WHERE [ID] = 13

	UPDATE [dbo].[EquipmentUnavailableReasons] SET [Reason] = 'Safety Inspection' WHERE [Reason] = 'Safety Check'

	UPDATE [dbo].[EligibleInstructorsForActivity] SET [IsSpecialist] = 0 WHERE IsSpecialist IS NULL

	SET @CurrentVersion = '1.1'
END

IF @CurrentVersion = '1.1'
BEGIN
	-- Upgrade database to version 1.2
	
	UPDATE [dbo].[DatabaseVersion] SET [Version] = '1.2'
	
	-- Define the Instructor Unavailability Reason Groups that the application expects to be present.
	-- If these groups are deleted, some reports may not work as expected.
	SET IDENTITY_INSERT [InstructorUnavailableReasonGroups] ON
	INSERT INTO [dbo].[InstructorUnavailableReasonGroups] ([ID], [Title]) VALUES (1, 'Default')
	INSERT INTO [dbo].[InstructorUnavailableReasonGroups] ([ID], [Title]) VALUES (2, 'Non-Work Related')
	INSERT INTO [dbo].[InstructorUnavailableReasonGroups] ([ID], [Title]) VALUES (3, 'Other Training Related')
	INSERT INTO [dbo].[InstructorUnavailableReasonGroups] ([ID], [Title]) VALUES (4, 'Non-Training Related')
	INSERT INTO [dbo].[InstructorUnavailableReasonGroups] ([ID], [Title]) VALUES (5, 'Evening Training')
	SET IDENTITY_INSERT [InstructorUnavailableReasonGroups] OFF
	
	-- Define a default Equipment Group
	SET IDENTITY_INSERT [dbo].[EquipmentGroup] ON
	INSERT INTO [dbo].[EquipmentGroup] ([ID], [Title]) VALUES (1, 'Default')
	SET IDENTITY_INSERT [dbo].[EquipmentGroup] OFF
	
	-- Define a default Venue Group
	SET IDENTITY_INSERT [dbo].[VenueGroup] ON
	INSERT INTO [dbo].[VenueGroup] ([ID], [Title]) VALUES (1, 'Default')
	SET IDENTITY_INSERT [dbo].[VenueGroup] OFF
	
	-- Set existing Instructor Unavailability Reasons, Equipment and Venue records to their default groups.
	-- These foreign key values match the 'Default' records inserted above.
	UPDATE [dbo].[UnavailableReasons] SET [UnavailableReasonGroupID] = 1
	UPDATE [dbo].[Equipment] SET [EquipmentGroupID] = 1
	UPDATE [dbo].[Venue] SET [VenueGroupID] = 1
	
	-- Set codes for EventPartType records
	UPDATE [dbo].[EventPartType]
	SET [Code] = CASE [ID] WHEN 1 THEN 'AM' WHEN 2 THEN 'PM' ELSE 'FULL' END

	-- Convert all null values to 0 in ActivityPartInstructorLevel
	UPDATE [dbo].[ActivityPartInstructorLevel]
	SET [LeadsCount]		= ISNULL([LeadsCount],		0), 
		[AssessorCount]		= ISNULL([AssessorCount],	0), 
		[InstructorCount]	= ISNULL([InstructorCount], 0), 
		[ShadowCount]		= ISNULL([ShadowCount],		0), 
		[SpecialistCount]	= ISNULL([SpecialistCount], 0)

	UPDATE [dbo].[InstructorEventPart]
	SET [IsLead]		= ISNULL([IsLead],			0), 
		[IsAssessor]	= ISNULL([IsAssessor],		0), 
		[IsInstructor]	= ISNULL([IsInstructor],	0), 
		[IsShadow]		= ISNULL([IsShadow],		0), 
		[IsSpecialist]	= ISNULL([IsSpecialist],	0)

	UPDATE [dbo].[ResourceStatus]
	SET [Code] = CASE [ID] WHEN 1 THEN 'N' WHEN 2 THEN 'P' ELSE 'F' END

	UPDATE [dbo].[VenueEventPart] 
	SET [NeedsCatering] = 0
	WHERE [NeedsCatering] IS NULL

	INSERT INTO [dbo].[CancelEventReasons] ([ID], [Reason]) VALUES (15, 'Candidate(s) failed to attend (To be rescheduled)')
	INSERT INTO [dbo].[CancelEventReasons] ([ID], [Reason]) VALUES (16, 'Candidate(s) failed to attend (Not to be rescheduled)')

	SET @CurrentVersion = '1.2'
END


IF @CurrentVersion = '1.2'
BEGIN
	-- Upgrade database to version 1.3
	UPDATE [dbo].[DatabaseVersion] SET [Version] = '1.3'

	-- Mark events that are Not Ready, Ready, Blocked or Cancelled as being stale
	UPDATE [Event]
	SET [iTrentDataStale] = CASE WHEN [Status] IN (1, 2, 4, 6) THEN 1 ELSE 0 END
	WHERE [iTrentDataStale] IS NULL

	UPDATE [Event]
	SET [BlockAfterUpload] = 0

	-- Insert a seed history record for each instructor in the system
	INSERT INTO InstructorSectionHistory (InstructorID, SectionID, StartDate)
	SELECT ID as InstructorID, SectionID, '01 Apr 2012' AS StartDate
	FROM Instructor

	SET IDENTITY_INSERT [iTrentExportStatus] ON
	INSERT INTO [dbo].[iTrentExportStatus] ([ID], [Title]) VALUES (1, 'Pending')
	INSERT INTO [dbo].[iTrentExportStatus] ([ID], [Title]) VALUES (2, 'Uploaded')
	SET IDENTITY_INSERT [iTrentExportStatus] OFF

	SET IDENTITY_INSERT [iTrentExportType] ON
	INSERT INTO [dbo].[iTrentExportType] ([ID], [Title]) VALUES (1, 'Ready & Cancelled Events')
	INSERT INTO [dbo].[iTrentExportType] ([ID], [Title]) VALUES (2, 'Updates to Scheduled Events')
	SET IDENTITY_INSERT [iTrentExportType] OFF

	SET @CurrentVersion = '1.3'
END

IF @CurrentVersion = '1.3'
BEGIN
	-- Upgrade database to next version e.g. 1.4
	UPDATE [dbo].[DatabaseVersion] SET [Version] = '1.4'

	ALTER TABLE [EVENT]
		ALTER COLUMN [Notes] VARCHAR(5000);

	----- NEW 

	ALTER TABLE [EquipmentUnavailablePeriods]
		ALTER COLUMN [Comments] VARCHAR(500);

	ALTER TABLE [InstructorUnavailablePeriods]
		ALTER COLUMN [Comments] VARCHAR(500);

	ALTER TABLE [VenueUnavailablePeriods]
		ALTER COLUMN [Comments] VARCHAR(500);

	--- END NEW


	SET IDENTITY_INSERT [TrainingCentre] ON

	INSERT [TrainingCentre] ([ID], [Name])
		VALUES (999, 'National')

	SET IDENTITY_INSERT [TrainingCentre]  OFF

	ALTER TABLE [dbo].[Event]
		ADD [TrainingCentreID] INT CONSTRAINT [DF_Event_TrainingCentreID] DEFAULT ((1)) NOT NULL;

	ALTER TABLE [dbo].[Event] WITH NOCHECK
		ADD CONSTRAINT [FK_Event_TrainingCentre] FOREIGN KEY ([TrainingCentreID]) REFERENCES [dbo].[TrainingCentre] ([ID]);
	
	EXECUTE sp_refreshsqlmodule N'[dbo].[vwEquipmentCalendarBase]';
	
	EXEC ('ALTER VIEW dbo.vwEventCalendarBase
					AS
					SELECT     e.ID, CONVERT(VARCHAR, ep.Date, 03) + '';'' + CONVERT(CHAR(1), ep.DayType) AS Date, ep.Date AS baseDate, a.Title, a.SectionID, a.Code + '' '' + CONVERT(VARCHAR, 
										  e.EventNumber) + ''/'' + SUBSTRING(CONVERT(VARCHAR, e.FinanciaYear), 3, 2) AS Code, e.Status, e.TrainingCentreID, e.ID AS EventID, 
										  ep.Status AS ResourceStatus
					FROM         dbo.EventPart AS ep LEFT OUTER JOIN
										  dbo.Event AS e ON e.ID = ep.EventID LEFT OUTER JOIN
										  dbo.Activity AS a ON e.ActivityID = a.ID')
										  
			EXEC ('ALTER VIEW [dbo].[vwInstructorCalendarBase]
		AS
		SELECT
			i.ID,  
			CONVERT(VARCHAR, ep.[Date], 03)  + '';'' +CONVERT(CHAR(1), ep.DayType) as [Date],
			ep.[Date] as baseDate,
			a.Title,
			a.Code + '' '' + CONVERT(VARCHAR, EventNumber) + ''/'' + SUBSTRING(CONVERT(VARCHAR, e.FinanciaYear), 3, 2)  as [Code],
			e.[Status],
			i.TrainingCentreID,
			e.ID as EventID,
			ep.[Status] as ResourceStatus
		FROM 
			dbo.Instructor i
		LEFT OUTER JOIN
			dbo.InstructorEventPart iep ON iep.InstructorID = i.ID 
		LEFT OUTER JOIN
			dbo.EventPart ep ON ep.ID = iep.DayPartID
		LEFT OUTER JOIN
			dbo.Event e ON e.ID = ep.EventID
		LEFT OUTER JOIN
			dbo.Activity a ON e.ActivityID = a.ID
		WHERE e.[Status] IN (1,2,3,4,5) OR  e.[Status] IS NULL')
		
    EXECUTE sp_refreshsqlmodule N'[dbo].[vwInstructorCalendarBase]';
	EXECUTE sp_refreshsqlmodule N'[dbo].[vwVenueCalendarBase]';
	
	EXEC('ALTER PROCEDURE [dbo].[GetEventCalendarView] 
			@startDate	VARCHAR(10),
			@endDate	VARCHAR(10),
			@page		INT,
			@size		INT,
			@status		VARCHAR(400) = NULL,
			@section	VARCHAR(400) = NULL,
			@totalCount INT OUTPUT,
			@trainingCentreIDs VARCHAR(400) = NULL 

		AS
		BEGIN
			SET NOCOUNT ON
			DECLARE @sql NVARCHAR(MAX) = N'''' 
			DECLARE @sql2 NVARCHAR(MAX) = N''''
		 
			--build the dynamic pivot columns for each of 14 day parts for the week
			-- ;1 indicates AM, ;2 indicates PM
			SELECT TOP (7)  
			@sql += N'',['' + 
				CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
			  (ORDER BY [object_id])-1, @StartDate), 03) + '';1]'' + N'',['' + 
				CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
			  (ORDER BY [object_id])-1, @StartDate), 03) + '';2]''
			FROM sys.all_objects ORDER BY [object_id]; 
		 
		 SELECT TOP (7)  
			@sql2 += N'',['' + 
				CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
			  (ORDER BY [object_id])-1, @StartDate), 03) + '';1]'' + N'',['' + 
				CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
			  (ORDER BY [object_id])-1, @StartDate), 03) + '';2]''
			FROM sys.all_objects ORDER BY [object_id]; 

		DECLARE @filter varchar(50)
		SET  @filter = NULL
		IF(@section IS NULL AND @status IS NULL)
			SET  @filter = ''''
		 
		-- query to count the total rows that match the query, before paging 
		SELECT @sql = N''

			SELECT *, ROW_NUMBER() OVER(ORDER BY ID) Corr 
			FROM 
			( 
				SELECT ID, [Date], Title + '''';'''' + Convert(char(1), [Status]) + '''';'''' + Code + '''';'''' + Convert(varchar(Max), [EventID]) + '''';'''' + Convert(varchar(Max), ResourceStatus) as stringvalue
				FROM vwEventCalendarBase
				WHERE 
					(ISNULL(SectionID, -1) IN (-1, '' + ISNULL(@section, ''SectionID'') + '')) AND
					(ISNULL(Status, -1) IN (-1, '' + ISNULL(@status, ''Status'') + '')) AND
					(ISNULL(TrainingCentreID, -1) IN (-1, '' + ISNULL(@trainingCentreIDs, ''TrainingCentreID'') + '')) AND
					baseDate >= '''''' + @startDate + '''''' AND baseDate  <= '''''' + @endDate + ''''''			
									
			) as d 
			PIVOT 
			( 
				min([stringvalue])     
				for [Date] in  
			  ('' + STUFF(@sql, 1, 1, '''') + '')  
			)  
			as p			
		'' 

		print @sql
		EXEC sp_executesql @sql
		SET @totalCount = @@rowcount
		 
		--baseDate >= '''''' + @startDate + '''''' AND baseDate  < '''''' + @endDate + '''''' AND	
		--SectionID = COALESCE('' + ISNULL(@section, ''null'') + '', sectionID) AND
		--Status = COALESCE('' + ISNULL(@status, ''null'') + '', status) 
		--ISNULL(@filter + '''', ''AND baseDate between ''''''+ @startDate + '''''' AND '''''' + @endDate + '''''''') + ''	 
		 
		SELECT @sql2 = N''
		WITH CTE AS 
		( 
			SELECT *, ROW_NUMBER() OVER(ORDER BY ID) Corr 
			FROM 
			( 
				SELECT ID, [Date], Title + '''';'''' + Convert(char(1), [Status]) + '''';'''' + Code + '''';'''' + Convert(varchar(Max), [EventID]) + '''';'''' + Convert(varchar(Max), ResourceStatus) as stringvalue
				FROM vwEventCalendarBase
				WHERE 
					(ISNULL(SectionID, -1) IN (-1, '' + ISNULL(@section, ''SectionID'') + '')) AND
					(ISNULL(Status, -1) IN (-1, '' + ISNULL(@status, ''Status'') + '')) AND
					(ISNULL(TrainingCentreID, -1) IN (-1, '' + ISNULL(@trainingCentreIDs, ''TrainingCentreID'') + '')) AND
					baseDate >= '''''' + @startDate + '''''' AND baseDate  <= '''''' + @endDate + ''''''
									
			) as d 
			PIVOT 
			( 
				min([stringvalue])     
				for [Date] in  
			  ('' + STUFF(@sql2, 1, 1, '''') + '')  
			)  
			as p		
		)
		SELECT * 
		FROM CTE 
		WHERE Corr BETWEEN (''+ CONVERT(varchar(3), @size) + '' * ('' + CONVERT(varchar(4), @page) + '' - 1))+1 AND (''+ CONVERT(varchar(3), @size) + ''*'' + CONVERT(varchar(4), @page) + '')
		'' 
		print @sql2
		EXEC sp_executesql @sql2
		END')
		
		EXEC('ALTER PROCEDURE [dbo].[GetInstructorCalendarView] 
			@startDate varchar(10),
			@endDate varchar(10),
			@page INT,
			@size INT,
			@sortBy VARCHAR(20),
			@sortDir VARCHAR(4),
			@status VARCHAR(400) = NULL,
			@section VARCHAR(400) = NULL,
			@totalCount INT OUTPUT,
			@trainingCentreIDs VARCHAR(400) = NULL,
			@group VARCHAR(400) = NULL,
			@instructor VARCHAR(400) = NULL
		AS
		BEGIN
			SET NOCOUNT ON
			DECLARE @sql NVARCHAR(MAX) = N'''' 
		   
			--build the dynamic pivot columns for each of 14 day parts for the week
			-- ;1 indicates AM, ;2 indicates PM
			SELECT TOP (7)  
			@sql += N'',['' + 
				CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
			  (ORDER BY [object_id])-1, @StartDate), 03) + '';1]'' + N'',['' + 
				CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
			  (ORDER BY [object_id])-1, @StartDate), 03) + '';2]''
			FROM sys.all_objects ORDER BY [object_id]; 

			-- Populate a local table with one record per date and day part.
			DECLARE @DatePartTable TABLE (
				BaseDate DATE,
				DateAndPart VARCHAR(10)
			)
			
			;with dates as (
				SELECT TOP (7) DATEADD(DAY, ROW_NUMBER() OVER (ORDER BY [object_id])-1, @StartDate) as BaseDate
				FROM sys.all_objects 
			)
			insert @DatePartTable (BaseDate, DateAndPart)
			select d1.BaseDate, CONVERT(VARCHAR, d1.BaseDate, 03)  + '';1'' as DateAndPart
			from dates d1
			union all
			select d1.BaseDate, CONVERT(VARCHAR, d1.BaseDate, 03)  + '';2'' as DateAndPart
			from dates d1
			
			-- Combine the @DatePartTable values into a single string. This lets us use the values in the dynamic SQL statement below.
			-- The string helps to define a table value constructor within a CROSS JOIN, to generate one row per instructor per date & day part.
			DECLARE @vals VARCHAR(8000) 
			SELECT @vals = COALESCE(@vals + '', '', '''') + ''('''''' + CONVERT(varchar, BaseDate, 112) + '''''','''''' + DateAndPart + '''''')''
			FROM @DatePartTable
		 
			 DECLARE @FullResults TABLE (
				ID int,
				SectionName varchar(50),
				GroupName varchar(20),
				GroupID int,
				SectionID int,
				Name varchar(200),
				Day1AM varchar(4000),
				Day1PM varchar(4000),
				Day2AM varchar(4000),
				Day2PM varchar(4000),
				Day3AM varchar(4000),
				Day3PM varchar(4000),
				Day4AM varchar(4000),
				Day4PM varchar(4000),
				Day5AM varchar(4000),
				Day5PM varchar(4000),
				Day6AM varchar(4000),
				Day6PM varchar(4000),
				Day7AM varchar(4000),
				Day7PM varchar(4000),
				Corr int
			)

		declare @sortExpr varchar(100)

		-- By default, sort the results by Section Name, Instructor Name, Group Name.
		set @sortExpr = @sortBy + '' '' + @sortDir + '', '' + 
			case @sortBy 
				when ''SectionName'' then ''Name asc, GroupName asc''
				when ''Name'' then ''SectionName asc, GroupName asc''
				when ''GroupName'' then ''SectionName asc, Name asc''
				else ''SectionName asc, Name asc, GroupName asc''
			end
			
		-- We cross join the instructors to the set of dates and day parts, then look for a section history record on each date for the instructors.
		-- If no such record is found, the instructor is inactive on that date, and we emit a string to that effect.
		-- Otherwise, they are active, so we emit a string with details of the event they are participating in, if any.
		SELECT @sql = N''
			SELECT *, ROW_NUMBER() OVER(ORDER BY '' + @sortExpr + '') Corr 
			FROM 
			( 
				SELECT i.ID, ISNULL(s.Title, ''''*INACTIVE'''') as SectionName, g.Name as GroupName, g.ID as GroupID, s.ID as SectionID, i.LastName + '''', '''' + i.FirstName as Name, dt.DateAndPart AS [Date], 
					CASE WHEN h.ID IS NULL THEN ''''UNAVAILABLE*INACTIVE'''' ELSE b.Title + '''';'''' + Convert(char(1), b.[Status]) + '''';'''' + b.Code + '''';'''' + Convert(varchar(Max), b.[EventID])  + '''';'''' + Convert(varchar(Max), b.ResourceStatus) END as stringvalue
				FROM Instructor i 
				LEFT JOIN Section s ON i.SectionID = s.ID
				LEFT JOIN [Group] g ON i.GroupID = g.ID
				CROSS JOIN (VALUES '' + @vals + '') as dt (BaseDate, DateAndPart)
				LEFT JOIN vwInstructorCalendarBase b ON b.ID = i.ID AND b.[Date] = dt.DateAndPart
				LEFT JOIN InstructorSectionHistory h ON h.InstructorID = i.ID AND dbo.PeriodsOverlap(dt.BaseDate, dt.BaseDate, h.StartDate, ISNULL(h.EndDate, ''''31 Dec 2999'''')) = 1
				WHERE 
					(ISNULL(i.SectionID, -1) IN ('' + ISNULL(@section, ''-1, i.SectionID'') + '')) AND
					(ISNULL(b.Status, -1) IN ('' + ISNULL(@status, ''-1, b.Status'') + '')) AND
					(ISNULL(i.GroupID, -1) IN ('' + ISNULL(@group, ''-1, i.GroupID'') + '')) AND
					(ISNULL(i.TrainingCentreID, -1) IN (-1, '' + ISNULL(@trainingCentreIDs, ''-1, i.TrainingCentreID'') + '')) AND
					(i.ID IN ('' + ISNULL(@instructor, ''i.ID'') + ''))'' +
			'') as d
			PIVOT 
			( 
				min([stringvalue])     
				for [Date] in  
			  ('' + STUFF(@sql, 1, 1, '''') + '')  
			)
			as p
			WHERE NOT EXISTS
			(
				SELECT * FROM InstructorUnavailablePeriods i
				WHERE i.StartDate <= '''''' + @startDate + '''''' AND i.endDate is null AND i.InstructorID = p.ID
			)
			AND EXISTS (
				SELECT * FROM InstructorSectionHistory h WHERE h.InstructorID = p.ID 
				AND dbo.PeriodsOverlap('''''' + @startDate + '''''', '''''' + @endDate + '''''', h.StartDate, ISNULL(h.EndDate, ''''31 Dec 2999'''')) = 1
			)
		'' 

		 INSERT @FullResults (ID, SectionName, GroupName, GroupID, SectionID, Name, Day1AM, Day1PM, Day2AM, Day2PM, Day3AM, Day3PM, Day4AM, Day4PM, Day5AM, Day5PM, Day6AM, Day6PM, Day7AM, Day7PM, Corr)
		 EXEC sp_executesql @sql
		 
		 SET @totalCount = @@rowcount
		  
		 SELECT *
		 FROM @FullResults
		 WHERE Corr BETWEEN (@size * (@page - 1))+1 AND (@size * @page)
			END')
  
   EXEC ('ALTER PROCEDURE [dbo].[GetVenueCalendarView] 
			@startDate	VARCHAR(10),
			@endDate	VARCHAR(10),
			@page		INT,
			@size		INT,
			@sortBy		VARCHAR(10),
			@sortDir	VARCHAR(4),
			@status		VARCHAR(400) = NULL,
			@section	VARCHAR(400) = NULL,
			@totalCount INT OUTPUT,
			@trainingCentreIDs VARCHAR(400) = NULL,
			@group VARCHAR(400) = NULL,
			@venue VARCHAR(400) = NULL
		AS
		BEGIN
			SET NOCOUNT ON
			DECLARE @sql NVARCHAR(MAX) = N'''' 
			DECLARE @sql2 NVARCHAR(MAX) = N''''

			--build the dynamic pivot columns for each of 14 day parts for the week
			-- ;1 indicates AM, ;2 indicates PM
			SELECT TOP (7)  
			@sql += N'',['' + 
				CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
			  (ORDER BY [object_id])-1, @StartDate), 03) + '';1]'' + N'',['' + 
				CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
			  (ORDER BY [object_id])-1, @StartDate), 03) + '';2]''
			FROM sys.all_objects ORDER BY [object_id]; 
		 
			SELECT TOP (7)  
			@sql2 += N'',['' + 
				CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
			  (ORDER BY [object_id])-1, @StartDate), 03) + '';1]'' + N'',['' + 
				CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
			  (ORDER BY [object_id])-1, @StartDate), 03) + '';2]''
			FROM sys.all_objects ORDER BY [object_id];
		 
		DECLARE @filter varchar(50)
		SET  @filter = NULL
		IF(@section IS NULL AND @status IS NULL)
			SET  @filter = ''''
		 
		-- query to count the total rows that match the query, before paging 
		SELECT @sql = N''
			SELECT *, ROW_NUMBER() OVER(ORDER BY '' + @sortBy + '' '' + @sortDir + '') Corr 
			FROM
			(
				SELECT ID, Name, GroupTitle, [Date], EventTitle + '''';'''' + Convert(char(1), [Status]) + '''';'''' + Code + '''';'''' + Convert(varchar(Max), [EventID])  + '''';'''' + Convert(varchar(Max), ResourceStatus) as stringvalue
				FROM vwVenueCalendarBase
				WHERE 
					(ISNULL(SectionID, -1) IN (-1, '' + ISNULL(@section, ''SectionID'') + '')) AND
					(ISNULL(Status, -1) IN (-1, '' + ISNULL(@status, ''Status'') + '')) AND
					(ISNULL(GroupID, -1) IN (-1, '' + ISNULL(@group, ''GroupID'') + '')) AND
					(ISNULL(TrainingCentreID, -1) IN (-1, '' + ISNULL(@trainingCentreIDs, ''TrainingCentreID'') + '')) AND
					(ID IN ('' + ISNULL(@venue, ''ID'') + '')) '' +
					ISNULL(@filter + '''', ''AND baseDate between ''''''+ @startDate + '''''' AND '''''' + @endDate + '''''''') + ''
			) as d 
			PIVOT 
			(
				min([stringvalue])
				for [Date] in  
			  ('' + STUFF(@sql, 1, 1, '''') + '')
			)
			as p
			WHERE NOT EXISTS
			(
				SELECT * FROM VenueUnavailablePeriods v
				WHERE v.StartDate <= '''''' + @startDate + '''''' AND v.endDate is null AND v.VenueID = p.ID
			)
		''
		EXEC sp_executesql @sql
		SET @totalCount = @@rowcount 
		 
		 
		SELECT @sql2 = N''
		WITH CTE AS 
		( 
			SELECT *, ROW_NUMBER() OVER(ORDER BY '' + @sortBy + '' '' + @sortDir + '') Corr 
			FROM 
			( 
				SELECT ID, Name,  GroupTitle, [Date], EventTitle + '''';'''' + Convert(char(1), [Status]) + '''';'''' + Code + '''';'''' + Convert(varchar(Max), [EventID])  + '''';'''' + Convert(varchar(Max), ResourceStatus) as stringvalue
				FROM vwVenueCalendarBase
				WHERE 
					(ISNULL(SectionID, -1) IN (-1, '' + ISNULL(@section, ''SectionID'') + '')) AND
					(ISNULL(Status, -1) IN (-1, '' + ISNULL(@status, ''Status'') + '')) AND
					(ISNULL(GroupID, -1) IN (-1, '' + ISNULL(@group, ''GroupID'') + '')) AND
					(ISNULL(TrainingCentreID, -1) IN (-1, '' + ISNULL(@trainingCentreIDs, ''TrainingCentreID'') + '')) AND
					(ID IN ('' + ISNULL(@venue, ''ID'') + '')) '' +		 			 			
					ISNULL(@filter + '''', ''AND baseDate between ''''''+ @startDate + '''''' AND '''''' + @endDate + '''''''') + ''		
			) as d 
			PIVOT 
			( 
				min([stringvalue])     
				for [Date] in  
			  ('' + STUFF(@sqL2, 1, 1, '''') + '')  
			)  
			as p
			WHERE NOT EXISTS
			(
				SELECT * FROM VenueUnavailablePeriods v
				WHERE v.StartDate <= '''''' + @startDate + '''''' AND v.endDate is null AND v.VenueID = p.ID
			)
		)
		SELECT * 
		FROM CTE 
		WHERE Corr BETWEEN (''+ CONVERT(varchar(3), @size) + '' * ('' + CONVERT(varchar(4), @page) + '' - 1))+1 AND (''+ CONVERT(varchar(3), @size) + ''*'' + CONVERT(varchar(4), @page) + '')
		'' 

		EXEC sp_executesql @sql2
		END')
		
		EXEC ('ALTER PROCEDURE [dbo].[GetEquipmentCalendarView] 
			@startDate	VARCHAR(10),
			@endDate	VARCHAR(10),
			@page		INT,
			@size		INT,
			@sortBy		VARCHAR(10),
			@sortDir	VARCHAR(4),
			@status		VARCHAR(400) = NULL,
			@section	VARCHAR(400) = NULL,
			@totalCount INT OUTPUT,
			@trainingCentreIDs VARCHAR(400) = NULL,
			@group		VARCHAR(400) = NULL,
			@equipment VARCHAR(400) = NULL
		AS
		BEGIN
			SET NOCOUNT ON
			DECLARE @sql NVARCHAR(MAX) = N'''' 
			DECLARE @sql2 NVARCHAR(MAX) = N''''

			--build the dynamic pivot columns for each of 14 day parts for the week
			-- ;1 indicates AM, ;2 indicates PM
			SELECT TOP (7)  
			@sql += N'',['' + 
				CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
			  (ORDER BY [object_id])-1, @StartDate), 03) + '';1]'' + N'',['' + 
				CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
			  (ORDER BY [object_id])-1, @StartDate), 03) + '';2]''
			FROM sys.all_objects ORDER BY [object_id]; 
		 
		 SELECT TOP (7)  
			@sql2 += N'',['' + 
				CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
			  (ORDER BY [object_id])-1, @StartDate), 03) + '';1]'' + N'',['' + 
				CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
			  (ORDER BY [object_id])-1, @StartDate), 03) + '';2]''
			FROM sys.all_objects ORDER BY [object_id]; 
		 
		DECLARE @filter varchar(50)
		SET  @filter = NULL
		IF(@section IS NULL AND @status IS NULL)
			SET  @filter = ''''
		 
		-- query to count the total rows that match the query, before paging 
		SELECT @sql = N''

			SELECT *, ROW_NUMBER() OVER(ORDER BY '' + @sortBy + '' '' + @sortDir + '') Corr 
			FROM 
			( 
				SELECT ID, Name, GroupTitle, [Date], EventTitle + '''';'''' + Convert(char(1), [Status]) + '''';'''' + Code + '''';'''' + Convert(varchar(Max), [EventID])  + '''';'''' + Convert(varchar(Max), ResourceStatus) as stringvalue
				FROM vwEquipmentCalendarBase	
				WHERE 
					(ISNULL(SectionID, -1) IN (-1, '' + ISNULL(@section, ''SectionID'') + '')) AND
					(ISNULL(Status, -1) IN (-1, '' + ISNULL(@status, ''Status'') + '')) AND
					(ISNULL(GroupID, -1) IN (-1, '' + ISNULL(@group, ''GroupID'') + '')) AND
					(ISNULL(TrainingCentreID, -1) IN (-1, '' + ISNULL(@trainingCentreIDs, ''TrainingCentreID'') + '')) AND
					(ID IN ('' + ISNULL(@equipment, ''ID'') + '')) '' +
					ISNULL(@filter + '''', ''AND baseDate between ''''''+ @startDate + '''''' AND '''''' + @endDate + '''''''') + ''			
									
			) as d 
			PIVOT 
			( 
				min([stringvalue])     
				for [Date] in  
			  ('' + STUFF(@sql, 1, 1, '''') + '')  
			)  
			as p	
			WHERE NOT EXISTS
			(
				SELECT * FROM EquipmentUnavailablePeriods e
				WHERE e.StartDate <= '''''' + @startDate + '''''' AND e.endDate is null AND e.EquipmentID = p.ID
			)		
		'' 

		EXEC sp_executesql @sql
		SET @totalCount = @@rowcount

		--query to get the specific page we want 
		SELECT @sql2 = N''
		WITH CTE AS 
		( 
			SELECT *, ROW_NUMBER() OVER(ORDER BY '' + @sortBy + '' '' + @sortDir + '') Corr 
			FROM 
			( 
				SELECT ID, Name, GroupTitle, [Date], EventTitle + '''';'''' + Convert(char(1), [Status]) + '''';'''' + Code + '''';'''' + Convert(varchar(Max), [EventID])  + '''';'''' + Convert(varchar(Max), ResourceStatus) as stringvalue
				FROM vwEquipmentCalendarBase		
				WHERE			
					(ISNULL(SectionID, -1) IN (-1, '' + ISNULL(@section, ''SectionID'') + '')) AND
					(ISNULL(Status, -1) IN (-1, '' + ISNULL(@status, ''Status'') + '')) AND
					(ISNULL(GroupID, -1) IN (-1, '' + ISNULL(@group, ''GroupID'') + '')) AND
					(ISNULL(TrainingCentreID, -1) IN (-1, '' + ISNULL(@trainingCentreIDs, ''TrainingCentreID'') + '')) AND
					(ID IN ('' + ISNULL(@equipment, ''ID'') + '')) '' +
					ISNULL(@filter + '''', ''AND baseDate between ''''''+ @startDate + '''''' AND '''''' + @endDate + '''''''') + ''			
			) as d 
			PIVOT 
			( 
				min([stringvalue])     
				for [Date] in  
			  ('' + STUFF(@sql2, 1, 1, '''') + '')  
			)  
			as p
			WHERE NOT EXISTS
			(
				SELECT * FROM EquipmentUnavailablePeriods e
				WHERE e.StartDate <= '''''' + @startDate + '''''' AND e.endDate is null AND e.EquipmentID = p.ID
			)	
		)
		SELECT * 
		FROM CTE 
		WHERE Corr BETWEEN (''+ CONVERT(varchar(3), @size) + '' * ('' + CONVERT(varchar(4), @page) + '' - 1))+1 AND (''+ CONVERT(varchar(3), @size) + ''*'' + CONVERT(varchar(4), @page) + '')
		'' 

		EXEC sp_executesql @sql2
		END')
		
	/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
	SET QUOTED_IDENTIFIER ON
	SET ARITHABORT ON
	SET NUMERIC_ROUNDABORT OFF
	SET CONCAT_NULL_YIELDS_NULL ON
	SET ANSI_NULLS ON
	SET ANSI_PADDING ON
	SET ANSI_WARNINGS ON

	CREATE TABLE dbo.Tmp_Section
		(
		ID int NOT NULL IDENTITY (1, 1),
		Title nvarchar(50) NOT NULL
		)  ON [PRIMARY]
	ALTER TABLE dbo.Tmp_Section SET (LOCK_ESCALATION = TABLE)
	SET IDENTITY_INSERT dbo.Tmp_Section ON
	IF EXISTS(SELECT * FROM dbo.Section)
		 EXEC('INSERT INTO dbo.Tmp_Section (ID, Title)
			SELECT ID, Title FROM dbo.Section WITH (HOLDLOCK TABLOCKX)')
	SET IDENTITY_INSERT dbo.Tmp_Section OFF
	ALTER TABLE dbo.Activity
		DROP CONSTRAINT FK_ActivityTemplate_Section
	ALTER TABLE dbo.Instructor
		DROP CONSTRAINT FK_Instructor_Section
	ALTER TABLE dbo.InstructorSectionHistory
		DROP CONSTRAINT FK_InstructorSectionHistory_Section
	DROP TABLE dbo.Section
	EXECUTE sp_rename N'dbo.Tmp_Section', N'Section', 'OBJECT' 
	ALTER TABLE dbo.Section ADD CONSTRAINT
		PK_Section PRIMARY KEY CLUSTERED 
		(
		ID
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	select Has_Perms_By_Name(N'dbo.Section', 'Object', 'ALTER') as ALT_Per, Has_Perms_By_Name(N'dbo.Section', 'Object', 'VIEW DEFINITION') as View_def_Per, Has_Perms_By_Name(N'dbo.Section', 'Object', 'CONTROL') as Contr_Per 
	ALTER TABLE dbo.InstructorSectionHistory WITH NOCHECK ADD CONSTRAINT
	FK_InstructorSectionHistory_Section FOREIGN KEY
	(
	SectionID
	) REFERENCES dbo.Section
	(
	ID
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
	ALTER TABLE dbo.InstructorSectionHistory
		NOCHECK CONSTRAINT FK_InstructorSectionHistory_Section
	ALTER TABLE dbo.InstructorSectionHistory SET (LOCK_ESCALATION = TABLE)
	select Has_Perms_By_Name(N'dbo.InstructorSectionHistory', 'Object', 'ALTER') as ALT_Per, Has_Perms_By_Name(N'dbo.InstructorSectionHistory', 'Object', 'VIEW DEFINITION') as View_def_Per, Has_Perms_By_Name(N'dbo.InstructorSectionHistory', 'Object', 'CONTROL') as Contr_Per
	ALTER TABLE dbo.Instructor WITH NOCHECK ADD CONSTRAINT
		FK_Instructor_Section FOREIGN KEY
		(
		SectionID
		) REFERENCES dbo.Section
		(
		ID
		) ON UPDATE  NO ACTION 
		 ON DELETE  NO ACTION 
		
	ALTER TABLE dbo.Instructor
		NOCHECK CONSTRAINT FK_Instructor_Section
	ALTER TABLE dbo.Instructor SET (LOCK_ESCALATION = TABLE)
	select Has_Perms_By_Name(N'dbo.Instructor', 'Object', 'ALTER') as ALT_Per, Has_Perms_By_Name(N'dbo.Instructor', 'Object', 'VIEW DEFINITION') as View_def_Per, Has_Perms_By_Name(N'dbo.Instructor', 'Object', 'CONTROL') as Contr_Per 
	ALTER TABLE dbo.Activity WITH NOCHECK ADD CONSTRAINT
		FK_ActivityTemplate_Section FOREIGN KEY
		(
		SectionID
		) REFERENCES dbo.Section
		(
		ID
		) ON UPDATE  NO ACTION 
		 ON DELETE  NO ACTION 
	ALTER TABLE dbo.Activity
		NOCHECK CONSTRAINT FK_ActivityTemplate_Section
	ALTER TABLE dbo.Activity SET (LOCK_ESCALATION = TABLE)
	select Has_Perms_By_Name(N'dbo.Activity', 'Object', 'ALTER') as ALT_Per, Has_Perms_By_Name(N'dbo.Activity', 'Object', 'VIEW DEFINITION') as View_def_Per, Has_Perms_By_Name(N'dbo.Activity', 'Object', 'CONTROL') as Contr_Per 
	
		
	SET @CurrentVersion = '1.4'
END

/* Code that should run during all upgrades regardless of version should be placed below this point. */

/* Make the foreign key columns non-nullable. This will work for a database upgrade as we have assigned 
   a value to the columns for all rows in the tables. For a new database deployment the upgrade blocks above
   do not run, hence the code must be placed here, and the tables will be empty so the code will work.
   Ideally the columns would be defined as non-nullable in the <Name>.Table.sql scripts, but this would break
   upgrades as existing records would fail the FK constraints. An alternative is to use a Pre-Deployment script
   to move the records into a temporary table then move them back in an upgrade block above, but this has its
   own issues; the dataset may be large and time-consuming to move, and doing so may break other FK constraints
   that reference the table. */
ALTER TABLE [dbo].[UnavailableReasons] ALTER COLUMN [UnavailableReasonGroupID] INT NOT NULL
ALTER TABLE [dbo].[Equipment] ALTER COLUMN [EquipmentGroupID] INT NOT NULL
ALTER TABLE [dbo].[Venue] ALTER COLUMN [VenueGroupID] INT NOT NULL

/* Make the Code column non-nullable. This is not an FK column but was initially defined as nullable
   in preference to making it non-nullable with a temporary default. */
ALTER TABLE [dbo].[EventPartType] ALTER COLUMN [Code] VARCHAR(5) NOT NULL

ALTER TABLE [dbo].[ActivityPartInstructorLevel] ALTER COLUMN [LeadsCount] INT NOT NULL
ALTER TABLE [dbo].[ActivityPartInstructorLevel] ALTER COLUMN [AssessorCount] INT NOT NULL
ALTER TABLE [dbo].[ActivityPartInstructorLevel] ALTER COLUMN [InstructorCount] INT NOT NULL
ALTER TABLE [dbo].[ActivityPartInstructorLevel] ALTER COLUMN [ShadowCount] INT NOT NULL
ALTER TABLE [dbo].[ActivityPartInstructorLevel] ALTER COLUMN [SpecialistCount] INT NOT NULL

ALTER TABLE [dbo].[InstructorEventPart] ALTER COLUMN [IsLead] BIT NOT NULL
ALTER TABLE [dbo].[InstructorEventPart] ALTER COLUMN [IsAssessor] BIT NOT NULL
ALTER TABLE [dbo].[InstructorEventPart] ALTER COLUMN [IsInstructor] BIT NOT NULL
ALTER TABLE [dbo].[InstructorEventPart] ALTER COLUMN [IsShadow] BIT NOT NULL
ALTER TABLE [dbo].[InstructorEventPart] ALTER COLUMN [IsSpecialist] BIT NOT NULL

ALTER TABLE [dbo].[EligibleInstructorsForActivity] ALTER COLUMN [IsLead] BIT NOT NULL
ALTER TABLE [dbo].[EligibleInstructorsForActivity] ALTER COLUMN [IsAssessor] BIT NOT NULL
ALTER TABLE [dbo].[EligibleInstructorsForActivity] ALTER COLUMN [IsInstructor] BIT NOT NULL
ALTER TABLE [dbo].[EligibleInstructorsForActivity] ALTER COLUMN [IsShadow] BIT NOT NULL
ALTER TABLE [dbo].[EligibleInstructorsForActivity] ALTER COLUMN [IsSpecialist] BIT NOT NULL

ALTER TABLE [dbo].[ResourceStatus] ALTER COLUMN [Code] VARCHAR(5) NOT NULL

ALTER TABLE [dbo].[VenueEventPart] ALTER COLUMN [NeedsCatering] BIT NOT NULL

ALTER TABLE [dbo].[Event] ALTER COLUMN [iTrentDataStale] BIT NOT NULL
ALTER TABLE [dbo].[Event] ALTER COLUMN [BlockAfterUpload] BIT NOT NULL
