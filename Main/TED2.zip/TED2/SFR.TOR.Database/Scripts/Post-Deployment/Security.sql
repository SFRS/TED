/* The SFR.TOR.Database project previously held scripts to create users and role memberships within
 * the Schema Objects folder, and permissions were defined in the Database.sqlpermissions file. However
 * these do not allow security to vary across environments. In particular, we need to use a different
 * login for Production than for UAT or Debug. To resolve this, all commands to create users, role memberships
 * and permissions are listed here. The commands refer to the $(DatabaseLogin) parameter which is defined in
 * each publish.xml file as a SqlCmdVariable. Since each project configuration (Debug, UAT, Production, etc) can 
 * specify its own publish.xml file, we are able to set DatabaseLogin to the relevant value for each environment. 
 * Additionally, if the project's deployment settings are configured to drop objects from the database that
 * do not appear in the project (i.e. within Schema Objects), then the users, role memberships and permissions
 * will always be dropped during the initial part of the deployment and then recreated by this script.
 * Please be aware of this, as an error in this script could render an application unable to access the database. */

IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'$(DatabaseLogin)')
CREATE USER [$(DatabaseLogin)] FOR LOGIN [$(DatabaseLogin)]

EXECUTE sp_addrolemember @rolename = N'db_datawriter', @membername = N'$(DatabaseLogin)'
EXECUTE sp_addrolemember @rolename = N'db_datareader', @membername = N'$(DatabaseLogin)'

GRANT CONNECT TO [$(DatabaseLogin)]
GRANT EXECUTE TO [$(DatabaseLogin)]
