CREATE PROCEDURE [dbo].[ReportInstructorUtilisation]
	@TrainingCentreID int,
	@from date,
	@AvailabilityGroupID int,
	@timePeriod int,
	@countWeekdays bit,
	@countWeekends bit,
	@ReturnDataset int = null
AS
BEGIN
	SET NOCOUNT ON

	declare @DaytimeTrainingGroupID int
	declare @NonWorkGroupID int
	declare @OtherTrainingGroupID int
	declare @NonTrainingGroupID int
	declare @EveningTrainingGroupID int
	declare @FreeDaysGroupID int
	declare @TotalInstructorDaysGroupID int
	set @DaytimeTrainingGroupID = 0
	set @NonWorkGroupID = 2
	set @OtherTrainingGroupID = 3
	set @NonTrainingGroupID = 4
	set @EveningTrainingGroupID = 5
	set @FreeDaysGroupID = 998
	set @TotalInstructorDaysGroupID = 999

	declare @monthStart date
	declare @monthStartWeekday int
	declare @effectiveStart date
	declare @effectiveStop date
	declare @lastEffectiveTo date

	declare @effectiveDates table (
		EffectiveFrom date,
		EffectiveTo date
	)

	declare @daysOfWeek table (DayNum int)

	if @countWeekdays = 1
		insert @daysOfWeek values (2),(3),(4),(5),(6)

	if @countWeekends = 1
		insert @daysOfWeek values (1),(7)

	-- Define whether the InstructorUnavailableReasonGroups (and the virtual groups for Free Days and Daytime Training) 
	-- use absolute or relative percentages, and what order the columns appear in within the report.
	declare @groups table (
		GroupID int,
		UseRelative bit,
		Title varchar(50),
		ColumnOrder int
	)

	insert @groups (GroupID, UseRelative, ColumnOrder, Title) values 
		(@TotalInstructorDaysGroupID, 0, null, 'Total Instructor Days'),
		(@FreeDaysGroupID, 1, 1, 'Free Days'),
		(@DaytimeTrainingGroupID, 1, 2, 'Daytime Training'), 
		(@NonWorkGroupID, 0, 5, null), 
		(@OtherTrainingGroupID, 1, 3, null), 
		(@NonTrainingGroupID, 1, 4, null), 
		(@EveningTrainingGroupID, 0, 6, null)

	declare @data table (
		GroupID int not null,
		InstructorID int null,
		SectionID int null,
		EffectiveDate date null,
		DayCount float not null,
		AbsPercentage float null,
		RelPercentage float null
	)

	set @monthStart = dateadd(day, -datepart(d, @from) + 1, @from)
	set @monthStartWeekday = datepart(dw, @monthStart)
	
	set @effectiveStart = 
		case @timePeriod
			when 1 then 
				-- @timePeriod = 1 means results are broken down by week, starting on the first Monday or Saturday of the month
				dateadd(d, -@monthStartWeekday + 
							case when @countWeekdays = 0 
								then 7 -- find the next Saturday
								else case when @monthStartWeekday > 2 then 9 else 2 end -- find the next Monday
							end
						, @monthStart)
			else @monthStart -- we want results broken down by month
		end

	-- There can be no effective date on or beyond this date, though some days after this date may still be counted
	set @effectiveStop = dateadd(m, case @timePeriod when 1 then 1 else 12 end, @monthStart)
	
	;with DateTable as (
		SELECT 
			@effectiveStart as FromDate, 
			dateadd(d, -1, case when @timePeriod = 1 then dateadd(d, case when @countWeekdays = 0 then 2 else 7 end, @effectiveStart) else dateadd(m, 1, @effectiveStart) end) as ToDate
		UNION ALL
		SELECT 
			case when @timePeriod = 1 then dateadd(d, 7, FromDate) else dateadd(m, 1, FromDate) end as FromDate,
			dateadd(d, -1, case when @timePeriod = 1 then dateadd(d, case when @countWeekdays = 0 then 9 else 14 end, FromDate) else dateadd(m, 2, FromDate) end) as ToDate
		FROM DateTable 
		WHERE case when @timePeriod = 1 then dateadd(d, 7, FromDate) else dateadd(m, 1, FromDate) end < @effectiveStop
	)
	insert @effectiveDates (EffectiveFrom, EffectiveTo)
	select FromDate, ToDate
	from DateTable

	-- Set to the last day counted in the report
	set @lastEffectiveTo = (select max(EffectiveTo) from @effectiveDates)

	-- Total Instructor Days per section. We stop counting days when they leave the section or an open-ended unavailability period starts.
	;with DateTable as (
		select @effectiveStart AS [DATE]
		union all
		select dateadd(dd, 1, [DATE]) 
		from DateTable 
		where dateadd(dd, 1, [DATE]) <= @lastEffectiveTo
	)
	insert @data (GroupID, SectionID, InstructorID, EffectiveDate, DayCount)
	select 
		@TotalInstructorDaysGroupID as GroupID,
		s.ID as SectionID,
		i.ID as InstructorID,
		ed.EffectiveFrom as EffectiveDate,
		count(i.ID) as DayCount
	from DateTable d 
	inner join @effectiveDates ed on d.[DATE] between ed.EffectiveFrom and ed.EffectiveTo
	inner join @daysOfWeek dw on dw.DayNum = datepart(dw, d.[DATE])
	inner join InstructorSectionHistory h on d.[DATE] between h.StartDate and isnull(h.EndDate, '31 Dec 2999')
	inner join Section s on h.SectionID = s.ID
	inner join Instructor i on i.ID = h.InstructorID and i.TrainingCentreID = @TrainingCentreID
	left join InstructorUnavailablePeriods p on p.InstructorID = i.ID and d.[DATE] >= p.StartDate and p.EndDate is null
	where p.ID is null 
	group by s.ID, i.ID, ed.EffectiveFrom
	option (maxrecursion 0)

	-- Gather daytime training stats
	;with cte_instructordates as (
		select i.ID as InstructorID, h.SectionID, ed.EffectiveFrom as EffectiveDate
		from Instructor i
		cross join @effectiveDates ed
		inner join InstructorSectionHistory h on h.InstructorID = i.ID 
			and dbo.PeriodsOverlap(ed.EffectiveFrom, ed.EffectiveTo, h.StartDate, h.EndDate) = 1
		left join InstructorUnavailablePeriods p on p.InstructorID = i.ID and ed.EffectiveFrom >= p.StartDate and p.EndDate is null	
		where p.ID is null and i.TrainingCentreID = @TrainingCentreID 
	),
	cte_instructoreventparts as (
		select 
			ed.EffectiveFrom as EffectiveDate, 
			iep.InstructorID, 
			h.SectionID,
			sum(case when dw.DayNum is null then 0 else case when ep.DayType = 3 then 1 else 0.5 end end) as DayCount
		from @effectiveDates ed
		inner join EventPart ep on ep.[Date] between ed.EffectiveFrom and ed.EffectiveTo
		inner join @daysOfWeek dw on dw.DayNum = datepart(dw, ep.[Date])
		inner join InstructorEventPart iep on ep.ID = iep.DayPartID
		inner join InstructorSectionHistory h on h.InstructorID = iep.InstructorID 
			and dbo.PeriodsOverlap(ep.[Date], ep.[Date], h.StartDate, h.EndDate) = 1
		group by ed.EffectiveFrom, iep.InstructorID, h.SectionID
	)
	insert @data (GroupID, InstructorID, SectionID, EffectiveDate, DayCount)
	select 
		@DaytimeTrainingGroupID as GroupID, 
		id.InstructorID, 
		id.SectionID,
		id.EffectiveDate, 
		isnull(iep.DayCount, 0) as DayCount
	from cte_instructordates id
	left join cte_instructoreventparts iep 
		on id.EffectiveDate = iep.EffectiveDate and id.InstructorID = iep.InstructorID and id.SectionID = iep.SectionID
	
	-- Gather free day stats
	;with DateTable as (
		SELECT @effectiveStart AS [DATE], e.ID as DayType
		from EventPartType e 
		where e.ID <> 3
		UNION ALL
		SELECT DATEADD(dd, 1, [DATE]), DayType as DayType 
		FROM DateTable 
		WHERE DATEADD(dd, 1, [DATE]) <= @lastEffectiveTo
	),
	Parts as (
		select ep.ID as EventPartID, ep.Date, ep.DayType, iep.ID as InstructorEventPartID, iep.InstructorID
		from EventPart ep
		inner join InstructorEventPart iep on iep.DayPartID = ep.ID
		where ep.Date between @effectiveStart and @lastEffectiveTo
	)
	insert @data (GroupID, SectionID, InstructorID, EffectiveDate, DayCount)
	select 
		@FreeDaysGroupID as GroupID,
		s.ID as SectionID,
		t.InstructorID,
		ed.EffectiveFrom as EffectiveDate,
		count(t.InstructorID)/2.0 as DayCount -- divide by 2 as DateTable outputs one record per half day
	from Section s 
	cross join DateTable d
	inner join @effectiveDates ed on d.DATE between ed.EffectiveFrom and ed.EffectiveTo
	inner join @daysOfWeek dw on dw.DayNum = datepart(dw, d.DATE)
	cross apply (
		-- for each section/date combination, fetch instructors who belong to the section on that date, and who have no event or unavailable period
		select i.ID as InstructorID
		from Instructor i 
		inner join InstructorSectionHistory h on i.ID = h.InstructorID and s.ID = h.SectionID and d.DATE between h.StartDate and isnull(h.EndDate, '31 Dec 2999')
		left join Parts pa on pa.InstructorID = i.ID and pa.Date = d.DATE and pa.DayType = d.DayType
		left join InstructorUnavailablePeriods p on p.InstructorID = i.ID 
			and d.DATE between p.StartDate and isnull(p.EndDate, '31 Dec 2999') and (p.DayTypeID = d.DayType or p.DayTypeID = 3)
		where i.TrainingCentreID = @TrainingCentreID and pa.InstructorEventPartID is null and p.ID is null
	) t
	group by s.ID, t.InstructorID, ed.EffectiveFrom
	OPTION (MAXRECURSION 0)

	-- Fetch unavailability periods (excluding open-ended ones)
	;with cte_instructordatesgroups as (
		select i.ID as InstructorID, h.SectionID, ed.EffectiveFrom as EffectiveDate, g.ID as GroupID
		from Instructor i
		cross join @effectiveDates ed
		cross join InstructorUnavailableReasonGroups g
		inner join InstructorSectionHistory h 
			on i.ID = h.InstructorID and dbo.PeriodsOverlap(ed.EffectiveFrom, ed.EffectiveTo, h.StartDate, h.EndDate) = 1
		where i.TrainingCentreID = @TrainingCentreID
	),
	cte_instructorperiods as (
		select ed.EffectiveFrom as EffectiveDate, p.InstructorID, r.UnavailableReasonGroupID as GroupID, h.SectionID,
			-- Count days that intersect all 3 periods. Works out how many days the instructor was unavailable for
			-- while a member of each section, within each date range (i.e. week or month) in the report.
			sum(dbo.DaysInPeriod2(p.StartDate, p.EndDate, ed.EffectiveFrom, ed.EffectiveTo, h.StartDate, h.EndDate, @countWeekdays, @countWeekends, p.DayTypeID)) as DayCount
		from @effectiveDates ed
		inner join InstructorUnavailablePeriods p 
			on p.EndDate is not null and dbo.PeriodsOverlap(ed.EffectiveFrom, ed.EffectiveTo, p.StartDate, p.EndDate) = 1
		inner join UnavailableReasons r on p.UnavailableReasonID = r.ID
		inner join InstructorSectionHistory h on p.InstructorID = h.InstructorID 
			and dbo.PeriodsOverlap(ed.EffectiveFrom, ed.EffectiveTo, h.StartDate, h.EndDate) = 1
			and dbo.PeriodsOverlap(p.StartDate, p.EndDate, h.StartDate, h.EndDate) = 1
		group by ed.EffectiveFrom, p.InstructorID, r.UnavailableReasonGroupID, h.SectionID
	)
	insert @data (GroupID, SectionID, InstructorID, EffectiveDate, DayCount)
	select 
		idg.GroupID,
		idg.SectionID,
		idg.InstructorID,
		idg.EffectiveDate,
		isnull(ip.DayCount, 0) as DayCount
	from cte_instructordatesgroups idg
	left join cte_instructorperiods ip 
		on idg.InstructorID = ip.InstructorID and idg.SectionID = ip.SectionID and idg.GroupID = ip.GroupID and idg.EffectiveDate = ip.EffectiveDate

	-- Calculate totals for instructors (insert with null EffectiveDate)
	insert @data (GroupID, SectionID, InstructorID, EffectiveDate, DayCount)
	select d.GroupID, d.SectionID, d.InstructorID, null as EffectiveDate, sum(d.DayCount) as DayCount
	from @data d
	group by d.GroupID, d.SectionID, d.InstructorID
	
	-- Calculate totals for sections (insert with null InstructorID)
	-- Use cross joins and outer apply to ensure that we always insert a 'zero' record for each combination 
	-- of section, group and date, even if there are no matching instructor records present.
	insert @data (GroupID, SectionID, InstructorID, EffectiveDate, DayCount)
	select g.GroupID, s.ID as SectionID, null as InstructorID, e.EffectiveFrom as EffectiveDate, isnull(t.DayCount, 0) as DayCount
	from @effectiveDates e
	cross join @groups g
	cross join Section s
	outer apply (
		select d.GroupID, d.SectionID, null as InstructorID, d.EffectiveDate, sum(d.DayCount) as DayCount
		from @data d
		where d.EffectiveDate = e.EffectiveFrom and d.GroupID = g.GroupID and d.SectionID = s.ID
		group by d.GroupID, d.SectionID, d.EffectiveDate
	) t

	-- Calculate grand totals for sections (insert with null InstructorID and EffectiveDate)
	insert @data (GroupID, SectionID, InstructorID, EffectiveDate, DayCount)
	select d.GroupID, d.SectionID, null as InstructorID, null as EffectiveDate, sum(d.DayCount) as DayCount
	from @data d
	where d.InstructorID is null and d.EffectiveDate is not null -- only sum the section totals just inserted
	group by d.GroupID, d.SectionID

	-- Calculate totals for training centre (insert with null SectionID and InstructorID)
	insert @data (GroupID, SectionID, InstructorID, EffectiveDate, DayCount)
	select d.GroupID, null as SectionID, null as InstructorID, d.EffectiveDate, sum(d.DayCount) as DayCount
	from @data d
	where d.InstructorID is null and d.EffectiveDate is not null -- only sum the section totals just inserted
	group by d.GroupID, d.EffectiveDate

	-- Calculate grand total for training centre (insert with null SectionID, InstructorID and EffectiveDate)
	insert @data (GroupID, SectionID, InstructorID, EffectiveDate, DayCount)
	select d.GroupID, null as SectionID, null as InstructorID, null as EffectiveDate, sum(d.DayCount) as DayCount
	from @data d
	where d.SectionID is null -- only sum the training centre totals just inserted
	group by d.GroupID

	-- Calculate absolute percentages
	update d1
	set d1.AbsPercentage = isnull(round(d1.DayCount / nullif(d2.DayCount, 0) * 100, 2), 0)
	from @data d1
	inner join @data d2 on 
		d2.GroupID = @TotalInstructorDaysGroupID and
		isnull(d1.SectionID, -1) = isnull(d2.SectionID, -1) and 
		isnull(d1.InstructorID, -1) = isnull(d2.InstructorID, -1) and 
		isnull(d1.EffectiveDate, '31 Dec 2999') = isnull(d2.EffectiveDate, '31 Dec 2999')
	
	-- Calculate relative percentages
	update d1
	set d1.RelPercentage = isnull(round(d1.DayCount / nullif(t2.DayCount, 0) * 100, 2), 0)
	from @data d1 
	cross apply (
		select sum(d2.DayCount) as DayCount
		from @data d2
		inner join @groups g on d2.GroupID = g.GroupID and g.UseRelative = 1
		where isnull(d1.SectionID, -1) = isnull(d2.SectionID, -1) and 
			  isnull(d1.InstructorID, -1) = isnull(d2.InstructorID, -1) and 
			  isnull(d1.EffectiveDate, '31 Dec 2999') = isnull(d2.EffectiveDate, '31 Dec 2999')
	) t2
	inner join @groups g on d1.GroupID = g.GroupID and g.UseRelative = 1

	-- DataSet1
	if isnull(@ReturnDataset, 1) = 1
		select 
			d.EffectiveDate as InstructorEngagedDate,
			i.FirstName as InstructorFirstName,
			i.LastName as InstructorSecondName,
			case when i.ID is null then upper(s.Title) else s.Title end as SectionName,
			isnull(d.DayCount, 0) as InstructorTimeSpentInEvents,
			case when g.UseRelative = 1 then d.RelPercentage else d.AbsPercentage end as InstructorTimeSpentInEventsPercent,
			i.ID as InstructorID,
			tc.Name as TrainingCentreName,
			s.ID as SectionID,
			case when i.ID is null then 'true' else 'false' end as SectionSummaryRecord
		from @data d
		left join Instructor i on d.InstructorID = i.ID
		inner join Section s on d.SectionID = s.ID
		inner join @groups g on d.GroupID = g.GroupID
		inner join TrainingCentre tc on tc.ID = @TrainingCentreID
		where d.SectionID is not null and g.GroupID = @AvailabilityGroupID
		order by s.Title, d.EffectiveDate, i.LastName, i.FirstName

	-- DataSet2
	if isnull(@ReturnDataset, 2) = 2
		select 
			isnull(d.DayCount, 0) as InstructorTimeSpentInEvents,
			case when g.UseRelative = 1 then d.RelPercentage else d.AbsPercentage end as InstructorTimeSpentInEventsPercent,
			d.EffectiveDate as InstructorEngagedDate,
			tc.Name as TrainingCentreName
		from @data d
		inner join @groups g on d.GroupID = g.GroupID
		inner join TrainingCentre tc on tc.ID = @TrainingCentreID
		where d.SectionID is null and g.GroupID = @AvailabilityGroupID
		order by d.EffectiveDate
	
	SET NOCOUNT OFF
END
