﻿CREATE PROCEDURE [dbo].[ReportResourceUtilisation]
	@TrainingCentreID int,
	@from date,
	@to date,
	@AvailabilityGroupID int,
	@countWeekdays bit,
	@countWeekends bit,
	@ReturnDataset int = null
AS
BEGIN
	SET NOCOUNT ON

	declare @Page3From date
	declare @Page3To date
	set @Page3From = dateadd(d, -datepart(d, @from) + 1, @from)
	set @Page3To = dateadd(d, -1, dateadd(yy, 1, @Page3From))

	declare @daysOfWeek table (DayNum int)

	if @countWeekdays = 1
		insert @daysOfWeek values (2),(3),(4),(5),(6)

	if @countWeekends = 1
		insert @daysOfWeek values (1),(7)

	declare @DaytimeTrainingGroupID int
	declare @NonWorkGroupID int
	declare @OtherTrainingGroupID int
	declare @NonTrainingGroupID int
	declare @EveningTrainingGroupID int
	declare @FreeDaysGroupID int
	declare @TotalInstructorDaysGroupID int
	set @DaytimeTrainingGroupID = 0
	set @NonWorkGroupID = 2
	set @OtherTrainingGroupID = 3
	set @NonTrainingGroupID = 4
	set @EveningTrainingGroupID = 5
	set @FreeDaysGroupID = 998
	set @TotalInstructorDaysGroupID = 999

	-- Define whether the InstructorUnavailableReasonGroups (and the virtual groups for Free Days and Daytime Training) 
	-- use absolute or relative percentages, and what order the columns appear in within the report.
	declare @groups table (
		GroupID int,
		UseRelative bit,
		Title varchar(50),
		ColumnOrder int
	)

	insert @groups (GroupID, UseRelative, ColumnOrder, Title) values 
		(@TotalInstructorDaysGroupID, 0, null, 'Total Instructor Days'),
		(@FreeDaysGroupID, 1, 1, 'Free Days'),
		(@DaytimeTrainingGroupID, 1, 2, 'Daytime Training'), 
		(@NonWorkGroupID, 0, 5, null), 
		(@OtherTrainingGroupID, 1, 3, null), 
		(@NonTrainingGroupID, 1, 4, null), 
		(@EveningTrainingGroupID, 0, 6, null)

	update g
	set g.Title = rg.Title
	from @groups g
	inner join InstructorUnavailableReasonGroups rg on g.GroupID = rg.ID

	declare @UseRelative bit
	set @UseRelative = (select UseRelative from @groups where GroupID = @AvailabilityGroupID)

	declare @data table (
		SectionID int,
		GroupID int,
		DayCount float,
		AbsPercentage float null,
		RelPercentage float null
	)

	declare @unavailData table (
		SectionID int,
		ReasonID int,
		GroupID int,
		DayCount float,
		AbsPercentage float null,
		RelPercentage float null
	)

	declare @dataPage3 table (
		SectionID int,
		GroupID int,
		MonthStart date,
		MonthEnd date,
		DayCount float,
		AbsPercentage float null,
		RelPercentage float null
	)

	declare @results1 table (
		Section varchar(100) null,
		ReasonGroup varchar(200) null,
		ColumnOrder int null,
		DayCount float null,
		Percentage float null,
		IsAbsolute bit null
	)

	declare @resultsEvents table (
		Section varchar(100) null,
		NumEvents int null
	)

	declare @results2 table (
		Section varchar(100) null,
		Reason varchar(200) null,
		ReasonGroup varchar(200) null,
		DayCount float,
		Percentage float null,
		IsAbsolute bit null
	)

	declare @results3 table (
		Section varchar(100) null,
		SectionID int null,
		ReasonGroup varchar(200) null,
		StartDate date null,
		[Month] varchar(20) null,
		[Year] int null,
		DayCount float,
		Percentage float null,
		IsAbsolute bit null
	)
	
	-- Total Instructor Days per section. We stop counting days when they leave the section or an open-ended unavailability period starts.
	;with DateTable as (
		SELECT @from AS [DATE]
		UNION ALL
		SELECT DATEADD(dd, 1, [DATE]) 
		FROM DateTable 
		WHERE DATEADD(dd, 1, [DATE]) <= @to
	)
	insert @data (SectionID, GroupID, DayCount)
	select s.ID as SectionID,
		@TotalInstructorDaysGroupID as GroupID,
		count(i.ID) as DayCount
	from Section s
	cross join DateTable d 
	inner join @daysOfWeek dw on dw.DayNum = datepart(dw, d.[DATE])
	left join InstructorSectionHistory h on s.ID = h.SectionID and d.[DATE] between h.StartDate and isnull(h.EndDate, '31 Dec 2999')
	left join Instructor i on i.ID = h.InstructorID and i.TrainingCentreID = @TrainingCentreID
	left join InstructorUnavailablePeriods p on p.InstructorID = i.ID and d.[DATE] >= p.StartDate and p.EndDate is null
	where p.ID is null 
	group by s.ID
	OPTION (MAXRECURSION 0)

	-- Fetch Daytime Training
	insert @data (SectionID, GroupID, DayCount)
	select s.ID as SectionID, 
		@DaytimeTrainingGroupID as GroupID,
		sum(case when dw.DayNum is null or h.ID is null then 0 else case when ep.DayType = 3 then 1 else 0.5 end end) as DayCount
	from Section s
	left join EventPart ep on ep.Date between @from and @to
	left join @daysOfWeek dw on dw.DayNum = datepart(dw, ep.Date)
	left join InstructorEventPart iep on iep.DayPartID = ep.ID
	left join Instructor i on iep.InstructorID = i.ID and i.TrainingCentreID = @TrainingCentreID
	left join InstructorSectionHistory h on h.InstructorID = i.ID and s.ID = h.SectionID and ep.[Date] between h.StartDate and isnull(h.EndDate, '31 Dec 2999')
	group by s.ID

	-- Fetch Free Days
	;with DateTable as (
		SELECT @from AS [DATE], e.ID as DayType
		from EventPartType e 
		where e.ID <> 3
		UNION ALL
		SELECT DATEADD(dd, 1, [DATE]), DayType as DayType 
		FROM DateTable 
		WHERE DATEADD(dd, 1, [DATE]) <= @to
	),
	Parts as (
		select ep.ID as EventPartID, ep.Date, ep.DayType, iep.ID as InstructorEventPartID, iep.InstructorID
		from EventPart ep
		inner join InstructorEventPart iep on iep.DayPartID = ep.ID
		where ep.Date between @from and @to
	)
	insert @data (SectionID, GroupID, DayCount)
	select s.ID as SectionID,
		@FreeDaysGroupID as GroupID,
		count(t.InstructorID)/2.0 as DayCount -- divide by 2 as DateTable outputs one record per half day
	from Section s 
	cross join DateTable d
	inner join @daysOfWeek dw on dw.DayNum = datepart(dw, d.DATE)
	outer apply (
		select i.ID as InstructorID
		from Instructor i 
		inner join InstructorSectionHistory h on i.ID = h.InstructorID and s.ID = h.SectionID and dbo.PeriodsOverlap(d.DATE, d.DATE, h.StartDate, h.EndDate) = 1
		left join Parts pa on pa.InstructorID = i.ID and pa.Date = d.DATE and pa.DayType = d.DayType
		left join InstructorUnavailablePeriods p on p.InstructorID = i.ID 
			and dbo.PeriodsOverlap(d.DATE, d.DATE, p.StartDate, p.EndDate) = 1 and (p.DayTypeID = d.DayType or p.DayTypeID = 3)
		where i.TrainingCentreID = @TrainingCentreID and pa.InstructorEventPartID is null and p.ID is null
	) t
	group by s.ID
	OPTION (MAXRECURSION 0)

	-- Fetch unavailability periods (excluding open-ended ones), summed by section and reason
	insert @unavailData (SectionID, ReasonID, GroupID, DayCount)
	select s.ID as SectionID,
		r.ID as ReasonID,
		g.ID as GroupID,
		isnull(t.DayCount, 0) as DayCount
	from Section s
	cross join InstructorUnavailableReasonGroups g
	inner join UnavailableReasons r on g.ID = r.UnavailableReasonGroupID
	outer apply (
		select sum(dbo.DaysInPeriod2(p.StartDate, p.EndDate, h.StartDate, h.EndDate, @from, @to, @countWeekdays, @countWeekends, p.DayTypeID)) as DayCount
		from Instructor i
		inner join InstructorSectionHistory h on i.ID = h.InstructorID and s.ID = h.SectionID 
			and dbo.PeriodsOverlap(@from, @to, h.StartDate, h.EndDate) = 1
		inner join InstructorUnavailablePeriods p on i.ID = p.InstructorID and p.EndDate is not null 
			and dbo.PeriodsOverlap(@from, @to, p.StartDate, p.EndDate) = 1 
			and dbo.PeriodsOverlap(p.StartDate, p.EndDate, h.StartDate, h.EndDate) = 1
		where p.UnavailableReasonID = r.ID and i.TrainingCentreID = @TrainingCentreID
	) t

	-- collate unavailability periods by group
	insert @data (SectionID, GroupID, DayCount)
	select d.SectionID, d.GroupID, isnull(sum(d.DayCount), 0) as DayCount
	from @unavailData d
	group by d.SectionID, d.GroupID

	-- Calculate absolute percentages per unavailability reason and section
	update d1
	set d1.AbsPercentage = isnull(round(d1.DayCount / nullif(d2.DayCount, 0) * 100, 2), 0)
	from @unavailData d1 
	inner join @data d2 on d1.SectionID = d2.SectionID and d2.GroupID = @TotalInstructorDaysGroupID

	-- Calculate relative percentages per unavailability reason and section
	update d1
	set d1.RelPercentage = isnull(round(d1.DayCount / nullif(t2.DayCount, 0) * 100, 2), 0)
	from @unavailData d1 
	cross apply (
		select sum(d2.DayCount) as DayCount
		from @data d2
		inner join @groups g on d2.GroupID = g.GroupID and g.UseRelative = 1
		where d1.SectionID = d2.SectionID
	) t2
	inner join @groups g on d1.GroupID = g.GroupID and g.UseRelative = 1

	-- Calculate absolute percentages per section
	update d1
	set d1.AbsPercentage = isnull(round(d1.DayCount / nullif(d2.DayCount, 0) * 100, 2), 0)
	from @data d1 
	inner join @data d2 on d1.SectionID = d2.SectionID and d2.GroupID = @TotalInstructorDaysGroupID
	where d1.GroupID <> @TotalInstructorDaysGroupID 

	-- Calculate relative percentages per section
	update d1
	set d1.RelPercentage = isnull(round(d1.DayCount / nullif(t2.DayCount, 0) * 100, 2), 0)
	from @data d1 
	cross apply (
		select sum(d2.DayCount) as DayCount
		from @data d2
		inner join @groups g on d2.GroupID = g.GroupID and g.UseRelative = 1
		where d1.SectionID = d2.SectionID
	) t2
	inner join @groups g on d1.GroupID = g.GroupID and g.UseRelative = 1

	-- collate results and percentages for each section
	insert @results1 (Section, ReasonGroup, ColumnOrder, DayCount, Percentage, IsAbsolute)
	select 
		s.Title as Section, 
		g.Title as ReasonGroup,
		g.ColumnOrder,
		d1.DayCount,
		case when g.UseRelative = 1 then d1.RelPercentage else d1.AbsPercentage end as Percentage,
		case when g.UseRelative = 1 then 0 else 1 end as IsAbsolute
	from @data d1
	inner join @groups g on d1.GroupID = g.GroupID and d1.GroupID <> @TotalInstructorDaysGroupID
	inner join Section s on d1.SectionID = s.ID

	-- total the figures over all sections
	;with TotalAbs as (
		select sum(d1.DayCount) as TotalDays
		from @data d1
		where d1.GroupID = @TotalInstructorDaysGroupID
	),
	TotalRel as (
		select sum(d1.DayCount) as TotalDays
		from @data d1
		inner join @groups g on d1.GroupID = g.GroupID and g.UseRelative = 1
	)
	insert @results1 (Section, ReasonGroup, ColumnOrder, DayCount, Percentage, IsAbsolute)
	select 
		null as Section, 
		g.Title as ReasonGroup,
		max(g.ColumnOrder) as ColumnOrder,
		sum(d1.DayCount) as DayCount,
		isnull(round(sum(d1.DayCount) / 
					 nullif(case when max(cast(g.UseRelative as int)) = 1 
							then max(tr.TotalDays) 
							else max(ta.TotalDays) 
							end, 0) * 100, 2), 0) as Percentage,
		case when max(cast(g.UseRelative as int)) = 1 then 0 else 1 end as IsAbsolute
	from @data d1
	inner join @groups g on d1.GroupID = g.GroupID and d1.GroupID <> @TotalInstructorDaysGroupID
	cross join TotalAbs ta
	cross join TotalRel tr
	group by g.Title

	insert @resultsEvents (Section, NumEvents)
	select s.Title as Section, count(distinct t.EventID) as NumEvents
	from Section s
	outer apply (
		select e.ID as EventID, ep.Date, a.SectionID 
		from [Event] e
		inner join EventPart ep on e.ID = ep.EventID and ep.Date between @from and @to 
		inner join Activity a on e.ActivityID = a.ID
		inner join @daysOfWeek dw on dw.DayNum = datepart(dw, ep.Date)
		where s.ID = a.SectionID 
	) t
	group by s.Title

	-- Produce results for page 2
	insert @results2 (Section, Reason, ReasonGroup, DayCount, Percentage, IsAbsolute)
	select s.Title as Section, u.Reason, g.Title as ReasonGroup, isnull(d.DayCount, 0) as DayCount, 
		isnull(round(case when g2.UseRelative = 1 then d.RelPercentage else d.AbsPercentage end, 2), 0) as Percentage,
		case when g2.UseRelative = 1 then 0 else 1 end as IsAbsolute
	from @unavailData d
	inner join Section s on d.SectionID = s.ID
	inner join UnavailableReasons u on d.ReasonID = u.ID
	inner join InstructorUnavailableReasonGroups g on d.GroupID = g.ID
	inner join @groups g2 on d.GroupID = g2.GroupID 
	where d.GroupID = @AvailabilityGroupID

	-- Calculate summary results for page 2
	;with TotalAbs as (
		select sum(d1.DayCount) as TotalDays
		from @data d1
		where d1.GroupID = @TotalInstructorDaysGroupID
	),
	TotalRel as (
		select sum(d1.DayCount) as TotalDays
		from @data d1
		inner join @groups g on d1.GroupID = g.GroupID and g.UseRelative = 1
	)
	insert @results2 (Section, Reason, ReasonGroup, DayCount, Percentage, IsAbsolute)
	select null as Section, r2.Reason, r2.ReasonGroup, sum(r2.DayCount) as DayCount,
		isnull(round(sum(r2.DayCount) / 
					 nullif(case when @UseRelative = 1 
							then max(tr.TotalDays) 
							else max(ta.TotalDays) end, 0) * 100, 2), 0) as Percentage,
		case when @UseRelative = 1 then 0 else 1 end as IsAbsolute
	from @results2 r2
	cross join TotalAbs ta
	cross join TotalRel tr
	group by r2.Reason, r2.ReasonGroup

	-- Fetch data for use by Page 3 (12 month view)

	-- Total Instructor Days, grouped by section and month
	-- We don't count instructor days when they leave a section or when an open-ended unavailability period starts.
	;with DateTable as (
		SELECT @Page3From AS [DATE]
		UNION ALL
		SELECT DATEADD(dd, 1, [DATE]) 
		FROM DateTable 
		WHERE DATEADD(dd, 1, [DATE]) <= @Page3To
	)
	insert @dataPage3 (SectionID, GroupID, MonthStart, MonthEnd, DayCount)
	select t.SectionID,
		@TotalInstructorDaysGroupID as GroupID, 
		t.MonthStart,
		t.MonthEnd,
		count(t.InstructorID) as DayCount
	from (
		select s.ID as SectionID, i.ID as InstructorID, d.[DATE],
			   dateadd(d, -datepart(d, d.[DATE]) + 1, d.[DATE]) as MonthStart, 
			   dateadd(d, -1, dateadd(m, 1, dateadd(d, -datepart(d, d.[DATE]) + 1, d.[DATE]))) as MonthEnd
		from Section s
		cross join DateTable d
		inner join @daysOfWeek dw on dw.DayNum = datepart(dw, d.Date)
		left join InstructorSectionHistory h on s.ID = h.SectionID and d.[DATE] between h.StartDate and isnull(h.EndDate, '31 Dec 2999')
		left join Instructor i on i.ID = h.InstructorID and i.TrainingCentreID = @TrainingCentreID
		left join InstructorUnavailablePeriods p on p.InstructorID = i.ID and d.[DATE] >= p.StartDate and p.EndDate is null
		where p.ID is null
	) t
	group by t.SectionID, t.MonthStart, t.MonthEnd
	OPTION (MAXRECURSION 0)

	-- Fetch Daytime Training
	insert @dataPage3 (SectionID, GroupID, MonthStart, MonthEnd, DayCount)
	select t.SectionID, 
		@DaytimeTrainingGroupID as GroupID,
		t.MonthStart, 
		t.MonthEnd,
		sum(case when t.DayNum is null or t.HistoryID is null then 0 else case when t.DayType = 3 then 1 else 0.5 end end) as DayCount
	from (
		select s.ID as SectionID, dw.DayNum, ep.DayType, h.ID as HistoryID,
			dateadd(d, -datepart(d, ep.[Date]) + 1, ep.[Date]) as MonthStart, 
			dateadd(d, -1, dateadd(m, 1, dateadd(d, -datepart(d, ep.[Date]) + 1, ep.[Date]))) as MonthEnd
		from Section s
		left join EventPart ep on ep.[Date] between @Page3From and @Page3To
		left join @daysOfWeek dw on dw.DayNum = datepart(dw, ep.[Date])
		left join InstructorEventPart iep on iep.DayPartID = ep.ID
		left join Instructor i on iep.InstructorID = i.ID and i.TrainingCentreID = @TrainingCentreID
		left join InstructorSectionHistory h on h.InstructorID = i.ID and s.ID = h.SectionID and ep.[Date] between h.StartDate and isnull(h.EndDate, '31 Dec 2999')
	) t
	group by t.SectionID, t.MonthStart, t.MonthEnd

	-- Fetch Free Days grouped by section and month
	;with DateTable as (
		SELECT @Page3From AS [DATE], e.ID as DayType
		from EventPartType e 
		where e.ID <> 3
		UNION ALL
		SELECT DATEADD(dd, 1, [DATE]), DayType as DayType 
		FROM DateTable 
		WHERE DATEADD(dd, 1, [DATE]) <= @Page3To
	),
	Parts as (
		select ep.ID as epID, ep.[Date], ep.DayType, iep.ID as iepID, iep.InstructorID
		from EventPart ep
		inner join InstructorEventPart iep on iep.DayPartID = ep.ID
		where ep.Date between @Page3From and @Page3To
	)
	insert @dataPage3 (SectionID, GroupID, MonthStart, MonthEnd, DayCount)
	select t.SectionID,
		@FreeDaysGroupID as GroupID,
		t.MonthStart,
		t.MonthEnd,
		count(t.InstructorID)/2.0 as DayCount -- divide by 2 as the subquery returns one row per half day
	from (
		select s.ID as SectionID, i.ID as InstructorID, d.[DATE],
			   dateadd(d, -datepart(d, d.[DATE]) + 1, d.[DATE]) as MonthStart, 
			   dateadd(d, -1, dateadd(m, 1, dateadd(d, -datepart(d, d.[DATE]) + 1, d.[DATE]))) as MonthEnd
		from Section s 
		cross join DateTable d
		inner join @daysOfWeek dw on dw.DayNum = datepart(dw, d.[DATE])
		left join InstructorSectionHistory h on s.ID = h.SectionID and dbo.PeriodsOverlap(d.[DATE], d.[DATE], h.StartDate, h.EndDate) = 1
		left join Instructor i on i.ID = h.InstructorID and i.TrainingCentreID = @TrainingCentreID
		left join Parts pa on pa.InstructorID = i.ID and pa.[Date] = d.[DATE] and pa.DayType = d.DayType
		left join InstructorUnavailablePeriods p on p.InstructorID = i.ID 
			and dbo.PeriodsOverlap(d.[DATE], d.[DATE], p.StartDate, p.EndDate) = 1 and (p.DayTypeID = d.DayType or p.DayTypeID = 3)
		where pa.InstructorID is null and p.ID is null 
	) t
	group by t.SectionID, t.MonthStart, t.MonthEnd
	OPTION (MAXRECURSION 0)

	-- Fetch unavailability periods (excluding open-ended ones), grouped by section and month
	;with DateTable as (
		SELECT @Page3From AS MonthStart, dateadd(d, -1, dateadd(m, 1, @Page3From)) as MonthEnd
		UNION ALL
		SELECT dateadd(mm, 1, MonthStart) as MonthStart, dateadd(d, -1, dateadd(m, 1, dateadd(mm, 1, MonthStart))) as MonthEnd
		FROM DateTable 
		WHERE dateadd(d, -1, dateadd(m, 1, dateadd(mm, 1, MonthStart))) <= @Page3To
	)
	insert @dataPage3 (SectionID, GroupID, MonthStart, MonthEnd, DayCount)
	select s.ID as SectionID, g.ID as GroupID, d.MonthStart, d.MonthEnd, 
		sum(dbo.DaysInPeriod2(t.StartDate, t.EndDate, t.MonthStart, t.MonthEnd, t.SectionStart, t.SectionEnd, @countWeekdays, @countWeekends, t.DayTypeID)) as DayCount
	from Section s
	cross join InstructorUnavailableReasonGroups g
	cross join DateTable d
	outer apply (
		select p.StartDate, p.EndDate, p.DayTypeID, d.MonthStart, d.MonthEnd, h.StartDate as SectionStart, h.EndDate as SectionEnd
		from Instructor i
		inner join InstructorSectionHistory h on i.ID = h.InstructorID and s.ID = h.SectionID
			and dbo.PeriodsOverlap(d.MonthStart, d.MonthEnd, h.StartDate, h.EndDate) = 1
		inner join InstructorUnavailablePeriods p on i.ID = p.InstructorID and p.EndDate is not null
			and dbo.PeriodsOverlap(d.MonthStart, d.MonthEnd, p.StartDate, p.EndDate) = 1 
			and dbo.PeriodsOverlap(p.StartDate, p.EndDate, h.StartDate, h.EndDate) = 1
		inner join UnavailableReasons r on r.ID = p.UnavailableReasonID
		where r.UnavailableReasonGroupID = g.ID and i.TrainingCentreID = @TrainingCentreID
	) t
	group by s.ID, g.ID, d.MonthStart, d.MonthEnd

	-- Calculate absolute percentages per section and month, for the selected GroupID
	update t1
	set t1.AbsPercentage = t1.DayCount / nullif(t2.DayCount, 0) * 100
	from @dataPage3 t1 
	inner join @dataPage3 t2 on t1.SectionID = t2.SectionID and t1.MonthStart = t2.MonthStart 
	where t1.GroupID = @AvailabilityGroupID and t2.GroupID = @TotalInstructorDaysGroupID

	-- Calculate relative percentages per section and month
	update d3
	set d3.RelPercentage = d3.DayCount / nullif(t1.DayCount, 0) * 100
	from @dataPage3 d3
	outer apply (
		select sum(d1.DayCount) as DayCount
		from @dataPage3 d1
		inner join @groups g on d1.GroupID = g.GroupID and g.UseRelative = 1
		where d3.SectionID = d1.SectionID and d3.MonthStart = d1.MonthStart
	) t1
	inner join @groups g on d3.GroupID = g.GroupID and g.UseRelative = 1
	where d3.GroupID = @AvailabilityGroupID

	-- Produce results for page 3
	insert @results3 (Section, SectionID, ReasonGroup, StartDate, [Month], [Year], DayCount, Percentage, IsAbsolute)
	select s.Title as Section, s.ID as SectionID, g.Title as ReasonGroup, d3.MonthStart as StartDate, 
		datename(m, d3.MonthStart) as [Month], datepart(yy, d3.MonthStart) as [Year], isnull(d3.DayCount, 0) as DayCount, 
		isnull(round(case when g2.UseRelative = 1 then d3.RelPercentage else d3.AbsPercentage end, 2), 0) as Percentage,
		case when g2.UseRelative = 1 then 0 else 1 end as IsAbsolute
	from @dataPage3 d3
	inner join Section s on d3.SectionID = s.ID
	inner join InstructorUnavailableReasonGroups g on d3.GroupID = g.ID
	inner join @groups g2 on d3.GroupID = g2.GroupID
	where g.ID = @AvailabilityGroupID

	-- Calculate summary results for page 3
	insert @results3 (Section, SectionID, ReasonGroup, StartDate, [Month], [Year], DayCount, Percentage, IsAbsolute)
	select null as Section, null as SectionID, g.Title as ReasonGroup, d3.MonthStart as StartDate, 
		datename(m, d3.MonthStart) as [Month], datepart(yy, d3.MonthStart) as [Year], isnull(sum(d3.DayCount), 0) as DayCount,
		isnull(round(sum(d3.DayCount) / nullif(max(q.DayCount), 0) * 100, 2), 0) as Percentage,
		case when @UseRelative = 1 then 0 else 1 end as IsAbsolute
	from @dataPage3 d3
	inner join InstructorUnavailableReasonGroups g on d3.GroupID = g.ID
	outer apply (
		select sum(t2.DayCount) as DayCount 
		from @dataPage3 t2
		inner join @groups g on t2.GroupID = g.GroupID 
		where d3.MonthStart = t2.MonthStart 
		  and ((@UseRelative = 1 and g.UseRelative = 1) or (@UseRelative = 0 and t2.GroupID = @TotalInstructorDaysGroupID))
	) q
	where d3.GroupID = @AvailabilityGroupID
	group by g.Title, d3.MonthStart, datename(m, d3.MonthStart), datepart(yy, d3.MonthStart)
	
	-- DataSet1
	if isnull(@ReturnDataset, 1) = 1
		select 
			r3.Section as SectionName, 
			r3.SectionID as SectionID,
			r3.StartDate as InstructorEngagedDate, 
			r3.DayCount as InstructorTimeSpentInEvents, 
			r3.Percentage as InstructorTimeSpentInEventsPercent
		from @results3 r3
		where r3.Section is not null
		order by r3.Section, r3.StartDate

	-- DataSet2
	if isnull(@ReturnDataset, 2) = 2
		select 
			tc.Name + ' TOTAL' as SectionName, 
			r3.StartDate as InstructorEngagedDate, 
			r3.DayCount as InstructorsEngagedInEvents, 
			r3.Percentage as InstructorsEngagedInEventsPercent
		from @results3 r3
		inner join TrainingCentre tc on tc.ID = @TrainingCentreID
		where r3.Section is null
		order by r3.StartDate

	-- DataSet3
	if isnull(@ReturnDataset, 3) = 3
		select 
			r2.Section as SectionName,
			r2.Reason as UnavailableReasonTitle,
			r2.DayCount as InstructorsEngagedInEvents,
			r2.Percentage as InstructorsEngagedInEventsPercent
		from @results2 r2
		where r2.Section is not null
		order by r2.Section, r2.Reason

	-- DataSet4
	if isnull(@ReturnDataset, 4) = 4
		select 
			tc.Name + ' TOTAL' as SectionName, 
			r2.Reason as UnavailableReasonTitle,
			r2.DayCount as TotalInstructorsEngagedInNonWorkActivity,
			r2.Percentage as InstructorsEngagedInNonWorkActivityPercent
		from @results2 r2
		inner join TrainingCentre tc on tc.ID = @TrainingCentreID
		where r2.Section is null
		order by r2.Section, r2.Reason

	-- DataSet5
	if isnull(@ReturnDataset, 5) = 5
		select 
			r1.Section as SectionName,
			r1.ReasonGroup as GenericHeaderText,
			r1.DayCount as InstructorsEngagedInEvents,
			r1.Percentage as InstructorsEngagedInEventsPercent,
			r1.IsAbsolute as IsAbsolutePercentage,
			r1.ColumnOrder as ColumnOrder
		from @results1 r1
		where r1.Section is not null
		order by r1.ReasonGroup, r1.Section

	-- DataSet6
	if isnull(@ReturnDataset, 6) = 6
		select 
			re.Section as SectionName,
			re.NumEvents as TotalEventsForSection
		from @resultsEvents re
		order by re.Section

	-- DataSet7
	if isnull(@ReturnDataset, 7) = 7
		select 
			'header' as SectionName,
			r1.ReasonGroup as GenericHeaderText,
			r1.DayCount as TotalInstructorsForSection,
			r1.Percentage as InstructorsEngagedInEventsPercent,
			r1.IsAbsolute as IsAbsolutePercentage,
			r1.ColumnOrder as ColumnOrder
		from @results1 r1
		where r1.Section is null

	SET NOCOUNT OFF
END
