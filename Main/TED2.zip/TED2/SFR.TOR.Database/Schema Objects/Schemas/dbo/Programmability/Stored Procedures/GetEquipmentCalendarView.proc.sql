﻿CREATE PROCEDURE [dbo].[GetEquipmentCalendarView] 
	@startDate	VARCHAR(10),
	@endDate	VARCHAR(10),
	@page		INT,
	@size		INT,
	@sortBy		VARCHAR(10),
	@sortDir	VARCHAR(4),
	@status		VARCHAR(400) = NULL,
	@section	VARCHAR(400) = NULL,
	@totalCount INT OUTPUT,
	@trainingCentreID VARCHAR(4) = NULL,
	@group		VARCHAR(400) = NULL,
	@equipment VARCHAR(400) = NULL
AS
BEGIN
	SET NOCOUNT ON
    DECLARE @sql NVARCHAR(MAX) = N'' 
	DECLARE @sql2 NVARCHAR(MAX) = N''

	--build the dynamic pivot columns for each of 14 day parts for the week
	-- ;1 indicates AM, ;2 indicates PM
	SELECT TOP (7)  
    @sql += N',[' + 
		CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
      (ORDER BY [object_id])-1, @StartDate), 03) + ';1]' + N',[' + 
		CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
      (ORDER BY [object_id])-1, @StartDate), 03) + ';2]'
    FROM sys.all_objects ORDER BY [object_id]; 
 
 SELECT TOP (7)  
    @sql2 += N',[' + 
		CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
      (ORDER BY [object_id])-1, @StartDate), 03) + ';1]' + N',[' + 
		CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
      (ORDER BY [object_id])-1, @StartDate), 03) + ';2]'
    FROM sys.all_objects ORDER BY [object_id]; 
 
DECLARE @filter varchar(50)
SET  @filter = NULL
IF(@section IS NULL AND @status IS NULL)
	SET  @filter = ''
 
-- query to count the total rows that match the query, before paging 
SELECT @sql = N'

	SELECT *, ROW_NUMBER() OVER(ORDER BY ' + @sortBy + ' ' + @sortDir + ') Corr 
	FROM 
	( 
		SELECT ID, Name, GroupTitle, [Date], EventTitle + '';'' + Convert(char(1), [Status]) + '';'' + Code + '';'' + Convert(varchar(Max), [EventID])  + '';'' + Convert(varchar(Max), ResourceStatus) as stringvalue
		FROM vwEquipmentCalendarBase	
		WHERE 
			(ISNULL(SectionID, -1) IN (-1, ' + ISNULL(@section, 'SectionID') + ')) AND
			(ISNULL(Status, -1) IN (-1, ' + ISNULL(@status, 'Status') + ')) AND
			(ISNULL(GroupID, -1) IN (-1, ' + ISNULL(@group, 'GroupID') + ')) AND
			(ID IN (' + ISNULL(@equipment, 'ID') + ')) AND
			(TrainingCentreID = COALESCE(' + ISNULL(@trainingCentreID, 'null') + ', TrainingCentreID) OR [TrainingCentreID] is NULL)' + 			
			ISNULL(@filter + '', 'AND baseDate between '''+ @startDate + ''' AND ''' + @endDate + '''') + '			
							
	) as d 
	PIVOT 
	( 
		min([stringvalue])     
		for [Date] in  
	  (' + STUFF(@sql, 1, 1, '') + ')  
	)  
	as p	
	WHERE NOT EXISTS
	(
		SELECT * FROM EquipmentUnavailablePeriods e
		WHERE e.StartDate <= ''' + @startDate + ''' AND e.endDate is null AND e.EquipmentID = p.ID
	)		
' 

EXEC sp_executesql @sql
SET @totalCount = @@rowcount

--query to get the specific page we want 
SELECT @sql2 = N'
WITH CTE AS 
( 
	SELECT *, ROW_NUMBER() OVER(ORDER BY ' + @sortBy + ' ' + @sortDir + ') Corr 
	FROM 
	( 
		SELECT ID, Name, GroupTitle, [Date], EventTitle + '';'' + Convert(char(1), [Status]) + '';'' + Code + '';'' + Convert(varchar(Max), [EventID])  + '';'' + Convert(varchar(Max), ResourceStatus) as stringvalue
		FROM vwEquipmentCalendarBase		
		WHERE			
			(ISNULL(SectionID, -1) IN (-1, ' + ISNULL(@section, 'SectionID') + ')) AND
			(ISNULL(Status, -1) IN (-1, ' + ISNULL(@status, 'Status') + ')) AND
			(ISNULL(GroupID, -1) IN (-1, ' + ISNULL(@group, 'GroupID') + ')) AND
			(ID IN (' + ISNULL(@equipment, 'ID') + ')) AND
			(TrainingCentreID = COALESCE(' + ISNULL(@trainingCentreID, 'null') + ', TrainingCentreID) OR [TrainingCentreID] is NULL)' +
			ISNULL(@filter + '', 'AND baseDate between '''+ @startDate + ''' AND ''' + @endDate + '''') + '			
	) as d 
	PIVOT 
	( 
		min([stringvalue])     
		for [Date] in  
	  (' + STUFF(@sql2, 1, 1, '') + ')  
	)  
	as p
	WHERE NOT EXISTS
	(
		SELECT * FROM EquipmentUnavailablePeriods e
		WHERE e.StartDate <= ''' + @startDate + ''' AND e.endDate is null AND e.EquipmentID = p.ID
	)	
)
SELECT * 
FROM CTE 
WHERE Corr BETWEEN ('+ CONVERT(varchar(3), @size) + ' * (' + CONVERT(varchar(4), @page) + ' - 1))+1 AND ('+ CONVERT(varchar(3), @size) + '*' + CONVERT(varchar(4), @page) + ')
' 

EXEC sp_executesql @sql2
END