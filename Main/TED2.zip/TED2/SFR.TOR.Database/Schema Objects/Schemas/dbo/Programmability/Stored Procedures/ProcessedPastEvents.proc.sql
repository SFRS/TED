﻿

CREATE PROCEDURE [dbo].[ProcessedPastEvents] 
	
AS
BEGIN	
	SET NOCOUNT ON;

    UPDATE [Event]
	SET [Status] = 5 --Complete
	WHERE ID IN (
		SELECT e.ID
		FROM [Event] AS e
		WHERE e.[Status] = 3 AND ((( -- the event status is Scheduled
			SELECT COUNT(*)			-- and ALL it's event parts are in the past
			FROM EventPart AS ep1
			WHERE ep1.EventID = e.ID
			)) = ((
			SELECT COUNT(*)
			FROM EventPart AS ep2
			WHERE (ep2.[Date] < CAST(GETDATE() AS DATE)) AND (ep2.EventID = e.ID)
			)))  
	)
END