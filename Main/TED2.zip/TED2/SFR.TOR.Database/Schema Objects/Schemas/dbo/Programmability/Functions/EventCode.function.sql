create function dbo.EventCode
(
    @ActivityCode varchar(50), 
    @EventNumber int,
	@FinancialYear int
)
returns varchar(100)
as
begin
	return @ActivityCode + ' ' + cast(@EventNumber as varchar) + '/' + right(@FinancialYear, 2)
end