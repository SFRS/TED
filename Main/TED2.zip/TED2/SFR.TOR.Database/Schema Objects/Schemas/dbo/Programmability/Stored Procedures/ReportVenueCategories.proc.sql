CREATE PROCEDURE [dbo].[ReportVenueCategories]
	@TrainingCentreID int,
	@ReturnDataset int = null
AS
BEGIN
	SET NOCOUNT ON

	-- DataSet1
	if isnull(@ReturnDataset, 1) = 1
		select 
			tc.Name as TrainingCentre,
			vg.Title as VenueGroupTitle,
			v.Name as VenueName,
			vt.Name as VenueCategory
		from Venue v 
		inner join VenueGroup vg on vg.ID = v.VenueGroupID
		inner join TrainingCentre tc on tc.ID = v.TrainingCentreID
		left join VenueTagVenue vtv on vtv.VenueID = v.ID
		left join VenueTag vt on vtv.VenueTagID = vt.ID
		where tc.ID = @TrainingCentreID
		order by tc.Name, vg.Title, v.Name, vt.Name

	SET NOCOUNT OFF
END
