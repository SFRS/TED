CREATE PROCEDURE [dbo].[ReportEventsByVenueCategories]
	@TrainingCentreID int,
	@from date,
	@to date,
	@ReturnDataset int = null
AS
BEGIN
	SET NOCOUNT ON

-- DataSet1
	if isnull(@ReturnDataset, 1) = 1
		select 
			v.Name as VenueName,
			ep.[Date] as BookingDate,
			ep.StartTime as StartTime,
			ep.EndTime as EndTime,
			a.Title as EventTitle,
			s.Title as EventSection,
			tc.Name as TrainingCentre,
			vg.Title as VenueGroupTitle
		from EventPart ep
		inner join VenueEventPart vep on ep.ID = vep.DayPartID
		inner join Venue v on v.ID = vep.VenueID
		inner join VenueGroup vg on vg.ID = v.VenueGroupID
		inner join TrainingCentre tc on tc.ID = v.TrainingCentreID
		inner join [Event] e on e.ID = ep.EventID
		inner join Activity a on a.ID = e.ActivityID
		inner join Section s on s.ID = a.SectionID
		where ep.[Date] between @from and @to and tc.ID = @TrainingCentreID
		order by tc.Name, vg.Title, v.Name, ep.[Date], ep.StartTime

	SET NOCOUNT OFF
END
