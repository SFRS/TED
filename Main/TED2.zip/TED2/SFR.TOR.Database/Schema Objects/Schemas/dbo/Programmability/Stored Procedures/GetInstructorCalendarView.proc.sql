﻿CREATE PROCEDURE [dbo].[GetInstructorCalendarView] 
	@startDate varchar(10),
	@endDate varchar(10),
	@page INT,
	@size INT,
	@sortBy VARCHAR(20),
	@sortDir VARCHAR(4),
	@status VARCHAR(400) = NULL,
	@section VARCHAR(400) = NULL,
	@totalCount INT OUTPUT,
	@trainingCentreID VARCHAR(4) = NULL,
	@group VARCHAR(400) = NULL,
	@instructor VARCHAR(400) = NULL
AS
BEGIN
	SET NOCOUNT ON
    DECLARE @sql NVARCHAR(MAX) = N'' 
   
	--build the dynamic pivot columns for each of 14 day parts for the week
	-- ;1 indicates AM, ;2 indicates PM
	SELECT TOP (7)  
    @sql += N',[' + 
		CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
      (ORDER BY [object_id])-1, @StartDate), 03) + ';1]' + N',[' + 
		CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
      (ORDER BY [object_id])-1, @StartDate), 03) + ';2]'
    FROM sys.all_objects ORDER BY [object_id]; 

	-- Populate a local table with one record per date and day part.
	DECLARE @DatePartTable TABLE (
		BaseDate DATE,
		DateAndPart VARCHAR(10)
	)
	
	;with dates as (
		SELECT TOP (7) DATEADD(DAY, ROW_NUMBER() OVER (ORDER BY [object_id])-1, @StartDate) as BaseDate
		FROM sys.all_objects 
	)
	insert @DatePartTable (BaseDate, DateAndPart)
	select d1.BaseDate, CONVERT(VARCHAR, d1.BaseDate, 03)  + ';1' as DateAndPart
	from dates d1
	union all
	select d1.BaseDate, CONVERT(VARCHAR, d1.BaseDate, 03)  + ';2' as DateAndPart
	from dates d1
	
	-- Combine the @DatePartTable values into a single string. This lets us use the values in the dynamic SQL statement below.
	-- The string helps to define a table value constructor within a CROSS JOIN, to generate one row per instructor per date & day part.
	DECLARE @vals VARCHAR(8000) 
	SELECT @vals = COALESCE(@vals + ', ', '') + '(''' + CONVERT(varchar, BaseDate, 112) + ''',''' + DateAndPart + ''')'
	FROM @DatePartTable
 
	 DECLARE @FullResults TABLE (
		ID int,
		SectionName varchar(50),
		GroupName varchar(20),
		GroupID int,
		SectionID int,
		Name varchar(200),
		Day1AM varchar(4000),
		Day1PM varchar(4000),
		Day2AM varchar(4000),
		Day2PM varchar(4000),
		Day3AM varchar(4000),
		Day3PM varchar(4000),
		Day4AM varchar(4000),
		Day4PM varchar(4000),
		Day5AM varchar(4000),
		Day5PM varchar(4000),
		Day6AM varchar(4000),
		Day6PM varchar(4000),
		Day7AM varchar(4000),
		Day7PM varchar(4000),
		Corr int
	)

declare @sortExpr varchar(100)

-- By default, sort the results by Section Name, Instructor Name, Group Name.
set @sortExpr = @sortBy + ' ' + @sortDir + ', ' + 
	case @sortBy 
		when 'SectionName' then 'Name asc, GroupName asc'
		when 'Name' then 'SectionName asc, GroupName asc'
		when 'GroupName' then 'SectionName asc, Name asc'
		else 'SectionName asc, Name asc, GroupName asc'
	end
	
-- We cross join the instructors to the set of dates and day parts, then look for a section history record on each date for the instructors.
-- If no such record is found, the instructor is inactive on that date, and we emit a string to that effect.
-- Otherwise, they are active, so we emit a string with details of the event they are participating in, if any.
SELECT @sql = N'
	SELECT *, ROW_NUMBER() OVER(ORDER BY ' + @sortExpr + ') Corr 
	FROM 
	( 
		SELECT i.ID, ISNULL(s.Title, ''*INACTIVE'') as SectionName, g.Name as GroupName, g.ID as GroupID, s.ID as SectionID, i.LastName + '', '' + i.FirstName as Name, dt.DateAndPart AS [Date], 
			CASE WHEN h.ID IS NULL THEN ''UNAVAILABLE*INACTIVE'' ELSE b.Title + '';'' + Convert(char(1), b.[Status]) + '';'' + b.Code + '';'' + Convert(varchar(Max), b.[EventID])  + '';'' + Convert(varchar(Max), b.ResourceStatus) END as stringvalue
		FROM Instructor i 
		LEFT JOIN Section s ON i.SectionID = s.ID
		LEFT JOIN [Group] g ON i.GroupID = g.ID
		CROSS JOIN (VALUES ' + @vals + ') as dt (BaseDate, DateAndPart)
		LEFT JOIN vwInstructorCalendarBase b ON b.ID = i.ID AND b.[Date] = dt.DateAndPart
		LEFT JOIN InstructorSectionHistory h ON h.InstructorID = i.ID AND dbo.PeriodsOverlap(dt.BaseDate, dt.BaseDate, h.StartDate, ISNULL(h.EndDate, ''31 Dec 2999'')) = 1
		WHERE 
			(ISNULL(i.SectionID, -1) IN (' + ISNULL(@section, '-1, i.SectionID') + ')) AND
			(ISNULL(b.Status, -1) IN (' + ISNULL(@status, '-1, b.Status') + ')) AND
			(ISNULL(i.GroupID, -1) IN (' + ISNULL(@group, '-1, i.GroupID') + ')) AND
			(i.ID IN (' + ISNULL(@instructor, 'i.ID') + ')) AND
			(i.TrainingCentreID = COALESCE(' + ISNULL(@trainingCentreID, 'null') + ', i.TrainingCentreID) OR i.TrainingCentreID is NULL)' +
	') as d
	PIVOT 
	( 
		min([stringvalue])     
		for [Date] in  
	  (' + STUFF(@sql, 1, 1, '') + ')  
	)
	as p
	WHERE NOT EXISTS
	(
		SELECT * FROM InstructorUnavailablePeriods i
		WHERE i.StartDate <= ''' + @startDate + ''' AND i.endDate is null AND i.InstructorID = p.ID
	)
	AND EXISTS (
		SELECT * FROM InstructorSectionHistory h WHERE h.InstructorID = p.ID 
		AND dbo.PeriodsOverlap(''' + @startDate + ''', ''' + @endDate + ''', h.StartDate, ISNULL(h.EndDate, ''31 Dec 2999'')) = 1
	)
' 

 INSERT @FullResults (ID, SectionName, GroupName, GroupID, SectionID, Name, Day1AM, Day1PM, Day2AM, Day2PM, Day3AM, Day3PM, Day4AM, Day4PM, Day5AM, Day5PM, Day6AM, Day6PM, Day7AM, Day7PM, Corr)
 EXEC sp_executesql @sql
 
 SET @totalCount = @@rowcount
  
 SELECT *
 FROM @FullResults
 WHERE Corr BETWEEN (@size * (@page - 1))+1 AND (@size * @page)

END
