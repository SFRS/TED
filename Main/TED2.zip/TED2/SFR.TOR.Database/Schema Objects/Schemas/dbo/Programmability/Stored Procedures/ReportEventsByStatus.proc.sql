CREATE PROCEDURE [dbo].[ReportEventsByStatus]
	@TrainingCentreID int,
	@from date,
	@to date,
	@EventStatusIDs varchar(max),
	@ResourceStatusIDs varchar(max),
	@SectionIDs varchar(max),
	@countWeekdays bit,
	@countWeekends bit,
	@ReturnDataset int = null
AS
BEGIN
	SET NOCOUNT ON

	declare @daysOfWeek table (DayNum int)

	if @countWeekdays = 1
		insert @daysOfWeek values (2),(3),(4),(5),(6)

	if @countWeekends = 1
		insert @daysOfWeek values (1),(7)

	declare @eventStatusTable table (EventStatusID int)
	declare @resourceStatusTable table (ResourceStatusID int)
	declare @sectionTable table (SectionID int)

	insert @eventStatusTable (EventStatusID)
	select distinct cast(val as int) from dbo.SplitString(@EventStatusIDs, ',')

	insert @resourceStatusTable (ResourceStatusID)
	select distinct cast(val as int) from dbo.SplitString(@ResourceStatusIDs, ',')

	insert @sectionTable (SectionID)
	select distinct cast(val as int) from dbo.SplitString(@SectionIDs, ',')

	-- DataSet1
	if isnull(@ReturnDataset, 1) = 1
		with EventCounts as (
			select 
				ep.EventID, 
				sum(case when ep.DayType = 3 then 1 else 0.5 end) as DaysCounted, 
				sum(case when ep.Status = 3 then (case when ep.DayType = 3 then 1 else 0.5 end) else 0 end) as ResourcedDaysCounted,
				sum(case when cat.CateringCount > 0 then (case when ep.DayType = 3 then 1 else 0.5 end) else 0 end) as CateringDaysCounted
				-- counts catering per day, not per venue
			from EventPart ep
			inner join @daysOfWeek dw on datepart(dw, ep.[Date]) = dw.DayNum
			outer apply (
				select count(*) as CateringCount 
				from VenueEventPart vep 
				inner join Venue v on vep.VenueID = v.ID
				where vep.DayPartID = ep.ID and vep.NeedsCatering = 1 and v.TrainingCentreID = @TrainingCentreID
			) cat
			where ep.[Date] between @from and @to
			group by ep.EventID
		),
		EventDates as (
			select 
				ec.EventID, 
				cast(min(ep.[Date]) as date) as StartDate, 
				cast(max(ep.[Date]) as date) as EndDate, 
				sum(case when ep.DayType = 3 then 1 else 0.5 end) as TotalDays
			from EventCounts ec
			inner join EventPart ep on ec.EventID = ep.EventID and ep.[Date] is not null
			group by ec.EventID
		)
		select 
			dbo.EventCode(a.Code, e.EventNumber, e.FinanciaYear) as EventCode,
			a.Title as EventTitle,
			es.Title as EventStatus,
			s.Title as SectionName,
			rs.Title as Resourced,
			-- The following fields are casted to varchar because AutoMapper fails to read the float values correctly
			cast(ed.TotalDays as varchar) as TotalDays,
			cast(ec.DaysCounted as varchar) as DaysCounted,
			cast(ec.ResourcedDaysCounted as varchar) as DaysResourced,
			cast(ec.CateringDaysCounted as varchar) as DaysCatered,
			ed.StartDate as StartDate,
			ed.EndDate as EndDate
		from [Event] e
		inner join EventCounts ec on e.ID = ec.EventID
		inner join EventDates ed on e.ID = ed.EventID
		inner join Activity a on e.ActivityID = a.ID
		inner join EventStatus es on e.[Status] = es.ID
		inner join @eventStatusTable est on es.ID = est.EventStatusID
		inner join Section s on a.SectionID = s.ID
		inner join @sectionTable st on s.ID = st.SectionID
		inner join ResourceStatus rs on e.Resourced = rs.ID
		inner join @resourceStatusTable rst on rs.ID = rst.ResourceStatusID
		order by ed.StartDate, ed.EndDate, a.Code, e.FinanciaYear, e.EventNumber

	SET NOCOUNT OFF
END
