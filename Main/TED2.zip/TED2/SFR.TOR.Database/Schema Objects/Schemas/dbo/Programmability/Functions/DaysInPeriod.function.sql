﻿CREATE FUNCTION [dbo].[DaysInPeriod]
(
	@fromDate date, 
	@toDate date, 
	@countFrom date, 
	@countTo date, 
	@countWeekdays bit, 
	@countWeekends bit, 
	@dayType int
)
RETURNS FLOAT
AS
BEGIN
	return dbo.DaysInPeriod2(@fromDate, @toDate, @countFrom, @countTo, @countFrom, @countTo, @countWeekdays, @countWeekends, @dayType)
END
