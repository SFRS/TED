﻿CREATE FUNCTION [dbo].[DaysInPeriod2]
(
	@fromDate date, 
	@toDate date, 
	@countFrom date, 
	@countTo date, 
	@countFrom2 date, 
	@countTo2 date, 
	@countWeekdays bit, 
	@countWeekends bit, 
	@dayType int
)
RETURNS FLOAT
AS
BEGIN
	declare @useFromDate date
	declare @useToDate date
	declare @totalDays int
	declare @weekdays int
	declare @weekends int
	declare @result float

	set @useFromDate = case when @fromDate < @countFrom then @countFrom else @fromDate end
	set @useToDate = case when @toDate > @countTo then @countTo else @toDate end
	
	set @useFromDate = case when @useFromDate < @countFrom2 then @countFrom2 else @useFromDate end
	set @useToDate = case when @useToDate > @countTo2 then @countTo2 else @useToDate end
	
	if @useFromDate > @useToDate
	begin
		set @result = 0
		return @result
	end
	
	set @totalDays = DATEDIFF(dd, @useFromDate, @useToDate) + 1

	set @weekdays = @totalDays 
					- (DATEDIFF(wk, @useFromDate, @useToDate) * 2) 
					- (CASE WHEN DATENAME(dw, @useFromDate) = 'Sunday' THEN 1 ELSE 0 END)
					- (CASE WHEN DATENAME(dw, @useToDate) = 'Saturday' THEN 1 ELSE 0 END)
	
	set @weekends = @totalDays - @weekdays

	if @countWeekdays = 1 and @countWeekends = 1
		set @result = @totalDays
	else if @countWeekdays = 1
		set @result = @weekdays
	else
		set @result = @weekends

	if @result = 1 and @dayType in (1,2)
		set @result = 0.5

	return @result
END
