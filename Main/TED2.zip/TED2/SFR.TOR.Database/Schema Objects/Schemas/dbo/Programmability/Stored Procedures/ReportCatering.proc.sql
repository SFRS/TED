CREATE PROCEDURE [dbo].[ReportCatering]
	@TrainingCentreID int,
	@from date,
	@to date,
	@ReturnDataset int = null
AS
BEGIN
	SET NOCOUNT ON

	-- DataSet1
	if isnull(@ReturnDataset, 1) = 1
		select 
			dbo.EventCode(a.Code, e.EventNumber, e.FinanciaYear) as EventCode,
			a.Title as EventTitle,
			v.Name as VenueName,
			s.Title as SectionName,
			ep.[Date] as [Date],
			ep.StartTime as StartTime,
			ep.EndTime as EndTime
		from EventPart ep
		inner join VenueEventPart vep on ep.ID = vep.DayPartID and vep.NeedsCatering = 1
		inner join Venue v on v.ID = vep.VenueID and v.TrainingCentreID = @TrainingCentreID
		inner join [Event] e on e.ID = ep.EventID
		inner join Activity a on a.ID = e.ActivityID
		inner join Section s on s.ID = a.SectionID
		where ep.[Date] between @from and @to 
		order by ep.[Date], ep.StartTime, a.Code, e.FinanciaYear, e.EventNumber
	
	-- DataSet2
	if isnull(@ReturnDataset, 2) = 2
		select tc.Name as TrainingCentreName
		from TrainingCentre tc
		where tc.ID = @TrainingCentreID

	SET NOCOUNT OFF
END
