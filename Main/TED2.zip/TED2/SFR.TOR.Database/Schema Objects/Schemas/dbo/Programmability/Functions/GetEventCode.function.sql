﻿CREATE FUNCTION [dbo].[GetEventCode]
(
	@EventID int
)
RETURNS varchar(100)
AS
BEGIN
	declare @ActivityCode varchar(50)
	declare @EventNumber int
	declare @FinancialYear int
	
	select @ActivityCode = a.Code, @EventNumber = e.EventNumber, @FinancialYear = e.FinanciaYear
	from Event e
	inner join Activity a on e.ActivityID = a.ID
	where e.ID = @EventID
	
	return dbo.EventCode(@ActivityCode, @EventNumber, @FinancialYear)
END
