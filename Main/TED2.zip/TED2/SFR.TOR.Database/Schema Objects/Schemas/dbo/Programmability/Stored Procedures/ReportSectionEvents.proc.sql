CREATE PROCEDURE [dbo].[ReportSectionEvents]
	@TrainingCentreID int,
	@from date,
	@to date,
	@SectionIDs varchar(max),
	@countWeekdays bit,
	@countWeekends bit,
	@ReturnDataset int = null
AS
BEGIN
	SET NOCOUNT ON

	declare @daysOfWeek table (DayNum int)

	if @countWeekdays = 1
		insert @daysOfWeek values (2),(3),(4),(5),(6)

	if @countWeekends = 1
		insert @daysOfWeek values (1),(7)

	declare @DaytimeTrainingGroupID int
	declare @NonWorkGroupID int
	declare @OtherTrainingGroupID int
	declare @NonTrainingGroupID int
	declare @EveningTrainingGroupID int
	declare @FreeDaysGroupID int
	declare @TotalInstructorDaysGroupID int
	set @DaytimeTrainingGroupID = 0
	set @NonWorkGroupID = 2
	set @OtherTrainingGroupID = 3
	set @NonTrainingGroupID = 4
	set @EveningTrainingGroupID = 5
	set @FreeDaysGroupID = 998
	set @TotalInstructorDaysGroupID = 999

	-- Define whether the InstructorUnavailableReasonGroups (and the virtual groups for Free Days and Daytime Training) 
	-- use absolute or relative percentages, and what order the columns appear in within the report.
	declare @groups table (
		GroupID int,
		UseRelative bit,
		Title varchar(50),
		ColumnOrder int
	)

	insert @groups (GroupID, UseRelative, ColumnOrder, Title) values 
		(@TotalInstructorDaysGroupID, 0, null, 'Total Instructor Days'),
		(@FreeDaysGroupID, 1, 1, 'Free Days'),
		(@DaytimeTrainingGroupID, 1, 2, 'Daytime Training'), 
		(@NonWorkGroupID, 0, 5, null), 
		(@OtherTrainingGroupID, 1, 3, null), 
		(@NonTrainingGroupID, 1, 4, null), 
		(@EveningTrainingGroupID, 0, 6, null)

	declare @sections table (
		SectionID int
	)

	insert @sections (SectionID)
	select distinct cast(val as int)
	from dbo.SplitString(@SectionIDs, ',')

	declare @eventData table (
		EventID int,
		StartDate date,
		EndDate date,
		DaysInPeriod float,
		DaysFullyResourced float
	)

	declare @totals table (
		GroupID int not null,
		DayCount float not null,
		AbsPercentage float null,
		RelPercentage float null
	)

	-- Fetch events. For each event, count how many days it covers within the report period, and how many of those 
	-- days are fully resourced. Then get the event's start and end dates (which may be outwith the report period).
	;with EventSummary as (
		select 
			ep.EventID, 
			sum(case when ep.DayType = 3 then 1 else 0.5 end) as NumDays,
			sum(case when ep.Status = 3 then (case when ep.DayType = 3 then 1 else 0.5 end) else 0 end) as DaysFullyResourced
		from EventPart ep
		inner join @daysOfWeek d on d.DayNum = datepart(dw, ep.Date)
		inner join Event e on ep.EventID = e.ID
		inner join Activity a on e.ActivityID = a.ID
		inner join @sections s on s.SectionID = a.SectionID
		where ep.Date between @from and @to
		group by ep.EventID
	)
	insert @eventData (EventID, StartDate, EndDate, DaysInPeriod, DaysFullyResourced)
	select 
		es.EventID, 
		min(ep.Date) as StartDate,
		max(ep.Date) as EndDate,
		es.NumDays as DaysInPeriod,
		es.DaysFullyResourced
	from EventSummary es 
	inner join EventPart ep on es.EventID = ep.EventID
	group by es.EventID, es.NumDays, es.DaysFullyResourced

	-- Total Instructor Days. We stop counting days when they leave the section or an open-ended unavailability period starts.
	;with DateTable as (
		select @from AS [DATE]
		union all
		select dateadd(dd, 1, [DATE]) 
		from DateTable 
		where dateadd(dd, 1, [DATE]) <= @to
	)
	insert @totals (GroupID, DayCount)
	select 
		@TotalInstructorDaysGroupID as GroupID,
		count(i.ID) as DayCount
	from @sections s
	cross join DateTable d
	inner join @daysOfWeek dw on dw.DayNum = datepart(dw, d.[DATE])
	left join InstructorSectionHistory h on s.SectionID = h.SectionID and d.[DATE] between h.StartDate and isnull(h.EndDate, '31 Dec 2999')
	left join Instructor i on i.ID = h.InstructorID and i.TrainingCentreID = @TrainingCentreID
	left join InstructorUnavailablePeriods p on p.InstructorID = i.ID and d.[DATE] >= p.StartDate and p.EndDate is null
	where p.ID is null 
	OPTION (MAXRECURSION 0)
	
	-- Fetch free days
	;with DateTable as (
		SELECT @from AS [DATE], e.ID as DayType
		from EventPartType e 
		where e.ID <> 3
		UNION ALL
		SELECT DATEADD(dd, 1, [DATE]), DayType as DayType 
		FROM DateTable 
		WHERE DATEADD(dd, 1, [DATE]) <= @to
	),
	Parts as (
		select ep.ID as EventPartID, ep.[Date], ep.DayType, iep.ID as InstructorEventPartID, iep.InstructorID
		from EventPart ep
		inner join InstructorEventPart iep on iep.DayPartID = ep.ID
		inner join Instructor i on i.ID = iep.InstructorID
		where ep.Date between @from and @to
	)
	insert @totals (GroupID, DayCount)
	select 
		@FreeDaysGroupID as GroupID,
		count(t.InstructorID)/2.0 as DayCount -- divide by 2 as DateTable outputs one record per half day
	from DateTable d
	inner join @daysOfWeek dw on dw.DayNum = datepart(dw, d.[DATE])
	cross apply (
		select i.ID as InstructorID
		from @sections s 
		inner join InstructorSectionHistory h on s.SectionID = h.SectionID and dbo.PeriodsOverlap(d.[DATE], d.[DATE], h.StartDate, h.EndDate) = 1
		inner join Instructor i on i.ID = h.InstructorID
		left join Parts pa on pa.InstructorID = i.ID and pa.[Date] = d.[DATE] and pa.DayType = d.DayType
		left join InstructorUnavailablePeriods p on p.InstructorID = i.ID 
			and dbo.PeriodsOverlap(d.[DATE], d.[DATE], p.StartDate, p.EndDate) = 1 and (p.DayTypeID = d.DayType or p.DayTypeID = 3)
		where i.TrainingCentreID = @TrainingCentreID and pa.InstructorEventPartID is null and p.ID is null
	) t
	OPTION (MAXRECURSION 0)

	-- Fetch daytime training
	insert @totals (GroupID, DayCount)
	select 
		@DaytimeTrainingGroupID as GroupID, 
		isnull(sum(case when dw.DayNum is null or h.ID is null then 0 else case when ep.DayType = 3 then 1 else 0.5 end end), 0) as DayCount
	from @daysOfWeek dw 
	inner join EventPart ep on ep.[Date] between @from and @to and dw.DayNum = datepart(dw, ep.[Date])
	inner join InstructorEventPart iep on ep.ID = iep.DayPartID
	inner join Instructor i on i.ID = iep.InstructorID and i.TrainingCentreID = @TrainingCentreID
	inner join InstructorSectionHistory h on i.ID = h.InstructorID and dbo.PeriodsOverlap(ep.[Date], ep.[Date], h.StartDate, h.EndDate) = 1
	inner join @sections s on s.SectionID = h.SectionID

	-- Fetch unavailability periods (excluding open-ended ones)
	insert @totals (GroupID, DayCount)
	select 
		g.ID as GroupID,
		sum(dbo.DaysInPeriod2(p.StartDate, p.EndDate, h.StartDate, h.EndDate, @from, @to, @countWeekdays, @countWeekends, p.DayTypeID)) as DayCount
	from InstructorUnavailableReasonGroups g
	inner join UnavailableReasons r on g.ID = r.UnavailableReasonGroupID
	inner join InstructorUnavailablePeriods p on p.UnavailableReasonID = r.ID and p.EndDate is not null
		and dbo.PeriodsOverlap(@from, @to, p.StartDate, p.EndDate) = 1
	inner join Instructor i on p.InstructorID = i.ID and i.TrainingCentreID = @TrainingCentreID 
	inner join InstructorSectionHistory h on i.ID = h.InstructorID 
		and dbo.PeriodsOverlap(p.StartDate, p.EndDate, h.StartDate, h.EndDate) = 1
		and dbo.PeriodsOverlap(@from, @to, h.StartDate, h.EndDate) = 1
	inner join @sections s on s.SectionID = h.SectionID
	group by g.ID

	-- Calculate absolute percentages
	update t1
	set t1.AbsPercentage = isnull(round(t1.DayCount / nullif(t2.DayCount, 0) * 100, 2), 0)
	from @totals t1
	inner join @totals t2 on t2.GroupID = @TotalInstructorDaysGroupID
	
	-- Calculate relative percentages
	update t1
	set t1.RelPercentage = isnull(round(t1.DayCount / nullif(t3.DayCount, 0) * 100, 2), 0)
	from @totals t1
	inner join @groups g1 on t1.GroupID = g1.GroupID and g1.UseRelative = 1
	cross apply (
		select sum(t2.DayCount) as DayCount
		from @totals t2
		inner join @groups g2 on t2.GroupID = g2.GroupID and g2.UseRelative = 1
	) t3

	-- DataSet1
	if isnull(@ReturnDataset, 1) = 1
		select 
			dbo.EventCode(a.Code, e.EventNumber, e.FinanciaYear) as EventCode,
			a.Title as EventTitle,
			d.DaysInPeriod as NumberOfDays,
			d.DaysFullyResourced as DaysFullyResourced,
			d.StartDate as StartDate,
			d.EndDate as EndDate,
			es.Title as OverallStatus,
			'Day' as DayEveningString
		from @eventData d
		inner join Event e on d.EventID = e.ID
		inner join Activity a on e.ActivityID = a.ID
		inner join EventStatus es on es.ID = e.Status
		order by d.StartDate, d.EndDate, a.Code, e.EventNumber

	-- DataSet2
	if isnull(@ReturnDataset, 2) = 2
		select 
			t1.DaytimeTraining as TotalTrainingDelivery,
			t2.DaytimeAbsPerc as TotalTrainingDeliveryAbsolutePercent,
			t3.DaytimeRelPerc as TotalTrainingDeliveryRelativePercent,
			t1.NonTraining as TotalNonTrainingRelated,
			t2.NonTrainAbsPerc as TotalNonTrainingRelatedAbsolutePercent,
			t3.NonTrainRelPerc as TotalNonTrainingRelatedRelativePercent,
			t1.NonWork as TotalNonWorkRelated,
			t2.NonWorkAbsPerc as TotalNonWorkRelatedAbsolutePercent,
			t1.OtherTraining as TotalOtherTrainingRelated,
			t2.OtherTrainAbsPerc as TotalOtherTrainingRelatedAbsolutePercent,
			t3.OtherTrainRelPerc as TotalOtherTrainingRelatedRelativePercent,
			t1.EveningTraining as TotalEveningDelivery,
			t2.EveningAbsPerc as TotalEveningDeliveryAbsolutePercent,
			t1.FreeDays as TotalFreeDays,
			t2.FreeAbsPerc as TotalFreeDaysAbsolutePercent,
			t3.FreeRelPerc as TotalFreeDaysRelativePercent,
			t1.DaytimeTraining + t1.OtherTraining + t1.NonTraining as TotalDaysBusy,
			t2.DaytimeAbsPerc + t2.OtherTrainAbsPerc + t2.NonTrainAbsPerc as TotalDaysBusyAbsolutePercent,
			t3.DaytimeRelPerc + t3.OtherTrainRelPerc + t3.NonTrainRelPerc as TotalDaysBusyRelativePercent,
			t1.TotalWorkDays as TotalWorkingDaysInReport,
			t2.TotalWorkAbsPerc as TotalWorkingDaysInReportAbsolutePercent
		from (
			select 
				isnull([999], 0) as TotalWorkDays, 
				isnull([998], 0) as FreeDays, 
				isnull([0], 0) as DaytimeTraining, 
				isnull([2], 0) as NonWork, 
				isnull([3], 0) as OtherTraining, 
				isnull([4], 0) as NonTraining, 
				isnull([5], 0) as EveningTraining
			from (select GroupID, DayCount from @totals) as SourceTable
			pivot (sum(DayCount) for GroupID in ([999], [998], [0], [2], [3], [4], [5])) as PivotTable
		) t1
		cross join (
			select 
				round(isnull([999], 0),2) as TotalWorkAbsPerc, 
				round(isnull([998], 0),2) as FreeAbsPerc, 
				round(isnull([0], 0),2) as DaytimeAbsPerc, 
				round(isnull([2], 0),2) as NonWorkAbsPerc, 
				round(isnull([3], 0),2) as OtherTrainAbsPerc, 
				round(isnull([4], 0),2) as NonTrainAbsPerc, 
				round(isnull([5], 0),2) as EveningAbsPerc
			from (select GroupID, AbsPercentage from @totals) as SourceTable
			pivot (sum(AbsPercentage) for GroupID in ([999], [998], [0], [2], [3], [4], [5])) as PivotTable
		) t2
		cross join (
			select 
				round(isnull([998], 0),2) as FreeRelPerc, 
				round(isnull([0], 0),2) as DaytimeRelPerc, 
				round(isnull([3], 0),2) as OtherTrainRelPerc, 
				round(isnull([4], 0),2) as NonTrainRelPerc
			from (select GroupID, RelPercentage from @totals) as SourceTable
			pivot (sum(RelPercentage) for GroupID in ([998], [0], [3], [4])) as PivotTable
		) t3

	SET NOCOUNT OFF
END
