CREATE PROCEDURE [dbo].[ReportSectionSignOff]
	@TrainingCentreID int,
	@from date,
	@to date,
	@SectionIDs varchar(max),
	@countWeekdays bit,
	@countWeekends bit,
	@ReturnDataset int = null
AS
BEGIN
	SET NOCOUNT ON

	declare @daysOfWeek table (DayNum int)

	if @countWeekdays = 1
		insert @daysOfWeek values (2),(3),(4),(5),(6)

	if @countWeekends = 1
		insert @daysOfWeek values (1),(7)

	declare @sections table (
		SectionID int
	)

	insert @sections (SectionID)
	select distinct cast(val as int)
	from dbo.SplitString(@SectionIDs, ',')
	
	declare @DaytimeTrainingGroupID int
	declare @NonWorkGroupID int
	declare @OtherTrainingGroupID int
	declare @NonTrainingGroupID int
	declare @EveningTrainingGroupID int
	declare @FreeDaysGroupID int
	declare @TotalInstructorDaysGroupID int
	set @DaytimeTrainingGroupID = 0
	set @NonWorkGroupID = 2
	set @OtherTrainingGroupID = 3
	set @NonTrainingGroupID = 4
	set @EveningTrainingGroupID = 5
	set @FreeDaysGroupID = 998
	set @TotalInstructorDaysGroupID = 999

	-- Define whether the InstructorUnavailableReasonGroups (and the virtual groups for Free Days and Daytime Training) 
	-- use absolute or relative percentages, and what order the columns appear in within the report.
	declare @groups table (
		GroupID int,
		UseRelative bit,
		Title varchar(50),
		ColumnOrder int
	)

	insert @groups (GroupID, UseRelative, ColumnOrder, Title) values 
		(@TotalInstructorDaysGroupID, 0, null, 'Total Instructor Days'),
		(@FreeDaysGroupID, 1, 1, 'Free Days'),
		(@DaytimeTrainingGroupID, 1, 2, 'Daytime Training'), 
		(@NonWorkGroupID, 0, 5, null), 
		(@OtherTrainingGroupID, 1, 3, null), 
		(@NonTrainingGroupID, 1, 4, null), 
		(@EveningTrainingGroupID, 0, 6, null)
	
	update g
	set g.Title = rg.Title
	from @groups g
	inner join InstructorUnavailableReasonGroups rg on g.GroupID = rg.ID

	declare @eventPartData table (
		EventPartID int,
		EventPartDate date,
		EventPartDayType int
	)
	
	insert @eventPartData (EventPartID, EventPartDate, EventPartDayType)
	select ep.ID as EventPartID, ep.Date as EventPartDate, ep.DayType as EventPartDayType
	from EventPart ep
	inner join @daysOfWeek dw on dw.DayNum = datepart(dw, ep.Date) 
	inner join Event e on ep.EventID = e.ID
	inner join Activity a on e.ActivityID = a.ID
	inner join @sections s on s.SectionID = a.SectionID
	where ep.Date between @from and @to 

	declare @eventPartResults table (
		WeekNum int null,
		[Date] date null,
		AMPM varchar(5) null,
		EventCode varchar(50) null,
		EventStatus varchar(20) null,
		EventTitle varchar(100) null,
		ResourcedStatusChar varchar(1) null
	)

	;with DateTable as (
		SELECT @from AS [DATE], e.ID as DayType
		from EventPartType e 
		where e.ID <> 3
		UNION ALL
		SELECT DATEADD(dd, 1, [DATE]), DayType as DayType 
		FROM DateTable 
		WHERE DATEADD(dd, 1, [DATE]) <= @to
	)
	insert @eventPartResults (WeekNum, [Date], AMPM, EventCode, EventStatus, EventTitle, ResourcedStatusChar)
	select 
		ceiling((datediff(d, @from, dt.DATE) + 1) / 7.0) as WeekNum,
		dt.DATE, ept.Code as AMPM, 
		dbo.EventCode(a.Code, e.EventNumber, e.FinanciaYear) as EventCode, es.Title as EventStatus, 
		a.Title as EventTitle, rs.Code as ResourcedStatusChar
	from DateTable dt
	inner join @daysOfWeek dw on dw.DayNum = datepart(dw, dt.DATE) 
	left join @eventPartData epd on dt.DATE = epd.EventPartDate and dt.DayType = epd.EventPartDayType
	left join EventPart ep on ep.ID = epd.EventPartID
	left join EventPartType ept on dt.DayType = ept.ID
	left join ResourceStatus rs on ep.Status = rs.ID
	left join [Event] e on ep.EventID = e.ID
	left join EventStatus es on e.Status = es.ID
	left join Activity a on e.ActivityID = a.ID
	order by dt.DATE, ept.Code, a.Code, e.FinanciaYear, e.EventNumber
	OPTION (MAXRECURSION 0)

	declare @data table (
		GroupID int not null,
		WeekNum int null,
		[Date] date null,
		DayCount float not null,
		AbsPercentage float null,
		RelPercentage float null
	)

	-- Total Instructor Days. We stop counting days when they leave the section or an open-ended unavailability period starts.
	;with DateTable as (
		select @from AS [DATE]
		union all
		select dateadd(dd, 1, [DATE]) 
		from DateTable 
		where dateadd(dd, 1, [DATE]) <= @to
	)
	insert @data (GroupID, WeekNum, [Date], DayCount)
	select 
		@TotalInstructorDaysGroupID as GroupID,
		ceiling((datediff(d, @from, d.[DATE]) + 1) / 7.0) as WeekNum,
		d.[DATE] as [Date],
		count(i.ID) as DayCount
	from Section s
	inner join @sections ss on s.ID = ss.SectionID
	cross join DateTable d
	inner join @daysOfWeek dw on dw.DayNum = datepart(dw, d.[DATE])
	left join InstructorSectionHistory h on s.ID = h.SectionID and dbo.PeriodsOverlap(d.[DATE], d.[DATE], h.StartDate, h.EndDate) = 1
	left join Instructor i on i.ID = h.InstructorID and i.TrainingCentreID = @TrainingCentreID
	left join InstructorUnavailablePeriods p on p.InstructorID = i.ID and d.[DATE] >= p.StartDate and p.EndDate is null
	where p.ID is null 
	group by d.[DATE]
	OPTION (MAXRECURSION 0)

	-- Gather daytime training stats
	insert @data (GroupID, WeekNum, [Date], DayCount)
	select 
		@DaytimeTrainingGroupID as GroupID, 
		ceiling((datediff(d, @from, ep.[Date]) + 1) / 7.0) as WeekNum,
		ep.[Date] as [Date],
		isnull(sum(case when dw.DayNum is null or h.ID is null then 0 else case when ep.DayType = 3 then 1 else 0.5 end end), 0) as DayCount
	from EventPart ep 
	inner join @daysOfWeek dw on dw.DayNum = datepart(dw, ep.Date)
	inner join InstructorEventPart iep on ep.ID = iep.DayPartID
	inner join Instructor i on i.ID = iep.InstructorID and i.TrainingCentreID = @TrainingCentreID
	inner join InstructorSectionHistory h on i.ID = h.InstructorID and dbo.PeriodsOverlap(ep.[Date], ep.[Date], h.StartDate, h.EndDate) = 1
	inner join @sections s on s.SectionID = h.SectionID
	where ep.[Date] between @from and @to
	group by ep.[Date]

	-- Gather free day stats
	;with DateTable as (
		SELECT @from AS [DATE], e.ID as DayType
		from EventPartType e 
		where e.ID <> 3
		UNION ALL
		SELECT DATEADD(dd, 1, [DATE]), DayType as DayType 
		FROM DateTable 
		WHERE DATEADD(dd, 1, [DATE]) <= @to
	),
	Parts as (
		select ep.ID as EventPartID, ep.Date, ep.DayType, iep.ID as InstructorEventPartID, iep.InstructorID
		from EventPart ep
		inner join InstructorEventPart iep on iep.DayPartID = ep.ID
		where ep.Date between @from and @to
	)
	insert @data (GroupID, WeekNum, [Date], DayCount)
	select 
		@FreeDaysGroupID as GroupID,
		ceiling((datediff(d, @from, d.[DATE]) + 1) / 7.0) as WeekNum,
		d.[DATE] as [Date],
		count(t.InstructorID)/2.0 as DayCount -- divide by 2 as DateTable outputs one record per half day
	from Section s 
	inner join @sections ss on s.ID = ss.SectionID
	cross join DateTable d
	inner join @daysOfWeek dw on dw.DayNum = datepart(dw, d.DATE)
	cross apply (
		select i.ID as InstructorID
		from Instructor i 
		inner join InstructorSectionHistory h on i.ID = h.InstructorID and s.ID = h.SectionID 
			and dbo.PeriodsOverlap(d.[DATE], d.[DATE], h.StartDate, h.EndDate) = 1
		left join Parts pa on pa.InstructorID = i.ID and pa.[Date] = d.[DATE] and pa.DayType = d.DayType
		left join InstructorUnavailablePeriods p on p.InstructorID = i.ID 
			and dbo.PeriodsOverlap(d.[DATE], d.[DATE], p.StartDate, p.EndDate) = 1 and (p.DayTypeID = d.DayType or p.DayTypeID = 3)
		where i.TrainingCentreID = @TrainingCentreID and pa.InstructorEventPartID is null and p.ID is null
	) t
	group by d.[DATE]
	OPTION (MAXRECURSION 0)

	-- Fetch unavailability periods (excluding open-ended ones)
	;with DateTable as (
		select @from AS [DATE]
		union all
		select dateadd(dd, 1, [DATE]) 
		from DateTable 
		where dateadd(dd, 1, [DATE]) <= @to
	)
	insert @data (GroupID, WeekNum, [Date], DayCount)
	select 
		g.ID as GroupID,
		ceiling((datediff(d, @from, d.[DATE]) + 1) / 7.0) as WeekNum,
		d.[DATE] as [Date],
		sum(dbo.DaysInPeriod2(p.StartDate, p.EndDate, h.StartDate, h.EndDate, d.[DATE], d.[DATE], @countWeekdays, @countWeekends, p.DayTypeID)) as DayCount
	from DateTable d
	inner join @daysOfWeek dw on dw.DayNum = datepart(dw, d.DATE)
	cross join InstructorUnavailableReasonGroups g
	inner join UnavailableReasons r on g.ID = r.UnavailableReasonGroupID
	inner join InstructorUnavailablePeriods p on p.UnavailableReasonID = r.ID and p.EndDate is not null
		and dbo.PeriodsOverlap(d.[DATE], d.[DATE], p.StartDate, p.EndDate) = 1
	inner join Instructor i on p.InstructorID = i.ID and i.TrainingCentreID = @TrainingCentreID 
	inner join InstructorSectionHistory h on i.ID = h.InstructorID 
		and dbo.PeriodsOverlap(d.[DATE], d.[DATE], h.StartDate, h.EndDate) = 1
	inner join @sections s on s.SectionID = h.SectionID
	group by g.ID, d.[DATE]
	OPTION (MAXRECURSION 0)

	-- insert weekly totals
	insert @data (GroupID, WeekNum, [Date], DayCount)
	select d.GroupID, d.WeekNum, null as [Date], sum(d.DayCount) as DayCount
	from @data d
	group by d.GroupID, d.WeekNum

	-- calculate percentages
	update d1
	set d1.AbsPercentage = isnull(round(d1.DayCount / nullif(d2.DayCount, 0) * 100, 2), 0)
	from @data d1
	inner join @data d2 on isnull(d1.[Date], '31 Dec 2999') = isnull(d2.[Date], '31 Dec 2999') 
		and d1.WeekNum = d2.WeekNum and d2.GroupID = @TotalInstructorDaysGroupID

	update d1
	set d1.RelPercentage = isnull(round(d1.DayCount / nullif(d3.DayCount, 0) * 100, 2), 0)
	from @data d1
	inner join @groups g1 on d1.GroupID = g1.GroupID and g1.UseRelative = 1
	cross apply (
		select sum(d2.DayCount) as DayCount
		from @data d2
		inner join @groups g2 on d2.GroupID = g2.GroupID and g2.UseRelative = 1
		where isnull(d1.[Date], '31 Dec 2999') = isnull(d2.[Date], '31 Dec 2999') and d1.WeekNum = d2.WeekNum
	) d3
	
	-- DataSet1
	-- Union the events with the totals to return a single recordset. This enables the SSRS report to
	-- break down the events and totals by WeekNum. If they were separate datasets then the report would
	-- not be able to do that inside a single list.
	if isnull(@ReturnDataset, 1) = 1
		select 
			epr.WeekNum, epr.[Date], epr.AMPM, epr.EventCode, epr.EventStatus, epr.EventTitle, epr.ResourcedStatusChar,
			null as TotalTrainingDelivery, null as TotalAvailableNotAssigned, null as TotalNonTrainingRelated, 
			null as TotalNonWorkRelated, null as TotalOtherTrainingRelated, null as TotalEveningEvents, 
			null as TotalTrainingDeliveryAbsolutePercent, null as TotalAvailableNotAssignedAbsolutePercent, 
			null as TotalNonTrainingRelatedAbsolutePercent, null as TotalNonWorkRelatedAbsolutePercent, 
			null as TotalOtherTrainingRelatedAbsolutePercent, null as TotalEveningEventsAbsolutePercent, 
			null as TotalTrainingDeliveryRelativePercent, null as TotalAvailableNotAssignedRelativePercent, 
			null as TotalNonTrainingRelatedRelativePercent, null as TotalOtherTrainingRelatedRelativePercent, 
			null as TotalDaysBusy, null as TotalDaysBusyAbsolutePercent, null as TotalDaysBusyRelativePercent, 
			null as TotalWorkingDaysInReport, null as TotalWorkingDaysInReportAbsolutePercent
		from @eventPartResults epr
		union
		select 
			t1.WeekNum,
			t1.[Date],
			null as AMPM, null as EventCode, null as EventStatus, null as EventTitle, null as ResourcedStatusChar,
			t1.DaytimeTraining as TotalTrainingDelivery,
			t1.FreeDays as TotalAvailableNotAssigned,
			t1.NonTraining as TotalNonTrainingRelated,
			t1.NonWork as TotalNonWorkRelated,
			t1.OtherTraining as TotalOtherTrainingRelated,
			t1.EveningTraining as TotalEveningEvents,
			t2.DaytimeAbsPerc as TotalTrainingDeliveryAbsolutePercent,
			t2.FreeAbsPerc as TotalAvailableNotAssignedAbsolutePercent,
			t2.NonTrainAbsPerc as TotalNonTrainingRelatedAbsolutePercent,
			t2.NonWorkAbsPerc as TotalNonWorkRelatedAbsolutePercent,
			t2.OtherTrainAbsPerc as TotalOtherTrainingRelatedAbsolutePercent,
			t2.EveningAbsPerc as TotalEveningEventsAbsolutePercent,
			t3.DaytimeRelPerc as TotalTrainingDeliveryRelativePercent,
			t3.FreeRelPerc as TotalAvailableNotAssignedRelativePercent,
			t3.NonTrainRelPerc as TotalNonTrainingRelatedRelativePercent,
			t3.OtherTrainRelPerc as TotalOtherTrainingRelatedRelativePercent,
			t1.DaytimeTraining + t1.OtherTraining + t1.NonTraining as TotalDaysBusy,
			t2.DaytimeAbsPerc + t2.OtherTrainAbsPerc + t2.NonTrainAbsPerc as TotalDaysBusyAbsolutePercent,
			t3.DaytimeRelPerc + t3.OtherTrainRelPerc + t3.NonTrainRelPerc as TotalDaysBusyRelativePercent,
			t1.TotalWorkDays as TotalWorkingDaysInReport,
			t2.TotalWorkAbsPerc as TotalWorkingDaysInReportAbsolutePercent
		from (
			select 
				[Date],
				WeekNum,
				isnull([999], 0) as TotalWorkDays, 
				isnull([998], 0) as FreeDays, 
				isnull([0], 0) as DaytimeTraining, 
				isnull([2], 0) as NonWork, 
				isnull([3], 0) as OtherTraining, 
				isnull([4], 0) as NonTraining, 
				isnull([5], 0) as EveningTraining
			from (select [Date], WeekNum, GroupID, DayCount from @data) as SourceTable
			pivot (sum(DayCount) for GroupID in ([999], [998], [0], [2], [3], [4], [5])) as PivotTable
		) t1
		inner join (
			select 
				[Date],
				WeekNum,
				round(isnull([999], 0),2) as TotalWorkAbsPerc, 
				round(isnull([998], 0),2) as FreeAbsPerc, 
				round(isnull([0], 0),2) as DaytimeAbsPerc, 
				round(isnull([2], 0),2) as NonWorkAbsPerc, 
				round(isnull([3], 0),2) as OtherTrainAbsPerc, 
				round(isnull([4], 0),2) as NonTrainAbsPerc, 
				round(isnull([5], 0),2) as EveningAbsPerc
			from (select [Date], WeekNum, GroupID, AbsPercentage from @data) as SourceTable
			pivot (sum(AbsPercentage) for GroupID in ([999], [998], [0], [2], [3], [4], [5])) as PivotTable
		) t2 on isnull(t1.[Date], '31 Dec 2999') = isnull(t2.[Date], '31 Dec 2999') and t1.WeekNum = t2.WeekNum
		inner join (
			select 
				[Date],
				WeekNum,
				round(isnull([998], 0),2) as FreeRelPerc, 
				round(isnull([0], 0),2) as DaytimeRelPerc, 
				round(isnull([3], 0),2) as OtherTrainRelPerc, 
				round(isnull([4], 0),2) as NonTrainRelPerc
			from (select [Date], WeekNum, GroupID, RelPercentage from @data) as SourceTable
			pivot (sum(RelPercentage) for GroupID in ([998], [0], [3], [4])) as PivotTable
		) t3 on isnull(t1.[Date], '31 Dec 2999') = isnull(t3.[Date], '31 Dec 2999') and t1.WeekNum = t3.WeekNum

	SET NOCOUNT OFF
END
