CREATE FUNCTION [dbo].[PeriodsOverlap]
(
	@fromDate1 date, 
	@toDate1 date, 
	@fromDate2 date, 
	@toDate2 date
)
RETURNS BIT
AS
BEGIN
	DECLARE @result BIT
	
	SET @result = CASE WHEN (@fromDate1 between @fromDate2 and isnull(@toDate2, '31 Dec 2999') or 
							 @toDate1 between @fromDate2 and isnull(@toDate2, '31 Dec 2999') or 
							 @fromDate2 between @fromDate1 and @toDate1) THEN 1 ELSE 0 END
	
	RETURN @result
END