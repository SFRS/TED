CREATE PROCEDURE [dbo].[ReportInstructorAssignments]
	@from date,
	@to date,
	@InstructorID int,
	@countWeekdays bit,
	@countWeekends bit,
	@ReturnDataset int = null
AS
BEGIN
	SET NOCOUNT ON

	declare @daysOfWeek table (DayNum int)

	if @countWeekdays = 1
		insert @daysOfWeek values (2),(3),(4),(5),(6)

	if @countWeekends = 1
		insert @daysOfWeek values (1),(7)

	declare @DaytimeTrainingGroupID int
	declare @NonWorkGroupID int
	declare @OtherTrainingGroupID int
	declare @NonTrainingGroupID int
	declare @EveningTrainingGroupID int
	declare @FreeDaysGroupID int
	declare @TotalInstructorDaysGroupID int
	set @DaytimeTrainingGroupID = 0
	set @NonWorkGroupID = 2
	set @OtherTrainingGroupID = 3
	set @NonTrainingGroupID = 4
	set @EveningTrainingGroupID = 5
	set @FreeDaysGroupID = 998
	set @TotalInstructorDaysGroupID = 999

	-- Define whether the InstructorUnavailableReasonGroups (and the virtual groups for Free Days and Daytime Training) 
	-- use absolute or relative percentages, and what order the columns appear in within the report.
	declare @groups table (
		GroupID int,
		UseRelative bit,
		Title varchar(50),
		ColumnOrder int
	)

	insert @groups (GroupID, UseRelative, ColumnOrder, Title) values 
		(@TotalInstructorDaysGroupID, 0, null, 'Total Instructor Days'),
		(@FreeDaysGroupID, 1, 1, 'Free Days'),
		(@DaytimeTrainingGroupID, 1, 2, 'Daytime Training'), 
		(@NonWorkGroupID, 0, 5, null), 
		(@OtherTrainingGroupID, 1, 3, null), 
		(@NonTrainingGroupID, 1, 4, null), 
		(@EveningTrainingGroupID, 0, 6, null)

	declare @eventData table (
		RowNum int,
		EventID int,
		StartDate date,
		StartTime time,
		EndDate date,
		EndTime time,
		StartEventPartType int,
		EndEventPartType int,
		DaysCounted float,
		ConfirmedNoAdjacent bit
	)

	-- fetch event parts for the instructor, combining adjacent parts into a single record
	insert @eventData (RowNum, EventID, StartDate, StartTime, EndDate, EndTime, StartEventPartType, EndEventPartType, DaysCounted, ConfirmedNoAdjacent)
	select 
		row_number() over(order by ep.[Date], ep.StartTime) as RowNum,
		ep.EventID, ep.[Date], ep.StartTime, ep.[Date], ep.EndTime, ep.DayType, ep.DayType, 
		case when ep.DayType = 3 then 1 else 0.5 end as DaysCounted,
		0 as ConfirmedNoAdjacent
	from EventPart ep
	inner join InstructorEventPart iep on ep.ID = iep.DayPartID and iep.InstructorID = @InstructorID
	inner join @daysOfWeek dw on dw.DayNum = datepart(dw, ep.[Date])
	where ep.[Date] between @from and @to
	
	declare @CurrentRowNum int
	declare @CurrentEventID int
	declare @CurrentStartDate date
	declare @CurrentStartType int
	declare @PrevRowNum int
	declare @PrevEventID int
	declare @PrevEndDate date
	declare @PrevEndType int
	declare @diff int

	-- Loop around the data. In SQL 2012 we could do all this in a single SQL statement using lag & lead functions
	while exists (select * from @eventData where ConfirmedNoAdjacent = 0)
	begin
		set @CurrentRowNum = null
		set @CurrentEventID = null
		set @CurrentStartDate = null
		set @CurrentStartType = null
		set @PrevEventID = null
		set @PrevEndDate = null
		set @PrevEndType = null
		set @diff = null
		
		-- Get the latest row that may have an adjacent one prior to it
		set @CurrentRowNum = (select max(RowNum) from @eventData where ConfirmedNoAdjacent = 0)
		set @PrevRowNum = @CurrentRowNum - 1

		select @CurrentEventID = EventID, @CurrentStartDate = StartDate, @CurrentStartType = StartEventPartType
		from @eventData
		where RowNum = @CurrentRowNum

		-- Get the previous row, if any
		select @PrevEventID = EventID, @PrevEndDate = EndDate, @PrevEndType = EndEventPartType
		from @eventData
		where RowNum = @PrevRowNum

		if @PrevEventID is null
		begin
			-- No previous row found, setting ConfirmedNoAdjacent = 1 for the current row
			update @eventData
			set ConfirmedNoAdjacent = 1
			where RowNum = @CurrentRowNum

			continue
		end

		-- Get the difference in days between the previous and current rows
		set @diff = datediff(dd, @PrevEndDate, @CurrentStartDate)

		-- Check whether the rows are for the same event and are adjacent
		if @CurrentEventID = @PrevEventID and (
			@diff = 0 or (@diff = 1 and ((@CurrentStartType = 1 and @PrevEndType = 2) or (@CurrentStartType = 3 and @PrevEndType = 3))))
		begin
			-- The periods are adjacent, combine them into the previous row, delete the current row
			update a1
			set a1.EndDate = a2.EndDate, 
				a1.EndTime = a2.EndTime, 
				a1.EndEventPartType = a2.EndEventPartType, 
				a1.DaysCounted = a1.DaysCounted + a2.DaysCounted
			from @eventData a1
			inner join @eventData a2 on a2.RowNum = @CurrentRowNum
			where a1.RowNum = @PrevRowNum

			delete @eventData
			where RowNum = @CurrentRowNum
		end
		else
		begin
			-- The rows are not adjacent for the same event, set ConfirmedNoAdjacent = 1 on the current row
			update @eventData
			set ConfirmedNoAdjacent = 1
			where RowNum = @CurrentRowNum

			continue
		end
	end

	declare @assignmentResults table (
		EventCode varchar(100),
		Title varchar(100),
		EventStatus varchar(50),
		AvailabilityReason varchar(100),
		StartDate date,
		StartTime time,
		EndDate date,
		EndTime time,
		DaysCounted float
	)

	insert @assignmentResults (EventCode, Title, EventStatus, StartDate, StartTime, EndDate, EndTime, DaysCounted)
	select dbo.EventCode(a.Code, e.EventNumber, e.FinanciaYear) as EventCode, a.Title, es.Title as EventStatus,
		ad.StartDate, ad.StartTime, ad.EndDate, ad.EndTime, ad.DaysCounted
	from @eventData ad
	inner join [Event] e on e.ID = ad.EventID
	inner join Activity a on a.ID = e.ActivityID
	inner join EventStatus es on es.ID = e.Status
	
	-- fetch unavailable periods for the instructor
	insert @assignmentResults (Title, AvailabilityReason, StartDate, StartTime, EndDate, EndTime, DaysCounted)
	select 
		g.Title as Title, 
		r.Reason as AvailabilityReason, 
		p.StartDate, 
		cast(case when p.DayTypeID = 2 then '13:00' else '09:00' end as time) as StartTime,
		p.EndDate,
		cast(case when p.EndDate is null then null else (case when p.DayTypeID = 1 then '12:00' else '17:00' end) end as time) as EndTime,
		dbo.DaysInPeriod(p.StartDate, isnull(p.EndDate, '31 Dec 2999'), @from, @to, @countWeekdays, @countWeekends, p.DayTypeID) as DaysCounted
	from InstructorUnavailablePeriods p
	inner join UnavailableReasons r on r.ID = p.UnavailableReasonID
	inner join InstructorUnavailableReasonGroups g on g.ID = r.UnavailableReasonGroupID
	where p.InstructorID = @InstructorID 
	and (p.StartDate between @from and @to or p.EndDate between @from and @to or @from between p.StartDate and isnull(p.EndDate, '31 Dec 2999'))
	and dbo.DaysInPeriod(p.StartDate, isnull(p.EndDate, '31 Dec 2999'), @from, @to, @countWeekdays, @countWeekends, p.DayTypeID) > 0

	declare @totals table (
		GroupID int not null,
		DayCount float not null,
		AbsPercentage float null,
		RelPercentage float null
	)

	-- Fetch total instructor days. We stop counting from the start of any open-ended unavailability period.
	-- We also do not count days on which the instructor does not belong to a section (i.e. is inactive/retired).
	;with DateTable as (
		select @from AS [DATE]
		union all
		select dateadd(dd, 1, [DATE]) 
		from DateTable 
		where dateadd(dd, 1, [DATE]) <= @to
	)
	insert @totals (GroupID, DayCount)
	select 
		@TotalInstructorDaysGroupID as GroupID,
		count(i.ID) as DayCount
	from DateTable d
	inner join @daysOfWeek dw on dw.DayNum = datepart(dw, d.Date)
	inner join Instructor i on i.ID = @InstructorID
	left join InstructorUnavailablePeriods p on p.InstructorID = i.ID and d.DATE >= p.StartDate and p.EndDate is null
	inner join InstructorSectionHistory h on h.InstructorID = i.ID and dbo.PeriodsOverlap(d.DATE, d.DATE, h.StartDate, h.EndDate) = 1
	where p.ID is null 
	OPTION (MAXRECURSION 0)
	
	-- Fetch free days
	;with DateTable as (
		SELECT @from AS [DATE], e.ID as DayType
		from EventPartType e 
		where e.ID <> 3
		UNION ALL
		SELECT DATEADD(dd, 1, [DATE]), DayType as DayType 
		FROM DateTable 
		WHERE DATEADD(dd, 1, [DATE]) <= @to
	),
	Parts as (
		select ep.ID as EventPartID, ep.Date, ep.DayType, iep.ID as InstructorEventPartID, iep.InstructorID
		from EventPart ep
		inner join InstructorEventPart iep on iep.DayPartID = ep.ID
		inner join Instructor i on i.ID = iep.InstructorID
		where ep.Date between @from and @to
	)
	insert @totals (GroupID, DayCount)
	select 
		@FreeDaysGroupID as GroupID,
		count(t.InstructorID)/2.0 as DayCount -- divide by 2 as DateTable outputs one record per half day
	from DateTable d
	inner join @daysOfWeek dw on dw.DayNum = datepart(dw, d.DATE)
	cross apply (
		select i.ID as InstructorID
		from Instructor i 
		left join Parts pa on pa.InstructorID = i.ID and pa.Date = d.DATE and pa.DayType = d.DayType
		left join InstructorUnavailablePeriods p on p.InstructorID = i.ID 
			and d.DATE between p.StartDate and isnull(p.EndDate, '31 Dec 2999') and (p.DayTypeID = d.DayType or p.DayTypeID = 3)
		where i.ID = @InstructorID and pa.InstructorEventPartID is null and p.ID is null
	) t
	OPTION (MAXRECURSION 0)

	-- Fetch daytime training
	insert @totals (GroupID, DayCount)
	select 
		@DaytimeTrainingGroupID as GroupID, 
		isnull(sum(case when dw.DayNum is null then 0 else case when ep.DayType = 3 then 1 else 0.5 end end), 0) as DayCount
	from @daysOfWeek dw 
	inner join EventPart ep on ep.Date between @from and @to and dw.DayNum = datepart(dw, ep.Date)
	inner join InstructorEventPart iep on ep.ID = iep.DayPartID and iep.InstructorID = @InstructorID

	-- Fetch unavailability periods (excluding open-ended ones)
	insert @totals (GroupID, DayCount)
	select 
		g.ID as GroupID,
		sum(dbo.DaysInPeriod(p.StartDate, p.EndDate, @from, @to, @countWeekdays, @countWeekends, p.DayTypeID)) as DayCount
	from InstructorUnavailableReasonGroups g
	inner join UnavailableReasons r on g.ID = r.UnavailableReasonGroupID
	inner join InstructorUnavailablePeriods p on p.UnavailableReasonID = r.ID and p.EndDate is not null and p.InstructorID = @InstructorID
	where (p.StartDate between @from and @to or p.EndDate between @from and @to or @from between p.StartDate and p.EndDate)
	group by g.ID

	-- Calculate absolute percentages
	update t1
	set t1.AbsPercentage = isnull(round(t1.DayCount / nullif(t2.DayCount, 0) * 100, 2), 0)
	from @totals t1
	inner join @totals t2 on t2.GroupID = @TotalInstructorDaysGroupID
	
	-- Calculate relative percentages
	update t1
	set t1.RelPercentage = isnull(round(t1.DayCount / nullif(t3.DayCount, 0) * 100, 2), 0)
	from @totals t1
	inner join @groups g1 on t1.GroupID = g1.GroupID and g1.UseRelative = 1
	cross apply (
		select sum(t2.DayCount) as DayCount
		from @totals t2
		inner join @groups g2 on t2.GroupID = g2.GroupID and g2.UseRelative = 1
	) t3

	-- DataSet1
	if isnull(@ReturnDataset, 1) = 1
		select 
			EventCode as Activity,
			Title as EventTitle,
			EventStatus as EventStatus,
			AvailabilityReason as AvailabilityReasons,
			StartDate as StartDate,
			StartTime as StartAMPM,
			EndDate as EndDate,
			EndTime as EndAMPM,
			-- The following field is casted to varchar because AutoMapper fails to read the float value correctly
			cast(DaysCounted as varchar) as DaysCounted
		from @assignmentResults
		order by StartDate, StartTime

	-- DataSet2
	if isnull(@ReturnDataset, 2) = 2
		select i.FirstName as FirstName, i.LastName as LastName, ISNULL(s.Title, '*INACTIVE') as SectionName
		from Instructor i
		left join Section s on s.ID = i.SectionID
		where i.ID = @InstructorID

	-- DataSet3
	if isnull(@ReturnDataset, 3) = 3
		select 
			t1.DaytimeTraining + t1.OtherTraining + t1.NonTraining as TotalDaysBusy,
			t1.FreeDays as TotalFreeDays,
			t1.DaytimeTraining as TotalDaysTraining,
			t1.OtherTraining as TotalDaysOtherTraining,
			t1.NonTraining as TotalDaysNonTraining,
			t1.NonWork as TotalDaysNonWork,
			t1.EveningTraining as TotalEveningTraining,
			t1.TotalWorkDays as TotalWorkingDaysInReport,
			t3.DaytimeRelPerc + t3.OtherTrainRelPerc + t3.NonTrainRelPerc as TotalDaysBusyRelativePercent,
			t3.FreeRelPerc as TotalFreeDaysRelativePercent,
			t3.DaytimeRelPerc as TotalDaysTrainingRelativePercent,
			t3.OtherTrainRelPerc as TotalDaysOtherTrainingRelativePercent,
			t3.NonTrainRelPerc as TotalDaysNonTrainingRelativePercent,
			t2.DaytimeAbsPerc + t2.OtherTrainAbsPerc + t2.NonTrainAbsPerc as TotalDaysBusyAbsolutePercent,
			t2.FreeAbsPerc as TotalFreeDaysAbsolutePercent,
			t2.DaytimeAbsPerc as TotalDaysTrainingAbsolutePercent,
			t2.OtherTrainAbsPerc as TotalDaysOtherTrainingAbsolutePercent,
			t2.NonTrainAbsPerc as TotalDaysNonTrainingAbsolutePercent,
			t2.NonWorkAbsPerc as TotalDaysNonWorkAbsolutePercent,
			t2.EveningAbsPerc as TotalEveningTrainingAbsolutePercent,
			t2.TotalWorkAbsPerc as TotalWorkingDaysInReportAbsolutePercent
		from (
			select 
				isnull([999], 0) as TotalWorkDays, 
				isnull([998], 0) as FreeDays, 
				isnull([0], 0) as DaytimeTraining, 
				isnull([2], 0) as NonWork, 
				isnull([3], 0) as OtherTraining, 
				isnull([4], 0) as NonTraining, 
				isnull([5], 0) as EveningTraining
			from (select GroupID, DayCount from @totals) as SourceTable
			pivot (sum(DayCount) for GroupID in ([999], [998], [0], [2], [3], [4], [5])) as PivotTable
		) t1
		cross join (
			select 
				round(isnull([999], 0),2) as TotalWorkAbsPerc, 
				round(isnull([998], 0),2) as FreeAbsPerc, 
				round(isnull([0], 0),2) as DaytimeAbsPerc, 
				round(isnull([2], 0),2) as NonWorkAbsPerc, 
				round(isnull([3], 0),2) as OtherTrainAbsPerc, 
				round(isnull([4], 0),2) as NonTrainAbsPerc, 
				round(isnull([5], 0),2) as EveningAbsPerc
			from (select GroupID, AbsPercentage from @totals) as SourceTable
			pivot (sum(AbsPercentage) for GroupID in ([999], [998], [0], [2], [3], [4], [5])) as PivotTable
		) t2
		cross join (
			select 
				round(isnull([998], 0),2) as FreeRelPerc, 
				round(isnull([0], 0),2) as DaytimeRelPerc, 
				round(isnull([3], 0),2) as OtherTrainRelPerc, 
				round(isnull([4], 0),2) as NonTrainRelPerc
			from (select GroupID, RelPercentage from @totals) as SourceTable
			pivot (sum(RelPercentage) for GroupID in ([998], [0], [3], [4])) as PivotTable
		) t3

	-- DataSet4
	if isnull(@ReturnDataset, 4) = 4
		-- The following fields are casted to varchar because AutoMapper fails to read the float values correctly
		select cast(dbo.DaysInPeriod(@from, @to, @from, @to, 1, 1, 3) as varchar) as TotalDays, 
			   cast(dbo.DaysInPeriod(@from, @to, @from, @to, @countWeekdays, @countWeekends, 3) as varchar) as DaysCounted

	SET NOCOUNT OFF
END
