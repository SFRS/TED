﻿CREATE PROCEDURE [dbo].[GetEventCalendarView] 
	@startDate	VARCHAR(10),
	@endDate	VARCHAR(10),
	@page		INT,
	@size		INT,
	@status		VARCHAR(400) = NULL,
	@section	VARCHAR(400) = NULL,
	@totalCount INT OUTPUT,
	@trainingCentreID VARCHAR(4) = NULL -- not implemented as yet. Need to define how we will figure out issues around Event where user has chosen multiple venues across different training centres

AS
BEGIN
	SET NOCOUNT ON
    DECLARE @sql NVARCHAR(MAX) = N'' 
    DECLARE @sql2 NVARCHAR(MAX) = N''
 
	--build the dynamic pivot columns for each of 14 day parts for the week
	-- ;1 indicates AM, ;2 indicates PM
	SELECT TOP (7)  
    @sql += N',[' + 
		CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
      (ORDER BY [object_id])-1, @StartDate), 03) + ';1]' + N',[' + 
		CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
      (ORDER BY [object_id])-1, @StartDate), 03) + ';2]'
    FROM sys.all_objects ORDER BY [object_id]; 
 
 SELECT TOP (7)  
    @sql2 += N',[' + 
		CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
      (ORDER BY [object_id])-1, @StartDate), 03) + ';1]' + N',[' + 
		CONVERT(CHAR(8), DATEADD(DAY, ROW_NUMBER() OVER  
      (ORDER BY [object_id])-1, @StartDate), 03) + ';2]'
    FROM sys.all_objects ORDER BY [object_id]; 

DECLARE @filter varchar(50)
SET  @filter = NULL
IF(@section IS NULL AND @status IS NULL)
	SET  @filter = ''
 
-- query to count the total rows that match the query, before paging 
SELECT @sql = N'

	SELECT *, ROW_NUMBER() OVER(ORDER BY ID) Corr 
	FROM 
	( 
		SELECT ID, [Date], Title + '';'' + Convert(char(1), [Status]) + '';'' + Code + '';'' + Convert(varchar(Max), [EventID]) + '';'' + Convert(varchar(Max), ResourceStatus) as stringvalue
		FROM vwEventCalendarBase
		WHERE 
			(ISNULL(SectionID, -1) IN (-1, ' + ISNULL(@section, 'SectionID') + ')) AND
			(ISNULL(Status, -1) IN (-1, ' + ISNULL(@status, 'Status') + ')) AND
			baseDate >= ''' + @startDate + ''' AND baseDate  <= ''' + @endDate + '''			
							
	) as d 
	PIVOT 
	( 
		min([stringvalue])     
		for [Date] in  
	  (' + STUFF(@sql, 1, 1, '') + ')  
	)  
	as p			
' 

print @sql
EXEC sp_executesql @sql
SET @totalCount = @@rowcount
 
--baseDate >= ''' + @startDate + ''' AND baseDate  < ''' + @endDate + ''' AND	
--SectionID = COALESCE(' + ISNULL(@section, 'null') + ', sectionID) AND
--Status = COALESCE(' + ISNULL(@status, 'null') + ', status) 
--ISNULL(@filter + '', 'AND baseDate between '''+ @startDate + ''' AND ''' + @endDate + '''') + '	 
 
SELECT @sql2 = N'
WITH CTE AS 
( 
	SELECT *, ROW_NUMBER() OVER(ORDER BY ID) Corr 
	FROM 
	( 
		SELECT ID, [Date], Title + '';'' + Convert(char(1), [Status]) + '';'' + Code + '';'' + Convert(varchar(Max), [EventID]) + '';'' + Convert(varchar(Max), ResourceStatus) as stringvalue
		FROM vwEventCalendarBase
		WHERE 
			(ISNULL(SectionID, -1) IN (-1, ' + ISNULL(@section, 'SectionID') + ')) AND
			(ISNULL(Status, -1) IN (-1, ' + ISNULL(@status, 'Status') + ')) AND
			baseDate >= ''' + @startDate + ''' AND baseDate  <= ''' + @endDate + '''
							
	) as d 
	PIVOT 
	( 
		min([stringvalue])     
		for [Date] in  
	  (' + STUFF(@sql2, 1, 1, '') + ')  
	)  
	as p		
)
SELECT * 
FROM CTE 
WHERE Corr BETWEEN ('+ CONVERT(varchar(3), @size) + ' * (' + CONVERT(varchar(4), @page) + ' - 1))+1 AND ('+ CONVERT(varchar(3), @size) + '*' + CONVERT(varchar(4), @page) + ')
' 
print @sql2
EXEC sp_executesql @sql2
END
