﻿CREATE TABLE [dbo].[VenueTagVenue] (
    [ID]         INT IDENTITY (1, 1) NOT NULL,
    [VenueID]    INT NOT NULL,
    [VenueTagID] INT NOT NULL
);

