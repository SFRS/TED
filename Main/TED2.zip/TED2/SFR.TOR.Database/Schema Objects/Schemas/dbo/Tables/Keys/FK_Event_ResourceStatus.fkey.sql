﻿ALTER TABLE [dbo].[Event]
    ADD CONSTRAINT [FK_Event_ResourceStatus] FOREIGN KEY ([Resourced]) REFERENCES [dbo].[ResourceStatus] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

