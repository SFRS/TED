﻿CREATE TABLE [dbo].[Section] (
    [ID]    INT      IDENTITY (1, 1)   NOT NULL,
    [Title] NVARCHAR (50) NOT NULL
);





