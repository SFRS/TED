﻿CREATE TABLE [dbo].[ActivityPart] (
    [ID]          INT           IDENTITY (1, 1) NOT NULL,
    [ActivityID]  INT           NOT NULL,
    [DayTypeID]   INT           NOT NULL,
    [Name]        VARCHAR (50)  NOT NULL,
    [Description] VARCHAR (100) NULL
);



