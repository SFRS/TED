﻿ALTER TABLE [dbo].[ActivityDefinition]
    ADD CONSTRAINT [FK_ActivityDefinition_Activity] FOREIGN KEY ([ActivityID]) REFERENCES [dbo].[Activity] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

