﻿CREATE TABLE [dbo].[GroupCalendar] (
    [ID]               INT            IDENTITY (1, 1) NOT NULL,
    [Title]            NVARCHAR (100) NOT NULL,
    [GroupDate]        DATE           NOT NULL,
    [TrainingCentreID] INT            NOT NULL
);

