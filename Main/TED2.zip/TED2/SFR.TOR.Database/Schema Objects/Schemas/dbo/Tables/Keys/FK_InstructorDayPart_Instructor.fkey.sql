﻿ALTER TABLE [dbo].[InstructorEventPart]
    ADD CONSTRAINT [FK_InstructorDayPart_Instructor] FOREIGN KEY ([InstructorID]) REFERENCES [dbo].[Instructor] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

