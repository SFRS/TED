﻿CREATE TABLE [dbo].[User] (
    [ID]                      INT           IDENTITY (1, 1) NOT NULL,
    [UserName]                VARCHAR (150) NOT NULL,
    [DefaultTrainingCentreID] INT           NOT NULL,
    [DefaultShowAllResources] BIT           NOT NULL
);

