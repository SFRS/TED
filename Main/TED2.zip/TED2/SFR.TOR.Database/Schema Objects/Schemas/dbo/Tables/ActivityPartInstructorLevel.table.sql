﻿CREATE TABLE [dbo].[ActivityPartInstructorLevel] (
    [ID]              INT IDENTITY (1, 1) NOT NULL,
    [ActivityPartID]  INT NOT NULL,
    [LeadsCount]      INT NULL,
    [AssessorCount]   INT NULL,
    [InstructorCount] INT NULL,
    [ShadowCount]     INT NULL,
	[SpecialistCount] INT NULL
);

