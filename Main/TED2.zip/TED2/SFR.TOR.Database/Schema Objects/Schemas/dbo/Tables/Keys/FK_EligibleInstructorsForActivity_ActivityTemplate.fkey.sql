﻿ALTER TABLE [dbo].[EligibleInstructorsForActivity]
    ADD CONSTRAINT [FK_EligibleInstructorsForActivity_ActivityTemplate] FOREIGN KEY ([ActivityTemplateID]) REFERENCES [dbo].[Activity] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

