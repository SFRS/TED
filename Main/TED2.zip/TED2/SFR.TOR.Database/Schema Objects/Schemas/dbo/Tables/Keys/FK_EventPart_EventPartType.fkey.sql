﻿ALTER TABLE [dbo].[EventPart]
    ADD CONSTRAINT [FK_EventPart_EventPartType] FOREIGN KEY ([DayType]) REFERENCES [dbo].[EventPartType] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

