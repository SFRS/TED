﻿CREATE TABLE [dbo].[EquipmentUnavailablePeriods] (
    [ID]                           INT				IDENTITY (1, 1) NOT NULL,
    [EquipmentID]                  INT				NOT NULL,
    [StartDate]                    DATE				NOT NULL,
    [StartTime]                    TIME (7)			NULL,
    [EndDate]                      DATE				NULL,
    [EndTime]                      TIME (7)			NULL,
    [EquipmentUnavailableReasonID] INT				NOT NULL,
    [DayTypeID]                    INT				NOT NULL,
	[Comments]					   VARCHAR (200)	NULL
);
