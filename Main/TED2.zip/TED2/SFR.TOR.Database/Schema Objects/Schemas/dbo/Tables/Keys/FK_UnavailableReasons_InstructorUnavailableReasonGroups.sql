﻿ALTER TABLE [dbo].[UnavailableReasons]
    ADD CONSTRAINT [FK_UnavailableReasons_InstructorUnavailableReasonGroups] FOREIGN KEY ([UnavailableReasonGroupID]) REFERENCES [dbo].[InstructorUnavailableReasonGroups] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;
