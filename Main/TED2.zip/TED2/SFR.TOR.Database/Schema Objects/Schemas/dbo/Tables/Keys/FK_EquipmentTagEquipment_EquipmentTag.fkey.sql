﻿ALTER TABLE [dbo].[EquipmentTagEquipment]
    ADD CONSTRAINT [FK_EquipmentTagEquipment_EquipmentTag] FOREIGN KEY ([EquipmentTagID]) REFERENCES [dbo].[EquipmentTag] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

