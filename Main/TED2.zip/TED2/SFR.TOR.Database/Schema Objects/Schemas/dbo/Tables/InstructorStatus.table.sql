﻿/*CREATE TABLE [dbo].[InstructorStatus] (
    [ID]    INT          NOT NULL,
    [Title] VARCHAR (50) NOT NULL
);*/

