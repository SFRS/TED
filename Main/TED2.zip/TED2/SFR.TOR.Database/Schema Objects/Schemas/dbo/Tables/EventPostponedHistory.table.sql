﻿CREATE TABLE [dbo].[EventPostponedHistory] (
    [ID]          INT           IDENTITY (1, 1) NOT NULL,
    [EventID]     INT           NOT NULL,
    [PostponedOn] DATETIME      NOT NULL,
    [Reason]      VARCHAR (500) NULL,
    [ReasonID]    INT           NULL
);



