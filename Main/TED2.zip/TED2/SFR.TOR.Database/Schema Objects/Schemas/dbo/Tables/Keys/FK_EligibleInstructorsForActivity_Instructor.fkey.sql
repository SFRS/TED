﻿ALTER TABLE [dbo].[EligibleInstructorsForActivity]
    ADD CONSTRAINT [FK_EligibleInstructorsForActivity_Instructor] FOREIGN KEY ([InstructorID]) REFERENCES [dbo].[Instructor] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

