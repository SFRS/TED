﻿ALTER TABLE [dbo].[VenueTagActivityPart]
    ADD CONSTRAINT [FK_VenueTagActivityPart_ActivityPart] FOREIGN KEY ([ActivityPartID]) REFERENCES [dbo].[ActivityPart] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

