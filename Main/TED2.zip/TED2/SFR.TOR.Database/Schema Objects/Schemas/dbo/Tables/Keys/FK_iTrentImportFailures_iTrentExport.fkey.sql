﻿ALTER TABLE [dbo].[iTrentImportFailures]
    ADD CONSTRAINT [FK_iTrentImportFailures_iTrentExport] FOREIGN KEY ([iTrentExportID]) REFERENCES [dbo].[iTrentExport] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

