﻿ALTER TABLE [dbo].[EquipmentEventPart]
    ADD CONSTRAINT [FK_EquipmentEventPart_EquipmentTag] FOREIGN KEY ([EquipmentTagID]) REFERENCES [dbo].[EquipmentTag] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

