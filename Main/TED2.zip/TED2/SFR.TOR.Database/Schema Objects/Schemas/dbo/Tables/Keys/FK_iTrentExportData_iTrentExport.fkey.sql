ALTER TABLE [dbo].[iTrentExportData]
    ADD CONSTRAINT [FK_iTrentExportData_iTrentExport] FOREIGN KEY ([iTrentExportID]) REFERENCES [dbo].[iTrentExport] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

