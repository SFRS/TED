﻿ALTER TABLE [dbo].[VenueTagVenue]
    ADD CONSTRAINT [FK_VenueTagVenue_VenueTag] FOREIGN KEY ([VenueTagID]) REFERENCES [dbo].[VenueTag] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

