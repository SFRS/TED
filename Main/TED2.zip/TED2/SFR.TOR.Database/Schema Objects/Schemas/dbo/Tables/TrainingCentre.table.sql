﻿CREATE TABLE [dbo].[TrainingCentre] (
    [ID]   INT           IDENTITY (1, 1) NOT NULL,
    [Name] VARCHAR (MAX) NOT NULL
);

