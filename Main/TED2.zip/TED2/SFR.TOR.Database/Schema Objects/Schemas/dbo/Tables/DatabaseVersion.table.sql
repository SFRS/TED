﻿CREATE TABLE [dbo].[DatabaseVersion] (
    [Version] VARCHAR (10) NOT NULL
);
