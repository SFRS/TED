﻿CREATE TABLE [dbo].[EventPartType] (
    [ID]    INT          NOT NULL,
    [Title] VARCHAR(50) NOT NULL,
	[Code] VARCHAR(5) NULL
);

