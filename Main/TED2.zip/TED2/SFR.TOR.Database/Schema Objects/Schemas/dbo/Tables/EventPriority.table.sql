﻿CREATE TABLE [dbo].[EventPriority] (
    [ID]    INT           NOT NULL,
    [Title] NVARCHAR (50) NOT NULL
);

