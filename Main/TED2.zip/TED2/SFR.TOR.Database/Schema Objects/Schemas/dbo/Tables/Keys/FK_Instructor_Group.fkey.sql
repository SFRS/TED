﻿ALTER TABLE [dbo].[Instructor]
    ADD CONSTRAINT [FK_Instructor_Group] FOREIGN KEY ([GroupID]) REFERENCES [dbo].[Group] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

