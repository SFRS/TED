﻿ALTER TABLE [dbo].[EventPart]
    ADD CONSTRAINT [FK_EventPart_ResourceStatus] FOREIGN KEY ([Status]) REFERENCES [dbo].[ResourceStatus] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

