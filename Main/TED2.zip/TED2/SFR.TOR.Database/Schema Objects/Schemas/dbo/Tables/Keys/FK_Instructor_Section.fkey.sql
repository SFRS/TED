﻿ALTER TABLE [dbo].[Instructor]
    ADD CONSTRAINT [FK_Instructor_Section] FOREIGN KEY ([SectionID]) REFERENCES [dbo].[Section] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;



