﻿CREATE TABLE [dbo].[iTrentImportFailures](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[iTrentExportID] [int] NOT NULL,
	[EventID] [int] NOT NULL,
	[ResourceFailureOnly] [bit] NOT NULL,
	[Comments] [varchar](max) NULL
);
