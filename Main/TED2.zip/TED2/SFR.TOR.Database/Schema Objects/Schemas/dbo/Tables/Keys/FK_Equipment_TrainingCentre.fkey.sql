﻿ALTER TABLE [dbo].[Equipment]
    ADD CONSTRAINT [FK_Equipment_TrainingCentre] FOREIGN KEY ([TrainingCentreID]) REFERENCES [dbo].[TrainingCentre] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

