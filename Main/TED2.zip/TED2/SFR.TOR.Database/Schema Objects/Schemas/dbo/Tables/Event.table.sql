﻿CREATE TABLE [dbo].[Event] (
    [ID]               INT            IDENTITY (1, 1) NOT NULL,
    [Description]      NVARCHAR (500) NULL,
    [Status]           INT            NOT NULL,
    [EventNumber]      INT            NOT NULL,
    [TotalDays]        FLOAT          NOT NULL,
    [Resourced]        INT            NOT NULL,
    [Notes]            NVARCHAR (500) NULL,
    [ActivityID]       INT            NULL,
    [PriorityID]       INT            NOT NULL,
    [FinanciaYear]     INT            NULL,
    [DateCreated]      DATETIME       NOT NULL,
    [DateChoice]       INT            NOT NULL,
    [DateRangeStart]   DATE           NULL,
    [DateRangeEnd]     DATE           NULL,
    [SpecificDate]     DATE           NULL,
    [CreatedBy]        NVARCHAR (100) NULL,
    [LastEditedBy]     NVARCHAR (100) NULL,
    [LastEditedOn]     DATETIME       NULL,
    [iTrentDataStale]  BIT            NULL,
	[BlockAfterUpload] BIT			  NULL,
	[EventCode]  AS ([dbo].[GetEventCode]([ID]))
);























