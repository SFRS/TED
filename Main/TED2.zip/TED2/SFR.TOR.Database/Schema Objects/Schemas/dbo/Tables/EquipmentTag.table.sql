﻿CREATE TABLE [dbo].[EquipmentTag] (
    [ID]   INT            IDENTITY (1, 1) NOT NULL,
    [Name] NVARCHAR (200) NOT NULL
);

