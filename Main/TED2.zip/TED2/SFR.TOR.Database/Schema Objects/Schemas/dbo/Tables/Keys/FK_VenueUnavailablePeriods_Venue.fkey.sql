﻿ALTER TABLE [dbo].[VenueUnavailablePeriods]
    ADD CONSTRAINT [FK_VenueUnavailablePeriods_Venue] FOREIGN KEY ([VenueID]) REFERENCES [dbo].[Venue] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

