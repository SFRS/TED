﻿ALTER TABLE [dbo].[VenueEventPart]
    ADD CONSTRAINT [FK_VenueDayPart_DayPart] FOREIGN KEY ([DayPartID]) REFERENCES [dbo].[EventPart] ([ID]) ON DELETE CASCADE ON UPDATE NO ACTION;



