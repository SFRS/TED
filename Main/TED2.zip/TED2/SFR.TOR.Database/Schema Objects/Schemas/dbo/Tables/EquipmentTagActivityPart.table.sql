﻿CREATE TABLE [dbo].[EquipmentTagActivityPart] (
    [ID]             INT IDENTITY (1, 1) NOT NULL,
    [EquipmentTagID] INT NOT NULL,
    [ActivityPartID] INT NOT NULL,
    [MinRequired]    INT NOT NULL
);

