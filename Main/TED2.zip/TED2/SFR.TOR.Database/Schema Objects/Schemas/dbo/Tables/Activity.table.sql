﻿CREATE TABLE [dbo].[Activity] (
    [ID]               INT            IDENTITY (1, 1) NOT NULL,
    [Title]            NVARCHAR (100) NOT NULL,
    [Description]      NTEXT          NULL,
    [Code]             VARCHAR (30)   NOT NULL,
    [SectionID]        INT            NOT NULL,
    [TotalDays]        FLOAT          NOT NULL,
    [ActivityStatusID] INT            NOT NULL
);







