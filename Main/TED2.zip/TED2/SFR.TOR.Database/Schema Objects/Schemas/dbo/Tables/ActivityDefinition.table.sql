﻿CREATE TABLE [dbo].[ActivityDefinition] (
    [ID]            INT      IDENTITY (1, 1) NOT NULL,
    [ActivityID]    INT      NOT NULL,
    [FinancialYear] CHAR (4) NOT NULL
);

