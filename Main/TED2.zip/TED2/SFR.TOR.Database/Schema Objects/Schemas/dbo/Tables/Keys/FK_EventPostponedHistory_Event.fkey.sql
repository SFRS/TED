﻿ALTER TABLE [dbo].[EventPostponedHistory]
    ADD CONSTRAINT [FK_EventPostponedHistory_Event] FOREIGN KEY ([EventID]) REFERENCES [dbo].[Event] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

