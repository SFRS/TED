﻿CREATE TABLE [dbo].[ActivityPartType] (
    [ID]    INT          NOT NULL,
    [Title] VARCHAR (50) NOT NULL
);

