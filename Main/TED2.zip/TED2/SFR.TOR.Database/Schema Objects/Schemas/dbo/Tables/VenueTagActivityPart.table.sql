﻿CREATE TABLE [dbo].[VenueTagActivityPart] (
    [ID]             INT IDENTITY (1, 1) NOT NULL,
    [VenueTagID]     INT NOT NULL,
    [ActivityPartID] INT NOT NULL,
    [MinRequired]    INT NOT NULL
);

