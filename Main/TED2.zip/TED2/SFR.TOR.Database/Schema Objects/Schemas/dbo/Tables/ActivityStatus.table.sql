﻿CREATE TABLE [dbo].[ActivityStatus] (
    [ID]    INT           NOT NULL,
    [Title] NVARCHAR (50) NOT NULL
);

