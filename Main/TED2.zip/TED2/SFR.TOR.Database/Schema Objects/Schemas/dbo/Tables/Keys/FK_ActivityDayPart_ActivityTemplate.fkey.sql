﻿ALTER TABLE [dbo].[ActivityPart]
    ADD CONSTRAINT [FK_ActivityDayPart_ActivityTemplate] FOREIGN KEY ([ActivityID]) REFERENCES [dbo].[Activity] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

