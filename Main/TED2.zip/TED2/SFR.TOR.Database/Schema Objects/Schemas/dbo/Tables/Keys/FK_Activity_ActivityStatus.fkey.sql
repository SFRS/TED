﻿ALTER TABLE [dbo].[Activity]
    ADD CONSTRAINT [FK_Activity_ActivityStatus] FOREIGN KEY ([ActivityStatusID]) REFERENCES [dbo].[ActivityStatus] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

