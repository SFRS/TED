﻿CREATE TABLE [dbo].[AuditType] (
    [ID]          INT           NOT NULL,
    [Description] VARCHAR (MAX) NULL
);

