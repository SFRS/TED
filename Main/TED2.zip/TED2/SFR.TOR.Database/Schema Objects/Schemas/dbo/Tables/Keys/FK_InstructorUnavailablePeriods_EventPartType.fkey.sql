﻿ALTER TABLE [dbo].[InstructorUnavailablePeriods]
    ADD CONSTRAINT [FK_InstructorUnavailablePeriods_EventPartType] FOREIGN KEY ([DayTypeID]) REFERENCES [dbo].[EventPartType] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

