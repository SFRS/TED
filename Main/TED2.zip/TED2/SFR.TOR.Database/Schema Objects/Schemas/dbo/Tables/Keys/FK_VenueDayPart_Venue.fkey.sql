﻿ALTER TABLE [dbo].[VenueEventPart]
    ADD CONSTRAINT [FK_VenueDayPart_Venue] FOREIGN KEY ([VenueID]) REFERENCES [dbo].[Venue] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

