﻿CREATE TABLE dbo.iTrentExportStatus
(
	[ID] INT NOT NULL IDENTITY (1, 1),
	[Title] NVARCHAR(50) NOT NULL
);
