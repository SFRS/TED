ALTER TABLE [dbo].[iTrentExportErrors]
    ADD CONSTRAINT [FK_iTrentExportErrors_Event] FOREIGN KEY ([EventID]) REFERENCES [dbo].[Event] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

