﻿CREATE TABLE [dbo].[EventStatusHistory] (
    [ID]          INT           IDENTITY (1, 1) NOT NULL,
    [OccurredOn]  DATETIME      NOT NULL,
    [EventID]     INT           NOT NULL,
    [UserName]    VARCHAR (MAX) NOT NULL,
    [OldStatusID] INT           NOT NULL,
    [NewStatusID] INT           NOT NULL
);

