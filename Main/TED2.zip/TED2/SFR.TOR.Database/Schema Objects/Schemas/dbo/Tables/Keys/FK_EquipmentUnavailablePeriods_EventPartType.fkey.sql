﻿ALTER TABLE [dbo].[EquipmentUnavailablePeriods]
    ADD CONSTRAINT [FK_EquipmentUnavailablePeriods_EventPartType] FOREIGN KEY ([DayTypeID]) REFERENCES [dbo].[EventPartType] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

