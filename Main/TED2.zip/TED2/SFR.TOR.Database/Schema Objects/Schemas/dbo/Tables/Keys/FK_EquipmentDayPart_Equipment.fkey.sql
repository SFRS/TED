﻿ALTER TABLE [dbo].[EquipmentEventPart]
    ADD CONSTRAINT [FK_EquipmentDayPart_Equipment] FOREIGN KEY ([EquipmentID]) REFERENCES [dbo].[Equipment] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

