﻿ALTER TABLE [dbo].[Instructor]
    ADD CONSTRAINT [FK_Instructor_TrainingCentre] FOREIGN KEY ([TrainingCentreID]) REFERENCES [dbo].[TrainingCentre] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

