﻿ALTER TABLE [dbo].[iTrentExport]
    ADD CONSTRAINT [FK_iTrentExport_iTrentExportStatus] FOREIGN KEY ([iTrentExportStatusID]) REFERENCES [dbo].[iTrentExportStatus] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

