﻿ALTER TABLE [dbo].[InstructorSectionHistory]
	ADD CONSTRAINT [FK_InstructorSectionHistory_Instructor] FOREIGN KEY ([InstructorID]) REFERENCES [dbo].[Instructor] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

