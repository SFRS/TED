CREATE TABLE dbo.iTrentExportType
(
	[ID] INT NOT NULL IDENTITY (1, 1),
	[Title] NVARCHAR(50) NOT NULL
);
