﻿ALTER TABLE [dbo].[InstructorUnavailablePeriods]
    ADD CONSTRAINT [FK_InstructorUnavailablePeriods_Instructor] FOREIGN KEY ([InstructorID]) REFERENCES [dbo].[Instructor] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

