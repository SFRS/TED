﻿ALTER TABLE [dbo].[EventCancelledHistory]
    ADD CONSTRAINT [FK_EventCancelledHistory_CancelEventReasons] FOREIGN KEY ([ReasonID]) REFERENCES [dbo].[CancelEventReasons] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

