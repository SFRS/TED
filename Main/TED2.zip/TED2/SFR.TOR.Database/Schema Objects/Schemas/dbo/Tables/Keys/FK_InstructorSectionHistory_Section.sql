﻿ALTER TABLE [dbo].[InstructorSectionHistory]
    ADD CONSTRAINT [FK_InstructorSectionHistory_Section] FOREIGN KEY ([SectionID]) REFERENCES [dbo].[Section] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

