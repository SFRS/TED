﻿CREATE TABLE [dbo].[PostponeEventReasons] (
    [ID]     INT           NOT NULL,
    [Reason] VARCHAR (500) NOT NULL
);

