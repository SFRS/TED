﻿CREATE TABLE [dbo].[EquipmentUnavailableReasons] (
    [ID]     INT           IDENTITY (1, 1) NOT NULL,
    [Reason] VARCHAR (100) NOT NULL
);

