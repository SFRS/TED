﻿CREATE TABLE [dbo].[ResourceStatus] (
    [ID]    INT           NOT NULL,
    [Title] NVARCHAR (50) NOT NULL,
	[Code] NVARCHAR (5) NULL
);

