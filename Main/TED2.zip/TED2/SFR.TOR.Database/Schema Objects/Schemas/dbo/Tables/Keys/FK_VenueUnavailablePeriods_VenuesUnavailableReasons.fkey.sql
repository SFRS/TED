﻿ALTER TABLE [dbo].[VenueUnavailablePeriods]
    ADD CONSTRAINT [FK_VenueUnavailablePeriods_VenuesUnavailableReasons] FOREIGN KEY ([VenueUnavailableReasonID]) REFERENCES [dbo].[VenuesUnavailableReasons] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

