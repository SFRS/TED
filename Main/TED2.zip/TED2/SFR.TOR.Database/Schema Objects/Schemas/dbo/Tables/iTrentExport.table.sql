﻿CREATE TABLE [dbo].[iTrentExport] (
	[ID]					INT				NOT NULL IDENTITY (1, 1),
	[Title]					NVARCHAR(250)	NOT NULL,
	[FinancialYear]			INT				NOT NULL,
	[iTrentExportStatusID]  INT				NOT NULL,
	[iTrentExportTypeID]	INT				NOT NULL,
	[ExportDate]			DATETIME		NOT NULL, 
    [EventsExported]		INT				NOT NULL, 
    [EventsUploaded]		INT				NOT NULL, 
    [ExportErrors]			INT				NOT NULL, 
    [UploadErrors]			INT				NOT NULL
);
