CREATE TABLE [dbo].[iTrentExportErrors](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[iTrentExportID] [int] NOT NULL,
	[EventID] [int] NOT NULL,
	[ErrorMessage] [nvarchar](max) NOT NULL
);