﻿ALTER TABLE [dbo].[InstructorUnavailablePeriods]
    ADD CONSTRAINT [FK_InstructorUnavailablePeriods_UnavailableReasons] FOREIGN KEY ([UnavailableReasonID]) REFERENCES [dbo].[UnavailableReasons] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

