﻿ALTER TABLE [dbo].[VenueUnavailablePeriods]
    ADD CONSTRAINT [FK_VenueUnavailablePeriods_EventPartType] FOREIGN KEY ([DayTypeID]) REFERENCES [dbo].[EventPartType] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

