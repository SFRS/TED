﻿ALTER TABLE [dbo].[VenueTagActivityPart]
    ADD CONSTRAINT [FK_VenueTagActivityPart_VenueTag] FOREIGN KEY ([VenueTagID]) REFERENCES [dbo].[VenueTag] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

