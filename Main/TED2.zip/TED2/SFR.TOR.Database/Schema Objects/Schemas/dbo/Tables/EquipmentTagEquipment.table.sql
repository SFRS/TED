﻿CREATE TABLE [dbo].[EquipmentTagEquipment] (
    [ID]             INT IDENTITY (1, 1) NOT NULL,
    [EquipmentID]    INT NOT NULL,
    [EquipmentTagID] INT NOT NULL
);



