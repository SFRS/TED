﻿ALTER TABLE [dbo].[EquipmentTagActivityPart]
    ADD CONSTRAINT [FK_EquipmentTagActivityPart_EquipmentTag] FOREIGN KEY ([EquipmentTagID]) REFERENCES [dbo].[EquipmentTag] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

