﻿CREATE TABLE [dbo].[VenueEventPart] (
    [ID]            INT IDENTITY (1, 1) NOT NULL,
    [VenueID]       INT NOT NULL,
    [DayPartID]     INT NOT NULL,
    [NeedsCatering] BIT NULL,
    [VenueTagID]    INT NULL
);





