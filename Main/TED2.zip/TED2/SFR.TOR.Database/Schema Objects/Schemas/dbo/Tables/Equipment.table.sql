﻿CREATE TABLE [dbo].[Equipment] (
    [ID]               INT            IDENTITY (1, 1) NOT NULL,
    [Name]             NVARCHAR (100) NOT NULL,
    [TrainingCentreID] INT            NOT NULL,
	[EquipmentGroupID] INT			  NULL /* Changed to NOT NULL in Upgrade.sql */ 
);
