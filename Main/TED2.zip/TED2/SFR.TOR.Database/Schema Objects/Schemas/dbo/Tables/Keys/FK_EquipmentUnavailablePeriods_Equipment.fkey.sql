﻿ALTER TABLE [dbo].[EquipmentUnavailablePeriods]
    ADD CONSTRAINT [FK_EquipmentUnavailablePeriods_Equipment] FOREIGN KEY ([EquipmentID]) REFERENCES [dbo].[Equipment] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

