﻿ALTER TABLE [dbo].[ActivityPartInstructorLevel]
    ADD CONSTRAINT [FK_ActivityPartInstructorLevel_ActivityPart] FOREIGN KEY ([ActivityPartID]) REFERENCES [dbo].[ActivityPart] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

