﻿CREATE TABLE [dbo].[VenueUnavailablePeriods] (
    [ID]                       INT				IDENTITY (1, 1) NOT NULL,
    [VenueID]                  INT				NOT NULL,
    [StartDate]                DATE				NOT NULL,
    [StartTime]                TIME (7)			NULL,
    [EndDate]                  DATE				NULL,
    [EndTime]                  TIME (7)			NULL,
    [VenueUnavailableReasonID] INT				NOT NULL,
    [DayTypeID]                INT				NOT NULL,
	[Comments]				   VARCHAR (200)	NULL
);
