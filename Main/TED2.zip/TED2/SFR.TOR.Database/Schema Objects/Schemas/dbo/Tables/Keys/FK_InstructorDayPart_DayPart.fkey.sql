﻿ALTER TABLE [dbo].[InstructorEventPart]
    ADD CONSTRAINT [FK_InstructorDayPart_DayPart] FOREIGN KEY ([DayPartID]) REFERENCES [dbo].[EventPart] ([ID]) ON DELETE CASCADE ON UPDATE NO ACTION;



