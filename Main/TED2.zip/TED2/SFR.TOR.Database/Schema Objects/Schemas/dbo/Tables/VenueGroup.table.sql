﻿CREATE TABLE [dbo].[VenueGroup] (
    [ID]   INT         IDENTITY (1, 1) NOT NULL,
    [Title]	VARCHAR (50) NOT NULL
);