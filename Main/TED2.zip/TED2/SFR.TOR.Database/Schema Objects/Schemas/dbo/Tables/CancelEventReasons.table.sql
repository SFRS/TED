﻿CREATE TABLE [dbo].[CancelEventReasons] (
    [ID]     INT           NOT NULL,
    [Reason] VARCHAR (500) NOT NULL
);

