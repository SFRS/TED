﻿ALTER TABLE [dbo].[EventPostponedHistory]
    ADD CONSTRAINT [FK_EventPostponedHistory_PostponeEventReasons] FOREIGN KEY ([ReasonID]) REFERENCES [dbo].[PostponeEventReasons] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

