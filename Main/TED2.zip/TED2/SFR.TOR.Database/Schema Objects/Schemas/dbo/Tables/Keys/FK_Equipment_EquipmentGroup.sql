﻿ALTER TABLE [dbo].[Equipment]
    ADD CONSTRAINT [FK_Equipment_EquipmentGroup] FOREIGN KEY ([EquipmentGroupID]) REFERENCES [dbo].[EquipmentGroup] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;
