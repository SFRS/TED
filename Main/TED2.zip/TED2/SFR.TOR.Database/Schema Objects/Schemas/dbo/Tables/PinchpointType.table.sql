﻿CREATE TABLE [dbo].[PinchpointType] (
    [ID]       INT          IDENTITY (1, 1) NOT NULL,
    [TypeName] VARCHAR (50) NOT NULL
);

