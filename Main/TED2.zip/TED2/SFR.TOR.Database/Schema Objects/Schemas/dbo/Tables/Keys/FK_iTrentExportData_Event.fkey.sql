ALTER TABLE [dbo].[iTrentExportData]
    ADD CONSTRAINT [FK_iTrentExportData_Event] FOREIGN KEY ([EventID]) REFERENCES [dbo].[Event] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

