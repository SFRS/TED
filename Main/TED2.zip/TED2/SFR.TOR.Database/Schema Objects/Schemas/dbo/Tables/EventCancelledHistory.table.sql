﻿CREATE TABLE [dbo].[EventCancelledHistory] (
    [ID]          INT           IDENTITY (1, 1) NOT NULL,
    [EventID]     INT           NOT NULL,
    [CancelledOn] DATETIME      NOT NULL,
    [Reason]      VARCHAR (500) NULL,
    [ReasonID]    INT           NULL
);

