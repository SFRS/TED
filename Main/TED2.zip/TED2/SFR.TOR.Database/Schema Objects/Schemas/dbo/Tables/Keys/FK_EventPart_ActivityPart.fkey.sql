﻿ALTER TABLE [dbo].[EventPart]
    ADD CONSTRAINT [FK_EventPart_ActivityPart] FOREIGN KEY ([ActivityPartID]) REFERENCES [dbo].[ActivityPart] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

