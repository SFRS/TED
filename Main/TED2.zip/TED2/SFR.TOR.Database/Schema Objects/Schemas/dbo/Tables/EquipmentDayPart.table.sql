﻿/*CREATE TABLE [dbo].[EquipmentDayPart] (
    [ID]          INT IDENTITY (1, 1) NOT NULL,
    [EquipmentID] INT NOT NULL,
    [DayPartID]   INT NOT NULL
);*/

