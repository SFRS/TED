﻿ALTER TABLE [dbo].[VenueTagVenue]
    ADD CONSTRAINT [FK_VenueTagVenue_Venue] FOREIGN KEY ([VenueID]) REFERENCES [dbo].[Venue] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

