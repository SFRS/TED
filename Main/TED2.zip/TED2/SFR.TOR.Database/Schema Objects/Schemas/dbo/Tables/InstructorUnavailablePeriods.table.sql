﻿CREATE TABLE [dbo].[InstructorUnavailablePeriods] (
    [ID]                  INT           IDENTITY (1, 1) NOT NULL,
    [InstructorID]        INT           NOT NULL,
    [StartDate]           DATE          NOT NULL,
    [StartTime]           TIME (7)      NOT NULL,
    [EndDate]             DATE          NULL,
    [EndTime]             TIME (7)      NOT NULL,
    [UnavailableReasonID] INT           NOT NULL,
    [DayTypeID]           INT           NOT NULL,
    [Comments]            VARCHAR (200) NULL
);







