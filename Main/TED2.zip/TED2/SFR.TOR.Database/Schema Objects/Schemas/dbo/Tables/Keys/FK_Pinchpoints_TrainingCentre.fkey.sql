﻿ALTER TABLE [dbo].[Pinchpoints]
    ADD CONSTRAINT [FK_Pinchpoints_TrainingCentre] FOREIGN KEY ([TrainingCentreID]) REFERENCES [dbo].[TrainingCentre] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

