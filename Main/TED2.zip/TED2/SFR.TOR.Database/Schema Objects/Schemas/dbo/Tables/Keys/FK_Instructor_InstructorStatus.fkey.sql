﻿/*ALTER TABLE [dbo].[Instructor]
    ADD CONSTRAINT [FK_Instructor_InstructorStatus] FOREIGN KEY ([StatusID]) REFERENCES [dbo].[InstructorStatus] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;*/

