﻿ALTER TABLE [dbo].[VenueEventPart]
    ADD CONSTRAINT [FK_VenueEventPart_VenueTag] FOREIGN KEY ([VenueTagID]) REFERENCES [dbo].[VenueTag] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

