﻿ALTER TABLE [dbo].[PinchpointReason]
    ADD CONSTRAINT [FK_PinchpointReason_PinchpointType] FOREIGN KEY ([TypeID]) REFERENCES [dbo].[PinchpointType] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

