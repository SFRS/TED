﻿CREATE TABLE [dbo].[InstructorSectionHistory] (
	[ID] 			INT 	IDENTITY(1,1) NOT NULL,
	[InstructorID] 	INT 	NOT NULL,
	[SectionID] 	INT 	NOT NULL,
	[StartDate] 	DATE 	NOT NULL,
	[EndDate] 		DATE 	NULL
);
