﻿CREATE TABLE [dbo].[Instructor] (
    [ID]               INT           IDENTITY (1, 1) NOT NULL,
    [FirstName]        NVARCHAR (50) NOT NULL,
    [LastName]         NVARCHAR (50) NOT NULL,
    [SectionID]        INT           NULL,
    [TrainingCentreID] INT           NOT NULL,
    [GroupID]          INT           NULL
);











