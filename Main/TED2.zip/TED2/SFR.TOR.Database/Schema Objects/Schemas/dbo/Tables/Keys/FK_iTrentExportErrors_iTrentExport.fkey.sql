ALTER TABLE [dbo].[iTrentExportErrors]
    ADD CONSTRAINT [FK_iTrentExportErrors_iTrentExport] FOREIGN KEY ([iTrentExportID]) REFERENCES [dbo].[iTrentExport] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

