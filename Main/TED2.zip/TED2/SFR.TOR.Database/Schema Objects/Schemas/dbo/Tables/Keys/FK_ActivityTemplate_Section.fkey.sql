﻿ALTER TABLE [dbo].[Activity]
    ADD CONSTRAINT [FK_ActivityTemplate_Section] FOREIGN KEY ([SectionID]) REFERENCES [dbo].[Section] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;


GO
ALTER TABLE [dbo].[Activity] NOCHECK CONSTRAINT [FK_ActivityTemplate_Section];

