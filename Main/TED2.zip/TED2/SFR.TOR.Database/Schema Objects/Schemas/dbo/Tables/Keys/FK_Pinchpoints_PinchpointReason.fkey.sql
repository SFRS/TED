﻿ALTER TABLE [dbo].[Pinchpoints]
    ADD CONSTRAINT [FK_Pinchpoints_PinchpointReason] FOREIGN KEY ([ReasonID]) REFERENCES [dbo].[PinchpointReason] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

