﻿ALTER TABLE [dbo].[EventStatusHistory]
    ADD CONSTRAINT [FK_EventStatusHistory_EventStatus1] FOREIGN KEY ([NewStatusID]) REFERENCES [dbo].[EventStatus] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

