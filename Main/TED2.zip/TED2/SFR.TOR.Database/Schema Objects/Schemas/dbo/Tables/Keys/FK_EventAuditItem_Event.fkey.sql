﻿ALTER TABLE [dbo].[EventStatusHistory]
    ADD CONSTRAINT [FK_EventAuditItem_Event] FOREIGN KEY ([EventID]) REFERENCES [dbo].[Event] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

