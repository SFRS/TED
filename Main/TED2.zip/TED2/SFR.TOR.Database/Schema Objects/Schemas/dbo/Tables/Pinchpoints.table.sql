﻿CREATE TABLE [dbo].[Pinchpoints] (
    [ID]               INT           IDENTITY (1, 1) NOT NULL,
    [StartDate]        DATE          NOT NULL,
    [EndDate]          DATE          NULL,
    [TrainingCentreID] INT           NOT NULL,
    [ReasonID]         INT           NULL,
    [Reason]           VARCHAR (200) NULL
);

