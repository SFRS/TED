﻿/*CREATE TABLE [dbo].[InstructorDayPart] (
    [ID]           INT IDENTITY (1, 1) NOT NULL,
    [InstructorID] INT NOT NULL,
    [DayPartID]    INT NOT NULL,
    [IsLead]       BIT NULL,
    [IsAssessor]   BIT NULL,
    [IsInstructor] BIT NULL,
    [IsShadow]     BIT NULL
);*/



