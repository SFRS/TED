﻿ALTER TABLE [dbo].[ActivityPart]
    ADD CONSTRAINT [FK_ActivityDayPart_DayType] FOREIGN KEY ([DayTypeID]) REFERENCES [dbo].[ActivityPartType] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

