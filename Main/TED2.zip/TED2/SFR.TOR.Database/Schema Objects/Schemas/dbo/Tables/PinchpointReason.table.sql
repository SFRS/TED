﻿CREATE TABLE [dbo].[PinchpointReason] (
    [ID]     INT           IDENTITY (1, 1) NOT NULL,
    [Reason] VARCHAR (200) NULL,
    [TypeID] INT           NOT NULL
);

