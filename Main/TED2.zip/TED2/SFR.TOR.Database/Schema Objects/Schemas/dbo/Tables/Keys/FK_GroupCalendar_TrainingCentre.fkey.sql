﻿ALTER TABLE [dbo].[GroupCalendar]
    ADD CONSTRAINT [FK_GroupCalendar_TrainingCentre] FOREIGN KEY ([TrainingCentreID]) REFERENCES [dbo].[TrainingCentre] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

