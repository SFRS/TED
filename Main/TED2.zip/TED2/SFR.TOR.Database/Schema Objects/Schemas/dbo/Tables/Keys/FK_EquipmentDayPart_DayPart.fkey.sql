﻿ALTER TABLE [dbo].[EquipmentEventPart]
    ADD CONSTRAINT [FK_EquipmentDayPart_DayPart] FOREIGN KEY ([DayPartID]) REFERENCES [dbo].[EventPart] ([ID]) ON DELETE CASCADE ON UPDATE NO ACTION;



