﻿CREATE TABLE [dbo].[EventPart] (
    [ID]             INT            IDENTITY (1, 1) NOT NULL,
    [EventID]        INT            NOT NULL,
    [Status]         INT            NOT NULL,
    [DayType]        INT            NULL,
    [Date]           DATETIME       NULL,
    [Notes]          NVARCHAR (500) NULL,
    [Name]           NVARCHAR (50)  NULL,
    [ActivityPartID] INT            NOT NULL,
    [StartTime]      TIME (7)       NULL,
    [EndTime]        TIME (7)       NULL
);











