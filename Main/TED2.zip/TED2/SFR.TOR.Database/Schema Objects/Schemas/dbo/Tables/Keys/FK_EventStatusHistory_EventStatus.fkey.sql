﻿ALTER TABLE [dbo].[EventStatusHistory]
    ADD CONSTRAINT [FK_EventStatusHistory_EventStatus] FOREIGN KEY ([OldStatusID]) REFERENCES [dbo].[EventStatus] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

