﻿/*CREATE TABLE [dbo].[ActivityTemplate] (
    [ID]          INT            IDENTITY (1, 1) NOT NULL,
    [Title]       NVARCHAR (100) NOT NULL,
    [Description] NTEXT          NULL,
    [Code]        VARCHAR (50)   NOT NULL,
    [SectionID]   INT            NOT NULL,
    [TotalDays]   FLOAT          NOT NULL
);*/



