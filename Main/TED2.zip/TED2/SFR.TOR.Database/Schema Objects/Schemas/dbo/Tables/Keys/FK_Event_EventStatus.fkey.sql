﻿ALTER TABLE [dbo].[Event]
    ADD CONSTRAINT [FK_Event_EventStatus] FOREIGN KEY ([Status]) REFERENCES [dbo].[EventStatus] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

