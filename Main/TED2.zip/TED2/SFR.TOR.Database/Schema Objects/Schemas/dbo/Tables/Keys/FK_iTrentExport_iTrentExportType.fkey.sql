ALTER TABLE [dbo].[iTrentExport]
    ADD CONSTRAINT [FK_iTrentExport_iTrentExportType] FOREIGN KEY ([iTrentExportTypeID]) REFERENCES [dbo].[iTrentExportType] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

