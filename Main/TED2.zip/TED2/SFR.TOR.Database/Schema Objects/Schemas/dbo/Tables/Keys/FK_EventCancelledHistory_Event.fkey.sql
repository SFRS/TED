﻿ALTER TABLE [dbo].[EventCancelledHistory]
    ADD CONSTRAINT [FK_EventCancelledHistory_Event] FOREIGN KEY ([EventID]) REFERENCES [dbo].[Event] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

