﻿CREATE TABLE [dbo].[DayPartStatus] (
    [ID]    INT           NOT NULL,
    [Title] NVARCHAR (50) NOT NULL
);

