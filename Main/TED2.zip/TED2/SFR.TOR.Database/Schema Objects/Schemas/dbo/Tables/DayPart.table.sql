﻿/*CREATE TABLE [dbo].[DayPart] (
    [ID]      INT      IDENTITY (1, 1) NOT NULL,
    [EventID] INT      NOT NULL,
    [Status]  INT      NOT NULL,
    [DayType] INT      NOT NULL,
    [Date]    DATETIME NOT NULL
);*/



