﻿CREATE TABLE [dbo].[EventStatus] (
    [ID]    INT           NOT NULL,
    [Title] NVARCHAR (50) NULL
);

