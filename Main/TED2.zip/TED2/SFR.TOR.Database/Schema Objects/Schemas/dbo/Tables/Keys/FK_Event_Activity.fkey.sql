﻿ALTER TABLE [dbo].[Event]
    ADD CONSTRAINT [FK_Event_Activity] FOREIGN KEY ([ActivityID]) REFERENCES [dbo].[Activity] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

