﻿ALTER TABLE [dbo].[EquipmentUnavailablePeriods]
    ADD CONSTRAINT [FK_EquipmentUnavailablePeriods_EquipmentUnavailableReasons] FOREIGN KEY ([EquipmentUnavailableReasonID]) REFERENCES [dbo].[EquipmentUnavailableReasons] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

