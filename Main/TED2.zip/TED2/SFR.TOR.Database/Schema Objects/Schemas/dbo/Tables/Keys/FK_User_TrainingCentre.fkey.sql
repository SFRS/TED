﻿ALTER TABLE [dbo].[User]
    ADD CONSTRAINT [FK_User_TrainingCentre] FOREIGN KEY ([DefaultTrainingCentreID]) REFERENCES [dbo].[TrainingCentre] ([ID]) ON DELETE NO ACTION ON UPDATE NO ACTION;

