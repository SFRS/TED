﻿


CREATE VIEW [dbo].[vwEquipmentCalendarBase]
AS

SELECT 
	eq.ID,
	eq.Name, 
	CONVERT(VARCHAR, ep.[Date], 03)  + ';' +CONVERT(CHAR(1), ep.DayType) as [Date],
	ep.[Date] as baseDate,
	a.Title as EventTitle,
	a.SectionID,	
	a.Code + ' ' + CONVERT(VARCHAR, EventNumber) + '/' + SUBSTRING(CONVERT(VARCHAR, e.FinanciaYear), 3, 2)  as [Code],
	e.[Status],
	e.ID as EventID,
	eq.TrainingCentreID,
	ep.[Status] as ResourceStatus,
	eg.Title as GroupTitle,
	eg.ID as GroupID
FROM 
	dbo.Equipment eq
LEFT OUTER JOIN
	dbo.EquipmentEventPart eep ON eep.EquipmentID = eq.ID 
LEFT OUTER JOIN
	dbo.EventPart ep ON ep.ID = eep.DayPartID
LEFT OUTER JOIN
	dbo.[Event] e ON e.ID = ep.EventID
LEFT OUTER JOIN
	dbo.Activity a ON e.ActivityID = a.ID
LEFT OUTER JOIN 
	dbo.EquipmentGroup eg ON eq.EquipmentGroupID = eg.ID