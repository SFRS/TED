﻿CREATE VIEW [dbo].[vwInstructorCalendarBase]
AS
SELECT
	i.ID,  
	CONVERT(VARCHAR, ep.[Date], 03)  + ';' +CONVERT(CHAR(1), ep.DayType) as [Date],
	ep.[Date] as baseDate,
	a.Title,
	a.Code + ' ' + CONVERT(VARCHAR, EventNumber) + '/' + SUBSTRING(CONVERT(VARCHAR, e.FinanciaYear), 3, 2)  as [Code],
	e.[Status],
	e.ID as EventID,
	ep.[Status] as ResourceStatus
FROM 
	dbo.Instructor i
LEFT OUTER JOIN
	dbo.InstructorEventPart iep ON iep.InstructorID = i.ID 
LEFT OUTER JOIN
	dbo.EventPart ep ON ep.ID = iep.DayPartID
LEFT OUTER JOIN
	dbo.Event e ON e.ID = ep.EventID
LEFT OUTER JOIN
	dbo.Activity a ON e.ActivityID = a.ID
WHERE e.[Status] IN (1,2,3,4,5) OR  e.[Status] IS NULL