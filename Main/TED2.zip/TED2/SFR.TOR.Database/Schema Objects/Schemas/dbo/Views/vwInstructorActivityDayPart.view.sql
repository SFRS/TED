﻿/*


CREATE VIEW [dbo].[vwInstructorActivityDayPart]
AS
SELECT   
	eia.ID as EligibleInstructorID,  
	i.ID,
	i.FirstName + ' ' + i.LastName AS Name,
	at.ID as ActivityID,
	s.Title as SectionTitle,
	COALESCE(eia.IsLead, 0) AS IsLead, 
	COALESCE(eia.IsAssessor, 0) AS IsAssessor,
    COALESCE(eia.IsInstructor, 0) AS IsInstructor,
    COALESCE(eia.IsShadow, 0) AS IsShadow
FROM 
EligibleInstructorsForActivity eia
LEFT OUTER JOIN  Activity at
	ON at.ID = eia.ActivityTemplateID
RIGHT OUTER JOIN Instructor i 	
	ON eia.InstructorID = i.ID		
JOIN Section s
	ON i.SectionID = s.ID*/