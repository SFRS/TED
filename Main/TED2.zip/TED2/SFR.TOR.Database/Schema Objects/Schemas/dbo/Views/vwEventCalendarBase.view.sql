﻿

CREATE VIEW [dbo].[vwEventCalendarBase]
AS

SELECT 
	e.ID, 
	CONVERT(VARCHAR, ep.[Date], 03)  + ';' +CONVERT(CHAR(1), ep.DayType) as [Date],
	ep.[Date] as baseDate,
	a.Title,
	a.sectionID,
	a.Code + ' ' + CONVERT(VARCHAR, EventNumber) + '/' + SUBSTRING(CONVERT(VARCHAR, e.FinanciaYear), 3, 2)  as [Code],	
	e.[Status],
	e.ID as EventID,	
	ep.[Status] as ResourceStatus
FROM 
	dbo.EventPart ep
LEFT OUTER JOIN
	dbo.[Event] e ON e.ID = ep.EventID
LEFT OUTER JOIN
	dbo.Activity a ON e.ActivityID = a.ID