﻿ALTER DATABASE [$(DatabaseName)]
    ADD FILE (NAME = [TOR], FILENAME = '$(DataLocation)\$(DatabaseName).mdf', SIZE = 2304 KB, FILEGROWTH = 1024 KB) TO FILEGROUP [PRIMARY];

